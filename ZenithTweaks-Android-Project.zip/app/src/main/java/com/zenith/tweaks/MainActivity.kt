package com.zenith.tweaks

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private lateinit var setup: LinearLayout
    private lateinit var setupMsg: TextView
    private lateinit var tabs: LinearLayout
    private lateinit var dash: Dashboard
    private lateinit var games: GamesPage
    private lateinit var tweak: TweakPage
    private lateinit var pages: List<Page>
    private val tabViews = ArrayList<TextView>()
    private var cur = -1
    private var caps: Caps.Info? = null

    private val onResult = Shizuku.OnRequestPermissionResultListener { _, _ -> mainHandler.post { refresh() } }
    private val onBinder = Shizuku.OnBinderReceivedListener { mainHandler.post { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { mainHandler.post { refresh() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.BG; window.navigationBarColor = C.BG
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        content = FrameLayout(this)
        root.addView(content, lp(-1, 0, weight = 1f))

        dash = Dashboard(this) { caps }; games = GamesPage(this) { caps }; tweak = TweakPage(this) { caps }
        pages = listOf(dash, games, tweak)
        for (p in pages) { p.root.visibility = View.GONE; content.addView(p.root, fl()) }

        setup = buildSetup(); content.addView(setup, fl())

        tabs = LinearLayout(this); tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setBackgroundColor(C.BG2)
        val names = listOf("Dashboard", "Game", "Tweak")
        for (i in names.indices) {
            val t = text(names[i], 13f, C.SUB, true); t.gravity = Gravity.CENTER
            t.setPadding(0, dpi(14), 0, dpi(14)); t.setOnClickListener { select(i) }
            tabViews.add(t); tabs.addView(t, lp(0, -2, weight = 1f))
        }
        root.addView(tabs, lp())
        setContentView(root)

        root.setOnApplyWindowInsetsListener { v, ins ->
            val top: Int; val bot: Int
            if (Build.VERSION.SDK_INT >= 30) { val s = ins.getInsets(WindowInsets.Type.systemBars()); top = s.top; bot = s.bottom }
            else { @Suppress("DEPRECATION") top = ins.systemWindowInsetTop; @Suppress("DEPRECATION") bot = ins.systemWindowInsetBottom }
            v.setPadding(0, top, 0, bot); ins
        }
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)

        try {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onResult)
        } catch (e: Throwable) {}
        select(0)
    }

    private fun buildSetup(): LinearLayout {
        val l = LinearLayout(this); l.orientation = LinearLayout.VERTICAL; l.gravity = Gravity.CENTER
        l.setBackgroundColor(C.BG); l.setPadding(dpi(24), dpi(24), dpi(24), dpi(24))
        l.isClickable = true
        l.addView(text("⚡", 54f, C.CYAN), lp())
        (l.getChildAt(0) as TextView).gravity = Gravity.CENTER
        val t = text("Zenith Tweaks", 26f, C.TEXT, true); t.gravity = Gravity.CENTER; l.addView(t, lp(bottom = dpi(8)))
        setupMsg = text("", 14f, C.SUB); setupMsg.gravity = Gravity.CENTER; l.addView(setupMsg, lp(bottom = dpi(20)))
        l.addView(button("Buka Shizuku") { openShizuku() }, lp(bottom = dpi(10)))
        l.addView(button("Beri izin ke Zenith", false) { askPermission() }, lp(bottom = dpi(10)))
        l.addView(button("Cek ulang", false) { refresh() }, lp())
        return l
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) startActivity(i)
        else try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))) } catch (e: Exception) {}
    }

    private fun askPermission() {
        try {
            if (!Sh.alive()) { refresh(); return }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                setupMsg.text = "Izin sebelumnya ditolak. Buka aplikasi Shizuku → Aplikasi terotorisasi → aktifkan Zenith Tweaks."
            } else Shizuku.requestPermission(1)
        } catch (e: Throwable) { refresh() }
    }

    private fun refresh() {
        val ready = Sh.granted()
        if (ready) {
            setup.visibility = View.GONE
            if (caps == null) Sh.async(Caps.SCRIPT, 15) { r -> caps = Caps.parse(r.out); dash.bindCaps(caps!!) }
        } else {
            setup.visibility = View.VISIBLE
            setupMsg.text = when {
                !Sh.alive() -> "Shizuku belum berjalan.\n\nPasang aplikasi Shizuku, lalu jalankan lewat Wireless debugging (atau root), kemudian kembali ke sini."
                else -> "Shizuku aktif. Zenith butuh izin untuk menjalankan perintah sistem."
            }
        }
    }

    private fun select(i: Int) {
        if (cur == i) return
        if (cur >= 0) { pages[cur].onHide(); pages[cur].root.visibility = View.GONE }
        cur = i
        pages[i].root.visibility = View.VISIBLE
        for (k in tabViews.indices) {
            tabViews[k].setTextColor(if (k == i) C.CYAN else C.SUB)
        }
        if (Sh.granted()) pages[i].onShow()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        if (cur >= 0 && Sh.granted()) pages[cur].onShow()
    }

    override fun onPause() { super.onPause(); if (cur >= 0) pages[cur].onHide() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (cur == 1 && games.handleBack()) return
        @Suppress("DEPRECATION") super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onResult)
        } catch (e: Throwable) {}
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = this.run { (this as android.content.Context).text(s, size, color, bold) }
    private fun button(l: String, primary: Boolean = true, click: () -> Unit) = (this as android.content.Context).button(l, primary, click)
    private fun dpi(v: Int) = (this as android.content.Context).dpi(v)
}

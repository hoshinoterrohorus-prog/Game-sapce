package com.zenith.tweaks

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Eksekusi perintah shell lewat Shizuku (uid shell/root). */
object Sh {
    class R(val out: String, val err: String, val code: Int) {
        val ok get() = code == 0
        val text get() = (out + (if (err.isNotBlank()) "\n" + err else "")).trim()
    }

    private val pool = Executors.newFixedThreadPool(3)
    private val method by lazy {
        Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
            .also { it.isAccessible = true }
    }

    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun granted(): Boolean = try { alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    fun denied(): Boolean = try { alive() && Shizuku.shouldShowRequestPermissionRationale() } catch (e: Throwable) { false }
    fun uid(): Int = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
    fun version(): Int = try { Shizuku.getVersion() } catch (e: Throwable) { -1 }

    fun run(cmd: String, timeoutSec: Long = 12): R {
        if (!granted()) return R("", "Shizuku belum siap / belum diberi izin", -1)
        return try {
            val p = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            try { p.outputStream.close() } catch (e: Throwable) {}
            val o = StringBuilder(); val e = StringBuilder()
            val t1 = Thread { try { o.append(p.inputStream.bufferedReader().readText()) } catch (x: Throwable) {} }
            val t2 = Thread { try { e.append(p.errorStream.bufferedReader().readText()) } catch (x: Throwable) {} }
            t1.start(); t2.start()
            t1.join(timeoutSec * 1000)
            if (t1.isAlive) { try { p.destroy() } catch (x: Throwable) {}; return R(o.toString(), "Waktu habis", -2) }
            t2.join(1500)
            val code = try { p.waitFor() } catch (x: Throwable) { 0 }
            R(o.toString(), e.toString(), code)
        } catch (e: Throwable) {
            val c = e.cause ?: e
            R("", (c.javaClass.simpleName + ": " + (c.message ?: "")).trim(), -3)
        }
    }

    fun async(cmd: String, timeoutSec: Long = 12, cb: (R) -> Unit) {
        pool.execute {
            val r = run(cmd, timeoutSec)
            mainHandler.post { cb(r) }
        }
    }

    fun bg(block: () -> Unit) { pool.execute(block) }
}

package com.zenith.tweaks

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Eksekusi perintah shell lewat Shizuku (uid shell/root). */
object Sh {
    class R(val out: String, val err: String, val code: Int) {
        val ok get() = code == 0
        val text get() = (out + (if (err.isNotBlank()) "\n" + err else "")).trim()
    }

    private val pool = Executors.newFixedThreadPool(3)
    private val method by lazy {
        Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
            .also { it.isAccessible = true }
    }

    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun granted(): Boolean = try { alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    fun denied(): Boolean = try { alive() && Shizuku.shouldShowRequestPermissionRationale() } catch (e: Throwable) { false }
    fun uid(): Int = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
    fun version(): Int = try { Shizuku.getVersion() } catch (e: Throwable) { -1 }

    fun run(cmd: String, timeoutSec: Long = 12): R {
        if (!granted()) return R("", "Shizuku belum siap / belum diberi izin", -1)
        return try {
            val p = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            var out = ""; var err = ""
            val t1 = Thread { out = try { p.inputStream.bufferedReader().readText() } catch (e: Exception) { "" } }
            val t2 = Thread { err = try { p.errorStream.bufferedReader().readText() } catch (e: Exception) { "" } }
            t1.start(); t2.start()
            val done = p.waitFor(timeoutSec, TimeUnit.SECONDS)
            if (!done) { p.destroy(); return R(out, "Waktu habis", -2) }
            t1.join(1500); t2.join(1500)
            R(out, err, p.exitValue())
        } catch (e: Throwable) {
            val c = e.cause ?: e
            R("", c.message ?: c.javaClass.simpleName, -3)
        }
    }

    fun async(cmd: String, timeoutSec: Long = 12, cb: (R) -> Unit) {
        pool.execute {
            val r = run(cmd, timeoutSec)
            mainHandler.post { cb(r) }
        }
    }

    fun bg(block: () -> Unit) { pool.execute(block) }
}

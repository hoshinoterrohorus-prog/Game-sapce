package com.zenith.tweaks

/** Statistik sistem: satu skrip shell, di-parse di sini. */
object Sys {
    class Snap(
        val cpuTotal: Long, val cpuIdle: Long,
        val memTotalKb: Long, val memAvailKb: Long, val swapTotalKb: Long, val swapFreeKb: Long,
        val freqKhz: List<Long>, val maxKhz: List<Long>,
        val gpuHz: Long, val gpuName: String,
        val cpuTempC: Float, val battTempC: Float,
        val battPct: Int, val charging: Boolean, val battMv: Int, val battMa: Int
    )

    const val SCRIPT = """
head -1 /proc/stat | sed 's/^/CPU /'
grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo | sed 's/^/MEM /'
for f in /sys/devices/system/cpu/cpu[0-9]*; do echo "FRQ ${'$'}{f##*cpu} ${'$'}(cat ${'$'}f/cpufreq/scaling_cur_freq 2>/dev/null) ${'$'}(cat ${'$'}f/cpufreq/cpuinfo_max_freq 2>/dev/null)"; done
for d in /sys/class/devfreq/*; do [ -r ${'$'}d/cur_freq ] && echo "DEV ${'$'}{d##*/} ${'$'}(cat ${'$'}d/cur_freq 2>/dev/null)"; done
for z in /sys/class/thermal/thermal_zone*; do echo "TMP ${'$'}(cat ${'$'}z/type 2>/dev/null) ${'$'}(cat ${'$'}z/temp 2>/dev/null)"; done
dumpsys battery 2>/dev/null | sed 's/^ *//;s/^/BAT /'
"""

    private var prevTotal = 0L
    private var prevIdle = 0L

    fun parse(out: String): Snap? {
        var ct = 0L; var ci = 0L
        var mt = 0L; var ma = 0L; var st = 0L; var sf = 0L
        val fr = sortedMapOf<Int, Long>(); val mx = sortedMapOf<Int, Long>()
        var gHz = 0L; var gName = ""
        val cpuT = ArrayList<Float>(); var batT = 0f
        var pct = 0; var chg = false; var mv = 0; var ma2 = 0
        var any = false
        for (raw in out.lineSequence()) {
            val line = raw.trim()
            val p = line.split(Regex("\\s+"))
            when (p.getOrNull(0)) {
                "CPU" -> {
                    val n = p.drop(2).mapNotNull { it.toLongOrNull() }
                    if (n.size >= 4) {
                        ct = n.take(8).sum(); ci = n[3] + n.getOrElse(4) { 0L }; any = true
                    }
                }
                "MEM" -> {
                    val v = p.getOrNull(2)?.toLongOrNull() ?: 0L
                    when (p.getOrNull(1)) {
                        "MemTotal:" -> mt = v; "MemAvailable:" -> ma = v
                        "SwapTotal:" -> st = v; "SwapFree:" -> sf = v
                    }
                }
                "FRQ" -> {
                    val i = p.getOrNull(1)?.toIntOrNull() ?: continue
                    fr[i] = p.getOrNull(2)?.toLongOrNull() ?: 0L
                    mx[i] = p.getOrNull(3)?.toLongOrNull() ?: 0L
                }
                "DEV" -> {
                    val name = p.getOrNull(1) ?: ""
                    val hz = p.getOrNull(2)?.toLongOrNull() ?: 0L
                    val l = name.lowercase()
                    if (hz > 0 && (l.contains("mali") || l.contains("gpu") || l.contains("kgsl") || l.contains("g3d")) && gHz == 0L) { gHz = hz; gName = name }
                }
                "TMP" -> {
                    val t = p.lastOrNull()?.toFloatOrNull() ?: continue
                    val c = if (t > 1000f) t / 1000f else t
                    val type = (p.getOrNull(1) ?: "").lowercase()
                    if (c in 5f..120f) {
                        if (type.contains("cpu") || type.contains("soc") || type.contains("mtktscpu") || type.contains("big") || type.contains("little") || type.contains("tsens"))
                            cpuT.add(c)
                    }
                }
                "BAT" -> {
                    val rest = line.removePrefix("BAT").trim()
                    val k = rest.substringBefore(':').trim(); val v = rest.substringAfter(':', "").trim()
                    when (k) {
                        "level" -> pct = v.toIntOrNull() ?: pct
                        "temperature" -> batT = (v.toFloatOrNull() ?: 0f) / 10f
                        "voltage" -> mv = v.toIntOrNull() ?: mv
                        "status" -> chg = v == "2" || v == "5"
                        "Charge counter" -> {}
                        "current now", "Current now" -> ma2 = (v.toIntOrNull() ?: 0) / 1000
                    }
                }
            }
        }
        if (!any) return null
        val cpuMax = cpuT.maxOrNull() ?: 0f
        return Snap(ct, ci, mt, ma, st, sf, fr.values.toList(), mx.values.toList(), gHz, gName, cpuMax, batT, pct, chg, mv, ma2)
    }

    /** Persentase CPU sejak sampel sebelumnya. */
    fun cpuPct(s: Snap): Float {
        val dt = s.cpuTotal - prevTotal; val di = s.cpuIdle - prevIdle
        val r = if (prevTotal == 0L || dt <= 0) 0f else (1f - di.toFloat() / dt).coerceIn(0f, 1f) * 100f
        prevTotal = s.cpuTotal; prevIdle = s.cpuIdle
        return r
    }
}

/** Paket di layar + FPS lewat SurfaceFlinger. */
object Fps {
    fun foreground(): String {
        val r = Sh.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'", 6)
        val m = Regex("([A-Za-z0-9_.]+)/[A-Za-z0-9_.\$]+").find(r.out)
        return m?.groupValues?.get(1) ?: ""
    }

    /** FPS layar paket `pkg`, atau -1 jika tidak terbaca. */
    fun measure(pkg: String): Float {
        if (pkg.isBlank()) return -1f
        val list = Sh.run("dumpsys SurfaceFlinger --list 2>/dev/null | grep -F '$pkg'", 6).out.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.contains("Background") && !it.contains("Bounds") }
        if (list.isEmpty()) return -1f
        val layer = list.firstOrNull { it.contains("SurfaceView") } ?: list.last()
        val out = Sh.run("dumpsys SurfaceFlinger --latency '${layer.replace("'", "")}'", 6).out.lines()
        val ts = ArrayList<Long>()
        for (l in out.drop(1)) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size < 3) continue
            val t = p[1].toLongOrNull() ?: continue
            if (t <= 0L || t == Long.MAX_VALUE || t > 9_000_000_000_000_000L) continue
            ts.add(t)
        }
        if (ts.size < 5) return -1f
        val span = (ts.last() - ts.first()) / 1e9
        return if (span <= 0.0) -1f else ((ts.size - 1) / span).toFloat()
    }
}

/** Deteksi kemampuan perangkat. */
object Caps {
    class Info(
        val model: String, val android: String, val sdk: Int, val soc: String, val hw: String,
        val vulkan: String, val egl: String,
        val gameCmd: Boolean, val angle: Boolean, val updatableDriver: Boolean,
        val size: String, val density: String, val refresh: String, val raw: String
    )

    const val SCRIPT = """
echo "model=${'$'}(getprop ro.product.model)"
echo "android=${'$'}(getprop ro.build.version.release)"
echo "sdk=${'$'}(getprop ro.build.version.sdk)"
echo "soc=${'$'}(getprop ro.board.platform)"
echo "hw=${'$'}(getprop ro.hardware)"
echo "vulkan=${'$'}(getprop ro.hardware.vulkan)"
echo "egl=${'$'}(getprop ro.hardware.egl)"
echo "gamecmd=${'$'}(cmd game list-modes com.android.settings 2>&1 | head -c 120)"
echo "angle=${'$'}(pm list packages 2>/dev/null | grep -c -i angle)"
echo "ugd=${'$'}(settings get global updatable_driver_production_allowlist 2>&1 | head -c 80)"
echo "size=${'$'}(wm size | tail -1)"
echo "density=${'$'}(wm density | tail -1)"
echo "refresh=${'$'}(settings get system peak_refresh_rate) / ${'$'}(settings get system min_refresh_rate)"
"""

    fun parse(out: String): Info {
        val m = HashMap<String, String>()
        for (l in out.lines()) { val i = l.indexOf('='); if (i > 0) m[l.substring(0, i)] = l.substring(i + 1).trim() }
        val gc = m["gamecmd"] ?: ""
        val gameOk = gc.isNotEmpty() && !gc.contains("Can't find service", true) && !gc.contains("unknown command", true) && !gc.contains("not found", true)
        return Info(
            m["model"] ?: "?", m["android"] ?: "?", m["sdk"]?.toIntOrNull() ?: 0,
            m["soc"] ?: "?", m["hw"] ?: "?", m["vulkan"] ?: "", m["egl"] ?: "",
            gameOk, (m["angle"]?.toIntOrNull() ?: 0) > 0,
            (m["ugd"] ?: "").let { it.isNotEmpty() && it != "null" },
            m["size"] ?: "", m["density"] ?: "", m["refresh"] ?: "", out
        )
    }
}

package com.zenith.tweaks

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

val mainHandler = Handler(Looper.getMainLooper())

object C {
    const val BG = 0xFF070A14.toInt()
    const val BG2 = 0xFF111833.toInt()
    const val CARD = 0x1AFFFFFF
    const val STROKE = 0x2EFFFFFF
    const val TEXT = 0xFFF2F5FF.toInt()
    const val SUB = 0xB0C5CCE6.toInt()
    const val CYAN = 0xFF2DE2E6.toInt()
    const val VIOLET = 0xFF8B6CFF.toInt()
    const val PINK = 0xFFFF5C9E.toInt()
    const val GREEN = 0xFF4ADE80.toInt()
    const val AMBER = 0xFFFBBF24.toInt()
    const val RED = 0xFFFB7185.toInt()
}

fun Context.dp(v: Float) = v * resources.displayMetrics.density
fun Context.dpi(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
fun View.dpi(v: Int) = context.dpi(v)

fun lighten(c: Int, f: Float = 0.45f): Int {
    val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
    return Color.argb(Color.alpha(c), (r + (255 - r) * f).toInt(), (g + (255 - g) * f).toInt(), (b + (255 - b) * f).toInt())
}

fun rr(color: Int, radius: Float, stroke: Int = 0, sw: Float = 1f): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color); g.cornerRadius = radius
    if (stroke != 0) g.setStroke(sw.toInt().coerceAtLeast(1), stroke)
    return g
}

fun grad(radius: Float, a: Int = C.CYAN, b: Int = C.VIOLET): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(a, b)); g.cornerRadius = radius; return g
}

// ---------- animasi kecil ----------
fun View.press(scale: Float = 0.96f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(scale).scaleY(scale).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(2.5f)).start()
        }
        false
    }
}

fun View.enter(delay: Long = 0, dy: Float = 26f) {
    alpha = 0f; translationY = context.dp(dy)
    animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(460).setInterpolator(DecelerateInterpolator(2.2f)).start()
}

fun ViewGroup.stagger(step: Long = 55, max: Int = 10) {
    for (i in 0 until childCount) getChildAt(i).enter(minOf(i, max) * step)
}

// ---------- widget dasar ----------
fun Context.card(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x30FFFFFF, 0x0CFFFFFF))
    g.cornerRadius = dp(24f); g.setStroke(dpi(1), C.STROKE)
    l.background = g
    l.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
    return l
}

fun Context.text(s: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s; t.textSize = size; t.setTextColor(color)
    if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    return t
}

fun Context.label(s: String, color: Int = C.SUB): TextView {
    val t = text(s.uppercase(), 11f, color, true)
    t.letterSpacing = 0.14f
    return t
}

fun Context.title(s: String): TextView {
    val t = text(s, 30f, C.TEXT, true)
    t.letterSpacing = -0.02f
    t.paint.shader = LinearGradient(0f, 0f, t.paint.measureText(s) * 1.25f, 0f, intArrayOf(0xFFFFFFFF.toInt(), C.CYAN, C.VIOLET), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    return t
}

fun lp(w: Int = -1, h: Int = -2, top: Int = 0, bottom: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.topMargin = top; p.bottomMargin = bottom
    return p
}

fun Context.chip(label: String, on: Boolean, click: () -> Unit): TextView {
    val t = text(label, 13f, if (on) 0xFF04101A.toInt() else C.TEXT, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dpi(14), dpi(8), dpi(14), dpi(8))
    t.background = if (on) grad(dp(18f)) else rr(0x14FFFFFF, dp(18f), C.STROKE)
    t.press(0.93f)
    t.setOnClickListener { t.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); click() }
    return t
}

fun Context.button(label: String, primary: Boolean = true, click: () -> Unit): TextView {
    val t = text(label, 15f, if (primary) 0xFF04101A.toInt() else C.TEXT, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dpi(16), dpi(13), dpi(16), dpi(13))
    t.background = if (primary) grad(dp(18f)) else rr(0x14FFFFFF, dp(18f), C.STROKE)
    t.press(0.95f)
    t.setOnClickListener { t.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); click() }
    return t
}

// ---------- latar aurora bergerak ----------
class Aurora(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val cols = intArrayOf(0x668B6CFF, 0x552DE2E6, 0x40FF5C9E)
    private var shaders: Array<RadialGradient>? = null
    private var rad = 1f
    private val an = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 30000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedFraction; invalidate() }
    }
    fun start() { if (!an.isStarted) an.start() else if (an.isPaused) an.resume() }
    fun stop() { if (an.isRunning) an.pause() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        rad = w * 0.95f
        shaders = Array(3) { RadialGradient(0f, 0f, rad, cols[it], 0x00000000, Shader.TileMode.CLAMP) }
    }
    override fun onDraw(c: Canvas) {
        c.drawColor(C.BG)
        val sh = shaders ?: return
        val w = width.toFloat(); val h = height.toFloat()
        for (i in 0..2) {
            val a = (t + i / 3f) * 6.2831853f
            val cx = w * (0.5f + 0.45f * Math.cos((a * (1 + i % 2)).toDouble()).toFloat())
            val cy = h * (0.30f + 0.28f * i + 0.18f * Math.sin((a * 2).toDouble()).toFloat())
            c.save(); c.translate(cx, cy)
            p.shader = sh[i]; c.drawCircle(0f, 0f, rad, p)
            c.restore()
        }
        p.shader = null
    }
}

/** Pengukur melingkar dengan animasi halus */
class Ring(ctx: Context) : View(ctx) {
    var label = ""; var big = ""; var color = C.CYAN
    private var shown = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var sweep: SweepGradient? = null
    private var sweepKey = 0L
    private val m = Matrix()

    fun set(v: Float, big: String, label: String, col: Int = C.CYAN) {
        this.big = big; this.label = label; color = col
        anim?.cancel()
        val a = ValueAnimator.ofFloat(shown, v.coerceIn(0f, 1f)); a.duration = 700; a.interpolator = DecelerateInterpolator(2f)
        a.addUpdateListener { shown = it.animatedValue as Float; invalidate() }
        anim = a; a.start()
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val s = minOf(w, height.toFloat())
        val st = s * 0.11f
        r.set((w - s) / 2 + st, st, (w + s) / 2 - st, s - st)
        p.style = Paint.Style.STROKE; p.strokeWidth = st; p.strokeCap = Paint.Cap.ROUND
        p.color = 0x1FFFFFFF; c.drawArc(r, 135f, 270f, false, p)
        val key = color.toLong() * 31 + w.toLong()
        if (sweep == null || key != sweepKey) {
            sweepKey = key
            sweep = SweepGradient(r.centerX(), r.centerY(), intArrayOf(color, lighten(color), lighten(color)), floatArrayOf(0f, 0.75f, 1f))
            m.reset(); m.postRotate(135f, r.centerX(), r.centerY()); sweep!!.setLocalMatrix(m)
        }
        if (shown > 0.003f) {
            p.strokeWidth = st * 1.9f; p.color = (color and 0x00FFFFFF) or 0x30000000
            c.drawArc(r, 135f, 270f * shown, false, p)
            p.strokeWidth = st; p.shader = sweep
            c.drawArc(r, 135f, 270f * shown, false, p)
            p.shader = null
            val ang = Math.toRadians((135f + 270f * shown).toDouble())
            val rad = r.width() / 2
            p.style = Paint.Style.FILL; p.color = Color.WHITE
            c.drawCircle(r.centerX() + (rad * Math.cos(ang)).toFloat(), r.centerY() + (rad * Math.sin(ang)).toFloat(), st * 0.28f, p)
        }
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = C.TEXT; p.textSize = s * 0.25f; p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        c.drawText(big, w / 2, s * 0.54f, p)
        p.color = C.SUB; p.textSize = s * 0.12f; p.typeface = Typeface.DEFAULT; p.letterSpacing = 0.1f
        c.drawText(label.uppercase(), w / 2, s * 0.74f, p)
        p.letterSpacing = 0f
    }
    override fun onMeasure(w: Int, h: Int) { val s = MeasureSpec.getSize(w); setMeasuredDimension(s, s) }
}

/** Grafik garis riwayat, kurva halus + glow */
class Spark(ctx: Context) : View(ctx) {
    val data = ArrayList<Float>()
    var max = 100f; var color = C.CYAN
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    fun push(v: Float, cap: Int = 60) { data.add(v); while (data.size > cap) data.removeAt(0); invalidate() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0x14FFFFFF
        for (i in 1..3) c.drawLine(0f, h * i / 4, w, h * i / 4, p)
        if (data.size < 2) return
        val mx = maxOf(max, data.maxOrNull() ?: 1f)
        val n = data.size
        val xs = FloatArray(n) { w * it / (n - 1) }
        val ys = FloatArray(n) { h - (data[it] / mx).coerceIn(0f, 1f) * (h - 10f) - 5f }
        path.reset(); path.moveTo(xs[0], ys[0])
        for (i in 1 until n) path.quadTo(xs[i - 1], ys[i - 1], (xs[i - 1] + xs[i]) / 2, (ys[i - 1] + ys[i]) / 2)
        path.lineTo(xs[n - 1], ys[n - 1])
        val fill = Path(path); fill.lineTo(w, h); fill.lineTo(0f, h); fill.close()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, (color and 0x00FFFFFF) or 0x66000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawPath(fill, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeJoin = Paint.Join.ROUND; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = context.dp(6f); p.color = (color and 0x00FFFFFF) or 0x28000000; c.drawPath(path, p)
        p.strokeWidth = context.dp(2f); p.color = color; c.drawPath(path, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE; c.drawCircle(xs[n - 1], ys[n - 1], context.dp(3.5f), p)
    }
}

/** Batang horizontal tipis, bergerak halus */
class Bar(ctx: Context) : View(ctx) {
    var color = C.CYAN
    private var shown = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun setFrac(f: Float) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(shown, f.coerceIn(0f, 1f)); a.duration = 600; a.interpolator = DecelerateInterpolator(2f)
        a.addUpdateListener { shown = it.animatedValue as Float; invalidate() }
        anim = a; a.start()
    }
    override fun onDraw(c: Canvas) {
        val h = height.toFloat(); val w = width.toFloat()
        p.shader = null; p.color = 0x1FFFFFFF; c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        if (shown > 0.001f) {
            p.shader = LinearGradient(0f, 0f, w, 0f, C.CYAN, C.VIOLET, Shader.TileMode.CLAMP)
            c.drawRoundRect(0f, 0f, maxOf(h, w * shown), h, h / 2, h / 2, p); p.shader = null
        }
    }
}

/** Slider bertahap (untuk downscale 0.3 … 1.0) */
class StepSlider(ctx: Context, val n: Int) : View(ctx) {
    var index = 0; private set
    var onChange: ((Int) -> Unit)? = null
    private var pos = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pad = ctx.dp(16f)

    private fun xAt(i: Float) = pad + (width - 2 * pad) * i / (n - 1)
    fun setIndex(i: Int, animate: Boolean = true) {
        index = i.coerceIn(0, n - 1)
        anim?.cancel()
        if (!animate) { pos = index.toFloat(); invalidate(); return }
        val a = ValueAnimator.ofFloat(pos, index.toFloat()); a.duration = 260; a.interpolator = OvershootInterpolator(1.4f)
        a.addUpdateListener { pos = it.animatedValue as Float; invalidate() }
        anim = a; a.start()
    }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), context.dpi(54)) }
    override fun onDraw(c: Canvas) {
        val cy = height / 2f; val th = context.dp(6f)
        p.style = Paint.Style.FILL; p.shader = null
        p.color = 0x22FFFFFF; c.drawRoundRect(pad, cy - th / 2, width - pad, cy + th / 2, th, th, p)
        val tx = xAt(pos)
        p.shader = LinearGradient(pad, 0f, width - pad, 0f, C.CYAN, C.VIOLET, Shader.TileMode.CLAMP)
        c.drawRoundRect(pad, cy - th / 2, maxOf(tx, pad + th), cy + th / 2, th, th, p); p.shader = null
        for (i in 0 until n) { p.color = if (i <= pos + 0.01f) 0xFFFFFFFF.toInt() else 0x55FFFFFF; c.drawCircle(xAt(i.toFloat()), cy, context.dp(1.6f), p) }
        p.color = 0x302DE2E6; c.drawCircle(tx, cy, context.dp(19f), p)
        p.color = Color.WHITE; c.drawCircle(tx, cy, context.dp(11f), p)
        p.color = C.CYAN; c.drawCircle(tx, cy, context.dp(5f), p)
    }
    private fun upd(x: Float) {
        val i = Math.round((x - pad) / (width - 2 * pad) * (n - 1)).coerceIn(0, n - 1)
        if (i != index) { setIndex(i); performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); onChange?.invoke(i) }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); upd(e.x) }
            MotionEvent.ACTION_MOVE -> upd(e.x)
            MotionEvent.ACTION_UP -> performClick()
        }
        return true
    }
}

/** Ikon tab digambar sendiri */
class TabIcon(ctx: Context, val kind: Int) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat(); val ox = (width - s) / 2f
        p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.085f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.color = if (on) C.CYAN else C.SUB
        c.save(); c.translate(ox, 0f)
        when (kind) {
            0 -> {
                c.drawArc(RectF(s * 0.12f, s * 0.14f, s * 0.88f, s * 0.9f), 150f, 240f, false, p)
                c.drawLine(s * 0.5f, s * 0.52f, s * 0.7f, s * 0.3f, p)
                p.style = Paint.Style.FILL; c.drawCircle(s * 0.5f, s * 0.52f, s * 0.07f, p)
            }
            1 -> {
                c.drawRoundRect(RectF(s * 0.08f, s * 0.28f, s * 0.92f, s * 0.74f), s * 0.22f, s * 0.22f, p)
                c.drawLine(s * 0.28f, s * 0.43f, s * 0.28f, s * 0.59f, p); c.drawLine(s * 0.2f, s * 0.51f, s * 0.36f, s * 0.51f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(s * 0.66f, s * 0.46f, s * 0.05f, p); c.drawCircle(s * 0.76f, s * 0.57f, s * 0.05f, p)
            }
            else -> {
                val ys = floatArrayOf(0.25f, 0.5f, 0.75f); val ks = floatArrayOf(0.35f, 0.68f, 0.45f)
                for (i in 0..2) {
                    p.style = Paint.Style.STROKE
                    c.drawLine(s * 0.12f, s * ys[i], s * 0.88f, s * ys[i], p)
                    p.style = Paint.Style.FILL; p.color = if (on) C.CYAN else C.SUB
                    c.drawCircle(s * ks[i], s * ys[i], s * 0.1f, p)
                }
            }
        }
        c.restore()
    }
}

/** Logo Zenith berdenyut */
class Logo(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val bolt = Path().apply {
        moveTo(56f, 8f); lineTo(26f, 56f); lineTo(46f, 56f); lineTo(40f, 92f); lineTo(76f, 40f); lineTo(55f, 40f); close()
    }
    private val an = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedFraction; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); an.start() }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); an.cancel() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val cx = w / 2; val cy = height / 2f
        val base = minOf(w, height.toFloat()) * 0.26f
        p.style = Paint.Style.STROKE
        for (i in 0..2) {
            val ph = (t + i / 3f) % 1f
            p.strokeWidth = context.dp(2f); p.color = (C.CYAN and 0x00FFFFFF) or ((1f - ph) * 110).toInt().shl(24)
            c.drawCircle(cx, cy, base * (1.1f + ph * 1.5f), p)
        }
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx - base, cy - base, cx + base, cy + base, C.CYAN, C.VIOLET, Shader.TileMode.CLAMP)
        c.drawRoundRect(cx - base, cy - base, cx + base, cy + base, base * 0.5f, base * 0.5f, p); p.shader = null
        c.save(); val sc = base * 1.3f / 100f
        c.translate(cx - 50f * sc, cy - 50f * sc); c.scale(sc, sc)
        p.color = 0xFF04101A.toInt(); c.drawPath(bolt, p); c.restore()
    }
}

fun ViewGroup.addv(v: View, p: ViewGroup.LayoutParams? = null) { if (p != null) addView(v, p) else addView(v) }
fun fl(w: Int = -1, h: Int = -1) = FrameLayout.LayoutParams(w, h)

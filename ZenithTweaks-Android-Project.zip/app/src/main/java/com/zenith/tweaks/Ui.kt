package com.zenith.tweaks

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

val mainHandler = Handler(Looper.getMainLooper())

object C {
    const val BG = 0xFF090D18.toInt()
    const val BG2 = 0xFF121A33.toInt()
    const val CARD = 0x1AFFFFFF
    const val STROKE = 0x26FFFFFF
    const val TEXT = 0xFFF2F5FF.toInt()
    const val SUB = 0xAAC5CCE6.toInt()
    const val CYAN = 0xFF2DE2E6.toInt()
    const val VIOLET = 0xFF8B6CFF.toInt()
    const val GREEN = 0xFF4ADE80.toInt()
    const val AMBER = 0xFFFBBF24.toInt()
    const val RED = 0xFFFB7185.toInt()
}

fun Context.dp(v: Float) = v * resources.displayMetrics.density
fun Context.dpi(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
fun View.dpi(v: Int) = context.dpi(v)

fun rr(color: Int, radius: Float, stroke: Int = 0, sw: Float = 1f): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color); g.cornerRadius = radius
    if (stroke != 0) g.setStroke(sw.toInt().coerceAtLeast(1), stroke)
    return g
}

fun Context.card(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.background = rr(C.CARD, dp(20f), C.STROKE)
    l.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
    return l
}

fun Context.text(s: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s; t.textSize = size; t.setTextColor(color)
    if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    return t
}

fun lp(w: Int = -1, h: Int = -2, top: Int = 0, bottom: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.topMargin = top; p.bottomMargin = bottom
    return p
}

fun Context.chip(label: String, on: Boolean, click: () -> Unit): TextView {
    val t = text(label, 13f, if (on) Color.BLACK else C.TEXT, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dpi(14), dpi(8), dpi(14), dpi(8))
    t.background = if (on) rr(C.CYAN, dp(18f)) else rr(0x14FFFFFF, dp(18f), C.STROKE)
    t.setOnClickListener { click() }
    return t
}

fun Context.button(label: String, primary: Boolean = true, click: () -> Unit): TextView {
    val t = text(label, 15f, if (primary) Color.BLACK else C.TEXT, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dpi(16), dpi(12), dpi(16), dpi(12))
    t.background = if (primary) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.CYAN, C.VIOLET)).also { it.cornerRadius = dp(16f) } else rr(0x14FFFFFF, dp(16f), C.STROKE)
    t.setOnClickListener { click() }
    return t
}

/** Pengukur melingkar */
class Ring(ctx: Context) : View(ctx) {
    var value = 0f; var label = ""; var big = ""; var color = C.CYAN
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val s = minOf(w, height.toFloat())
        val st = s * 0.11f
        r.set((w - s) / 2 + st, st, (w + s) / 2 - st, s - st)
        p.style = Paint.Style.STROKE; p.strokeWidth = st; p.strokeCap = Paint.Cap.ROUND
        p.color = 0x22FFFFFF; c.drawArc(r, 135f, 270f, false, p)
        p.color = color; c.drawArc(r, 135f, 270f * value.coerceIn(0f, 1f), false, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = C.TEXT; p.textSize = s * 0.24f; p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        c.drawText(big, w / 2, s * 0.53f, p)
        p.color = C.SUB; p.textSize = s * 0.13f; p.typeface = Typeface.DEFAULT
        c.drawText(label, w / 2, s * 0.73f, p)
    }
    override fun onMeasure(w: Int, h: Int) { val s = MeasureSpec.getSize(w); setMeasuredDimension(s, s) }
    fun set(v: Float, big: String, label: String, col: Int = C.CYAN) { value = v; this.big = big; this.label = label; color = col; invalidate() }
}

/** Grafik garis riwayat */
class Spark(ctx: Context) : View(ctx) {
    val data = ArrayList<Float>()
    var max = 100f; var color = C.CYAN; var unit = ""
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    fun push(v: Float, cap: Int = 60) { data.add(v); while (data.size > cap) data.removeAt(0); invalidate() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0x18FFFFFF
        for (i in 1..3) c.drawLine(0f, h * i / 4, w, h * i / 4, p)
        if (data.size < 2) return
        val mx = maxOf(max, data.maxOrNull() ?: 1f)
        path.reset()
        for (i in data.indices) {
            val x = w * i / (data.size - 1).coerceAtLeast(1)
            val y = h - (data[i] / mx).coerceIn(0f, 1f) * (h - 6f) - 3f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val fill = Path(path); fill.lineTo(w, h); fill.lineTo(0f, h); fill.close()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, (color and 0x00FFFFFF) or 0x55000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawPath(fill, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(2f); p.color = color; p.strokeJoin = Paint.Join.ROUND
        c.drawPath(path, p)
    }
    private fun dp(v: Float) = context.dp(v)
}

/** Batang horizontal tipis */
class Bar(ctx: Context) : View(ctx) {
    var frac = 0f; var color = C.CYAN
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val h = height.toFloat(); val w = width.toFloat()
        p.color = 0x22FFFFFF; c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        p.color = color; c.drawRoundRect(0f, 0f, w * frac.coerceIn(0f, 1f), h, h / 2, h / 2, p)
    }
}

fun ViewGroup.addv(v: View, p: ViewGroup.LayoutParams? = null) { if (p != null) addView(v, p) else addView(v) }
fun fl(w: Int = -1, h: Int = -1) = FrameLayout.LayoutParams(w, h)

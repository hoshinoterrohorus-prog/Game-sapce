package com.zenith.tweaks

import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class GamesPage(val ctx: Context, val caps: () -> Caps.Info?) : Page {
    private val frame = FrameLayout(ctx)
    override val root get() = frame
    private val listCol = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)
    private val chips = LinearLayout(ctx)
    private val search = EditText(ctx)
    private var all: List<AppItem> = emptyList()
    private var filter = 0 // 0 terpilih, 1 game, 2 semua
    private var query = ""
    private var loaded = false
    private var sheet: View? = null

    init {
        val main = LinearLayout(ctx); main.orientation = LinearLayout.VERTICAL
        main.setPadding(ctx.dpi(16), ctx.dpi(8), ctx.dpi(16), 0)
        main.addView(ctx.text("Game & Aplikasi", 26f, C.TEXT, true))
        main.addView(ctx.text("Pilih satu, atur khusus untuk dia saja", 13f, C.SUB), lp(bottom = ctx.dpi(10)))

        search.hint = "Cari aplikasi…"; search.setHintTextColor(C.SUB); search.setTextColor(C.TEXT); search.textSize = 14f
        search.setSingleLine(true)
        search.background = rr(0x14FFFFFF, ctx.dp(14f), C.STROKE)
        search.setPadding(ctx.dpi(14), ctx.dpi(10), ctx.dpi(14), ctx.dpi(10))
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString()?.trim()?.lowercase() ?: ""; render() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        main.addView(search, lp(bottom = ctx.dpi(8)))
        chips.orientation = LinearLayout.HORIZONTAL
        main.addView(chips, lp(bottom = ctx.dpi(8)))

        listCol.orientation = LinearLayout.VERTICAL
        listCol.setPadding(0, 0, 0, ctx.dpi(16))
        scroll.addView(listCol, fl(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        main.addView(scroll, lp(-1, 0, weight = 1f))
        frame.addView(main, fl())
        drawChips()
    }

    private fun drawChips() {
        chips.removeAllViews()
        val names = listOf("Terpilih", "Game", "Semua")
        for (i in names.indices) chips.addView(ctx.chip(names[i], filter == i) { filter = i; drawChips(); render() }, lp(-2, -2).also { it.rightMargin = ctx.dpi(8) })
    }

    override fun onShow() {
        if (!loaded) {
            loaded = true
            Sh.bg {
                val l = Apps.list(ctx)
                mainHandler.post { all = l; render() }
            }
        } else render()
    }
    override fun onHide() {}

    fun handleBack(): Boolean { if (sheet != null) { closeSheet(); return true }; return false }

    private fun render() {
        listCol.removeAllViews()
        val pinned = Store.pinned(ctx)
        var items = when (filter) { 0 -> all.filter { it.pkg in pinned }; 1 -> all.filter { it.isGame }; else -> all }
        if (query.isNotEmpty()) items = (if (filter == 0) all else items).filter { it.label.lowercase().contains(query) || it.pkg.contains(query) }
        if (items.isEmpty()) {
            val t = ctx.text(if (filter == 0 && query.isEmpty()) "Belum ada yang dipilih.\nBuka tab “Game” atau “Semua”, lalu ketuk bintang ☆ untuk menambahkan." else "Tidak ditemukan.", 13f, C.SUB)
            t.gravity = Gravity.CENTER; t.setPadding(0, ctx.dpi(40), 0, 0)
            listCol.addView(t); return
        }
        for (a in items) listCol.addView(row(a, a.pkg in pinned), lp(bottom = ctx.dpi(8)))
    }

    private fun row(a: AppItem, pinned: Boolean): View {
        val r = LinearLayout(ctx); r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
        r.background = rr(C.CARD, ctx.dp(18f), C.STROKE)
        r.setPadding(ctx.dpi(12), ctx.dpi(10), ctx.dpi(8), ctx.dpi(10))
        val ic = ImageView(ctx); ic.setImageDrawable(Apps.icon(ctx, a.pkg))
        r.addView(ic, lp(ctx.dpi(44), ctx.dpi(44)))
        val mid = LinearLayout(ctx); mid.orientation = LinearLayout.VERTICAL
        mid.addView(ctx.text(a.label, 15f, C.TEXT, true).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
        val prof = Store.profile(ctx, a.pkg)
        val sub = if (prof.isDefault) a.pkg else summary(prof)
        mid.addView(ctx.text(sub, 11f, if (prof.isDefault) C.SUB else C.CYAN).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
        r.addView(mid, lp(0, -2, weight = 1f).also { it.leftMargin = ctx.dpi(12) })
        val star = ctx.text(if (pinned) "★" else "☆", 22f, if (pinned) C.AMBER else C.SUB)
        star.setPadding(ctx.dpi(12), ctx.dpi(6), ctx.dpi(12), ctx.dpi(6))
        star.setOnClickListener {
            val s = Store.pinned(ctx); if (!s.add(a.pkg)) s.remove(a.pkg); Store.setPinned(ctx, s); render()
        }
        r.addView(star)
        r.setOnClickListener { openSheet(a) }
        return r
    }

    private fun summary(p: Profile): String {
        val l = ArrayList<String>()
        if (p.scale != 100) l.add("${p.scale}%")
        if (p.fps != 0) l.add("${p.fps}fps")
        if (p.mode != "default") l.add(p.mode)
        if (p.renderer != "default") l.add(p.renderer.uppercase())
        if (p.driver != "default") l.add("driver ${p.driver}")
        return l.joinToString(" • ")
    }

    private fun closeSheet() { sheet?.let { frame.removeView(it) }; sheet = null; render() }

    private fun openSheet(a: AppItem) {
        val sv = ScrollView(ctx); sv.setBackgroundColor(C.BG); sv.isVerticalScrollBarEnabled = false
        sv.isClickable = true
        val col = LinearLayout(ctx); col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(8), ctx.dpi(16), ctx.dpi(28))
        sv.addView(col, fl(-1, -2))

        val head = LinearLayout(ctx); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER_VERTICAL
        val back = ctx.text("‹", 30f, C.TEXT); back.setPadding(0, 0, ctx.dpi(14), ctx.dpi(4)); back.setOnClickListener { closeSheet() }
        head.addView(back)
        val ic = ImageView(ctx); ic.setImageDrawable(Apps.icon(ctx, a.pkg)); head.addView(ic, lp(ctx.dpi(48), ctx.dpi(48)))
        val nm = LinearLayout(ctx); nm.orientation = LinearLayout.VERTICAL
        nm.addView(ctx.text(a.label, 18f, C.TEXT, true).also { it.maxLines = 1 })
        nm.addView(ctx.text(a.pkg, 11f, C.SUB).also { it.maxLines = 1 })
        head.addView(nm, lp(0, -2, weight = 1f).also { it.leftMargin = ctx.dpi(12) })
        col.addView(head, lp(bottom = ctx.dpi(12)))

        var p = Store.profile(ctx, a.pkg)
        val log = ctx.text("", 11f, C.SUB); log.typeface = android.graphics.Typeface.MONOSPACE

        fun group(title: String, hint: String, opts: List<Pair<String, String>>, cur: () -> String, set: (String) -> Unit) {
            val c = ctx.card()
            c.addView(ctx.text(title, 13f, C.TEXT, true))
            if (hint.isNotEmpty()) c.addView(ctx.text(hint, 11f, C.SUB), lp(top = ctx.dpi(2)))
            val flow = LinearLayout(ctx); flow.orientation = LinearLayout.VERTICAL
            c.addView(flow, lp(top = ctx.dpi(8)))
            fun draw() {
                flow.removeAllViews()
                var rowL: LinearLayout? = null
                for ((i, o) in opts.withIndex()) {
                    if (i % 3 == 0) { rowL = LinearLayout(ctx); rowL.orientation = LinearLayout.HORIZONTAL; flow.addView(rowL, lp(bottom = ctx.dpi(6))) }
                    val ch = ctx.chip(o.first, cur() == o.second) { set(o.second); draw() }
                    rowL!!.addView(ch, lp(-2, -2).also { it.rightMargin = ctx.dpi(6) })
                }
            }
            draw()
            col.addView(c, lp(bottom = ctx.dpi(10)))
        }

        group("Resolusi (downscale)", "Menurunkan resolusi render game ini saja. Butuh Android 13+ dan aplikasi terdaftar sebagai game.",
            listOf("100%" to "100", "90%" to "90", "80%" to "80", "70%" to "70", "60%" to "60", "50%" to "50", "40%" to "40"),
            { p.scale.toString() }) { p = p.copy(scale = it.toInt()) }
        group("Batas FPS", "", listOf("Bawaan" to "0", "30" to "30", "45" to "45", "60" to "60", "90" to "90", "120" to "120"),
            { p.fps.toString() }) { p = p.copy(fps = it.toInt()) }
        group("Game Mode", "", listOf("Bawaan" to "default", "Standar" to "standard", "Performa" to "performance", "Hemat" to "battery"),
            { p.mode }) { p = p.copy(mode = it) }
        group("Renderer grafis", "ANGLE menjalankan OpenGL ES di atas Vulkan. Hanya untuk game ini. Tidak semua game/HP kompatibel.",
            listOf("Bawaan" to "default", "ANGLE" to "angle", "GL Native" to "native"),
            { p.renderer }) { p = p.copy(renderer = it) }
        group("Driver GPU", "Pilih driver untuk game ini saja. Butuh paket driver yang tersedia di HP; kalau tidak ada, tidak ada efek.",
            listOf("Bawaan" to "default", "Driver sistem" to "system", "Driver update" to "production", "Pra-rilis" to "prerelease"),
            { p.driver }) { p = p.copy(driver = it) }

        val btns = LinearLayout(ctx); btns.orientation = LinearLayout.HORIZONTAL
        fun busy(msg: String) { log.text = msg }
        fun doApply(launch: Boolean) {
            if (!Sh.granted()) { busy("Shizuku belum aktif / belum diberi izin."); return }
            Store.saveProfile(ctx, a.pkg, p)
            val s = Store.pinned(ctx); s.add(a.pkg); Store.setPinned(ctx, s)
            busy("Menerapkan…")
            Sh.bg {
                var out = Tweaks.apply(a.pkg, p, caps())
                if (launch) { Tweaks.launch(a.pkg); out += "\n› membuka ${a.label}" }
                mainHandler.post { busy(out + "\n\nSelesai. Aplikasi sudah dihentikan paksa; buka ulang agar pengaturan dipakai.") }
            }
        }
        btns.addView(ctx.button("Terapkan") { doApply(false) }, lp(0, -2, weight = 1f).also { it.rightMargin = ctx.dpi(8) })
        btns.addView(ctx.button("Terapkan & Buka") { doApply(true) }, lp(0, -2, weight = 1f))
        col.addView(btns, lp(bottom = ctx.dpi(8)))
        col.addView(ctx.button("Reset game ini ke bawaan", false) {
            if (!Sh.granted()) { busy("Shizuku belum aktif / belum diberi izin."); return@button }
            p = Profile(); Store.saveProfile(ctx, a.pkg, p)
            busy("Mereset…")
            Sh.bg { val o = Tweaks.reset(a.pkg, caps()); mainHandler.post { busy(o + "\n\nSudah kembali ke bawaan.") ; closeSheetDelayed() } }
        }, lp(bottom = ctx.dpi(12)))
        val lc = ctx.card(); lc.addView(ctx.text("LOG", 11f, C.SUB, true)); lc.addView(log, lp(top = ctx.dpi(4)))
        col.addView(lc)

        sheet = sv
        frame.addView(sv, fl())
    }

    private fun closeSheetDelayed() { mainHandler.postDelayed({ closeSheet() }, 1200) }
}

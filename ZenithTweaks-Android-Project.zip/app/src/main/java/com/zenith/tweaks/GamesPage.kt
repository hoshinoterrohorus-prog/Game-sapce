package com.zenith.tweaks

import android.content.Context
import android.graphics.Outline
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import java.util.Locale

/** Daftar nilai downscale yang diterima `cmd game`, dalam persen internal. */
val SCALES = listOf(100, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30)
fun scaleLabel(p: Int) = if (p >= 100) "1.0" else String.format(Locale.US, "%.2f", p / 100f).trimEnd('0').let { if (it.endsWith(".")) it + "0" else it }

fun roundIcon(ctx: Context, pkg: String, size: Int, radius: Float): ImageView {
    val ic = ImageView(ctx); ic.setImageDrawable(Apps.icon(ctx, pkg))
    ic.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, ctx.dp(radius)) }
    }
    ic.clipToOutline = true
    return ic
}

class GamesPage(val ctx: Context, val caps: () -> Caps.Info?) : Page {
    private val frame = FrameLayout(ctx)
    override val root get() = frame
    private val listCol = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)
    private val chips = LinearLayout(ctx)
    private val search = EditText(ctx)
    private val main = LinearLayout(ctx)
    private var all: List<AppItem> = emptyList()
    private var filter = 0
    private var query = ""
    private var loaded = false
    private var sheet: View? = null
    private var animateRows = true

    init {
        main.orientation = LinearLayout.VERTICAL
        main.setPadding(ctx.dpi(16), ctx.dpi(8), ctx.dpi(16), 0)
        main.addView(ctx.title("Game & Aplikasi"))
        main.addView(ctx.text("Pilih satu, atur khusus untuk dia saja", 13f, C.SUB), lp(bottom = ctx.dpi(12)))

        search.hint = "Cari aplikasi…"; search.setHintTextColor(C.SUB); search.setTextColor(C.TEXT); search.textSize = 14f
        search.setSingleLine(true)
        search.background = rr(0x18FFFFFF, ctx.dp(18f), C.STROKE)
        search.setPadding(ctx.dpi(16), ctx.dpi(11), ctx.dpi(16), ctx.dpi(11))
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString()?.trim()?.lowercase() ?: ""; animateRows = false; render() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        main.addView(search, lp(bottom = ctx.dpi(10)))
        chips.orientation = LinearLayout.HORIZONTAL
        main.addView(chips, lp(bottom = ctx.dpi(10)))

        listCol.orientation = LinearLayout.VERTICAL
        listCol.setPadding(0, 0, 0, ctx.dpi(16))
        scroll.addView(listCol, fl(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        main.addView(scroll, lp(-1, 0, weight = 1f))
        frame.addView(main, fl())
        drawChips()
    }

    private fun drawChips() {
        chips.removeAllViews()
        val names = listOf("★ Terpilih", "Game", "Semua")
        for (i in names.indices) chips.addView(ctx.chip(names[i], filter == i) { filter = i; animateRows = true; drawChips(); render() }, lp(-2, -2).also { it.rightMargin = ctx.dpi(8) })
    }

    override fun onShow() {
        if (!loaded) {
            loaded = true
            Sh.bg {
                val l = Apps.list(ctx)
                mainHandler.post { all = l; render() }
            }
        } else if (sheet == null) render()
    }
    override fun onHide() {}
    override fun intro() { main.stagger(60, 4) }

    fun handleBack(): Boolean { if (sheet != null) { closeSheet(); return true }; return false }

    private fun render() {
        listCol.removeAllViews()
        val pinned = Store.pinned(ctx)
        var items = when (filter) { 0 -> all.filter { it.pkg in pinned }; 1 -> all.filter { it.isGame }; else -> all }
        if (query.isNotEmpty()) items = (if (filter == 0) all else items).filter { it.label.lowercase().contains(query) || it.pkg.contains(query) }
        if (items.isEmpty()) {
            val t = ctx.text(if (!loaded || (all.isEmpty())) "Memuat daftar aplikasi…" else if (filter == 0 && query.isEmpty()) "Belum ada yang dipilih.\nBuka tab “Game” atau “Semua”, lalu ketuk ☆ untuk menambahkan." else "Tidak ditemukan.", 13f, C.SUB)
            t.gravity = Gravity.CENTER; t.setPadding(0, ctx.dpi(48), 0, 0)
            listCol.addView(t); t.enter(0); return
        }
        for ((i, a) in items.withIndex()) {
            val v = row(a, a.pkg in pinned)
            listCol.addView(v, lp(bottom = ctx.dpi(10)))
            if (animateRows && i < 9) v.enter(i * 45L, 18f)
        }
        animateRows = false
    }

    private fun row(a: AppItem, pinned: Boolean): View {
        val r = LinearLayout(ctx); r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
        val g = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, intArrayOf(0x2CFFFFFF, 0x0CFFFFFF))
        g.cornerRadius = ctx.dp(22f); g.setStroke(ctx.dpi(1), C.STROKE); r.background = g
        r.setPadding(ctx.dpi(12), ctx.dpi(10), ctx.dpi(6), ctx.dpi(10))
        r.addView(roundIcon(ctx, a.pkg, 46, 13f), lp(ctx.dpi(46), ctx.dpi(46)))
        val mid = LinearLayout(ctx); mid.orientation = LinearLayout.VERTICAL
        mid.addView(ctx.text(a.label, 15f, C.TEXT, true).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
        val prof = Store.profile(ctx, a.pkg)
        mid.addView(ctx.text(if (prof.isDefault) a.pkg else summary(prof), 11f, if (prof.isDefault) C.SUB else C.CYAN).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
        r.addView(mid, lp(0, -2, weight = 1f).also { it.leftMargin = ctx.dpi(12) })
        val star = ctx.text(if (pinned) "★" else "☆", 24f, if (pinned) C.AMBER else C.SUB)
        star.setPadding(ctx.dpi(14), ctx.dpi(8), ctx.dpi(14), ctx.dpi(8))
        star.setOnClickListener {
            val s = Store.pinned(ctx); val added = s.add(a.pkg); if (!added) s.remove(a.pkg); Store.setPinned(ctx, s)
            star.text = if (added) "★" else "☆"; star.setTextColor(if (added) C.AMBER else C.SUB)
            star.scaleX = 0.4f; star.scaleY = 0.4f
            star.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(4f)).start()
            if (!added && filter == 0) mainHandler.postDelayed({ animateRows = false; render() }, 260)
        }
        r.addView(star)
        r.press(0.97f)
        r.setOnClickListener { openSheet(a) }
        return r
    }

    private fun summary(p: Profile): String {
        val l = ArrayList<String>()
        if (p.scale != 100) l.add("${scaleLabel(p.scale)}×")
        if (p.fps != 0) l.add("${p.fps}fps")
        if (p.mode != "default") l.add(p.mode)
        if (p.renderer != "default") l.add(p.renderer.uppercase())
        if (p.driver != "default") l.add("driver ${p.driver}")
        return l.joinToString(" • ")
    }

    private fun closeSheet() {
        val s = sheet ?: return
        sheet = null
        s.animate().translationY(s.height * 0.12f).alpha(0f).setDuration(220).withEndAction { frame.removeView(s); render() }.start()
    }

    private fun resText(sc: Int): String {
        val m = Regex("(\\d+)x(\\d+)").findAll(caps()?.size ?: "").lastOrNull() ?: return "Resolusi render game = layar × ${scaleLabel(sc)}"
        val w = m.groupValues[1].toInt(); val h = m.groupValues[2].toInt()
        return if (sc >= 100) "Resolusi asli  ${w}×${h}" else "Resolusi render  ${(w * sc / 100f).toInt()}×${(h * sc / 100f).toInt()}   (dari ${w}×${h})"
    }

    private fun openSheet(a: AppItem) {
        val sv = ScrollView(ctx); sv.setBackgroundColor(0xF2070A14.toInt()); sv.isVerticalScrollBarEnabled = false
        sv.isClickable = true
        val col = LinearLayout(ctx); col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(8), ctx.dpi(16), ctx.dpi(28))
        sv.addView(col, fl(-1, -2))

        val head = LinearLayout(ctx); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER_VERTICAL
        val back = ctx.text("‹", 34f, C.TEXT); back.setPadding(ctx.dpi(2), 0, ctx.dpi(16), ctx.dpi(4)); back.setOnClickListener { closeSheet() }
        head.addView(back)
        head.addView(roundIcon(ctx, a.pkg, 54, 16f), lp(ctx.dpi(54), ctx.dpi(54)))
        val nm = LinearLayout(ctx); nm.orientation = LinearLayout.VERTICAL
        nm.addView(ctx.text(a.label, 20f, C.TEXT, true).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
        nm.addView(ctx.text(a.pkg, 11f, C.SUB).also { it.maxLines = 1 })
        head.addView(nm, lp(0, -2, weight = 1f).also { it.leftMargin = ctx.dpi(14) })
        col.addView(head, lp(bottom = ctx.dpi(14)))

        var p = Store.profile(ctx, a.pkg)
        val log = ctx.text("", 11f, C.SUB); log.typeface = android.graphics.Typeface.MONOSPACE; log.setTextIsSelectable(true)

        fun group(title: String, hint: String, opts: List<Pair<String, String>>, cur: () -> String, set: (String) -> Unit) {
            val c = ctx.card()
            c.addView(ctx.label(title))
            if (hint.isNotEmpty()) c.addView(ctx.text(hint, 11f, C.SUB), lp(top = ctx.dpi(4)))
            val flow = LinearLayout(ctx); flow.orientation = LinearLayout.VERTICAL
            c.addView(flow, lp(top = ctx.dpi(10)))
            fun draw() {
                flow.removeAllViews()
                var rowL: LinearLayout? = null
                for ((i, o) in opts.withIndex()) {
                    if (i % 3 == 0) { rowL = LinearLayout(ctx); rowL.orientation = LinearLayout.HORIZONTAL; flow.addView(rowL, lp(bottom = ctx.dpi(8))) }
                    rowL!!.addView(ctx.chip(o.first, cur() == o.second) { set(o.second); draw() }, lp(-2, -2).also { it.rightMargin = ctx.dpi(8) })
                }
            }
            draw()
            col.addView(c, lp(bottom = ctx.dpi(12)))
        }

        // ----- Downscale: slider 1.0 … 0.3 -----
        run {
            val c = ctx.card()
            c.addView(ctx.label("Downscale resolusi"))
            val big = ctx.text("", 40f, C.TEXT, true)
            c.addView(big, lp(top = ctx.dpi(4)))
            val sub = ctx.text("", 12f, C.SUB)
            c.addView(sub)
            val sl = StepSlider(ctx, SCALES.size)
            fun upd() {
                big.text = if (p.scale >= 100) "1.0×  asli" else "${scaleLabel(p.scale)}×"
                big.setTextColor(if (p.scale >= 100) C.TEXT else C.CYAN)
                sub.text = resText(p.scale)
            }
            sl.setIndex(SCALES.indexOf(p.scale).coerceAtLeast(0), false)
            sl.onChange = { i -> p = p.copy(scale = SCALES[i]); upd() }
            upd()
            c.addView(sl, lp(top = ctx.dpi(6)))
            val ends = LinearLayout(ctx); ends.orientation = LinearLayout.HORIZONTAL
            ends.addView(ctx.text("1.0 asli", 10f, C.SUB), lp(0, -2, weight = 1f))
            ends.addView(ctx.text("0.3 paling kasar", 10f, C.SUB))
            c.addView(ends)
            c.addView(ctx.text("Hanya game ini. Butuh Android 13+ dan aplikasi terdaftar sebagai game.", 11f, C.SUB), lp(top = ctx.dpi(8)))
            col.addView(c, lp(bottom = ctx.dpi(12)))
        }

        group("Batas FPS", "", listOf("Bawaan" to "0", "30" to "30", "45" to "45", "60" to "60", "90" to "90", "120" to "120"),
            { p.fps.toString() }) { p = p.copy(fps = it.toInt()) }
        group("Game Mode", "", listOf("Bawaan" to "default", "Standar" to "standard", "Performa" to "performance", "Hemat" to "battery"),
            { p.mode }) { p = p.copy(mode = it) }
        group("Renderer grafis", "ANGLE = OpenGL ES di atas Vulkan. Hanya untuk game ini; tidak semua game/HP cocok.",
            listOf("Bawaan" to "default", "ANGLE" to "angle", "GL Native" to "native"),
            { p.renderer }) { p = p.copy(renderer = it) }
        group("Driver GPU", "Hanya game ini. Butuh paket driver yang tersedia di HP; kalau tidak ada, tidak ada efek.",
            listOf("Bawaan" to "default", "Driver sistem" to "system", "Driver update" to "production", "Pra-rilis" to "prerelease"),
            { p.driver }) { p = p.copy(driver = it) }

        val lc = ctx.card(); lc.addView(ctx.label("Log")); lc.addView(log, lp(top = ctx.dpi(4)))
        lc.visibility = View.GONE
        fun busy(msg: String) { log.text = msg; if (lc.visibility != View.VISIBLE) { lc.visibility = View.VISIBLE; lc.enter(0, 14f) } }

        fun doApply(launch: Boolean) {
            if (!Sh.granted()) { busy("Shizuku belum aktif / belum diberi izin."); return }
            Store.saveProfile(ctx, a.pkg, p)
            val s = Store.pinned(ctx); s.add(a.pkg); Store.setPinned(ctx, s)
            busy("Menerapkan…")
            Sh.bg {
                var out = Tweaks.apply(a.pkg, p, caps())
                if (launch) { Tweaks.launch(a.pkg); out += "\n› membuka ${a.label}" }
                mainHandler.post { busy(out + "\n\nSelesai. Game dihentikan paksa; buka ulang agar pengaturan dipakai.") }
            }
        }
        val btns = LinearLayout(ctx); btns.orientation = LinearLayout.HORIZONTAL
        btns.addView(ctx.button("Terapkan") { doApply(false) }, lp(0, -2, weight = 1f).also { it.rightMargin = ctx.dpi(10) })
        btns.addView(ctx.button("Terapkan & Buka") { doApply(true) }, lp(0, -2, weight = 1f))
        col.addView(btns, lp(bottom = ctx.dpi(10)))
        col.addView(ctx.button("Reset game ini ke bawaan", false) {
            if (!Sh.granted()) { busy("Shizuku belum aktif / belum diberi izin."); return@button }
            p = Profile(); Store.saveProfile(ctx, a.pkg, p)
            busy("Mereset…")
            Sh.bg { val o = Tweaks.reset(a.pkg, caps()); mainHandler.post { busy(o + "\n\nSudah kembali ke bawaan."); mainHandler.postDelayed({ closeSheet() }, 1300) } }
        }, lp(bottom = ctx.dpi(12)))
        col.addView(lc)

        sheet = sv
        frame.addView(sv, fl())
        sv.alpha = 0f
        sv.post {
            sv.translationY = sv.height * 0.10f
            sv.animate().alpha(1f).translationY(0f).setDuration(340).setInterpolator(DecelerateInterpolator(2f)).start()
            for (i in 0 until col.childCount) col.getChildAt(i).enter(60L + i * 45L, 22f)
        }
    }
}

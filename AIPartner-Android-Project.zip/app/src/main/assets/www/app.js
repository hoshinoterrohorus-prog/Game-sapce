var ai="188dev",Ei={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},Ti={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},rd=0,Gl=1,od=2;var Ar=1,ad=2,Ds=3,Si=0,qt=1,en=2,es=0,wr=1,zl=2,Wl=3,Xl=4,ld=5;var Us=100,cd=101,ud=102,hd=103,dd=104,fd=200,pd=201,md=202,gd=203,_d=204,xd=205,Md=206,yd=207,vd=208,Ed=209,Td=210,Sd=211,bd=212,Rd=213,Ad=214,wd=0,Cd=1,Pd=2,ql=3,Ld=4,Id=5,Nd=6,Dd=7,Ud=0,Od=1,Fd=2,Vn=0,Yl=1,Zl=2,jl=3,Jl=4,Kl=5,$l=6,Ql=7;var Cr=301,Os=302,$o=303,Qo=304,Fs=1000,Hs=1001,ea=1002,Pn=1003,ta=1004;var ts=1005;var Yt=1006,Bs=1007;var Ln=1008;var In=1009,Hd=1010,Bd=1011,Pr=1012,ec=1013,bi=1014,li=1015,kn=1016,tc=1017,nc=1018,ns=1020,Vd=35902,kd=35899,Gd=1021,zd=1022,ci=1023,Vs=1026,Ri=1027,Wd=1028,ic=1029,is=1030,sc=1031;var rc=1033,na=33776,ia=33777,sa=33778,ra=33779,oc=35840,ac=35841,lc=35842,cc=35843,uc=36196,hc=37492,dc=37496,fc=37488,pc=37489,oa=37490,mc=37491,gc=37808,_c=37809,xc=37810,Mc=37811,yc=37812,vc=37813,Ec=37814,Tc=37815,Sc=37816,bc=37817,Rc=37818,Ac=37819,wc=37820,Cc=37821,Pc=36492,Lc=36494,Ic=36495,Nc=36283,Dc=36284,aa=36285,Uc=36286;var Oc=2300,la=2301;var Fc=0,Lr=1,ks=2;var Ir=0,Xd=1,ss="",Nn="srgb",fn="srgb-linear",Hc="linear",ft="srgb";var qd=512,Yd=513,Zd=514,Bc=515,jd=516,Jd=517,Vc=518,kc=519;var Gc=35048;var zc="300 es",Wc=2000;function Rm(e){for(let t=e.length-1;t>=0;--t)if(e[t]>=65535)return!0;return!1}function Am(e){return ArrayBuffer.isView(e)&&!(e instanceof DataView)}function Is(e){return document.createElementNS("http://www.w3.org/1999/xhtml",e)}function Kd(){let e=Is("canvas");return e.style.display="block",e}var Mh={},Ns=null;function Rr(...e){let t="THREE."+e.shift();if(Ns)Ns("log",t,...e);else console.log(t,...e)}function $d(e){let t=e[0];if(typeof t==="string"&&t.startsWith("TSL:")){let n=e[1];if(n&&n.isStackTrace)e[0]+=" "+n.getLocation();else e[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return e}function we(...e){e=$d(e);let t="THREE."+e.shift();if(Ns)Ns("warn",t,...e);else{let n=e[0];if(n&&n.isStackTrace)console.warn(n.getError(t));else console.warn(t,...e)}}function He(...e){e=$d(e);let t="THREE."+e.shift();if(Ns)Ns("error",t,...e);else{let n=e[0];if(n&&n.isStackTrace)console.error(n.getError(t));else console.error(t,...e)}}function Ki(...e){let t=e.join(" ");if(t in Mh)return;Mh[t]=!0,we(...e)}function Qd(e,t,n){return new Promise(function(i,s){function r(){switch(e.clientWaitSync(t,e.SYNC_FLUSH_COMMANDS_BIT,0)){case e.WAIT_FAILED:s();break;case e.TIMEOUT_EXPIRED:setTimeout(r,n);break;default:i()}}setTimeout(r,n)})}var ef={[0]:0,[2]:6,[4]:4,[3]:5,[1]:1,[6]:2,[7]:7,[5]:3};class Gn{addEventListener(e,t){if(this._listeners===void 0)this._listeners={};let n=this._listeners;if(n[e]===void 0)n[e]=[];if(n[e].indexOf(t)===-1)n[e].push(t)}hasEventListener(e,t){let n=this._listeners;if(n===void 0)return!1;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){let n=this._listeners;if(n===void 0)return;let i=n[e];if(i!==void 0){let s=i.indexOf(t);if(s!==-1)i.splice(s,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let n=t[e.type];if(n!==void 0){e.target=this;let i=n.slice(0);for(let s=0,r=i.length;s<r;s++)i[s].call(this,e);e.target=null}}}var Wt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],yh=1234567,Sr=Math.PI/180,$i=180/Math.PI;function zn(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(Wt[e&255]+Wt[e>>8&255]+Wt[e>>16&255]+Wt[e>>24&255]+"-"+Wt[t&255]+Wt[t>>8&255]+"-"+Wt[t>>16&15|64]+Wt[t>>24&255]+"-"+Wt[n&63|128]+Wt[n>>8&255]+"-"+Wt[n>>16&255]+Wt[n>>24&255]+Wt[i&255]+Wt[i>>8&255]+Wt[i>>16&255]+Wt[i>>24&255]).toLowerCase()}function Ye(e,t,n){return Math.max(t,Math.min(n,e))}function Xc(e,t){return(e%t+t)%t}function wm(e,t,n,i,s){return i+(e-t)*(s-i)/(n-t)}function Cm(e,t,n){if(e!==t)return(n-e)/(t-e);else return 0}function br(e,t,n){return(1-n)*e+n*t}function Pm(e,t,n,i){return br(e,t,1-Math.exp(-n*i))}function Lm(e,t=1){return t-Math.abs(Xc(e,t*2)-t)}function Im(e,t,n){if(e<=t)return 0;if(e>=n)return 1;return e=(e-t)/(n-t),e*e*(3-2*e)}function Nm(e,t,n){if(e<=t)return 0;if(e>=n)return 1;return e=(e-t)/(n-t),e*e*e*(e*(e*6-15)+10)}function Dm(e,t){return e+Math.floor(Math.random()*(t-e+1))}function Um(e,t){return e+Math.random()*(t-e)}function Om(e){return e*(0.5-Math.random())}function Fm(e){if(e!==void 0)yh=e;let t=yh+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Hm(e){return e*Sr}function Bm(e){return e*$i}function Vm(e){return e>0&&Number.isInteger(e)&&2**Math.round(Math.log2(e))===e}function km(e){return Math.pow(2,Math.ceil(Math.log(e)/Math.LN2))}function qc(e){return Math.pow(2,Math.floor(Math.log(e)/Math.LN2))}function Gm(e,t,n,i,s){let{cos:r,sin:o}=Math,a=r(n/2),l=o(n/2),c=r((t+i)/2),u=o((t+i)/2),h=r((t-i)/2),d=o((t-i)/2),f=r((i-t)/2),m=o((i-t)/2);switch(s){case"XYX":e.set(a*u,l*h,l*d,a*c);break;case"YZY":e.set(l*d,a*u,l*h,a*c);break;case"ZXZ":e.set(l*h,l*d,a*u,a*c);break;case"XZX":e.set(a*u,l*m,l*f,a*c);break;case"YXY":e.set(l*f,a*u,l*m,a*c);break;case"ZYZ":e.set(l*m,l*f,a*u,a*c);break;default:we("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function ca(e){switch(e.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function Yc(e,t){if(t.constructor===Float32Array)return e;let n=ca(t);if(n===void 0)throw Error("THREE.MathUtils: Invalid component type.");return Math.max(e/n,-1)}function Zc(e,t){if(t.constructor===Float32Array)return e;let n=ca(t);if(n===void 0)throw Error("THREE.MathUtils: Invalid component type.");return Math.round(e*n)}var $e={DEG2RAD:Sr,RAD2DEG:$i,generateUUID:zn,clamp:Ye,euclideanModulo:Xc,mapLinear:wm,inverseLerp:Cm,lerp:br,damp:Pm,pingpong:Lm,smoothstep:Im,smootherstep:Nm,randInt:Dm,randFloat:Um,randFloatSpread:Om,seededRandom:Fm,degToRad:Hm,radToDeg:Bm,isPowerOfTwo:Vm,ceilPowerOfTwo:km,floorPowerOfTwo:qc,setQuaternionFromProperEuler:Gm,normalize:Zc,denormalize:Yc};class Ce{static{this.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6],this.y=i[1]*t+i[4]*n+i[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Ye(this.x,e.x,t.x),this.y=Ye(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Ye(this.x,e,t),this.y=Ye(this.y,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Ye(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(Ye(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),i=Math.sin(t),s=this.x-e.x,r=this.y-e.y;return this.x=s*n-r*i+e.x,this.y=s*i+r*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class be{constructor(e=0,t=0,n=0,i=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=i}static slerpFlat(e,t,n,i,s,r,o){let a=n[i+0],l=n[i+1],c=n[i+2],u=n[i+3],h=s[r+0],d=s[r+1],f=s[r+2],m=s[r+3];if(u!==m||a!==h||l!==d||c!==f){let x=a*h+l*d+c*f+u*m;if(x<0)h=-h,d=-d,f=-f,m=-m,x=-x;let p=1-o;if(x<0.9995){let g=Math.acos(x),v=Math.sin(g);p=Math.sin(p*g)/v,o=Math.sin(o*g)/v,a=a*p+h*o,l=l*p+d*o,c=c*p+f*o,u=u*p+m*o}else{a=a*p+h*o,l=l*p+d*o,c=c*p+f*o,u=u*p+m*o;let g=1/Math.sqrt(a*a+l*l+c*c+u*u);a*=g,l*=g,c*=g,u*=g}}e[t]=a,e[t+1]=l,e[t+2]=c,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,i,s,r){let o=n[i],a=n[i+1],l=n[i+2],c=n[i+3],u=s[r],h=s[r+1],d=s[r+2],f=s[r+3];return e[t]=o*f+c*u+a*d-l*h,e[t+1]=a*f+c*h+l*u-o*d,e[t+2]=l*f+c*d+o*h-a*u,e[t+3]=c*f-o*u-a*h-l*d,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,i){return this._x=e,this._y=t,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let{_x:n,_y:i,_z:s,_order:r}=e,{cos:o,sin:a}=Math,l=o(n/2),c=o(i/2),u=o(s/2),h=a(n/2),d=a(i/2),f=a(s/2);switch(r){case"XYZ":this._x=h*c*u+l*d*f,this._y=l*d*u-h*c*f,this._z=l*c*f+h*d*u,this._w=l*c*u-h*d*f;break;case"YXZ":this._x=h*c*u+l*d*f,this._y=l*d*u-h*c*f,this._z=l*c*f-h*d*u,this._w=l*c*u+h*d*f;break;case"ZXY":this._x=h*c*u-l*d*f,this._y=l*d*u+h*c*f,this._z=l*c*f+h*d*u,this._w=l*c*u-h*d*f;break;case"ZYX":this._x=h*c*u-l*d*f,this._y=l*d*u+h*c*f,this._z=l*c*f-h*d*u,this._w=l*c*u+h*d*f;break;case"YZX":this._x=h*c*u+l*d*f,this._y=l*d*u+h*c*f,this._z=l*c*f-h*d*u,this._w=l*c*u-h*d*f;break;case"XZY":this._x=h*c*u-l*d*f,this._y=l*d*u-h*c*f,this._z=l*c*f+h*d*u,this._w=l*c*u+h*d*f;break;default:we("Quaternion: .setFromEuler() encountered an unknown order: "+r)}if(t===!0)this._onChangeCallback();return this}setFromAxisAngle(e,t){let n=t/2,i=Math.sin(n);return this._x=e.x*i,this._y=e.y*i,this._z=e.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],i=t[4],s=t[8],r=t[1],o=t[5],a=t[9],l=t[2],c=t[6],u=t[10],h=n+o+u;if(h>0){let d=0.5/Math.sqrt(h+1);this._w=0.25/d,this._x=(c-a)*d,this._y=(s-l)*d,this._z=(r-i)*d}else if(n>o&&n>u){let d=2*Math.sqrt(1+n-o-u);this._w=(c-a)/d,this._x=0.25*d,this._y=(i+r)/d,this._z=(s+l)/d}else if(o>u){let d=2*Math.sqrt(1+o-n-u);this._w=(s-l)/d,this._x=(i+r)/d,this._y=0.25*d,this._z=(a+c)/d}else{let d=2*Math.sqrt(1+u-n-o);this._w=(r-i)/d,this._x=(s+l)/d,this._y=(a+c)/d,this._z=0.25*d}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;if(n<0.00000001)if(n=0,Math.abs(e.x)>Math.abs(e.z))this._x=-e.y,this._y=e.x,this._z=0,this._w=n;else this._x=0,this._y=-e.z,this._z=e.y,this._w=n;else this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n;return this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ye(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let i=Math.min(1,t/n);return this.slerp(e,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();if(e===0)this._x=0,this._y=0,this._z=0,this._w=1;else e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e;return this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let{_x:n,_y:i,_z:s,_w:r}=e,{_x:o,_y:a,_z:l,_w:c}=t;return this._x=n*c+r*o+i*l-s*a,this._y=i*c+r*a+s*o-n*l,this._z=s*c+r*l+n*a-i*o,this._w=r*c-n*o-i*a-s*l,this._onChangeCallback(),this}slerp(e,t){let{_x:n,_y:i,_z:s,_w:r}=e,o=this.dot(e);if(o<0)n=-n,i=-i,s=-s,r=-r,o=-o;let a=1-t;if(o<0.9995){let l=Math.acos(o),c=Math.sin(l);a=Math.sin(a*l)/c,t=Math.sin(t*l)/c,this._x=this._x*a+n*t,this._y=this._y*a+i*t,this._z=this._z*a+s*t,this._w=this._w*a+r*t,this._onChangeCallback()}else this._x=this._x*a+n*t,this._y=this._y*a+i*t,this._z=this._z*a+s*t,this._w=this._w*a+r*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(i*Math.sin(e),i*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class R{static{this.prototype.isVector3=!0}constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){if(n===void 0)n=this.z;return this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(vh.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(vh.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*i,this.y=s[1]*t+s[4]*n+s[7]*i,this.z=s[2]*t+s[5]*n+s[8]*i,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,i=this.z,s=e.elements,r=1/(s[3]*t+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*i+s[12])*r,this.y=(s[1]*t+s[5]*n+s[9]*i+s[13])*r,this.z=(s[2]*t+s[6]*n+s[10]*i+s[14])*r,this}applyQuaternion(e){let t=this.x,n=this.y,i=this.z,{x:s,y:r,z:o,w:a}=e,l=2*(r*i-o*n),c=2*(o*t-s*i),u=2*(s*n-r*t);return this.x=t+a*l+r*u-o*c,this.y=n+a*c+o*l-s*u,this.z=i+a*u+s*c-r*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*i,this.y=s[1]*t+s[5]*n+s[9]*i,this.z=s[2]*t+s[6]*n+s[10]*i,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Ye(this.x,e.x,t.x),this.y=Ye(this.y,e.y,t.y),this.z=Ye(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Ye(this.x,e,t),this.y=Ye(this.y,e,t),this.z=Ye(this.z,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Ye(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let{x:n,y:i,z:s}=e,{x:r,y:o,z:a}=t;return this.x=i*a-s*o,this.y=s*r-n*a,this.z=n*o-i*r,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return _l.copy(this).projectOnVector(e),this.sub(_l)}reflect(e){return this.sub(_l.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(Ye(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,i=this.z-e.z;return t*t+n*n+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let i=Math.sin(t)*e;return this.x=i*Math.sin(n),this.y=Math.cos(t)*e,this.z=i*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),i=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=i,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}var _l=new R,vh=new be;class Pe{static{this.prototype.isMatrix3=!0}constructor(e,t,n,i,s,r,o,a,l){if(this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0)this.set(e,t,n,i,s,r,o,a,l)}set(e,t,n,i,s,r,o,a,l){let c=this.elements;return c[0]=e,c[1]=i,c[2]=o,c[3]=t,c[4]=s,c[5]=a,c[6]=n,c[7]=r,c[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,i=t.elements,s=this.elements,r=n[0],o=n[3],a=n[6],l=n[1],c=n[4],u=n[7],h=n[2],d=n[5],f=n[8],m=i[0],x=i[3],p=i[6],g=i[1],v=i[4],S=i[7],T=i[2],A=i[5],w=i[8];return s[0]=r*m+o*g+a*T,s[3]=r*x+o*v+a*A,s[6]=r*p+o*S+a*w,s[1]=l*m+c*g+u*T,s[4]=l*x+c*v+u*A,s[7]=l*p+c*S+u*w,s[2]=h*m+d*g+f*T,s[5]=h*x+d*v+f*A,s[8]=h*p+d*S+f*w,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],r=e[4],o=e[5],a=e[6],l=e[7],c=e[8];return t*r*c-t*o*l-n*s*c+n*o*a+i*s*l-i*r*a}invert(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],r=e[4],o=e[5],a=e[6],l=e[7],c=e[8],u=c*r-o*l,h=o*a-c*s,d=l*s-r*a,f=t*u+n*h+i*d;if(f===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/f;return e[0]=u*m,e[1]=(i*l-c*n)*m,e[2]=(o*n-i*r)*m,e[3]=h*m,e[4]=(c*t-i*a)*m,e[5]=(i*s-o*t)*m,e[6]=d*m,e[7]=(n*a-l*t)*m,e[8]=(r*t-n*s)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,i,s,r,o){let a=Math.cos(s),l=Math.sin(s);return this.set(n*a,n*l,-n*(a*r+l*o)+r+e,-i*l,i*a,-i*(-l*r+a*o)+o+t,0,0,1),this}scale(e,t){return Ki("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(xl.makeScale(e,t)),this}rotate(e){return Ki("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(xl.makeRotation(-e)),this}translate(e,t){return Ki("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(xl.makeTranslation(e,t)),this}makeTranslation(e,t){if(e.isVector2)this.set(1,0,e.x,0,1,e.y,0,0,1);else this.set(1,0,e,0,1,t,0,0,1);return this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let i=0;i<9;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}var xl=new Pe,Eh=new Pe().set(0.4123908,0.3575843,0.1804808,0.212639,0.7151687,0.0721923,0.0193308,0.1191948,0.9505322),Th=new Pe().set(3.2409699,-1.5373832,-0.4986108,-0.9692436,1.8759675,0.0415551,0.0556301,-0.203977,1.0569715);function zm(){let e={enabled:!0,workingColorSpace:"srgb-linear",spaces:{},convert:function(s,r,o){if(this.enabled===!1||r===o||!r||!o)return s;if(this.spaces[r].transfer==="srgb")s.r=oi(s.r),s.g=oi(s.g),s.b=oi(s.b);if(this.spaces[r].primaries!==this.spaces[o].primaries)s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[o].fromXYZ);if(this.spaces[o].transfer==="srgb")s.r=Ls(s.r),s.g=Ls(s.g),s.b=Ls(s.b);return s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){if(s==="")return"linear";return this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,o){return s.copy(this.spaces[o].fromXYZ).multiply(this.spaces[r].toXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace}},t=[0.64,0.33,0.3,0.6,0.15,0.06],n=[0.2126,0.7152,0.0722],i=[0.3127,0.329];return e.define({["srgb-linear"]:{primaries:t,whitePoint:i,transfer:"linear",toXYZ:Eh,fromXYZ:Th,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:"srgb"},outputColorSpaceConfig:{drawingBufferColorSpace:"srgb"}},["srgb"]:{primaries:t,whitePoint:i,transfer:"srgb",toXYZ:Eh,fromXYZ:Th,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:"srgb"}}}),e}var qe=zm();function oi(e){return e<0.04045?e*0.0773993808:Math.pow(e*0.9478672986+0.0521327014,2.4)}function Ls(e){return e<0.0031308?e*12.92:1.055*Math.pow(e,0.41666)-0.055}var _s;class jc{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src))return e.src;if(typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{if(_s===void 0)_s=Is("canvas");_s.width=e.width,_s.height=e.height;let i=_s.getContext("2d");if(e instanceof ImageData)i.putImageData(e,0,0);else i.drawImage(e,0,0,e.width,e.height);n=_s}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=Is("canvas");t.width=e.width,t.height=e.height;let n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);let i=n.getImageData(0,0,e.width,e.height),s=i.data;for(let r=0;r<s.length;r++)s[r]=oi(s[r]/255)*255;return n.putImageData(i,0,0),t}else if(e.data){let t=e.data.slice(0);for(let n=0;n<t.length;n++)if(t instanceof Uint8Array||t instanceof Uint8ClampedArray)t[n]=Math.floor(oi(t[n]/255)*255);else t[n]=oi(t[n]);return{data:t,width:e.width,height:e.height}}else return we("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}var Wm=0;class Nr{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Wm++}),this.uuid=zn(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;if(typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement)e.set(t.videoWidth,t.videoHeight,0);else if(typeof VideoFrame<"u"&&t instanceof VideoFrame)e.set(t.displayWidth,t.displayHeight,0);else if(t!==null)e.set(t.width||0,t.height||0,t.depth||0);else e.set(0,0,0);return e}set needsUpdate(e){if(e===!0)this.version++}toJSON(e){let t=e===void 0||typeof e==="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let r=0,o=i.length;r<o;r++)if(i[r].isDataTexture)s.push(Ml(i[r].image));else s.push(Ml(i[r]))}else s=Ml(i);n.url=s}if(!t)e.images[this.uuid]=n;return n}}function Ml(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap)return jc.getDataURL(e);else if(e.data)return{data:Array.from(e.data),width:e.width,height:e.height,type:e.data.constructor.name};else return we("Texture: Unable to serialize Texture."),{}}var Xm=0,yl=new R;class vt extends Gn{constructor(e=vt.DEFAULT_IMAGE,t=vt.DEFAULT_MAPPING,n=1001,i=1001,s=1006,r=1008,o=1023,a=1009,l=vt.DEFAULT_ANISOTROPY,c=""){super();this.isTexture=!0,Object.defineProperty(this,"id",{value:Xm++}),this.uuid=zn(),this.name="",this.source=new Nr(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=r,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=a,this.offset=new Ce(0,0),this.repeat=new Ce(1,1),this.center=new Ce(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Pe,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=c,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=e&&e.depth&&e.depth>1?!0:!1,this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(yl).x}get height(){return this.source.getSize(yl).y}get depth(){return this.source.getSize(yl).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.mipmapsAutoUpdate=e.mipmapsAutoUpdate,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isPMREMTexture=e.isPMREMTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let n=e[t];if(n===void 0){we(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let i=this[t];if(i===void 0){we(`Texture.setValues(): property '${t}' does not exist.`);continue}if(i&&n&&(i.isVector2&&n.isVector2))i.copy(n);else if(i&&n&&(i.isVector3&&n.isVector3))i.copy(n);else if(i&&n&&(i.isMatrix3&&n.isMatrix3))i.copy(n);else this[t]=n}}toJSON(e){let t=e===void 0||typeof e==="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};if(Object.keys(this.userData).length>0)n.userData=this.userData;if(!t)e.textures[this.uuid]=n;return n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==300)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case 1000:e.x=e.x-Math.floor(e.x);break;case 1001:e.x=e.x<0?0:1;break;case 1002:if(Math.abs(Math.floor(e.x)%2)===1)e.x=Math.ceil(e.x)-e.x;else e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case 1000:e.y=e.y-Math.floor(e.y);break;case 1001:e.y=e.y<0?0:1;break;case 1002:if(Math.abs(Math.floor(e.y)%2)===1)e.y=Math.ceil(e.y)-e.y;else e.y=e.y-Math.floor(e.y);break}if(this.flipY)e.y=1-e.y;return e}set needsUpdate(e){if(e===!0)this.version++,this.source.needsUpdate=!0}set needsPMREMUpdate(e){if(e===!0)this.pmremVersion++}}vt.DEFAULT_IMAGE=null;vt.DEFAULT_MAPPING=300;vt.DEFAULT_ANISOTROPY=1;class ut{static{this.prototype.isVector4=!0}constructor(e=0,t=0,n=0,i=1){this.x=e,this.y=t,this.z=n,this.w=i}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,i){return this.x=e,this.y=t,this.z=n,this.w=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,i=this.z,s=this.w,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*i+r[12]*s,this.y=r[1]*t+r[5]*n+r[9]*i+r[13]*s,this.z=r[2]*t+r[6]*n+r[10]*i+r[14]*s,this.w=r[3]*t+r[7]*n+r[11]*i+r[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);if(t<0.0001)this.x=1,this.y=0,this.z=0;else this.x=e.x/t,this.y=e.y/t,this.z=e.z/t;return this}setAxisAngleFromRotationMatrix(e){let t,n,i,s,r=0.01,o=0.1,a=e.elements,l=a[0],c=a[4],u=a[8],h=a[1],d=a[5],f=a[9],m=a[2],x=a[6],p=a[10];if(Math.abs(c-h)<0.01&&Math.abs(u-m)<0.01&&Math.abs(f-x)<0.01){if(Math.abs(c+h)<0.1&&Math.abs(u+m)<0.1&&Math.abs(f+x)<0.1&&Math.abs(l+d+p-3)<0.1)return this.set(1,0,0,0),this;t=Math.PI;let v=(l+1)/2,S=(d+1)/2,T=(p+1)/2,A=(c+h)/4,w=(u+m)/4,_=(f+x)/4;if(v>S&&v>T)if(v<0.01)n=0,i=0.707106781,s=0.707106781;else n=Math.sqrt(v),i=A/n,s=w/n;else if(S>T)if(S<0.01)n=0.707106781,i=0,s=0.707106781;else i=Math.sqrt(S),n=A/i,s=_/i;else if(T<0.01)n=0.707106781,i=0.707106781,s=0;else s=Math.sqrt(T),n=w/s,i=_/s;return this.set(n,i,s,t),this}let g=Math.sqrt((x-f)*(x-f)+(u-m)*(u-m)+(h-c)*(h-c));if(Math.abs(g)<0.001)g=1;return this.x=(x-f)/g,this.y=(u-m)/g,this.z=(h-c)/g,this.w=Math.acos((l+d+p-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Ye(this.x,e.x,t.x),this.y=Ye(this.y,e.y,t.y),this.z=Ye(this.z,e.z,t.z),this.w=Ye(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Ye(this.x,e,t),this.y=Ye(this.y,e,t),this.z=Ye(this.z,e,t),this.w=Ye(this.w,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Ye(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Jc extends Gn{constructor(e=1,t=1,n={}){super();n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:1006,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new ut(0,0,e,t),this.scissorTest=!1,this.viewport=new ut(0,0,e,t),this.textures=[];let i=n.count;for(let s=0;s<i;s++)this.textures[s]=new vt({width:e,height:t,depth:n.depth}),this.textures[s].isRenderTargetTexture=!0,this.textures[s].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){let t={minFilter:1006,generateMipmaps:!1,flipY:!1,internalFormat:null};if(e.mapping!==void 0)t.mapping=e.mapping;if(e.wrapS!==void 0)t.wrapS=e.wrapS;if(e.wrapT!==void 0)t.wrapT=e.wrapT;if(e.wrapR!==void 0)t.wrapR=e.wrapR;if(e.magFilter!==void 0)t.magFilter=e.magFilter;if(e.minFilter!==void 0)t.minFilter=e.minFilter;if(e.format!==void 0)t.format=e.format;if(e.type!==void 0)t.type=e.type;if(e.anisotropy!==void 0)t.anisotropy=e.anisotropy;if(e.colorSpace!==void 0)t.colorSpace=e.colorSpace;if(e.flipY!==void 0)t.flipY=e.flipY;if(e.generateMipmaps!==void 0)t.generateMipmaps=e.generateMipmaps;if(e.mipmapsAutoUpdate!==void 0)t.mipmapsAutoUpdate=e.mipmapsAutoUpdate;if(e.internalFormat!==void 0)t.internalFormat=e.internalFormat;for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){if(this._depthTexture!==null&&this._depthTexture.renderTarget===this)this._depthTexture.renderTarget=null;if(e!==null&&e.renderTarget===null)e.renderTarget=this;this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let i=0,s=this.textures.length;i<s;i++)if(this.textures[i].image.width=e,this.textures[i].image.height=t,this.textures[i].image.depth=n,this.textures[i].isData3DTexture!==!0)this.textures[i].isArrayTexture=this.textures[i].image.depth>1;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;let i=Object.assign({},e.textures[t].image);this.textures[t].source=new Nr(i)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){let t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;else this.depthTexture=null;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Mn extends Jc{constructor(e=1,t=1,n={}){super(e,t,n);this.isWebGLRenderTarget=!0}}class ua extends vt{constructor(e=null,t=1,n=1,i=1){super(null);this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:i},this.magFilter=1003,this.minFilter=1003,this.wrapR=1001,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Kc extends vt{constructor(e=null,t=1,n=1,i=1){super(null);this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:i},this.magFilter=1003,this.minFilter=1003,this.wrapR=1001,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}}class Re{static{this.prototype.isMatrix4=!0}constructor(e,t,n,i,s,r,o,a,l,c,u,h,d,f,m,x){if(this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0)this.set(e,t,n,i,s,r,o,a,l,c,u,h,d,f,m,x)}set(e,t,n,i,s,r,o,a,l,c,u,h,d,f,m,x){let p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=i,p[1]=s,p[5]=r,p[9]=o,p[13]=a,p[2]=l,p[6]=c,p[10]=u,p[14]=h,p[3]=d,p[7]=f,p[11]=m,p[15]=x,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Re().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){if(this.determinantAffine()===0)return e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this;return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,n=e.elements,i=1/xs.setFromMatrixColumn(e,0).length(),s=1/xs.setFromMatrixColumn(e,1).length(),r=1/xs.setFromMatrixColumn(e,2).length();return t[0]=n[0]*i,t[1]=n[1]*i,t[2]=n[2]*i,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*r,t[9]=n[9]*r,t[10]=n[10]*r,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,{x:n,y:i,z:s}=e,r=Math.cos(n),o=Math.sin(n),a=Math.cos(i),l=Math.sin(i),c=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){let h=r*c,d=r*u,f=o*c,m=o*u;t[0]=a*c,t[4]=-a*u,t[8]=l,t[1]=d+f*l,t[5]=h-m*l,t[9]=-o*a,t[2]=m-h*l,t[6]=f+d*l,t[10]=r*a}else if(e.order==="YXZ"){let h=a*c,d=a*u,f=l*c,m=l*u;t[0]=h+m*o,t[4]=f*o-d,t[8]=r*l,t[1]=r*u,t[5]=r*c,t[9]=-o,t[2]=d*o-f,t[6]=m+h*o,t[10]=r*a}else if(e.order==="ZXY"){let h=a*c,d=a*u,f=l*c,m=l*u;t[0]=h-m*o,t[4]=-r*u,t[8]=f+d*o,t[1]=d+f*o,t[5]=r*c,t[9]=m-h*o,t[2]=-r*l,t[6]=o,t[10]=r*a}else if(e.order==="ZYX"){let h=r*c,d=r*u,f=o*c,m=o*u;t[0]=a*c,t[4]=f*l-d,t[8]=h*l+m,t[1]=a*u,t[5]=m*l+h,t[9]=d*l-f,t[2]=-l,t[6]=o*a,t[10]=r*a}else if(e.order==="YZX"){let h=r*a,d=r*l,f=o*a,m=o*l;t[0]=a*c,t[4]=m-h*u,t[8]=f*u+d,t[1]=u,t[5]=r*c,t[9]=-o*c,t[2]=-l*c,t[6]=d*u+f,t[10]=h-m*u}else if(e.order==="XZY"){let h=r*a,d=r*l,f=o*a,m=o*l;t[0]=a*c,t[4]=-u,t[8]=l*c,t[1]=h*u+m,t[5]=r*c,t[9]=d*u-f,t[2]=f*u-d,t[6]=o*c,t[10]=m*u+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(qm,e,Ym)}lookAt(e,t,n){let i=this.elements;if(hn.subVectors(e,t),hn.lengthSq()===0)hn.z=1;if(hn.normalize(),mi.crossVectors(n,hn),mi.lengthSq()===0){if(Math.abs(n.z)===1)hn.x+=0.0001;else hn.z+=0.0001;hn.normalize(),mi.crossVectors(n,hn)}return mi.normalize(),bo.crossVectors(hn,mi),i[0]=mi.x,i[4]=bo.x,i[8]=hn.x,i[1]=mi.y,i[5]=bo.y,i[9]=hn.y,i[2]=mi.z,i[6]=bo.z,i[10]=hn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,i=t.elements,s=this.elements,r=n[0],o=n[4],a=n[8],l=n[12],c=n[1],u=n[5],h=n[9],d=n[13],f=n[2],m=n[6],x=n[10],p=n[14],g=n[3],v=n[7],S=n[11],T=n[15],A=i[0],w=i[4],_=i[8],E=i[12],I=i[1],k=i[5],N=i[9],V=i[13],Q=i[2],C=i[6],q=i[10],j=i[14],F=i[3],re=i[7],W=i[11],J=i[15];return s[0]=r*A+o*I+a*Q+l*F,s[4]=r*w+o*k+a*C+l*re,s[8]=r*_+o*N+a*q+l*W,s[12]=r*E+o*V+a*j+l*J,s[1]=c*A+u*I+h*Q+d*F,s[5]=c*w+u*k+h*C+d*re,s[9]=c*_+u*N+h*q+d*W,s[13]=c*E+u*V+h*j+d*J,s[2]=f*A+m*I+x*Q+p*F,s[6]=f*w+m*k+x*C+p*re,s[10]=f*_+m*N+x*q+p*W,s[14]=f*E+m*V+x*j+p*J,s[3]=g*A+v*I+S*Q+T*F,s[7]=g*w+v*k+S*C+T*re,s[11]=g*_+v*N+S*q+T*W,s[15]=g*E+v*V+S*j+T*J,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],i=e[8],s=e[12],r=e[1],o=e[5],a=e[9],l=e[13],c=e[2],u=e[6],h=e[10],d=e[14],f=e[3],m=e[7],x=e[11],p=e[15],g=a*d-l*h,v=o*d-l*u,S=o*h-a*u,T=r*d-l*c,A=r*h-a*c,w=r*u-o*c;return t*(m*g-x*v+p*S)-n*(f*g-x*T+p*A)+i*(f*v-m*T+p*w)-s*(f*S-m*A+x*w)}determinantAffine(){let e=this.elements,t=e[0],n=e[4],i=e[8],s=e[1],r=e[5],o=e[9],a=e[2],l=e[6],c=e[10];return t*(r*c-o*l)-n*(s*c-o*a)+i*(s*l-r*a)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let i=this.elements;if(e.isVector3)i[12]=e.x,i[13]=e.y,i[14]=e.z;else i[12]=e,i[13]=t,i[14]=n;return this}invert(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],r=e[4],o=e[5],a=e[6],l=e[7],c=e[8],u=e[9],h=e[10],d=e[11],f=e[12],m=e[13],x=e[14],p=e[15],g=t*o-n*r,v=t*a-i*r,S=t*l-s*r,T=n*a-i*o,A=n*l-s*o,w=i*l-s*a,_=c*m-u*f,E=c*x-h*f,I=c*p-d*f,k=u*x-h*m,N=u*p-d*m,V=h*p-d*x,Q=g*V-v*N+S*k+T*I-A*E+w*_;if(Q===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let C=1/Q;return e[0]=(o*V-a*N+l*k)*C,e[1]=(i*N-n*V-s*k)*C,e[2]=(m*w-x*A+p*T)*C,e[3]=(h*A-u*w-d*T)*C,e[4]=(a*I-r*V-l*E)*C,e[5]=(t*V-i*I+s*E)*C,e[6]=(x*S-f*w-p*v)*C,e[7]=(c*w-h*S+d*v)*C,e[8]=(r*N-o*I+l*_)*C,e[9]=(n*I-t*N-s*_)*C,e[10]=(f*A-m*S+p*g)*C,e[11]=(u*S-c*A-d*g)*C,e[12]=(o*E-r*k-a*_)*C,e[13]=(t*k-n*E+i*_)*C,e[14]=(m*v-f*T-x*g)*C,e[15]=(c*T-u*v+h*g)*C,this}scale(e){let t=this.elements,{x:n,y:i,z:s}=e;return t[0]*=n,t[4]*=i,t[8]*=s,t[1]*=n,t[5]*=i,t[9]*=s,t[2]*=n,t[6]*=i,t[10]*=s,t[3]*=n,t[7]*=i,t[11]*=s,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],i=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,i))}makeTranslation(e,t,n){if(e.isVector3)this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1);else this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1);return this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),i=Math.sin(t),s=1-n,{x:r,y:o,z:a}=e,l=s*r,c=s*o;return this.set(l*r+n,l*o-i*a,l*a+i*o,0,l*o+i*a,c*o+n,c*a-i*r,0,l*a-i*o,c*a+i*r,s*a*a+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,i,s,r){return this.set(1,n,s,0,e,1,r,0,t,i,1,0,0,0,0,1),this}compose(e,t,n){let i=this.elements,{_x:s,_y:r,_z:o,_w:a}=t,l=s+s,c=r+r,u=o+o,h=s*l,d=s*c,f=s*u,m=r*c,x=r*u,p=o*u,g=a*l,v=a*c,S=a*u,{x:T,y:A,z:w}=n;return i[0]=(1-(m+p))*T,i[1]=(d+S)*T,i[2]=(f-v)*T,i[3]=0,i[4]=(d-S)*A,i[5]=(1-(h+p))*A,i[6]=(x+g)*A,i[7]=0,i[8]=(f+v)*w,i[9]=(x-g)*w,i[10]=(1-(h+m))*w,i[11]=0,i[12]=e.x,i[13]=e.y,i[14]=e.z,i[15]=1,this}decompose(e,t,n){let i=this.elements;e.x=i[12],e.y=i[13],e.z=i[14];let s=this.determinantAffine();if(s===0)return n.set(1,1,1),t.identity(),this;let r=xs.set(i[0],i[1],i[2]).length(),o=xs.set(i[4],i[5],i[6]).length(),a=xs.set(i[8],i[9],i[10]).length();if(s<0)r=-r;An.copy(this);let l=1/r,c=1/o,u=1/a;return An.elements[0]*=l,An.elements[1]*=l,An.elements[2]*=l,An.elements[4]*=c,An.elements[5]*=c,An.elements[6]*=c,An.elements[8]*=u,An.elements[9]*=u,An.elements[10]*=u,t.setFromRotationMatrix(An),n.x=r,n.y=o,n.z=a,this}makePerspective(e,t,n,i,s,r,o=2000,a=!1){let l=this.elements,c=2*s/(t-e),u=2*s/(n-i),h=(t+e)/(t-e),d=(n+i)/(n-i),f,m;if(a)f=s/(r-s),m=r*s/(r-s);else if(o===2000)f=-(r+s)/(r-s),m=-2*r*s/(r-s);else if(o===2001)f=-r/(r-s),m=-r*s/(r-s);else throw Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=h,l[12]=0,l[1]=0,l[5]=u,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=m,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,i,s,r,o=2000,a=!1){let l=this.elements,c=2/(t-e),u=2/(n-i),h=-(t+e)/(t-e),d=-(n+i)/(n-i),f,m;if(a)f=1/(r-s),m=r/(r-s);else if(o===2000)f=-2/(r-s),m=-(r+s)/(r-s);else if(o===2001)f=-1/(r-s),m=-s/(r-s);else throw Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=0,l[12]=h,l[1]=0,l[5]=u,l[9]=0,l[13]=d,l[2]=0,l[6]=0,l[10]=f,l[14]=m,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let i=0;i<16;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}var xs=new R,An=new Re,qm=new R(0,0,0),Ym=new R(1,1,1),mi=new R,bo=new R,hn=new R,Sh=new Re,bh=new be;class Ht{constructor(e=0,t=0,n=0,i=Ht.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,i=this._order){return this._x=e,this._y=t,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let i=e.elements,s=i[0],r=i[4],o=i[8],a=i[1],l=i[5],c=i[9],u=i[2],h=i[6],d=i[10];switch(t){case"XYZ":if(this._y=Math.asin(Ye(o,-1,1)),Math.abs(o)<0.9999999)this._x=Math.atan2(-c,d),this._z=Math.atan2(-r,s);else this._x=Math.atan2(h,l),this._z=0;break;case"YXZ":if(this._x=Math.asin(-Ye(c,-1,1)),Math.abs(c)<0.9999999)this._y=Math.atan2(o,d),this._z=Math.atan2(a,l);else this._y=Math.atan2(-u,s),this._z=0;break;case"ZXY":if(this._x=Math.asin(Ye(h,-1,1)),Math.abs(h)<0.9999999)this._y=Math.atan2(-u,d),this._z=Math.atan2(-r,l);else this._y=0,this._z=Math.atan2(a,s);break;case"ZYX":if(this._y=Math.asin(-Ye(u,-1,1)),Math.abs(u)<0.9999999)this._x=Math.atan2(h,d),this._z=Math.atan2(a,s);else this._x=0,this._z=Math.atan2(-r,l);break;case"YZX":if(this._z=Math.asin(Ye(a,-1,1)),Math.abs(a)<0.9999999)this._x=Math.atan2(-c,l),this._y=Math.atan2(-u,s);else this._x=0,this._y=Math.atan2(o,d);break;case"XZY":if(this._z=Math.asin(-Ye(r,-1,1)),Math.abs(r)<0.9999999)this._x=Math.atan2(h,l),this._y=Math.atan2(o,s);else this._x=Math.atan2(-c,d),this._y=0;break;default:we("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}if(this._order=t,n===!0)this._onChangeCallback();return this}setFromQuaternion(e,t,n){return Sh.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Sh,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return bh.setFromEuler(this),this.setFromQuaternion(bh,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){if(this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0)this._order=e[3];return this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Ht.DEFAULT_ORDER="XYZ";class ha{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}var Zm=0,Rh=new R,Ms=new be,ei=new Re,Ro=new R,mr=new R,jm=new R,Jm=new be,Ah=new R(1,0,0),wh=new R(0,1,0),Ch=new R(0,0,1),Ph={type:"added"},Km={type:"removed"},ys={type:"childadded",child:null},vl={type:"childremoved",child:null};class tt extends Gn{constructor(){super();this.isObject3D=!0,Object.defineProperty(this,"id",{value:Zm++}),this.uuid=zn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=tt.DEFAULT_UP.clone();let e=new R,t=new Ht,n=new be,i=new R(1,1,1);function s(){n.setFromEuler(t,!1)}function r(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(r),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Re},normalMatrix:{value:new Pe}}),this.matrix=new Re,this.matrixWorld=new Re,this.matrixAutoUpdate=tt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=tt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ha,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){if(this.matrixAutoUpdate)this.updateMatrix();if(this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null)this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Ms.setFromAxisAngle(e,t),this.quaternion.multiply(Ms),this}rotateOnWorldAxis(e,t){return Ms.setFromAxisAngle(e,t),this.quaternion.premultiply(Ms),this}rotateX(e){return this.rotateOnAxis(Ah,e)}rotateY(e){return this.rotateOnAxis(wh,e)}rotateZ(e){return this.rotateOnAxis(Ch,e)}translateOnAxis(e,t){return Rh.copy(e).applyQuaternion(this.quaternion),this.position.add(Rh.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Ah,e)}translateY(e){return this.translateOnAxis(wh,e)}translateZ(e){return this.translateOnAxis(Ch,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ei.copy(this.matrixWorld).invert())}lookAt(e,t,n){if(e.isVector3)Ro.copy(e);else Ro.set(e,t,n);let i=this.parent;if(this.updateWorldMatrix(!0,!1),mr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight)ei.lookAt(mr,Ro,this.up);else ei.lookAt(Ro,mr,this.up);if(this.quaternion.setFromRotationMatrix(ei),i)ei.extractRotation(i.matrixWorld),Ms.setFromRotationMatrix(ei),this.quaternion.premultiply(Ms.invert())}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}if(e===this)return He("Object3D.add: object can't be added as a child of itself.",e),this;if(e&&e.isObject3D)e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Ph),ys.child=e,this.dispatchEvent(ys),ys.child=null;else He("Object3D.add: object not an instance of THREE.Object3D.",e);return this}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let t=this.children.indexOf(e);if(t!==-1)e.parent=null,this.children.splice(t,1),e.dispatchEvent(Km),vl.child=e,this.dispatchEvent(vl),vl.child=null;return this}removeFromParent(){let e=this.parent;if(e!==null)e.remove(this);return this}clear(){return this.remove(...this.children)}attach(e){if(this.updateWorldMatrix(!0,!1),ei.copy(this.matrixWorld).invert(),e.parent!==null)e.parent.updateWorldMatrix(!0,!1),ei.multiply(e.parent.matrixWorld);return e.applyMatrix4(ei),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Ph),ys.child=e,this.dispatchEvent(ys),ys.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,i=this.children.length;n<i;n++){let r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}return}getObjectsByProperty(e,t,n=[]){if(this[e]===t)n.push(this);let i=this.children;for(let s=0,r=i.length;s<r;s++)i[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(mr,e,jm),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(mr,Jm,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(e){e(this);let t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;if(t!==null)e(t),t.traverseAncestors(e)}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let{x:t,y:n,z:i}=e,s=this.matrix.elements;s[12]+=t-s[0]*t-s[4]*n-s[8]*i,s[13]+=n-s[1]*t-s[5]*n-s[9]*i,s[14]+=i-s[2]*t-s[6]*n-s[10]*i}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){if(this.matrixAutoUpdate)this.updateMatrix();if(this.matrixWorldNeedsUpdate||e){if(this.matrixWorldAutoUpdate===!0)if(this.parent===null)this.matrixWorld.copy(this.matrix);else this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix);this.matrixWorldNeedsUpdate=!1,e=!0}let t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){let i=this.parent;if(e===!0&&i!==null)i.updateWorldMatrix(!0,!1);if(this.matrixAutoUpdate)this.updateMatrix();if(this.matrixWorldNeedsUpdate||n){if(this.matrixWorldAutoUpdate===!0)if(this.parent===null)this.matrixWorld.copy(this.matrix);else this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix);this.matrixWorldNeedsUpdate=!1,n=!0}if(t===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0,n)}}toJSON(e){let t=e===void 0||typeof e==="string",n={};if(t)e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"};let i={};if(i.uuid=this.uuid,i.type=this.type,i.name=this.name,i.castShadow=this.castShadow,i.receiveShadow=this.receiveShadow,i.visible=this.visible,i.frustumCulled=this.frustumCulled,i.renderOrder=this.renderOrder,i.static=this.static,i.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0)i.userData=this.userData;if(i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.pivot!==null)i.pivot=this.pivot.toArray();if(this.morphTargetDictionary!==void 0)i.morphTargetDictionary=Object.assign({},this.morphTargetDictionary);if(this.morphTargetInfluences!==void 0)i.morphTargetInfluences=this.morphTargetInfluences.slice();if(this.isInstancedMesh){if(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null)i.instanceColor=this.instanceColor.toJSON()}if(this.isBatchedMesh){if(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.geometryInfo=this._geometryInfo.map((o)=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),i.instanceInfo=this._instanceInfo.map((o)=>({...o})),i.availableInstanceIds=this._availableInstanceIds.slice(),i.availableGeometryIds=this._availableGeometryIds.slice(),i.nextIndexStart=this._nextIndexStart,i.nextVertexStart=this._nextVertexStart,i.geometryCount=this._geometryCount,i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.matricesTexture=this._matricesTexture.toJSON(e),i.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null)i.colorsTexture=this._colorsTexture.toJSON(e);if(this.boundingSphere!==null)i.boundingSphere=this.boundingSphere.toJSON();if(this.boundingBox!==null)i.boundingBox=this.boundingBox.toJSON()}function s(o,a){if(o[a.uuid]===void 0)o[a.uuid]=a.toJSON(e);return a.uuid}if(this.isScene){if(this.background){if(this.background.isColor)i.background=this.background.toJSON();else if(this.background.isTexture)i.background=this.background.toJSON(e).uuid}if(this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0)i.environment=this.environment.toJSON(e).uuid}else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(e.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let a=o.shapes;if(Array.isArray(a))for(let l=0,c=a.length;l<c;l++){let u=a[l];s(e.shapes,u)}else s(e.shapes,a)}}if(this.isSkinnedMesh){if(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0)s(e.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid}if(this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let a=0,l=this.material.length;a<l;a++)o.push(s(e.materials,this.material[a]));i.material=o}else i.material=s(e.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){let a=this.animations[o];i.animations.push(s(e.animations,a))}}if(t){let o=r(e.geometries),a=r(e.materials),l=r(e.textures),c=r(e.images),u=r(e.shapes),h=r(e.skeletons),d=r(e.animations),f=r(e.nodes);if(o.length>0)n.geometries=o;if(a.length>0)n.materials=a;if(l.length>0)n.textures=l;if(c.length>0)n.images=c;if(u.length>0)n.shapes=u;if(h.length>0)n.skeletons=h;if(d.length>0)n.animations=d;if(f.length>0)n.nodes=f}return n.object=i,n;function r(o){let a=[];for(let l in o){let c=o[l];delete c.metadata,a.push(c)}return a}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){let i=e.children[n];this.add(i.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}tt.DEFAULT_UP=new R(0,1,0);tt.DEFAULT_MATRIX_AUTO_UPDATE=!0;tt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class yt extends tt{constructor(){super();this.isGroup=!0,this.type="Group"}}var $m={type:"move"};class Dr{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){if(this._hand===null)this._hand=new yt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1};return this._hand}getTargetRaySpace(){if(this._targetRay===null)this._targetRay=new yt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new R,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new R;return this._targetRay}getGripSpace(){if(this._grip===null)this._grip=new yt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new R,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new R,this._grip.eventsEnabled=!1;return this._grip}dispatchEvent(e){if(this._targetRay!==null)this._targetRay.dispatchEvent(e);if(this._grip!==null)this._grip.dispatchEvent(e);if(this._hand!==null)this._hand.dispatchEvent(e);return this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){if(this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null)this._targetRay.visible=!1;if(this._grip!==null)this._grip.visible=!1;if(this._hand!==null)this._hand.visible=!1;return this}update(e,t,n){let i=null,s=null,r=null,o=this._targetRay,a=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){r=!0;for(let m of e.hand.values()){let x=t.getJointPose(m,n),p=this._getHandJoint(l,m);if(x!==null)p.matrix.fromArray(x.transform.matrix),p.matrix.decompose(p.position,p.quaternion,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=x.radius;p.visible=x!==null}let c=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],h=c.position.distanceTo(u.position),d=0.02,f=0.005;if(l.inputState.pinching&&h>d+f)l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this});else if(!l.inputState.pinching&&h<=d-f)l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this})}else if(a!==null&&e.gripSpace){if(s=t.getPose(e.gripSpace,n),s!==null){if(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.quaternion,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity)a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity);else a.hasLinearVelocity=!1;if(s.angularVelocity)a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity);else a.hasAngularVelocity=!1;if(a.eventsEnabled)a.dispatchEvent({type:"gripUpdated",data:e,target:this})}}if(o!==null){if(i=t.getPose(e.targetRaySpace,n),i===null&&s!==null)i=s;if(i!==null){if(o.matrix.fromArray(i.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.matrixWorldNeedsUpdate=!0,i.linearVelocity)o.hasLinearVelocity=!0,o.linearVelocity.copy(i.linearVelocity);else o.hasLinearVelocity=!1;if(i.angularVelocity)o.hasAngularVelocity=!0,o.angularVelocity.copy(i.angularVelocity);else o.hasAngularVelocity=!1;this.dispatchEvent($m)}}}if(o!==null)o.visible=i!==null;if(a!==null)a.visible=s!==null;if(l!==null)l.visible=r!==null;return this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new yt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}var tf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},gi={h:0,s:0,l:0},Ao={h:0,s:0,l:0};function El(e,t,n){if(n<0)n+=1;if(n>1)n-=1;if(n<0.16666666666666666)return e+(t-e)*6*n;if(n<0.5)return t;if(n<0.6666666666666666)return e+(t-e)*6*(0.6666666666666666-n);return e}class xe{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let i=e;if(i&&i.isColor)this.copy(i);else if(typeof i==="number")this.setHex(i);else if(typeof i==="string")this.setStyle(i)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t="srgb"){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,qe.colorSpaceToWorking(this,t),this}setRGB(e,t,n,i=qe.workingColorSpace){return this.r=e,this.g=t,this.b=n,qe.colorSpaceToWorking(this,i),this}setHSL(e,t,n,i=qe.workingColorSpace){if(e=Xc(e,1),t=Ye(t,0,1),n=Ye(n,0,1),t===0)this.r=this.g=this.b=n;else{let s=n<=0.5?n*(1+t):n+t-n*t,r=2*n-s;this.r=El(r,s,e+0.3333333333333333),this.g=El(r,s,e),this.b=El(r,s,e-0.3333333333333333)}return qe.colorSpaceToWorking(this,i),this}setStyle(e,t="srgb"){function n(s){if(s===void 0)return;if(parseFloat(s)<1)we("Color: Alpha component of "+e+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(e)){let s,r=i[1],o=i[2];switch(r){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(100,parseFloat(s[1]))/100,Math.min(100,parseFloat(s[2]))/100,Math.min(100,parseFloat(s[3]))/100,t);break;case"hsl":case"hsla":if(s=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:we("Color: Unknown color model "+e)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(e)){let s=i[1],r=s.length;if(r===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);else if(r===6)return this.setHex(parseInt(s,16),t);else we("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t="srgb"){let n=tf[e.toLowerCase()];if(n!==void 0)this.setHex(n,t);else we("Color: Unknown color "+e);return this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=oi(e.r),this.g=oi(e.g),this.b=oi(e.b),this}copyLinearToSRGB(e){return this.r=Ls(e.r),this.g=Ls(e.g),this.b=Ls(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e="srgb"){return qe.workingToColorSpace(Xt.copy(this),e),Math.round(Ye(Xt.r*255,0,255))*65536+Math.round(Ye(Xt.g*255,0,255))*256+Math.round(Ye(Xt.b*255,0,255))}getHexString(e="srgb"){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=qe.workingColorSpace){qe.workingToColorSpace(Xt.copy(this),t);let{r:n,g:i,b:s}=Xt,r=Math.max(n,i,s),o=Math.min(n,i,s),a,l,c=(o+r)/2;if(o===r)a=0,l=0;else{let u=r-o;switch(l=c<=0.5?u/(r+o):u/(2-r-o),r){case n:a=(i-s)/u+(i<s?6:0);break;case i:a=(s-n)/u+2;break;case s:a=(n-i)/u+4;break}a/=6}return e.h=a,e.s=l,e.l=c,e}getRGB(e,t=qe.workingColorSpace){return qe.workingToColorSpace(Xt.copy(this),t),e.r=Xt.r,e.g=Xt.g,e.b=Xt.b,e}getStyle(e="srgb"){qe.workingToColorSpace(Xt.copy(this),e);let{r:t,g:n,b:i}=Xt;if(e!=="srgb")return`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`;return`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(e,t,n){return this.getHSL(gi),this.setHSL(gi.h+e,gi.s+t,gi.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(gi),e.getHSL(Ao);let n=br(gi.h,Ao.h,t),i=br(gi.s,Ao.s,t),s=br(gi.l,Ao.l,t);return this.setHSL(n,i,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,i=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*i,this.g=s[1]*t+s[4]*n+s[7]*i,this.b=s[2]*t+s[5]*n+s[8]*i,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}var Xt=new xe;xe.NAMES=tf;class da extends tt{constructor(){super();if(this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Ht,this.environmentIntensity=1,this.environmentRotation=new Ht,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u")__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),this.background=e.background!==null?e.background.clone():null,this.environment=e.environment!==null?e.environment.clone():null,this.fog=e.fog!==null?e.fog.clone():null,this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),this.overrideMaterial=e.overrideMaterial!==null?e.overrideMaterial.clone():null,this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);if(this.fog!==null)t.object.fog=this.fog.toJSON();return t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}}var wn=new R,ti=new R,Tl=new R,ni=new R,vs=new R,Es=new R,Lh=new R,Sl=new R,bl=new R,Rl=new R,Al=new ut,wl=new ut,Cl=new ut;class xn{constructor(e=new R,t=new R,n=new R){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,i){i.subVectors(n,t),wn.subVectors(e,t),i.cross(wn);let s=i.lengthSq();if(s>0)return i.multiplyScalar(1/Math.sqrt(s));return i.set(0,0,0)}static getBarycoord(e,t,n,i,s){wn.subVectors(i,t),ti.subVectors(n,t),Tl.subVectors(e,t);let r=wn.dot(wn),o=wn.dot(ti),a=wn.dot(Tl),l=ti.dot(ti),c=ti.dot(Tl),u=r*l-o*o;if(u===0)return s.set(0,0,0),null;let h=1/u,d=(l*a-o*c)*h,f=(r*c-o*a)*h;return s.set(1-d-f,f,d)}static containsPoint(e,t,n,i){if(this.getBarycoord(e,t,n,i,ni)===null)return!1;return ni.x>=0&&ni.y>=0&&ni.x+ni.y<=1}static getInterpolation(e,t,n,i,s,r,o,a){if(this.getBarycoord(e,t,n,i,ni)===null){if(a.x=0,a.y=0,"z"in a)a.z=0;if("w"in a)a.w=0;return null}return a.setScalar(0),a.addScaledVector(s,ni.x),a.addScaledVector(r,ni.y),a.addScaledVector(o,ni.z),a}static getInterpolatedAttribute(e,t,n,i,s,r){return Al.setScalar(0),wl.setScalar(0),Cl.setScalar(0),Al.fromBufferAttribute(e,t),wl.fromBufferAttribute(e,n),Cl.fromBufferAttribute(e,i),r.setScalar(0),r.addScaledVector(Al,s.x),r.addScaledVector(wl,s.y),r.addScaledVector(Cl,s.z),r}static isFrontFacing(e,t,n,i){return wn.subVectors(n,t),ti.subVectors(e,t),wn.cross(ti).dot(i)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,i){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[i]),this}setFromAttributeAndIndices(e,t,n,i){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return wn.subVectors(this.c,this.b),ti.subVectors(this.a,this.b),wn.cross(ti).length()*0.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(0.3333333333333333)}getNormal(e){return xn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return xn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,i,s){return xn.getInterpolation(e,this.a,this.b,this.c,t,n,i,s)}containsPoint(e){return xn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return xn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,i=this.b,s=this.c,r,o;vs.subVectors(i,n),Es.subVectors(s,n),Sl.subVectors(e,n);let a=vs.dot(Sl),l=Es.dot(Sl);if(a<=0&&l<=0)return t.copy(n);bl.subVectors(e,i);let c=vs.dot(bl),u=Es.dot(bl);if(c>=0&&u<=c)return t.copy(i);let h=a*u-c*l;if(h<=0&&a>=0&&c<=0&&a-c>0)return r=a/(a-c),t.copy(n).addScaledVector(vs,r);Rl.subVectors(e,s);let d=vs.dot(Rl),f=Es.dot(Rl);if(f>=0&&d<=f)return t.copy(s);let m=d*l-a*f;if(m<=0&&l>=0&&f<=0)return o=l/(l-f),t.copy(n).addScaledVector(Es,o);let x=c*f-d*u;if(x<=0&&u-c>=0&&d-f>=0)return Lh.subVectors(s,i),o=(u-c)/(u-c+(d-f)),t.copy(i).addScaledVector(Lh,o);let p=1/(x+m+h);return r=m*p,o=h*p,t.copy(n).addScaledVector(vs,r).addScaledVector(Es,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class yn{constructor(e=new R(1/0,1/0,1/0),t=new R(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Cn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Cn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=Cn.copy(t).multiplyScalar(0.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(0.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0&&e.isBatchedMesh!==!0)for(let r=0,o=s.count;r<o;r++){if(e.isMesh===!0)e.getVertexPosition(r,Cn);else Cn.fromBufferAttribute(s,r);Cn.applyMatrix4(e.matrixWorld),this.expandByPoint(Cn)}else{if(e.boundingBox!==void 0){if(e.boundingBox===null)e.computeBoundingBox();wo.copy(e.boundingBox)}else{if(n.boundingBox===null)n.computeBoundingBox();wo.copy(n.boundingBox)}wo.applyMatrix4(e.matrixWorld),this.union(wo)}}let i=e.children;for(let s=0,r=i.length;s<r;s++)this.expandByObject(i[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Cn),Cn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;if(e.normal.x>0)t=e.normal.x*this.min.x,n=e.normal.x*this.max.x;else t=e.normal.x*this.max.x,n=e.normal.x*this.min.x;if(e.normal.y>0)t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y;else t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y;if(e.normal.z>0)t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z;else t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z;return t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(gr),Co.subVectors(this.max,gr),Ts.subVectors(e.a,gr),Ss.subVectors(e.b,gr),bs.subVectors(e.c,gr),_i.subVectors(Ss,Ts),xi.subVectors(bs,Ss),Yi.subVectors(Ts,bs);let t=[0,-_i.z,_i.y,0,-xi.z,xi.y,0,-Yi.z,Yi.y,_i.z,0,-_i.x,xi.z,0,-xi.x,Yi.z,0,-Yi.x,-_i.y,_i.x,0,-xi.y,xi.x,0,-Yi.y,Yi.x,0];if(!Pl(t,Ts,Ss,bs,Co))return!1;if(t=[1,0,0,0,1,0,0,0,1],!Pl(t,Ts,Ss,bs,Co))return!1;return Po.crossVectors(_i,xi),t=[Po.x,Po.y,Po.z],Pl(t,Ts,Ss,bs,Co)}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Cn).distanceTo(e)}getBoundingSphere(e){if(this.isEmpty())e.makeEmpty();else this.getCenter(e.center),e.radius=this.getSize(Cn).length()*0.5;return e}intersect(e){if(this.min.max(e.min),this.max.min(e.max),this.isEmpty())this.makeEmpty();return this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){if(this.isEmpty())return this;return ii[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ii[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ii[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ii[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ii[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ii[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ii[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ii[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ii),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}var ii=[new R,new R,new R,new R,new R,new R,new R,new R],Cn=new R,wo=new yn,Ts=new R,Ss=new R,bs=new R,_i=new R,xi=new R,Yi=new R,gr=new R,Co=new R,Po=new R,Zi=new R;function Pl(e,t,n,i,s){for(let r=0,o=e.length-3;r<=o;r+=3){Zi.fromArray(e,r);let a=s.x*Math.abs(Zi.x)+s.y*Math.abs(Zi.y)+s.z*Math.abs(Zi.z),l=t.dot(Zi),c=n.dot(Zi),u=i.dot(Zi);if(Math.max(-Math.max(l,c,u),Math.min(l,c,u))>a)return!1}return!0}var St=new R,Lo=new Ce,Qm=0;class Ge extends Gn{constructor(e,t,n=!1){super();if(Array.isArray(e))throw TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Qm++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=35044,this.updateRanges=[],this.gpuType=1015,this.version=0,this._normalizationScale=e!==void 0?ca(e):void 0}onUploadCallback(){}set needsUpdate(e){if(e===!0)this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this._normalizationScale=e._normalizationScale,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[e+i]=t.array[n+i];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Lo.fromBufferAttribute(this,t),Lo.applyMatrix3(e),this.setXY(t,Lo.x,Lo.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)St.fromBufferAttribute(this,t),St.applyMatrix3(e),this.setXYZ(t,St.x,St.y,St.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)St.fromBufferAttribute(this,t),St.applyMatrix4(e),this.setXYZ(t,St.x,St.y,St.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)St.fromBufferAttribute(this,t),St.applyNormalMatrix(e),this.setXYZ(t,St.x,St.y,St.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)St.fromBufferAttribute(this,t),St.transformDirection(e),this.setXYZ(t,St.x,St.y,St.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];if(this.normalized)n=this._denormalize(n);return n}setComponent(e,t,n){if(this.normalized)n=this._normalize(n);return this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];if(this.normalized)t=this._denormalize(t);return t}setX(e,t){if(this.normalized)t=this._normalize(t);return this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];if(this.normalized)t=this._denormalize(t);return t}setY(e,t){if(this.normalized)t=this._normalize(t);return this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];if(this.normalized)t=this._denormalize(t);return t}setZ(e,t){if(this.normalized)t=this._normalize(t);return this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];if(this.normalized)t=this._denormalize(t);return t}setW(e,t){if(this.normalized)t=this._normalize(t);return this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){if(e*=this.itemSize,this.normalized)t=this._normalize(t),n=this._normalize(n);return this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,i){if(e*=this.itemSize,this.normalized)t=this._normalize(t),n=this._normalize(n),i=this._normalize(i);return this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this}setXYZW(e,t,n,i,s){if(e*=this.itemSize,this.normalized)t=this._normalize(t),n=this._normalize(n),i=this._normalize(i),s=this._normalize(s);return this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(e){let t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):Yc(e,this.array)}_normalize(e){let t=this._normalizationScale;return t!==void 0?Math.round(e*t):Zc(e,this.array)}}class fa extends Ge{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class pa extends Ge{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class Rt extends Ge{constructor(e,t,n){super(new Float32Array(e),t,n)}}var eg=new yn,_r=new R,Ll=new R;class pn{constructor(e=new R,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;if(t!==void 0)n.copy(t);else eg.setFromPoints(e).getCenter(n);let i=0;for(let s=0,r=e.length;s<r;s++)i=Math.max(i,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(i),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);if(t.copy(e),n>this.radius*this.radius)t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center);return t}getBoundingBox(e){if(this.isEmpty())return e.makeEmpty(),e;return e.set(this.center,this.center),e.expandByScalar(this.radius),e}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;_r.subVectors(e,this.center);let t=_r.lengthSq();if(t>this.radius*this.radius){let n=Math.sqrt(t),i=(n-this.radius)*0.5;this.center.addScaledVector(_r,i/n),this.radius+=i}return this}union(e){if(e.isEmpty())return this;if(this.isEmpty())return this.copy(e),this;if(this.center.equals(e.center)===!0)this.radius=Math.max(this.radius,e.radius);else Ll.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(_r.copy(e.center).add(Ll)),this.expandByPoint(_r.copy(e.center).sub(Ll));return this}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}var tg=0,gn=new Re,Il=new tt,Rs=new R,dn=new yn,xr=new yn,Dt=new R;class Qe extends Gn{constructor(){super();this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:tg++}),this.uuid=zn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){if(Array.isArray(e))this.index=new((Rm(e))?pa:fa)(e,1);else this.index=e;return this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;if(t!==void 0)t.applyMatrix4(e),t.needsUpdate=!0;let n=this.attributes.normal;if(n!==void 0){let s=new Pe().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}let i=this.attributes.tangent;if(i!==void 0)i.transformDirection(e),i.needsUpdate=!0;if(this.boundingBox!==null)this.computeBoundingBox();if(this.boundingSphere!==null)this.computeBoundingSphere();return this._transformed=!0,this}applyQuaternion(e){return gn.makeRotationFromQuaternion(e),this.applyMatrix4(gn),this}rotateX(e){return gn.makeRotationX(e),this.applyMatrix4(gn),this}rotateY(e){return gn.makeRotationY(e),this.applyMatrix4(gn),this}rotateZ(e){return gn.makeRotationZ(e),this.applyMatrix4(gn),this}translate(e,t,n){return gn.makeTranslation(e,t,n),this.applyMatrix4(gn),this}scale(e,t,n){return gn.makeScale(e,t,n),this.applyMatrix4(gn),this}lookAt(e){return Il.lookAt(e),Il.updateMatrix(),this.applyMatrix4(Il.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Rs).negate(),this.translate(Rs.x,Rs.y,Rs.z),this}setFromPoints(e){let t=this.getAttribute("position");if(t===void 0){let n=[];for(let i=0,s=e.length;i<s;i++){let r=e[i];n.push(r.x,r.y,r.z||0)}this.setAttribute("position",new Rt(n,3))}else{let n=Math.min(e.length,t.count);for(let i=0;i<n;i++){let s=e[i];t.setXYZ(i,s.x,s.y,s.z||0)}if(e.length>t.count)we("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry.");t.needsUpdate=!0}return this}computeBoundingBox(){if(this.boundingBox===null)this.boundingBox=new yn;let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){He("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new R(-1/0,-1/0,-1/0),new R(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,i=t.length;n<i;n++){let s=t[n];if(dn.setFromBufferAttribute(s),this.morphTargetsRelative)Dt.addVectors(this.boundingBox.min,dn.min),this.boundingBox.expandByPoint(Dt),Dt.addVectors(this.boundingBox.max,dn.max),this.boundingBox.expandByPoint(Dt);else this.boundingBox.expandByPoint(dn.min),this.boundingBox.expandByPoint(dn.max)}}else this.boundingBox.makeEmpty();if(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))He('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){if(this.boundingSphere===null)this.boundingSphere=new pn;let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){He("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new R,1/0);return}if(e){let n=this.boundingSphere.center;if(dn.setFromBufferAttribute(e),t)for(let s=0,r=t.length;s<r;s++){let o=t[s];if(xr.setFromBufferAttribute(o),this.morphTargetsRelative)Dt.addVectors(dn.min,xr.min),dn.expandByPoint(Dt),Dt.addVectors(dn.max,xr.max),dn.expandByPoint(Dt);else dn.expandByPoint(xr.min),dn.expandByPoint(xr.max)}dn.getCenter(n);let i=0;for(let s=0,r=e.count;s<r;s++)Dt.fromBufferAttribute(e,s),i=Math.max(i,n.distanceToSquared(Dt));if(t)for(let s=0,r=t.length;s<r;s++){let o=t[s],a=this.morphTargetsRelative;for(let l=0,c=o.count;l<c;l++){if(Dt.fromBufferAttribute(o,l),a)Rs.fromBufferAttribute(e,l),Dt.add(Rs);i=Math.max(i,n.distanceToSquared(Dt))}}if(this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius))He('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){He("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let{position:n,normal:i,uv:s}=t,r=this.getAttribute("tangent");if(r===void 0||r.count!==n.count)r=new Ge(new Float32Array(4*n.count),4),this.setAttribute("tangent",r);let o=[],a=[],l=new Uint8Array(n.count);for(let E=0;E<n.count;E++)o[E]=new R,a[E]=new R;let c=new R,u=new R,h=new R,d=new Ce,f=new Ce,m=new Ce,x=new R,p=new R;function g(E,I,k){l[E]=l[I]=l[k]=1,c.fromBufferAttribute(n,E),u.fromBufferAttribute(n,I),h.fromBufferAttribute(n,k),d.fromBufferAttribute(s,E),f.fromBufferAttribute(s,I),m.fromBufferAttribute(s,k),u.sub(c),h.sub(c),f.sub(d),m.sub(d);let N=1/(f.x*m.y-m.x*f.y);if(!isFinite(N))return;x.copy(u).multiplyScalar(m.y).addScaledVector(h,-f.y).multiplyScalar(N),p.copy(h).multiplyScalar(f.x).addScaledVector(u,-m.x).multiplyScalar(N),o[E].add(x),o[I].add(x),o[k].add(x),a[E].add(p),a[I].add(p),a[k].add(p)}let v=this.groups;if(v.length===0)v=[{start:0,count:e.count}];for(let E=0,I=v.length;E<I;++E){let k=v[E],{start:N,count:V}=k;for(let Q=N,C=N+V;Q<C;Q+=3)g(e.getX(Q+0),e.getX(Q+1),e.getX(Q+2))}let S=new R,T=new R,A=new R,w=new R;function _(E){A.fromBufferAttribute(i,E),w.copy(A);let I=o[E];if(S.copy(I),S.sub(A.multiplyScalar(A.dot(I))).normalize(),S.lengthSq()===0){if(Math.abs(w.x)<0.9)S.set(1,0,0);else S.set(0,1,0);S.crossVectors(w,S).normalize()}T.crossVectors(w,I);let N=T.dot(a[E])<0?-1:1;r.setXYZW(E,S.x,S.y,S.z,N)}for(let E=0,I=n.count;E<I;++E)if(l[E])_(E);this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==t.count)n=new Ge(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let h=0,d=n.count;h<d;h++)n.setXYZ(h,0,0,0);let i=new R,s=new R,r=new R,o=new R,a=new R,l=new R,c=new R,u=new R;if(e)for(let h=0,d=e.count;h<d;h+=3){let f=e.getX(h+0),m=e.getX(h+1),x=e.getX(h+2);i.fromBufferAttribute(t,f),s.fromBufferAttribute(t,m),r.fromBufferAttribute(t,x),c.subVectors(r,s),u.subVectors(i,s),c.cross(u),o.fromBufferAttribute(n,f),a.fromBufferAttribute(n,m),l.fromBufferAttribute(n,x),o.add(c),a.add(c),l.add(c),n.setXYZ(f,o.x,o.y,o.z),n.setXYZ(m,a.x,a.y,a.z),n.setXYZ(x,l.x,l.y,l.z)}else for(let h=0,d=t.count;h<d;h+=3)i.fromBufferAttribute(t,h+0),s.fromBufferAttribute(t,h+1),r.fromBufferAttribute(t,h+2),c.subVectors(r,s),u.subVectors(i,s),c.cross(u),n.setXYZ(h+0,c.x,c.y,c.z),n.setXYZ(h+1,c.x,c.y,c.z),n.setXYZ(h+2,c.x,c.y,c.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Dt.fromBufferAttribute(e,t),Dt.normalize(),e.setXYZ(t,Dt.x,Dt.y,Dt.z)}toNonIndexed(){function e(o,a){let{array:l,itemSize:c,normalized:u}=o,h=new l.constructor(a.length*c),d=0,f=0;for(let m=0,x=a.length;m<x;m++){if(o.isInterleavedBufferAttribute)d=a[m]*o.data.stride+o.offset;else d=a[m]*c;for(let p=0;p<c;p++)h[f++]=l[d++]}return new Ge(h,c,u)}if(this.index===null)return we("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new Qe,n=this.index.array,i=this.attributes;for(let o in i){let a=i[o],l=e(a,n);t.setAttribute(o,l)}let s=this.morphAttributes;for(let o in s){let a=[],l=s[o];for(let c=0,u=l.length;c<u;c++){let h=l[c],d=e(h,n);a.push(d)}t.morphAttributes[o]=a}t.morphTargetsRelative=this.morphTargetsRelative;let r=this.groups;for(let o=0,a=r.length;o<a;o++){let l=r[o];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){let e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0)e.userData=this.userData;if(this.parameters!==void 0&&this._transformed!==!0){let a=this.parameters;for(let l in a)if(a[l]!==void 0)e[l]=a[l];return e}e.data={attributes:{}};let t=this.index;if(t!==null)e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)};let n=this.attributes;for(let a in n){let l=n[a];e.data.attributes[a]=l.toJSON(e.data)}let i={},s=!1;for(let a in this.morphAttributes){let l=this.morphAttributes[a],c=[];for(let u=0,h=l.length;u<h;u++){let d=l[u];c.push(d.toJSON(e.data))}if(c.length>0)i[a]=c,s=!0}if(s)e.data.morphAttributes=i,e.data.morphTargetsRelative=this.morphTargetsRelative;let r=this.groups;if(r.length>0)e.data.groups=JSON.parse(JSON.stringify(r));let o=this.boundingSphere;if(o!==null)e.data.boundingSphere=o.toJSON();return e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;if(n!==null)this.setIndex(n.clone());let i=e.attributes;for(let l in i){let c=i[l];this.setAttribute(l,c.clone(t))}let s=e.morphAttributes;for(let l in s){let c=[],u=s[l];for(let h=0,d=u.length;h<d;h++)c.push(u[h].clone(t));this.morphAttributes[l]=c}this.morphTargetsRelative=e.morphTargetsRelative;let r=e.groups;for(let l=0,c=r.length;l<c;l++){let u=r[l];this.addGroup(u.start,u.count,u.materialIndex)}let o=e.boundingBox;if(o!==null)this.boundingBox=o.clone();let a=e.boundingSphere;if(a!==null)this.boundingSphere=a.clone();return this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Ai{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=35044,this.updateRanges=[],this.version=0,this.uuid=zn()}onUploadCallback(){}set needsUpdate(e){if(e===!0)this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let i=0,s=this.stride;i<s;i++)this.array[e+i]=t.array[n+i];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){if(e.arrayBuffers===void 0)e.arrayBuffers={};let t=Ih(this.array);if(e.arrayBuffers[t]===void 0)e.arrayBuffers[t]=this.array.slice(0).buffer;let n=new this.array.constructor(e.arrayBuffers[t]),i=new this.constructor(n,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){if(e.arrayBuffers===void 0)e.arrayBuffers={};let t=Ih(this.array);if(e.arrayBuffers[t]===void 0)e.arrayBuffers[t]=Array.from(new Uint32Array(this.array.slice(0).buffer));let n={uuid:this.uuid,buffer:t,type:this.array.constructor.name,stride:this.stride};return n.usage=this.usage,n}}function Ih(e){if(e.buffer._uuid===void 0)e.buffer._uuid=zn();if(e.byteOffset===0&&e.byteLength===e.buffer.byteLength)return e.buffer._uuid;return e.buffer._uuid+":"+e.byteOffset+":"+e.byteLength}var Qt=new R;class ui{constructor(e,t,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=i,this._normalizationScale=e!==void 0?ca(e.array):void 0}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)Qt.fromBufferAttribute(this,t),Qt.applyMatrix4(e),this.setXYZ(t,Qt.x,Qt.y,Qt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Qt.fromBufferAttribute(this,t),Qt.applyNormalMatrix(e),this.setXYZ(t,Qt.x,Qt.y,Qt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Qt.fromBufferAttribute(this,t),Qt.transformDirection(e),this.setXYZ(t,Qt.x,Qt.y,Qt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];if(this.normalized)n=this._denormalize(n);return n}setComponent(e,t,n){if(this.normalized)n=this._normalize(n);return this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){if(this.normalized)t=this._normalize(t);return this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){if(this.normalized)t=this._normalize(t);return this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){if(this.normalized)t=this._normalize(t);return this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){if(this.normalized)t=this._normalize(t);return this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];if(this.normalized)t=this._denormalize(t);return t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];if(this.normalized)t=this._denormalize(t);return t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];if(this.normalized)t=this._denormalize(t);return t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];if(this.normalized)t=this._denormalize(t);return t}setXY(e,t,n){if(e=e*this.data.stride+this.offset,this.normalized)t=this._normalize(t),n=this._normalize(n);return this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,i){if(e=e*this.data.stride+this.offset,this.normalized)t=this._normalize(t),n=this._normalize(n),i=this._normalize(i);return this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this}setXYZW(e,t,n,i,s){if(e=e*this.data.stride+this.offset,this.normalized)t=this._normalize(t),n=this._normalize(n),i=this._normalize(i),s=this._normalize(s);return this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this.data.array[e+3]=s,this}clone(e){if(e===void 0){Rr("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return new Ge(new this.array.constructor(t),this.itemSize,this.normalized)}else{if(e.interleavedBuffers===void 0)e.interleavedBuffers={};if(e.interleavedBuffers[this.data.uuid]===void 0)e.interleavedBuffers[this.data.uuid]=this.data.clone(e);return new ui(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}}toJSON(e){if(e===void 0){Rr("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else{if(e.interleavedBuffers===void 0)e.interleavedBuffers={};if(e.interleavedBuffers[this.data.uuid]===void 0)e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e);return{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}_denormalize(e){let t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):Yc(e,this.data.array)}_normalize(e){let t=this._normalizationScale;return t!==void 0?Math.round(e*t):Zc(e,this.data.array)}}var Nl=new R,ng=new R,ig=new Pe;class _n{constructor(e=new R(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,i){return this.normal.set(e,t,n),this.constant=i,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let i=Nl.subVectors(n,t).cross(ng.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(i,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){let i=e.delta(Nl),s=this.normal.dot(i);if(s===0){if(this.distanceToPoint(e.start)===0)return t.copy(e.start);return null}let r=-(e.start.dot(this.normal)+this.constant)/s;if(n===!0&&(r<0||r>1))return null;return t.copy(e.start).addScaledVector(i,r)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||ig.getNormalMatrix(e),i=this.coplanarPoint(Nl).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}}var sg=0;class tn extends Gn{constructor(){super();this.isMaterial=!0,Object.defineProperty(this,"id",{value:sg++}),this.uuid=zn(),this.name="",this.type="Material",this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=204,this.blendDst=205,this.blendEquation=100,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new xe(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=7680,this.stencilZFail=7680,this.stencilZPass=7680,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){if(this._alphaTest>0!==e>0)this.version++;this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e===void 0)return;for(let t in e){let n=e[t];if(n===void 0){we(`Material: parameter '${t}' has value of undefined.`);continue}let i=this[t];if(i===void 0){we(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}if(i&&i.isColor)i.set(n);else if(i&&i.isVector2&&(n&&n.isVector2)||i&&i.isEuler&&(n&&n.isEuler)||i&&i.isVector3&&(n&&n.isVector3))i.copy(n);else this[t]=n}}toJSON(e){let t=e===void 0||typeof e==="string";if(t)e={textures:{},images:{}};let n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};if(n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor)n.color=this.color.getHex();if(this.roughness!==void 0)n.roughness=this.roughness;if(this.metalness!==void 0)n.metalness=this.metalness;if(this.sheen!==void 0)n.sheen=this.sheen;if(this.sheenColor&&this.sheenColor.isColor)n.sheenColor=this.sheenColor.getHex();if(this.sheenRoughness!==void 0)n.sheenRoughness=this.sheenRoughness;if(this.emissive&&this.emissive.isColor)n.emissive=this.emissive.getHex();if(this.emissiveIntensity!==void 0)n.emissiveIntensity=this.emissiveIntensity;if(this.specular&&this.specular.isColor)n.specular=this.specular.getHex();if(this.specularIntensity!==void 0)n.specularIntensity=this.specularIntensity;if(this.specularColor&&this.specularColor.isColor)n.specularColor=this.specularColor.getHex();if(this.shininess!==void 0)n.shininess=this.shininess;if(this.clearcoat!==void 0)n.clearcoat=this.clearcoat;if(this.clearcoatRoughness!==void 0)n.clearcoatRoughness=this.clearcoatRoughness;if(this.diffuseRoughness!==void 0)n.diffuseRoughness=this.diffuseRoughness;if(this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture)n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(e).uuid;if(this.clearcoatMap&&this.clearcoatMap.isTexture)n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid;if(this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture)n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid;if(this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture)n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray();if(this.sheenColorMap&&this.sheenColorMap.isTexture)n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid;if(this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture)n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid;if(this.dispersion!==void 0)n.dispersion=this.dispersion;if(this.retroreflectivity!==void 0)n.retroreflectivity=this.retroreflectivity;if(this.iridescence!==void 0)n.iridescence=this.iridescence;if(this.iridescenceIOR!==void 0)n.iridescenceIOR=this.iridescenceIOR;if(this.iridescenceThicknessMinimum!==void 0)n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum;if(this.iridescenceThicknessMaximum!==void 0)n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum;if(this.iridescenceMap&&this.iridescenceMap.isTexture)n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid;if(this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture)n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid;if(this.anisotropy!==void 0)n.anisotropy=this.anisotropy;if(this.anisotropyRotation!==void 0)n.anisotropyRotation=this.anisotropyRotation;if(this.anisotropyMap&&this.anisotropyMap.isTexture)n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid;if(this.map&&this.map.isTexture)n.map=this.map.toJSON(e).uuid;if(this.matcap&&this.matcap.isTexture)n.matcap=this.matcap.toJSON(e).uuid;if(this.alphaMap&&this.alphaMap.isTexture)n.alphaMap=this.alphaMap.toJSON(e).uuid;if(this.lightMap&&this.lightMap.isTexture)n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity;if(this.aoMap&&this.aoMap.isTexture)n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity;if(this.bumpMap&&this.bumpMap.isTexture)n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale;if(this.normalMap&&this.normalMap.isTexture)n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray();if(this.displacementMap&&this.displacementMap.isTexture)n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias;if(this.roughnessMap&&this.roughnessMap.isTexture)n.roughnessMap=this.roughnessMap.toJSON(e).uuid;if(this.metalnessMap&&this.metalnessMap.isTexture)n.metalnessMap=this.metalnessMap.toJSON(e).uuid;if(this.emissiveMap&&this.emissiveMap.isTexture)n.emissiveMap=this.emissiveMap.toJSON(e).uuid;if(this.specularMap&&this.specularMap.isTexture)n.specularMap=this.specularMap.toJSON(e).uuid;if(this.specularIntensityMap&&this.specularIntensityMap.isTexture)n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid;if(this.specularColorMap&&this.specularColorMap.isTexture)n.specularColorMap=this.specularColorMap.toJSON(e).uuid;if(this.envMap&&this.envMap.isTexture){if(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0)n.combine=this.combine}if(this.envMapRotation!==void 0)n.envMapRotation=this.envMapRotation.toArray();if(this.envMapIntensity!==void 0)n.envMapIntensity=this.envMapIntensity;if(this.reflectivity!==void 0)n.reflectivity=this.reflectivity;if(this.refractionRatio!==void 0)n.refractionRatio=this.refractionRatio;if(this.gradientMap&&this.gradientMap.isTexture)n.gradientMap=this.gradientMap.toJSON(e).uuid;if(this.transmission!==void 0)n.transmission=this.transmission;if(this.transmissionMap&&this.transmissionMap.isTexture)n.transmissionMap=this.transmissionMap.toJSON(e).uuid;if(this.thickness!==void 0)n.thickness=this.thickness;if(this.thicknessMap&&this.thicknessMap.isTexture)n.thicknessMap=this.thicknessMap.toJSON(e).uuid;if(this.attenuationDistance!==void 0)n.attenuationDistance=this.attenuationDistance;if(this.attenuationColor!==void 0)n.attenuationColor=this.attenuationColor.getHex();if(this.size!==void 0)n.size=this.size;if(this.sizeAttenuation!==void 0)n.sizeAttenuation=this.sizeAttenuation;if(Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0)n.clippingPlanes=this.clippingPlanes.map((s)=>s.toJSON());if(this.rotation!==void 0)n.rotation=this.rotation;if(this.depthPacking!==void 0)n.depthPacking=this.depthPacking;if(this.linewidth!==void 0)n.linewidth=this.linewidth;if(this.linecap!==void 0)n.linecap=this.linecap;if(this.linejoin!==void 0)n.linejoin=this.linejoin;if(this.dashSize!==void 0)n.dashSize=this.dashSize;if(this.gapSize!==void 0)n.gapSize=this.gapSize;if(this.scale!==void 0)n.scale=this.scale;if(this.wireframe!==void 0)n.wireframe=this.wireframe;if(this.wireframeLinewidth!==void 0)n.wireframeLinewidth=this.wireframeLinewidth;if(this.wireframeLinecap!==void 0)n.wireframeLinecap=this.wireframeLinecap;if(this.wireframeLinejoin!==void 0)n.wireframeLinejoin=this.wireframeLinejoin;if(this.flatShading!==void 0)n.flatShading=this.flatShading;if(this.fog!==void 0)n.fog=this.fog;if(Object.keys(this.userData).length>0)n.userData=this.userData;function i(s){let r=[];for(let o in s){let a=s[o];delete a.metadata,r.push(a)}return r}if(t){let s=i(e.textures),r=i(e.images);if(s.length>0)n.textures=s;if(r.length>0)n.images=r}return n}fromJSON(e,t){if(e.uuid!==void 0)this.uuid=e.uuid;if(e.name!==void 0)this.name=e.name;if(e.color!==void 0&&this.color!==void 0)this.color.setHex(e.color);if(e.roughness!==void 0)this.roughness=e.roughness;if(e.metalness!==void 0)this.metalness=e.metalness;if(e.sheen!==void 0)this.sheen=e.sheen;if(e.sheenColor!==void 0)this.sheenColor=new xe().setHex(e.sheenColor);if(e.sheenRoughness!==void 0)this.sheenRoughness=e.sheenRoughness;if(e.emissive!==void 0&&this.emissive!==void 0)this.emissive.setHex(e.emissive);if(e.specular!==void 0&&this.specular!==void 0)this.specular.setHex(e.specular);if(e.specularIntensity!==void 0)this.specularIntensity=e.specularIntensity;if(e.specularColor!==void 0&&this.specularColor!==void 0)this.specularColor.setHex(e.specularColor);if(e.shininess!==void 0)this.shininess=e.shininess;if(e.clearcoat!==void 0)this.clearcoat=e.clearcoat;if(e.clearcoatRoughness!==void 0)this.clearcoatRoughness=e.clearcoatRoughness;if(e.diffuseRoughness!==void 0)this.diffuseRoughness=e.diffuseRoughness;if(e.dispersion!==void 0)this.dispersion=e.dispersion;if(e.retroreflectivity!==void 0)this.retroreflectivity=e.retroreflectivity;if(e.iridescence!==void 0)this.iridescence=e.iridescence;if(e.iridescenceIOR!==void 0)this.iridescenceIOR=e.iridescenceIOR;if(e.iridescenceThicknessMinimum!==void 0)this.iridescenceThicknessMinimum=e.iridescenceThicknessMinimum;if(e.iridescenceThicknessMaximum!==void 0)this.iridescenceThicknessMaximum=e.iridescenceThicknessMaximum;if(e.iridescenceThicknessRange!==void 0)this.iridescenceThicknessMinimum=e.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=e.iridescenceThicknessRange[1];if(e.transmission!==void 0)this.transmission=e.transmission;if(e.thickness!==void 0)this.thickness=e.thickness;if(e.attenuationDistance!==void 0)this.attenuationDistance=e.attenuationDistance;if(e.attenuationColor!==void 0&&this.attenuationColor!==void 0)this.attenuationColor.setHex(e.attenuationColor);if(e.anisotropy!==void 0)this.anisotropy=e.anisotropy;if(e.anisotropyRotation!==void 0)this.anisotropyRotation=e.anisotropyRotation;if(e.fog!==void 0)this.fog=e.fog;if(e.flatShading!==void 0)this.flatShading=e.flatShading;if(e.blending!==void 0)this.blending=e.blending;if(e.combine!==void 0)this.combine=e.combine;if(e.side!==void 0)this.side=e.side;if(e.shadowSide!==void 0)this.shadowSide=e.shadowSide;if(e.opacity!==void 0)this.opacity=e.opacity;if(e.transparent!==void 0)this.transparent=e.transparent;if(e.alphaTest!==void 0)this.alphaTest=e.alphaTest;if(e.alphaHash!==void 0)this.alphaHash=e.alphaHash;if(e.depthFunc!==void 0)this.depthFunc=e.depthFunc;if(e.depthTest!==void 0)this.depthTest=e.depthTest;if(e.depthWrite!==void 0)this.depthWrite=e.depthWrite;if(e.colorWrite!==void 0)this.colorWrite=e.colorWrite;if(e.clippingPlanes!==void 0)this.clippingPlanes=e.clippingPlanes.map((n)=>new _n().fromJSON(n));if(e.clipIntersection!==void 0)this.clipIntersection=e.clipIntersection;if(e.clipShadows!==void 0)this.clipShadows=e.clipShadows;if(e.depthPacking!==void 0)this.depthPacking=e.depthPacking;if(e.blendSrc!==void 0)this.blendSrc=e.blendSrc;if(e.blendDst!==void 0)this.blendDst=e.blendDst;if(e.blendEquation!==void 0)this.blendEquation=e.blendEquation;if(e.blendSrcAlpha!==void 0)this.blendSrcAlpha=e.blendSrcAlpha;if(e.blendDstAlpha!==void 0)this.blendDstAlpha=e.blendDstAlpha;if(e.blendEquationAlpha!==void 0)this.blendEquationAlpha=e.blendEquationAlpha;if(e.blendColor!==void 0&&this.blendColor!==void 0)this.blendColor.setHex(e.blendColor);if(e.blendAlpha!==void 0)this.blendAlpha=e.blendAlpha;if(e.stencilWriteMask!==void 0)this.stencilWriteMask=e.stencilWriteMask;if(e.stencilFunc!==void 0)this.stencilFunc=e.stencilFunc;if(e.stencilRef!==void 0)this.stencilRef=e.stencilRef;if(e.stencilFuncMask!==void 0)this.stencilFuncMask=e.stencilFuncMask;if(e.stencilFail!==void 0)this.stencilFail=e.stencilFail;if(e.stencilZFail!==void 0)this.stencilZFail=e.stencilZFail;if(e.stencilZPass!==void 0)this.stencilZPass=e.stencilZPass;if(e.stencilWrite!==void 0)this.stencilWrite=e.stencilWrite;if(e.wireframe!==void 0)this.wireframe=e.wireframe;if(e.wireframeLinewidth!==void 0)this.wireframeLinewidth=e.wireframeLinewidth;if(e.wireframeLinecap!==void 0)this.wireframeLinecap=e.wireframeLinecap;if(e.wireframeLinejoin!==void 0)this.wireframeLinejoin=e.wireframeLinejoin;if(e.rotation!==void 0)this.rotation=e.rotation;if(e.linewidth!==void 0)this.linewidth=e.linewidth;if(e.linecap!==void 0)this.linecap=e.linecap;if(e.linejoin!==void 0)this.linejoin=e.linejoin;if(e.dashSize!==void 0)this.dashSize=e.dashSize;if(e.gapSize!==void 0)this.gapSize=e.gapSize;if(e.scale!==void 0)this.scale=e.scale;if(e.polygonOffset!==void 0)this.polygonOffset=e.polygonOffset;if(e.polygonOffsetFactor!==void 0)this.polygonOffsetFactor=e.polygonOffsetFactor;if(e.polygonOffsetUnits!==void 0)this.polygonOffsetUnits=e.polygonOffsetUnits;if(e.dithering!==void 0)this.dithering=e.dithering;if(e.alphaToCoverage!==void 0)this.alphaToCoverage=e.alphaToCoverage;if(e.premultipliedAlpha!==void 0)this.premultipliedAlpha=e.premultipliedAlpha;if(e.forceSinglePass!==void 0)this.forceSinglePass=e.forceSinglePass;if(e.allowOverride!==void 0)this.allowOverride=e.allowOverride;if(e.visible!==void 0)this.visible=e.visible;if(e.toneMapped!==void 0)this.toneMapped=e.toneMapped;if(e.userData!==void 0)this.userData=e.userData;if(e.vertexColors!==void 0)if(typeof e.vertexColors==="number")this.vertexColors=e.vertexColors>0;else this.vertexColors=e.vertexColors;if(e.size!==void 0)this.size=e.size;if(e.sizeAttenuation!==void 0)this.sizeAttenuation=e.sizeAttenuation;if(e.map!==void 0)this.map=t[e.map]||null;if(e.matcap!==void 0)this.matcap=t[e.matcap]||null;if(e.alphaMap!==void 0)this.alphaMap=t[e.alphaMap]||null;if(e.bumpMap!==void 0)this.bumpMap=t[e.bumpMap]||null;if(e.bumpScale!==void 0)this.bumpScale=e.bumpScale;if(e.normalMap!==void 0)this.normalMap=t[e.normalMap]||null;if(e.normalMapType!==void 0)this.normalMapType=e.normalMapType;if(e.normalScale!==void 0){let n=e.normalScale;if(Array.isArray(n)===!1)n=[n,n];this.normalScale=new Ce().fromArray(n)}if(e.displacementMap!==void 0)this.displacementMap=t[e.displacementMap]||null;if(e.displacementScale!==void 0)this.displacementScale=e.displacementScale;if(e.displacementBias!==void 0)this.displacementBias=e.displacementBias;if(e.roughnessMap!==void 0)this.roughnessMap=t[e.roughnessMap]||null;if(e.metalnessMap!==void 0)this.metalnessMap=t[e.metalnessMap]||null;if(e.emissiveMap!==void 0)this.emissiveMap=t[e.emissiveMap]||null;if(e.emissiveIntensity!==void 0)this.emissiveIntensity=e.emissiveIntensity;if(e.specularMap!==void 0)this.specularMap=t[e.specularMap]||null;if(e.specularIntensityMap!==void 0)this.specularIntensityMap=t[e.specularIntensityMap]||null;if(e.specularColorMap!==void 0)this.specularColorMap=t[e.specularColorMap]||null;if(e.envMap!==void 0)this.envMap=t[e.envMap]||null;if(e.envMapRotation!==void 0)this.envMapRotation.fromArray(e.envMapRotation);if(e.envMapIntensity!==void 0)this.envMapIntensity=e.envMapIntensity;if(e.reflectivity!==void 0)this.reflectivity=e.reflectivity;if(e.refractionRatio!==void 0)this.refractionRatio=e.refractionRatio;if(e.lightMap!==void 0)this.lightMap=t[e.lightMap]||null;if(e.lightMapIntensity!==void 0)this.lightMapIntensity=e.lightMapIntensity;if(e.aoMap!==void 0)this.aoMap=t[e.aoMap]||null;if(e.aoMapIntensity!==void 0)this.aoMapIntensity=e.aoMapIntensity;if(e.gradientMap!==void 0)this.gradientMap=t[e.gradientMap]||null;if(e.clearcoatMap!==void 0)this.clearcoatMap=t[e.clearcoatMap]||null;if(e.clearcoatRoughnessMap!==void 0)this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null;if(e.clearcoatNormalMap!==void 0)this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null;if(e.clearcoatNormalScale!==void 0)this.clearcoatNormalScale=new Ce().fromArray(e.clearcoatNormalScale);if(e.diffuseRoughnessMap!==void 0)this.diffuseRoughnessMap=t[e.diffuseRoughnessMap]||null;if(e.iridescenceMap!==void 0)this.iridescenceMap=t[e.iridescenceMap]||null;if(e.iridescenceThicknessMap!==void 0)this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null;if(e.transmissionMap!==void 0)this.transmissionMap=t[e.transmissionMap]||null;if(e.thicknessMap!==void 0)this.thicknessMap=t[e.thicknessMap]||null;if(e.anisotropyMap!==void 0)this.anisotropyMap=t[e.anisotropyMap]||null;if(e.sheenColorMap!==void 0)this.sheenColorMap=t[e.sheenColorMap]||null;if(e.sheenRoughnessMap!==void 0)this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null;return this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let i=t.length;n=Array(i);for(let s=0;s!==i;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){if(e===!0)this.version++}}var si=new R,Dl=new R,Io=new R,No=new R;class wi{constructor(e=new R,t=new R(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,si)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);if(n<0)return t.copy(this.origin);return t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=si.subVectors(e,this.origin).dot(this.direction);if(t<0)return this.origin.distanceToSquared(e);return si.copy(this.origin).addScaledVector(this.direction,t),si.distanceToSquared(e)}distanceSqToSegment(e,t,n,i){Dl.copy(e).add(t).multiplyScalar(0.5),Io.copy(t).sub(e).normalize(),No.copy(this.origin).sub(Dl);let s=e.distanceTo(t)*0.5,r=-this.direction.dot(Io),o=No.dot(this.direction),a=-No.dot(Io),l=No.lengthSq(),c=Math.abs(1-r*r),u,h,d,f;if(c>0)if(u=r*a-o,h=r*o-a,f=s*c,u>=0)if(h>=-f)if(h<=f){let m=1/c;u*=m,h*=m,d=u*(u+r*h+2*o)+h*(r*u+h+2*a)+l}else h=s,u=Math.max(0,-(r*h+o)),d=-u*u+h*(h+2*a)+l;else h=-s,u=Math.max(0,-(r*h+o)),d=-u*u+h*(h+2*a)+l;else if(h<=-f)u=Math.max(0,-(-r*s+o)),h=u>0?-s:Math.min(Math.max(-s,-a),s),d=-u*u+h*(h+2*a)+l;else if(h<=f)u=0,h=Math.min(Math.max(-s,-a),s),d=h*(h+2*a)+l;else u=Math.max(0,-(r*s+o)),h=u>0?s:Math.min(Math.max(-s,-a),s),d=-u*u+h*(h+2*a)+l;else h=r>0?-s:s,u=Math.max(0,-(r*h+o)),d=-u*u+h*(h+2*a)+l;if(n)n.copy(this.origin).addScaledVector(this.direction,u);if(i)i.copy(Dl).addScaledVector(Io,h);return d}intersectSphere(e,t){if(e.radius<0)return null;si.subVectors(e.center,this.origin);let n=si.dot(this.direction),i=si.dot(si)-n*n,s=e.radius*e.radius;if(i>s)return null;let r=Math.sqrt(s-i),o=n-r,a=n+r;if(a<0)return null;if(o<0)return this.at(a,t);return this.at(o,t)}intersectsSphere(e){if(e.radius<0)return!1;return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0){if(e.distanceToPoint(this.origin)===0)return 0;return null}let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);if(n===null)return null;return this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);if(t===0)return!0;if(e.normal.dot(this.direction)*t<0)return!0;return!1}intersectBox(e,t){let n,i,s,r,o,a,l=1/this.direction.x,c=1/this.direction.y,u=1/this.direction.z,h=this.origin;if(l>=0)n=(e.min.x-h.x)*l,i=(e.max.x-h.x)*l;else n=(e.max.x-h.x)*l,i=(e.min.x-h.x)*l;if(c>=0)s=(e.min.y-h.y)*c,r=(e.max.y-h.y)*c;else s=(e.max.y-h.y)*c,r=(e.min.y-h.y)*c;if(n>r||s>i)return null;if(s>n||isNaN(n))n=s;if(r<i||isNaN(i))i=r;if(u>=0)o=(e.min.z-h.z)*u,a=(e.max.z-h.z)*u;else o=(e.max.z-h.z)*u,a=(e.min.z-h.z)*u;if(n>a||o>i)return null;if(o>n||n!==n)n=o;if(a<i||i!==i)i=a;if(i<0)return null;return this.at(n>=0?n:i,t)}intersectsBox(e){return this.intersectBox(e,si)!==null}intersectTriangle(e,t,n,i,s){let r=this.origin,o=this.direction,{x:a,y:l,z:c}=o,u=e.x-r.x,h=e.y-r.y,d=e.z-r.z,f=t.x-r.x,m=t.y-r.y,x=t.z-r.z,p=n.x-r.x,g=n.y-r.y,v=n.z-r.z,S=Math.abs(a),T=Math.abs(l),A=Math.abs(c),w,_,E,I,k,N,V,Q,C,q,j,F;if(S>=T&&S>=A)if(E=a,N=u,C=f,F=p,a>=0)w=l,_=c,I=h,k=d,V=m,Q=x,q=g,j=v;else w=c,_=l,I=d,k=h,V=x,Q=m,q=v,j=g;else if(T>=A)if(E=l,N=h,C=m,F=g,l>=0)w=c,_=a,I=d,k=u,V=x,Q=f,q=v,j=p;else w=a,_=c,I=u,k=d,V=f,Q=x,q=p,j=v;else if(E=c,N=d,C=x,F=v,c>=0)w=a,_=l,I=u,k=h,V=f,Q=m,q=p,j=g;else w=l,_=a,I=h,k=u,V=m,Q=f,q=g,j=p;if(E===0)return null;let re=w/E,W=_/E,J=1/E,ne=I-re*N,Me=k-W*N,Z=V-re*C,te=Q-W*C,ye=q-re*F,Ne=j-W*F,De=ye*te-Ne*Z,_e=ne*Ne-Me*ye,it=Z*Me-te*ne;if(i){if(De<0||_e<0||it<0)return null}else if((De<0||_e<0||it<0)&&(De>0||_e>0||it>0))return null;let We=De+_e+it;if(We===0)return null;let Be=J*(De*N+_e*C+it*F);if(We>0?Be<0:Be>0)return null;return this.at(Be/We,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class nn extends tn{constructor(e){super();this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new xe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ht,this.combine=0,this.reflectivity=1,this.refractionRatio=0.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}var Nh=new Re,ji=new wi,Do=new pn,Dh=new R,Uo=new R,Oo=new R,Fo=new R,Ul=new R,Ho=new R,Uh=new R,Bo=new R;class bt extends tt{constructor(e=new Qe,t=new nn){super();this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){if(super.copy(e,t),e.morphTargetInfluences!==void 0)this.morphTargetInfluences=e.morphTargetInfluences.slice();else this.morphTargetInfluences=void 0;if(e.morphTargetDictionary!==void 0)this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary);else this.morphTargetDictionary=void 0;return this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this.count=e.count,this}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,r=i.length;s<r;s++){let o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){let n=this.geometry,i=n.attributes.position,s=n.morphAttributes.position,r=n.morphTargetsRelative;t.fromBufferAttribute(i,e);let o=this.morphTargetInfluences;if(s&&o){Ho.set(0,0,0);for(let a=0,l=s.length;a<l;a++){let c=o[a],u=s[a];if(c===0)continue;if(Ul.fromBufferAttribute(u,e),r)Ho.addScaledVector(Ul,c);else Ho.addScaledVector(Ul.sub(t),c)}t.add(Ho)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,i=this.material,s=this.matrixWorld;if(i===void 0)return;if(n.boundingSphere===null)n.computeBoundingSphere();if(Do.copy(n.boundingSphere),Do.applyMatrix4(s),ji.copy(e.ray).recast(e.near),Do.containsPoint(ji.origin)===!1){if(ji.intersectSphere(Do,Dh)===null)return;if(ji.origin.distanceToSquared(Dh)>(e.far-e.near)**2)return}if(Nh.copy(s).invert(),ji.copy(e.ray).applyMatrix4(Nh),n.boundingBox!==null){if(ji.intersectsBox(n.boundingBox)===!1)return}this._computeIntersections(e,t,ji)}_computeIntersections(e,t,n){let i,s=this.geometry,r=this.material,o=s.index,a=s.attributes.position,l=s.attributes.uv,c=s.attributes.uv1,u=s.attributes.normal,{groups:h,drawRange:d}=s;if(o!==null)if(Array.isArray(r))for(let f=0,m=h.length;f<m;f++){let x=h[f],p=r[x.materialIndex],g=Math.max(x.start,d.start),v=Math.min(o.count,Math.min(x.start+x.count,d.start+d.count));for(let S=g,T=v;S<T;S+=3){let A=o.getX(S),w=o.getX(S+1),_=o.getX(S+2);if(i=Vo(this,p,e,n,l,c,u,A,w,_),i)i.faceIndex=Math.floor(S/3),i.face.materialIndex=x.materialIndex,t.push(i)}}else{let f=Math.max(0,d.start),m=Math.min(o.count,d.start+d.count);for(let x=f,p=m;x<p;x+=3){let g=o.getX(x),v=o.getX(x+1),S=o.getX(x+2);if(i=Vo(this,r,e,n,l,c,u,g,v,S),i)i.faceIndex=Math.floor(x/3),t.push(i)}}else if(a!==void 0)if(Array.isArray(r))for(let f=0,m=h.length;f<m;f++){let x=h[f],p=r[x.materialIndex],g=Math.max(x.start,d.start),v=Math.min(a.count,Math.min(x.start+x.count,d.start+d.count));for(let S=g,T=v;S<T;S+=3){let A=S,w=S+1,_=S+2;if(i=Vo(this,p,e,n,l,c,u,A,w,_),i)i.faceIndex=Math.floor(S/3),i.face.materialIndex=x.materialIndex,t.push(i)}}else{let f=Math.max(0,d.start),m=Math.min(a.count,d.start+d.count);for(let x=f,p=m;x<p;x+=3){let g=x,v=x+1,S=x+2;if(i=Vo(this,r,e,n,l,c,u,g,v,S),i)i.faceIndex=Math.floor(x/3),t.push(i)}}}}function rg(e,t,n,i,s,r,o,a){let l;if(t.side===1)l=i.intersectTriangle(o,r,s,!0,a);else l=i.intersectTriangle(s,r,o,t.side===0,a);if(l===null)return null;Bo.copy(a),Bo.applyMatrix4(e.matrixWorld);let c=n.ray.origin.distanceTo(Bo);if(c<n.near||c>n.far)return null;return{distance:c,point:Bo.clone(),object:e}}function Vo(e,t,n,i,s,r,o,a,l,c){e.getVertexPosition(a,Uo),e.getVertexPosition(l,Oo),e.getVertexPosition(c,Fo);let u=rg(e,t,n,i,Uo,Oo,Fo,Uh);if(u){let h=new R;if(xn.getBarycoord(Uh,Uo,Oo,Fo,h),s)u.uv=xn.getInterpolatedAttribute(s,a,l,c,h,new Ce);if(r)u.uv1=xn.getInterpolatedAttribute(r,a,l,c,h,new Ce);if(o){if(u.normal=xn.getInterpolatedAttribute(o,a,l,c,h,new R),u.normal.dot(i.direction)>0)u.normal.multiplyScalar(-1)}let d={a,b:l,c,normal:new R,materialIndex:0};xn.getNormal(Uo,Oo,Fo,d.normal),u.face=d,u.barycoord=h}return u}var Mr=new ut,Oh=new ut,Fh=new ut,og=new ut,Hh=new Re,ko=new R,Ol=new pn,Bh=new Re,Fl=new wi;class Gs extends bt{constructor(e,t){super(e,t);this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode="attached",this.bindMatrix=new Re,this.bindMatrixInverse=new Re,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){let e=this.geometry;if(this.boundingBox===null)this.boundingBox=new yn;this.boundingBox.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,ko),this.boundingBox.expandByPoint(ko)}computeBoundingSphere(){let e=this.geometry;if(this.boundingSphere===null)this.boundingSphere=new pn;this.boundingSphere.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,ko),this.boundingSphere.expandByPoint(ko)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,this.boundingBox=e.boundingBox!==null?e.boundingBox.clone():null,this.boundingSphere=e.boundingSphere!==null?e.boundingSphere.clone():null,this}raycast(e,t){let n=this.material,i=this.matrixWorld;if(n===void 0)return;if(this.boundingSphere===null)this.computeBoundingSphere();if(Ol.copy(this.boundingSphere),Ol.applyMatrix4(i),e.ray.intersectsSphere(Ol)===!1)return;if(Bh.copy(i).invert(),Fl.copy(e.ray).applyMatrix4(Bh),this.boundingBox!==null){if(Fl.intersectsBox(this.boundingBox)===!1)return}this._computeIntersections(e,t,Fl)}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){if(this.skeleton=e,t===void 0)this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld;this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){let e=new ut,t=this.geometry.attributes.skinWeight;for(let n=0,i=t.count;n<i;n++){e.fromBufferAttribute(t,n);let s=1/e.manhattanLength();if(s!==1/0)e.multiplyScalar(s);else e.set(1,0,0,0);t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){if(super.updateMatrixWorld(e),this.bindMode==="attached")this.bindMatrixInverse.copy(this.matrixWorld).invert();else if(this.bindMode==="detached")this.bindMatrixInverse.copy(this.bindMatrix).invert();else we("SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){let n=this.skeleton,i=this.geometry;if(Oh.fromBufferAttribute(i.attributes.skinIndex,e),Fh.fromBufferAttribute(i.attributes.skinWeight,e),t.isVector4)Mr.copy(t),t.set(0,0,0,0);else Mr.set(t.x,t.y,t.z,1),t.set(0,0,0);Mr.applyMatrix4(this.bindMatrix);for(let s=0;s<4;s++){let r=Fh.getComponent(s);if(r!==0){let o=Oh.getComponent(s);Hh.multiplyMatrices(n.bones[o].matrixWorld,n.boneInverses[o]),t.addScaledVector(og.copy(Mr).applyMatrix4(Hh),r)}}if(t.isVector4)t.w=Mr.w;return t.applyMatrix4(this.bindMatrixInverse)}}class Ur extends tt{constructor(){super();this.isBone=!0,this.type="Bone"}}class Or extends vt{constructor(e=null,t=1,n=1,i,s,r,o,a,l=1003,c=1003,u,h){super(null,r,o,a,l,c,i,s,u,h);this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}var Vh=new Re,ag=new Re;class Dn{constructor(e=[],t=[]){this.uuid=zn(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.previousBoneMatrices=null,this.boneTexture=null,this.previousBoneTexture=null,this.init()}init(){let e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){we("Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,i=this.bones.length;n<i;n++)this.boneInverses.push(new Re)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){let n=new Re;if(this.bones[e])n.copy(this.bones[e].matrixWorld).invert();this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];if(n)n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];if(n){if(n.parent&&n.parent.isBone)n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld);else n.matrix.copy(n.matrixWorld);n.matrix.decompose(n.position,n.quaternion,n.scale)}}}update(){let e=this.bones,t=this.boneInverses,n=this.boneMatrices,i=this.boneTexture;for(let s=0,r=e.length;s<r;s++){let o=e[s]?e[s].matrixWorld:ag;Vh.multiplyMatrices(o,t[s]),Vh.toArray(n,s*16)}if(i!==null)i.needsUpdate=!0}clone(){return new Dn(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);let t=new Float32Array(e*e*4);t.set(this.boneMatrices);let n=new Or(t,e,e,1023,1015);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){let i=this.bones[t];if(i.name===e)return i}return}dispose(){if(this.boneTexture!==null)this.boneTexture.dispose(),this.boneTexture=null;if(this.previousBoneTexture!==null)this.previousBoneTexture.dispose(),this.previousBoneTexture=null}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,i=e.bones.length;n<i;n++){let s=e.bones[n],r=t[s];if(r===void 0)we("Skeleton: No bone found with UUID:",s),r=new Ur;this.bones.push(r),this.boneInverses.push(new Re().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){let e={metadata:{version:4.7,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;let t=this.bones,n=this.boneInverses;for(let i=0,s=t.length;i<s;i++){let r=t[i];e.bones.push(r.uuid);let o=n[i];e.boneInverses.push(o.toArray())}return e}}class vi extends Ge{constructor(e,t,n,i=1){super(e,t,n);this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}var As=new Re,kh=new Re,Go=[],Gh=new yn,lg=new Re,yr=new bt,vr=new pn;class ma extends bt{constructor(e,t,n){super(e,t);this.isInstancedMesh=!0,this.instanceMatrix=new vi(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,lg)}computeBoundingBox(){let e=this.geometry,t=this.count;if(this.boundingBox===null)this.boundingBox=new yn;if(e.boundingBox===null)e.computeBoundingBox();this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,As),Gh.copy(e.boundingBox).applyMatrix4(As),this.boundingBox.union(Gh)}computeBoundingSphere(){let e=this.geometry,t=this.count;if(this.boundingSphere===null)this.boundingSphere=new pn;if(e.boundingSphere===null)e.computeBoundingSphere();this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,As),vr.copy(e.boundingSphere).applyMatrix4(As),this.boundingSphere.union(vr)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),this.morphTexture=e.morphTexture!==null?e.morphTexture.clone():null,this.instanceColor=e.instanceColor!==null?e.instanceColor.clone():null,this.count=e.count,this.boundingBox=e.boundingBox!==null?e.boundingBox.clone():null,this.boundingSphere=e.boundingSphere!==null?e.boundingSphere.clone():null,this}getColorAt(e,t){if(this.instanceColor===null)return t.setRGB(1,1,1);else return t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let n=t.morphTargetInfluences,i=this.morphTexture.source.data.data,s=n.length+1,r=e*s+1;for(let o=0;o<n.length;o++)n[o]=i[r+o]}raycast(e,t){let n=this.matrixWorld,i=this.count;if(yr.geometry=this.geometry,yr.material=this.material,yr.material===void 0)return;if(this.boundingSphere===null)this.computeBoundingSphere();if(vr.copy(this.boundingSphere),vr.applyMatrix4(n),e.ray.intersectsSphere(vr)===!1)return;for(let s=0;s<i;s++){this.getMatrixAt(s,As),kh.multiplyMatrices(n,As),yr.matrixWorld=kh,yr.raycast(e,Go);for(let r=0,o=Go.length;r<o;r++){let a=Go[r];a.instanceId=s,a.object=this,t.push(a)}Go.length=0}}setColorAt(e,t){if(this.instanceColor===null)this.instanceColor=new vi(new Float32Array(this.instanceMatrix.count*3).fill(1),3);return t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){let n=t.morphTargetInfluences,i=n.length+1;if(this.morphTexture===null)this.morphTexture=new Or(new Float32Array(i*this.count),i,this.count,1028,1015);let s=this.morphTexture.source.data.data,r=0;for(let l=0;l<n.length;l++)r+=n[l];let o=this.geometry.morphTargetsRelative?1:1-r,a=i*e;return s[a]=o,s.set(n,a+1),this}updateMorphTargets(){}dispose(){if(super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null)this.instanceColor.dispose();if(this.morphTexture!==null)this.morphTexture.dispose(),this.morphTexture=null}}var Ji=new pn,cg=new Ce(0.5,0.5),zo=new R;class Qi{constructor(e=new _n,t=new _n,n=new _n,i=new _n,s=new _n,r=new _n){this.planes=[e,t,n,i,s,r]}set(e,t,n,i,s,r){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(i),o[4].copy(s),o[5].copy(r),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=2000,n=!1){let i=this.planes,s=e.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],u=s[5],h=s[6],d=s[7],f=s[8],m=s[9],x=s[10],p=s[11],g=s[12],v=s[13],S=s[14],T=s[15];if(i[0].setComponents(l-r,d-c,p-f,T-g).normalize(),i[1].setComponents(l+r,d+c,p+f,T+g).normalize(),i[2].setComponents(l+o,d+u,p+m,T+v).normalize(),i[3].setComponents(l-o,d-u,p-m,T-v).normalize(),n)i[4].setComponents(a,h,x,S).normalize(),i[5].setComponents(l-a,d-h,p-x,T-S).normalize();else if(i[4].setComponents(l-a,d-h,p-x,T-S).normalize(),t===2000)i[5].setComponents(l+a,d+h,p+x,T+S).normalize();else if(t===2001)i[5].setComponents(a,h,x,S).normalize();else throw Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0){if(e.boundingSphere===null)e.computeBoundingSphere();Ji.copy(e.boundingSphere).applyMatrix4(e.matrixWorld)}else{let t=e.geometry;if(t.boundingSphere===null)t.computeBoundingSphere();Ji.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Ji)}intersectsSprite(e){Ji.center.set(0,0,0);let t=cg.distanceTo(e.center);return Ji.radius=0.7071067811865476+t,Ji.applyMatrix4(e.matrixWorld),this.intersectsSphere(Ji)}intersectsSphere(e){let t=this.planes,n=e.center,i=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let i=t[n];if(zo.x=i.normal.x>0?e.max.x:e.min.x,zo.y=i.normal.y>0?e.max.y:e.min.y,zo.z=i.normal.z>0?e.max.z:e.min.z,i.distanceToPoint(zo)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}var zh=new Re;class ga{constructor(){this.coordinateSystem=2000,this._frustums=[],this._count=0}setFromArrayCamera(e){let t=e.cameras,n=this._frustums;for(let i=0;i<t.length;i++){let s=t[i];if(zh.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),n[i]===void 0)n[i]=new Qi;n[i].setFromProjectionMatrix(zh,s.coordinateSystem,s.reversedDepth)}return this._count=t.length,this}getFrustum(e){return this._frustums[e]}intersectsObject(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsObject(e))return!0;return!1}intersectsSprite(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSprite(e))return!0;return!1}intersectsSphere(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSphere(e))return!0;return!1}intersectsBox(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsBox(e))return!0;return!1}containsPoint(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].containsPoint(e))return!0;return!1}copy(e){this.coordinateSystem=e.coordinateSystem;let t=this._frustums,n=e._frustums;for(let i=0;i<e._count;i++){if(t[i]===void 0)t[i]=new Qi;t[i].copy(n[i])}return this._count=e._count,this}clone(){return new ga().copy(this)}}class an extends tn{constructor(e){super();this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new xe(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}var Jo=new R,Ko=new R,Wh=new Re,Er=new wi,Wo=new pn,Hl=new R,Xh=new R;class Ci extends tt{constructor(e=new Qe,t=new an){super();this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){if(super.copy(e,t),e.morphTargetInfluences!==void 0)this.morphTargetInfluences=e.morphTargetInfluences.slice();else this.morphTargetInfluences=void 0;if(e.morphTargetDictionary!==void 0)this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary);else this.morphTargetDictionary=void 0;return this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let i=1,s=t.count;i<s;i++)Jo.fromBufferAttribute(t,i-1),Ko.fromBufferAttribute(t,i),n[i]=n[i-1],n[i]+=Jo.distanceTo(Ko);e.setAttribute("lineDistance",new Rt(n,1))}else we("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,i=this.matrixWorld,s=e.params.Line.threshold,r=n.drawRange;if(n.boundingSphere===null)n.computeBoundingSphere();if(Wo.copy(n.boundingSphere),Wo.applyMatrix4(i),Wo.radius+=s,e.ray.intersectsSphere(Wo)===!1)return;Wh.copy(i).invert(),Er.copy(e.ray).applyMatrix4(Wh);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),a=o*o,l=this.isLineSegments?2:1,c=n.index,h=n.attributes.position;if(c!==null){let d=Math.max(0,r.start),f=Math.min(c.count,r.start+r.count);for(let m=d,x=f-1;m<x;m+=l){let p=c.getX(m),g=c.getX(m+1),v=Xo(this,e,Er,a,p,g,m);if(v)t.push(v)}if(this.isLineLoop){let m=c.getX(f-1),x=c.getX(d),p=Xo(this,e,Er,a,m,x,f-1);if(p)t.push(p)}}else{let d=Math.max(0,r.start),f=Math.min(h.count,r.start+r.count);for(let m=d,x=f-1;m<x;m+=l){let p=Xo(this,e,Er,a,m,m+1,m);if(p)t.push(p)}if(this.isLineLoop){let m=Xo(this,e,Er,a,f-1,d,f-1);if(m)t.push(m)}}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,r=i.length;s<r;s++){let o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Xo(e,t,n,i,s,r,o){let a=e.geometry.attributes.position;if(Jo.fromBufferAttribute(a,s),Ko.fromBufferAttribute(a,r),n.distanceSqToSegment(Jo,Ko,Hl,Xh)>i)return;Hl.applyMatrix4(e.matrixWorld);let c=t.ray.origin.distanceTo(Hl);if(c<t.near||c>t.far)return;return{distance:c,point:Xh.clone().applyMatrix4(e.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:e}}var qh=new R,Yh=new R;class Un extends Ci{constructor(e,t){super(e,t);this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let i=0,s=t.count;i<s;i+=2)qh.fromBufferAttribute(t,i),Yh.fromBufferAttribute(t,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+qh.distanceTo(Yh);e.setAttribute("lineDistance",new Rt(n,1))}else we("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class _a extends Ci{constructor(e,t){super(e,t);this.isLineLoop=!0,this.type="LineLoop"}}class rs extends tn{constructor(e){super();this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new xe(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}var Zh=new Re,kl=new wi,qo=new pn,Yo=new R;class zs extends tt{constructor(e=new Qe,t=new rs){super();this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){if(super.copy(e,t),e.morphTargetInfluences!==void 0)this.morphTargetInfluences=e.morphTargetInfluences.slice();else this.morphTargetInfluences=void 0;if(e.morphTargetDictionary!==void 0)this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary);else this.morphTargetDictionary=void 0;return this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,i=this.matrixWorld,s=e.params.Points.threshold,r=n.drawRange;if(n.boundingSphere===null)n.computeBoundingSphere();if(qo.copy(n.boundingSphere),qo.applyMatrix4(i),qo.radius+=s,e.ray.intersectsSphere(qo)===!1)return;Zh.copy(i).invert(),kl.copy(e.ray).applyMatrix4(Zh);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),a=o*o,l=n.index,u=n.attributes.position;if(l!==null){let h=Math.max(0,r.start),d=Math.min(l.count,r.start+r.count);for(let f=h,m=d;f<m;f++){let x=l.getX(f);Yo.fromBufferAttribute(u,x),jh(Yo,x,a,i,e,t,this)}}else{let h=Math.max(0,r.start),d=Math.min(u.count,r.start+r.count);for(let f=h,m=d;f<m;f++)Yo.fromBufferAttribute(u,f),jh(Yo,f,a,i,e,t,this)}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,r=i.length;s<r;s++){let o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function jh(e,t,n,i,s,r,o){let a=kl.distanceSqToPoint(e);if(a<n){let l=new R;kl.closestPointToPoint(e,l),l.applyMatrix4(i);let c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:o})}}class xa extends vt{constructor(e=[],t=301,n,i,s,r,o,a,l,c){super(e,t,n,i,s,r,o,a,l,c);this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Ma extends vt{constructor(e,t,n,i,s,r,o,a,l){super(e,t,n,i,s,r,o,a,l);this.isCanvasTexture=!0,this.needsUpdate=!0}}class Pi extends vt{constructor(e,t,n=1014,i,s,r,o=1003,a=1003,l,c=1026,u=1){if(c!==1026&&c!==1027)throw Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");let h={width:e,height:t,depth:u};super(h,i,s,r,o,a,c,n,l);this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Nr(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}}class ya extends Pi{constructor(e,t=1014,n=301,i,s,r=1003,o=1003,a,l=1026){let c={width:e,height:e,depth:1},u=[c,c,c,c,c,c];super(e,e,t,n,i,s,r,o,a,l);this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class va extends vt{constructor(e=null){super();this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Ws extends Qe{constructor(e=1,t=1,n=1,i=1,s=1,r=1){super();this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:i,heightSegments:s,depthSegments:r};let o=this;i=Math.floor(i),s=Math.floor(s),r=Math.floor(r);let a=[],l=[],c=[],u=[],h=0,d=0;f("z","y","x",-1,-1,n,t,e,r,s,0),f("z","y","x",1,-1,n,t,-e,r,s,1),f("x","z","y",1,1,e,n,t,i,r,2),f("x","z","y",1,-1,e,n,-t,i,r,3),f("x","y","z",1,-1,e,t,n,i,s,4),f("x","y","z",-1,-1,e,t,-n,i,s,5),this.setIndex(a),this.setAttribute("position",new Rt(l,3)),this.setAttribute("normal",new Rt(c,3)),this.setAttribute("uv",new Rt(u,2));function f(m,x,p,g,v,S,T,A,w,_,E){let I=S/w,k=T/_,N=S/2,V=T/2,Q=A/2,C=w+1,q=_+1,j=0,F=0,re=new R;for(let W=0;W<q;W++){let J=W*k-V;for(let ne=0;ne<C;ne++){let Me=ne*I-N;re[m]=Me*g,re[x]=J*v,re[p]=Q,l.push(re.x,re.y,re.z),re[m]=0,re[x]=0,re[p]=A>0?1:-1,c.push(re.x,re.y,re.z),u.push(ne/w),u.push(1-W/_),j+=1}}for(let W=0;W<_;W++)for(let J=0;J<w;J++){let ne=h+J+C*W,Me=h+J+C*(W+1),Z=h+(J+1)+C*(W+1),te=h+(J+1)+C*W;a.push(ne,Me,te),a.push(Me,Z,te),F+=6}o.addGroup(d,F,E),d+=F,h+=j}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ws(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Xs extends Qe{constructor(e=1,t=32,n=0,i=Math.PI*2){super();this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:i},t=Math.max(3,t);let s=[],r=[],o=[],a=[],l=new R,c=new Ce;r.push(0,0,0),o.push(0,0,1),a.push(0.5,0.5);for(let u=0,h=3;u<=t;u++,h+=3){let d=n+u/t*i;l.x=e*Math.cos(d),l.y=e*Math.sin(d),r.push(l.x,l.y,l.z),o.push(0,0,1),c.x=(r[h]/e+1)/2,c.y=(r[h+1]/e+1)/2,a.push(c.x,c.y)}for(let u=1;u<=t;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new Rt(r,3)),this.setAttribute("normal",new Rt(o,3)),this.setAttribute("uv",new Rt(a,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Xs(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class Fr extends Qe{constructor(e=1,t=1,n=1,i=1){super();this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:i};let s=e/2,r=t/2,o=Math.floor(n),a=Math.floor(i),l=o+1,c=a+1,u=e/o,h=t/a,d=[],f=[],m=[],x=[];for(let p=0;p<c;p++){let g=p*h-r;for(let v=0;v<l;v++){let S=v*u-s;f.push(S,-g,0),m.push(0,0,1),x.push(v/o),x.push(1-p/a)}}for(let p=0;p<a;p++)for(let g=0;g<o;g++){let v=g+l*p,S=g+l*(p+1),T=g+1+l*(p+1),A=g+1+l*p;d.push(v,S,A),d.push(S,T,A)}this.setIndex(d),this.setAttribute("position",new Rt(f,3)),this.setAttribute("normal",new Rt(m,3)),this.setAttribute("uv",new Rt(x,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Fr(e.width,e.height,e.widthSegments,e.heightSegments)}}function os(e){let t={};for(let n in e){t[n]={};for(let i in e[n]){let s=e[n][i];if(Jh(s))if(s.isRenderTargetTexture)we("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[n][i]=null;else t[n][i]=s.clone();else if(Array.isArray(s))if(Jh(s[0])){let r=[];for(let o=0,a=s.length;o<a;o++)r[o]=s[o].clone();t[n][i]=r}else t[n][i]=s.slice();else t[n][i]=s}}return t}function Zt(e){let t={};for(let n=0;n<e.length;n++){let i=os(e[n]);for(let s in i)t[s]=i[s]}return t}function Jh(e){return e&&(e.isColor||e.isMatrix3||e.isMatrix4||e.isVector2||e.isVector3||e.isVector4||e.isTexture||e.isQuaternion)}function ug(e){let t=[];for(let n=0;n<e.length;n++)t.push(e[n].clone());return t}function $c(e){let t=e.getRenderTarget();if(t===null)return e.outputColorSpace;if(t.isXRRenderTarget===!0)return t.texture.colorSpace;return qe.workingColorSpace}var Ea={clone:os,merge:Zt},hg=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,dg=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class On extends tn{constructor(e){super();if(this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=hg,this.fragmentShader=dg,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0)this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=os(e.uniforms),this.uniformsGroups=ug(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.linewidth=e.linewidth,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let i in this.uniforms){let r=this.uniforms[i].value;if(r&&r.isTexture)t.uniforms[i]={type:"t",value:r.toJSON(e).uuid};else if(r&&r.isColor)t.uniforms[i]={type:"c",value:r.getHex()};else if(r&&r.isVector2)t.uniforms[i]={type:"v2",value:r.toArray()};else if(r&&r.isVector3)t.uniforms[i]={type:"v3",value:r.toArray()};else if(r&&r.isVector4)t.uniforms[i]={type:"v4",value:r.toArray()};else if(r&&r.isMatrix3)t.uniforms[i]={type:"m3",value:r.toArray()};else if(r&&r.isMatrix4)t.uniforms[i]={type:"m4",value:r.toArray()};else t.uniforms[i]={value:r}}if(Object.keys(this.defines).length>0)t.defines=this.defines;t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let i in this.extensions)if(this.extensions[i]===!0)n[i]=!0;if(Object.keys(n).length>0)t.extensions=n;return t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(let n in e.uniforms){let i=e.uniforms[n];switch(this.uniforms[n]={},i.type){case"t":this.uniforms[n].value=t[i.value]||null;break;case"c":this.uniforms[n].value=new xe().setHex(i.value);break;case"v2":this.uniforms[n].value=new Ce().fromArray(i.value);break;case"v3":this.uniforms[n].value=new R().fromArray(i.value);break;case"v4":this.uniforms[n].value=new ut().fromArray(i.value);break;case"m3":this.uniforms[n].value=new Pe().fromArray(i.value);break;case"m4":this.uniforms[n].value=new Re().fromArray(i.value);break;default:this.uniforms[n].value=i.value}}if(e.defines!==void 0)this.defines=e.defines;if(e.vertexShader!==void 0)this.vertexShader=e.vertexShader;if(e.fragmentShader!==void 0)this.fragmentShader=e.fragmentShader;if(e.glslVersion!==void 0)this.glslVersion=e.glslVersion;if(e.extensions!==void 0)for(let n in e.extensions)this.extensions[n]=e.extensions[n];if(e.lights!==void 0)this.lights=e.lights;if(e.clipping!==void 0)this.clipping=e.clipping;return this}}class Qc extends On{constructor(e){super(e);this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class qs extends tn{constructor(e){super();this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new xe(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new xe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new Ce(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ht,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class ln extends qs{constructor(e){super();this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Ce(1,1),this.clearcoatNormalMap=null,this.diffuseRoughnessMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Ye(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+0.4*t)/(1-0.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessMinimum=100,this.iridescenceThicknessMaximum=400,this.iridescenceThicknessMap=null,this.sheenColor=new xe(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new xe(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new xe(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._diffuseRoughness=0,this._dispersion=0,this._iridescence=0,this._retroreflectivity=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){if(this._anisotropy>0!==e>0)this.version++;this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){if(this._clearcoat>0!==e>0)this.version++;this._clearcoat=e}get diffuseRoughness(){return this._diffuseRoughness}set diffuseRoughness(e){if(this._diffuseRoughness>0!==e>0)this.version++;this._diffuseRoughness=e}get iridescence(){return this._iridescence}set iridescence(e){if(this._iridescence>0!==e>0)this.version++;this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){if(this._dispersion>0!==e>0)this.version++;this._dispersion=e}get retroreflectivity(){return this._retroreflectivity}set retroreflectivity(e){if(this._retroreflectivity>0!==e>0)this.version++;this._retroreflectivity=e}get sheen(){return this._sheen}set sheen(e){if(this._sheen>0!==e>0)this.version++;this._sheen=e}get transmission(){return this._transmission}set transmission(e){if(this._transmission>0!==e>0)this.version++;this._transmission=e}get iridescenceThicknessRange(){return Ki('MeshPhysicalMaterial: The "iridescenceThicknessRange" property has been replaced by "iridescenceThicknessMinimum" and "iridescenceThicknessMaximum".'),[this.iridescenceThicknessMinimum,this.iridescenceThicknessMaximum]}set iridescenceThicknessRange(e){Ki('MeshPhysicalMaterial: The "iridescenceThicknessRange" property has been replaced by "iridescenceThicknessMinimum" and "iridescenceThicknessMaximum".'),this.iridescenceThicknessMinimum=e[0],this.iridescenceThicknessMaximum=e[1]}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.diffuseRoughness=e.diffuseRoughness,this.diffuseRoughnessMap=e.diffuseRoughnessMap,this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessMinimum=e.iridescenceThicknessMinimum,this.iridescenceThicknessMaximum=e.iridescenceThicknessMaximum,this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.retroreflectivity=e.retroreflectivity,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class eu extends tn{constructor(e){super();this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=3200,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class tu extends tn{constructor(e){super();this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}function yi(e,t){if(!e||e.constructor===t)return e;if(typeof t.BYTES_PER_ELEMENT==="number")return new t(e);return Array.prototype.slice.call(e)}function Tr(e){return e!==void 0&&e.inTangents!==void 0&&e.outTangents!==void 0}function fg(e){function t(s,r){return e[s]-e[r]}let n=e.length,i=Array(n);for(let s=0;s!==n;++s)i[s]=s;return i.sort(t),i}function Kh(e,t,n){let i=e.length,s=new e.constructor(i);for(let r=0,o=0;o!==i;++r){let a=n[r]*t;for(let l=0;l!==t;++l)s[o++]=e[a+l]}return s}function pg(e,t,n,i){let s=1,r=e[0];while(r!==void 0&&r[i]===void 0)r=e[s++];if(r===void 0)return;let o=r[i];if(o===void 0)return;if(Array.isArray(o))do{if(o=r[i],o!==void 0)t.push(r.time),n.push(...o);r=e[s++]}while(r!==void 0);else if(o.toArray!==void 0)do{if(o=r[i],o!==void 0)t.push(r.time),o.toArray(n,n.length);r=e[s++]}while(r!==void 0);else do{if(o=r[i],o!==void 0)t.push(r.time),n.push(o);r=e[s++]}while(r!==void 0)}class hi{constructor(e,t,n,i){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,i=t[n],s=t[n-1];n:{e:{let r;t:{i:if(!(e<i)){for(let o=n+2;;){if(i===void 0){if(e<s)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(s=i,i=t[++n],e<i)break e}r=t.length;break t}if(!(e>=s)){let o=t[1];if(e<o)n=2,s=o;for(let a=n-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===a)break;if(i=s,s=t[--n-1],e>=s)break e}r=n,n=0;break t}break n}while(n<r){let o=n+r>>>1;if(e<t[o])r=o;else n=o+1}if(i=t[n],s=t[n-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,s,i)}return this.interpolate_(n,s,e,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,i=this.valueSize,s=e*i;for(let r=0;r!==i;++r)t[r]=n[s+r];return t}interpolate_(){throw Error("THREE.Interpolant: Call to abstract method.")}intervalChanged_(){}}class nu extends hi{constructor(e,t,n,i){super(e,t,n,i);this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:2400,endingEnd:2400}}intervalChanged_(e,t,n){let i=this.parameterPositions,s=e-2,r=e+1,o=i[s],a=i[r];if(o===void 0)switch(this.getSettings_().endingStart){case 2401:s=e,o=2*t-n;break;case 2402:s=i.length-2,o=t+i[s]-i[s+1];break;default:s=e,o=n}if(a===void 0)switch(this.getSettings_().endingEnd){case 2401:r=e,a=2*n-t;break;case 2402:r=1,a=n+i[1]-i[0];break;default:r=e-1,a=t}let l=(n-t)*0.5,c=this.valueSize;this._weightPrev=l/(t-o),this._weightNext=l/(a-n),this._offsetPrev=s*c,this._offsetNext=r*c}interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=e*o,l=a-o,c=this._offsetPrev,u=this._offsetNext,h=this._weightPrev,d=this._weightNext,f=(n-t)/(i-t),m=f*f,x=m*f,p=-h*x+2*h*m-h*f,g=(1+h)*x+(-1.5-2*h)*m+(-0.5+h)*f+1,v=(-1-d)*x+(1.5+d)*m+0.5*f,S=d*x-d*m;for(let T=0;T!==o;++T)s[T]=p*r[c+T]+g*r[l+T]+v*r[a+T]+S*r[u+T];return s}}class iu extends hi{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=e*o,l=a-o,c=(n-t)/(i-t),u=1-c;for(let h=0;h!==o;++h)s[h]=r[l+h]*u+r[a+h]*c;return s}}class su extends hi{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e){return this.copySampleValue_(e-1)}}class ru extends hi{interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=e*o,l=a-o,c=this.inTangents,u=this.outTangents;if(!c||!u){let f=(n-t)/(i-t),m=1-f;for(let x=0;x!==o;++x)s[x]=r[l+x]*m+r[a+x]*f;return s}let h=o*2,d=e-1;for(let f=0;f!==o;++f){let m=r[l+f],x=r[a+f],p=d*h+f*2,g=u[p],v=u[p+1],S=e*h+f*2,T=c[S],A=c[S+1],w=gg(n,t,g,T,i);s[f]=nf(w,m,v,A,x)}return s}}function nf(e,t,n,i,s){let r=1-e;return r*r*r*t+3*r*r*e*n+3*r*e*e*i+e*e*e*s}function mg(e,t,n,i,s){let r=1-e;return 3*r*r*(n-t)+6*r*e*(i-n)+3*e*e*(s-i)}function gg(e,t,n,i,s){let r=(e-t)/(s-t);for(let o=0;o<8;o++){let a=nf(r,t,n,i,s)-e;if(Math.abs(a)<0.0000000001)break;let l=mg(r,t,n,i,s);if(Math.abs(l)<0.0000000001)break;r=Math.max(0,Math.min(1,r-a/l))}return r}class mn{constructor(e,t,n,i){if(e===void 0)throw Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=yi(t,this.TimeBufferType),this.values=yi(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:yi(e.times,Array),values:yi(e.values,Array)};let i=e.getInterpolation();if(i!==e.DefaultInterpolation)n.interpolation=i;if(Tr(e.settings))n.settings={inTangents:yi(e.settings.inTangents,Array),outTangents:yi(e.settings.outTangents,Array)}}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new su(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new iu(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new nu(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new ru(this.times,this.values,this.getValueSize(),e);if(this.settings)t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents;return t}setInterpolation(e){let t;switch(e){case 2300:t=this.InterpolantFactoryMethodDiscrete;break;case 2301:t=this.InterpolantFactoryMethodLinear;break;case 2302:t=this.InterpolantFactoryMethodSmooth;break;case 2303:t=this.InterpolantFactoryMethodBezier;break}if(t===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw Error(n);return we("KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return 2300;case this.InterpolantFactoryMethodLinear:return 2301;case this.InterpolantFactoryMethodSmooth:return 2302;case this.InterpolantFactoryMethodBezier:return 2303}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]+=e;if(Tr(this.settings))$h(this.settings.inTangents,e),$h(this.settings.outTangents,e)}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]*=e;if(Tr(this.settings))Qh(this.settings.inTangents,e),Qh(this.settings.outTangents,e)}return this}trim(e,t){let n=this.times,i=n.length,s=0,r=i-1;while(s!==i&&n[s]<e)++s;while(r!==-1&&n[r]>t)--r;if(++r,s!==0||r!==i){if(s>=r)r=Math.max(r,1),s=r-1;let o=this.getValueSize();this.times=n.slice(s,r),this.values=this.values.slice(s*o,r*o)}return this}validate(){let e=!0,t=this.getValueSize();if(t-Math.floor(t)!==0)He("KeyframeTrack: Invalid value size in track.",this),e=!1;let n=this.times,i=this.values,s=n.length;if(s===0)He("KeyframeTrack: Track is empty.",this),e=!1;let r=null;for(let o=0;o!==s;o++){let a=n[o];if(typeof a==="number"&&isNaN(a)){He("KeyframeTrack: Time is not a valid number.",this,o,a),e=!1;break}if(r!==null&&r>a){He("KeyframeTrack: Out of order keys.",this,o,a,r),e=!1;break}r=a}if(i!==void 0){if(Am(i))for(let o=0,a=i.length;o!==a;++o){let l=i[o];if(isNaN(l)){He("KeyframeTrack: Value is not a valid number.",this,o,l),e=!1;break}}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===2302,s=e.length-1,r=1;for(let o=1;o<s;++o){let a=!1,l=e[o],c=e[o+1];if(l!==c&&(o!==1||l!==e[0]))if(!i){let u=o*n,h=u-n,d=u+n;for(let f=0;f!==n;++f){let m=t[u+f];if(m!==t[h+f]||m!==t[d+f]){a=!0;break}}}else a=!0;if(a){if(o!==r){e[r]=e[o];let u=o*n,h=r*n;for(let d=0;d!==n;++d)t[h+d]=t[u+d]}++r}}if(s>0){e[r]=e[s];for(let o=s*n,a=r*n,l=0;l!==n;++l)t[a+l]=t[o+l];++r}if(r!==e.length)this.times=e.slice(0,r),this.values=t.slice(0,r*n);else this.times=e,this.values=t;return this}clone(){let e=this.times.slice(),t=this.values.slice(),i=new this.constructor(this.name,e,t);if(i.createInterpolant=this.createInterpolant,Tr(this.settings))i.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()};return i}}function $h(e,t){for(let n=0,i=e.length;n!==i;n+=2)e[n]+=t}function Qh(e,t){for(let n=0,i=e.length;n!==i;n+=2)e[n]*=t}mn.prototype.ValueTypeName="";mn.prototype.TimeBufferType=Float32Array;mn.prototype.ValueBufferType=Float32Array;mn.prototype.DefaultInterpolation=2301;class Li extends mn{constructor(e,t,n){super(e,t,n)}}Li.prototype.ValueTypeName="bool";Li.prototype.ValueBufferType=Array;Li.prototype.DefaultInterpolation=2300;Li.prototype.InterpolantFactoryMethodLinear=void 0;Li.prototype.InterpolantFactoryMethodSmooth=void 0;class Ta extends mn{constructor(e,t,n,i){super(e,t,n,i)}}Ta.prototype.ValueTypeName="color";class Ii extends mn{constructor(e,t,n,i){super(e,t,n,i)}}Ii.prototype.ValueTypeName="number";class ou extends hi{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=(n-t)/(i-t),l=e*o;for(let c=l+o;l!==c;l+=4)be.slerpFlat(s,0,r,l-o,r,l,a);return s}}class Ni extends mn{constructor(e,t,n,i){super(e,t,n,i)}InterpolantFactoryMethodLinear(e){return new ou(this.times,this.values,this.getValueSize(),e)}}Ni.prototype.ValueTypeName="quaternion";Ni.prototype.InterpolantFactoryMethodSmooth=void 0;class Di extends mn{constructor(e,t,n){super(e,t,n)}}Di.prototype.ValueTypeName="string";Di.prototype.ValueBufferType=Array;Di.prototype.DefaultInterpolation=2300;Di.prototype.InterpolantFactoryMethodLinear=void 0;Di.prototype.InterpolantFactoryMethodSmooth=void 0;class as extends mn{constructor(e,t,n,i){super(e,t,n,i)}}as.prototype.ValueTypeName="vector";class Sa{constructor(e="",t=-1,n=[],i=2500){if(this.name=e,this.tracks=n,this.duration=t,this.blendMode=i,this.uuid=zn(),this.userData={},this.duration<0)this.resetDuration()}static parse(e){let t=[],n=e.tracks,i=1/(e.fps||1);for(let r=0,o=n.length;r!==o;++r)t.push(xg(n[r]).scale(i));let s=new this(e.name,e.duration,t,e.blendMode);return s.uuid=e.uuid,s.userData=JSON.parse(e.userData||"{}"),s}static toJSON(e){let t=[],n=e.tracks,i={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode,userData:JSON.stringify(e.userData)};for(let s=0,r=n.length;s!==r;++s)t.push(mn.toJSON(n[s]));return i}static CreateFromMorphTargetSequence(e,t,n,i){let s=t.length,r=[];for(let o=0;o<s;o++){let a=[],l=[];a.push((o+s-1)%s,o,(o+1)%s),l.push(0,1,0);let c=fg(a);if(a=Kh(a,1,c),l=Kh(l,1,c),!i&&a[0]===0)a.push(s),l.push(l[0]);r.push(new Ii(".morphTargetInfluences["+t[o].name+"]",a,l).scale(1/n))}return new this(e,-1,r)}static findByName(e,t){let n=e;if(!Array.isArray(e)){let i=e;n=i.geometry&&i.geometry.animations||i.animations}for(let i=0;i<n.length;i++)if(n[i].name===t)return n[i];return null}static CreateClipsFromMorphTargetSequences(e,t,n){let i={},s=/^([\w-]*?)([\d]+)$/;for(let o=0,a=e.length;o<a;o++){let l=e[o],c=l.name.match(s);if(c&&c.length>1){let u=c[1],h=i[u];if(!h)i[u]=h=[];h.push(l)}}let r=[];for(let o in i)r.push(this.CreateFromMorphTargetSequence(o,i[o],t,n));return r}resetDuration(){let e=this.tracks,t=0;for(let n=0,i=e.length;n!==i;++n){let s=this.tracks[n];t=Math.max(t,s.times[s.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){let e=[];for(let n=0;n<this.tracks.length;n++)e.push(this.tracks[n].clone());let t=new this.constructor(this.name,this.duration,e,this.blendMode);return t.userData=JSON.parse(JSON.stringify(this.userData)),t}toJSON(){return this.constructor.toJSON(this)}}function _g(e){switch(e.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Ii;case"vector":case"vector2":case"vector3":case"vector4":return as;case"color":return Ta;case"quaternion":return Ni;case"bool":case"boolean":return Li;case"string":return Di}throw Error("THREE.KeyframeTrack: Unsupported typeName: "+e)}function xg(e){if(e.type===void 0)throw Error("THREE.KeyframeTrack: track type undefined, can not parse");let t=_g(e.type);if(e.times===void 0){let i=[],s=[];pg(e.keys,i,s,"value"),e.times=i,e.values=s}let n;if(t.parse!==void 0)n=t.parse(e);else n=new t(e.name,e.times,e.values,e.interpolation);if(Tr(e.settings))n.settings={inTangents:yi(e.settings.inTangents,Float32Array),outTangents:yi(e.settings.outTangents,Float32Array)};return n}var Bn={enabled:!1,files:{},add:function(e,t){if(this.enabled===!1)return;if(ed(e))return;this.files[e]=t},get:function(e){if(this.enabled===!1)return;if(ed(e))return;return this.files[e]},remove:function(e){delete this.files[e]},clear:function(){this.files={}}};function ed(e){try{let t=e.slice(e.indexOf(":")+1);return new URL(t).protocol==="blob:"}catch(t){return!1}}class au{constructor(e,t,n){let i=this,s=!1,r=0,o=0,a=void 0,l=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this._abortController=null,this.itemStart=function(c){if(o++,s===!1){if(i.onStart!==void 0)i.onStart(c,r,o)}s=!0},this.itemEnd=function(c){if(r++,i.onProgress!==void 0)i.onProgress(c,r,o);if(r===o){if(s=!1,i.onLoad!==void 0)i.onLoad()}},this.itemError=function(c){if(i.onError!==void 0)i.onError(c)},this.resolveURL=function(c){if(c=c.normalize("NFC"),a)return a(c);return c},this.setURLModifier=function(c){return a=c,this},this.addHandler=function(c,u){return l.push(c,u),this},this.removeHandler=function(c){let u=l.indexOf(c);if(u!==-1)l.splice(u,2);return this},this.getHandler=function(c){for(let u=0,h=l.length;u<h;u+=2){let d=l[u],f=l[u+1];if(d.global)d.lastIndex=0;if(d.test(c))return f}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){if(!this._abortController)this._abortController=new AbortController;return this._abortController}}var sf=new au;class di{constructor(e){if(this.manager=e!==void 0?e:sf,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},this.priority="auto",this.cache="default",typeof __THREE_DEVTOOLS__<"u")__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}load(){}loadAsync(e,t){let n=this;return new Promise(function(i,s){n.load(e,i,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}setPriority(e){return this.priority=e,this}setCache(e){return this.cache=e,this}abort(){return this}}di.DEFAULT_MATERIAL_NAME="__DEFAULT";var ri={};class rf extends Error{constructor(e,t){super(e);this.response=t}}class Hr extends di{constructor(e){super(e);this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,n,i){if(e===void 0)e="";if(this.path!==void 0)e=this.path+e;e=this.manager.resolveURL(e);let s=Bn.get(`file:${e}`);if(s!==void 0){this.manager.itemStart(e),setTimeout(()=>{if(t)t(s);this.manager.itemEnd(e)},0);return}if(ri[e]!==void 0){ri[e].push({onLoad:t,onProgress:n,onError:i});return}ri[e]=[],ri[e].push({onLoad:t,onProgress:n,onError:i});let r=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",priority:this.priority,cache:this.cache,signal:typeof AbortSignal.any==="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),o=this.mimeType,a=this.responseType;fetch(r).then((l)=>{if(l.status===200||l.status===0){if(l.status===0)we("FileLoader: HTTP Status 0 received.");if(typeof ReadableStream>"u"||l.body===void 0||l.body.getReader===void 0)return l;let c=ri[e],u=l.body.getReader(),h=l.headers.get("X-File-Size")||l.headers.get("Content-Length"),d=h?parseInt(h):0,f=d!==0,m=0,x=new ReadableStream({start(p){g();function g(){u.read().then(({done:v,value:S})=>{if(v)p.close();else{m+=S.byteLength;let T=new ProgressEvent("progress",{lengthComputable:f,loaded:m,total:d});for(let A=0,w=c.length;A<w;A++){let _=c[A];if(_.onProgress)_.onProgress(T)}p.enqueue(S),g()}},(v)=>{p.error(v)})}}});return new Response(x)}else throw new rf(`fetch for "${l.url}" responded with ${l.status}: ${l.statusText}`,l)}).then((l)=>{switch(a){case"arraybuffer":return l.arrayBuffer();case"blob":return l.blob();case"document":return l.text().then((c)=>new DOMParser().parseFromString(c,o));case"json":return l.json();default:if(o==="")return l.text();else{let u=/charset="?([^;"\s]*)"?/i.exec(o),h=u&&u[1]?u[1].toLowerCase():void 0,d=new TextDecoder(h);return l.arrayBuffer().then((f)=>d.decode(f))}}}).then((l)=>{Bn.add(`file:${e}`,l);let c=ri[e];delete ri[e];for(let u=0,h=c.length;u<h;u++){let d=c[u];if(d.onLoad)d.onLoad(l)}}).catch((l)=>{let c=ri[e];if(c===void 0)throw this.manager.itemError(e),l;delete ri[e];for(let u=0,h=c.length;u<h;u++){let d=c[u];if(d.onError)d.onError(l)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}var ws=new WeakMap;class Br extends di{constructor(e){super(e)}load(e,t,n,i){if(this.path!==void 0)e=this.path+e;e=this.manager.resolveURL(e);let s=this,r=Bn.get(`image:${e}`);if(r!==void 0){if(r.complete===!0)s.manager.itemStart(e),setTimeout(function(){if(t)t(r);s.manager.itemEnd(e)},0);else{let u=ws.get(r);if(u===void 0)u=[],ws.set(r,u);u.push({onLoad:t,onError:i})}return r}let o=Is("img");function a(){if(c(),t)t(this);let u=ws.get(this)||[];for(let h=0;h<u.length;h++){let d=u[h];if(d.onLoad)d.onLoad(this)}ws.delete(this),s.manager.itemEnd(e)}function l(u){if(c(),i)i(u);Bn.remove(`image:${e}`);let h=ws.get(this)||[];for(let d=0;d<h.length;d++){let f=h[d];if(f.onError)f.onError(u)}ws.delete(this),s.manager.itemError(e),s.manager.itemEnd(e)}function c(){o.removeEventListener("load",a,!1),o.removeEventListener("error",l,!1)}if(o.addEventListener("load",a,!1),o.addEventListener("error",l,!1),e.slice(0,5)!=="data:"){if(this.crossOrigin!==void 0)o.crossOrigin=this.crossOrigin}return Bn.add(`image:${e}`,o),s.manager.itemStart(e),o.fetchPriority=this.priority,o.src=e,o}}class ba extends di{constructor(e){super(e)}load(e,t,n,i){let s=new vt,r=new Br(this.manager);return r.setPriority(this.priority),r.setCache(this.cache),r.setCrossOrigin(this.crossOrigin),r.setPath(this.path),r.load(e,function(o){if(s.image=o,s.needsUpdate=!0,t!==void 0)t(s)},n,i),s}}class Ys extends tt{static registerNode(e){this.prototype._lightNode=e}constructor(e,t=1){super();this.isLight=!0,this.type="Light",this.color=new xe(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}class Ra extends Ys{constructor(e,t,n){super(e,n);this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(tt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new xe(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){let t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}}var Bl=new Re,td=new R,nd=new R;class Vr{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.filterNode=null,this.shadowNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ce(512,512),this.mapType=1009,this.map=null,this.mapPass=null,this.matrix=new Re,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Qi,this._frameExtents=new Ce(1,1),this._viewportCount=1,this._viewports=[new ut(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera;td.setFromMatrixPosition(e.matrixWorld),t.position.copy(td),nd.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(nd),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,i){Bl.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(Bl,e.coordinateSystem,e.reversedDepth);let s=this._frameExtents,r=i?i.z/s.x:1,o=i?i.w/s.y:1,a=i?i.x/s.x:0,l=i?i.y/s.y:0;if(e.coordinateSystem===2001||e.reversedDepth)t.set(0.5*r,0,0,0.5*r+a,0,0.5*o,0,0.5*o+l,0,0,1,0,0,0,0,1);else t.set(0.5*r,0,0,0.5*r+a,0,0.5*o,0,0.5*o+l,0,0,0.5,0.5,0,0,0,1);t.multiply(Bl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){if(this.map)this.map.dispose();if(this.mapPass)this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.mapType=e.mapType,this.biasNode=e.biasNode,this.filterNode=e.filterNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.mapType=this.mapType,e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}var Zo=new R,jo=new be,Hn=new R;class Aa extends tt{constructor(){super();this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Re,this.projectionMatrix=new Re,this.projectionMatrixInverse=new Re,this.coordinateSystem=2000,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){if(super.updateMatrixWorld(e),this.matrixWorld.decompose(Zo,jo,Hn),Hn.x===1&&Hn.y===1&&Hn.z===1)this.matrixWorldInverse.copy(this.matrixWorld).invert();else this.matrixWorldInverse.compose(Zo,jo,Hn.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){if(super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(Zo,jo,Hn),Hn.x===1&&Hn.y===1&&Hn.z===1)this.matrixWorldInverse.copy(this.matrixWorld).invert();else this.matrixWorldInverse.compose(Zo,jo,Hn.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}var Mi=new R,id=new Ce,sd=new Ce;class Ut extends Aa{constructor(e=50,t=1,n=0.1,i=2000){super();this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=0.5*this.getFilmHeight()/e;this.fov=$i*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(Sr*0.5*this.fov);return 0.5*this.getFilmHeight()/e}getEffectiveFOV(){return $i*2*Math.atan(Math.tan(Sr*0.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Mi.set(-1,-1,0.5).applyMatrix4(this.projectionMatrixInverse),t.set(Mi.x,Mi.y).multiplyScalar(-e/Mi.z),Mi.set(1,1,0.5).applyMatrix4(this.projectionMatrixInverse),n.set(Mi.x,Mi.y).multiplyScalar(-e/Mi.z)}getViewSize(e,t){return this.getViewBounds(e,id,sd),t.subVectors(sd,id)}setViewOffset(e,t,n,i,s,r){if(this.aspect=e/t,this.view===null)this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1};this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){if(this.view!==null)this.view.enabled=!1;this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(Sr*0.5*this.fov)/this.zoom,n=2*t,i=this.aspect*n,s=-0.5*i,r=this.view;if(this.view!==null&&this.view.enabled){let{fullWidth:a,fullHeight:l}=r;s+=r.offsetX*i/a,t-=r.offsetY*n/l,i*=r.width/a,n*=r.height/l}let o=this.filmOffset;if(o!==0)s+=e*o/this.getFilmWidth();this.projectionMatrix.makePerspective(s,s+i,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);if(t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null)t.object.view=Object.assign({},this.view);return t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class of extends Vr{constructor(){super(new Ut(50,1,0.5,500));this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(e){let t=this.camera,n=$i*2*e.angle*this.focus,i=this.mapSize.width/this.mapSize.height*this.aspect,s=e.distance||t.far;if(n!==t.fov||i!==t.aspect||s!==t.far)t.fov=n,t.aspect=i,t.far=s,t.updateProjectionMatrix();super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this.aspect=e.aspect,this}toJSON(){let e=super.toJSON();return e.focus=this.focus,e.aspect=this.aspect,e}}class wa extends Ys{constructor(e,t,n=0,i=Math.PI/3,s=0,r=2){super(e,t);this.isSpotLight=!0,this.type="SpotLight",this.position.copy(tt.DEFAULT_UP),this.updateMatrix(),this.target=new tt,this.distance=n,this.angle=i,this.penumbra=s,this.decay=r,this.map=null,this.shadow=new of}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.map=e.map,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);if(t.object.distance=this.distance,t.object.angle=this.angle,t.object.decay=this.decay,t.object.penumbra=this.penumbra,t.object.target=this.target.uuid,this.map&&this.map.isTexture)t.object.map=this.map.toJSON(e).uuid;return t.object.shadow=this.shadow.toJSON(),t}}class af extends Vr{constructor(){super(new Ut(90,1,0.5,500));this.isPointLightShadow=!0}}class Ca extends Ys{constructor(e,t,n=0,i=2){super(e,t);this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new af}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}}class Zs extends Aa{constructor(e=-1,t=1,n=1,i=-1,s=0.1,r=2000){super();this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=i,this.near=s,this.far=r,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,i,s,r){if(this.view===null)this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1};this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){if(this.view!==null)this.view.enabled=!1;this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2,s=n-e,r=n+e,o=i+t,a=i-t;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,c=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,r=s+l*this.view.width,o-=c*this.view.offsetY,a=o-c*this.view.height}this.projectionMatrix.makeOrthographic(s,r,o,a,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);if(t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null)t.object.view=Object.assign({},this.view);return t}}class lf extends Vr{constructor(){super(new Zs(-5,5,5,-5,0.5,500));this.isDirectionalLightShadow=!0}}class ls extends Ys{constructor(e,t){super(e,t);this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(tt.DEFAULT_UP),this.updateMatrix(),this.target=new tt,this.shadow=new lf}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}class Ui{static extractUrlBase(e){let t=e.lastIndexOf("/");if(t===-1)return"./";return e.slice(0,t+1)}static resolveURL(e,t){if(typeof e!=="string"||e==="")return"";if(/^https?:\/\//i.test(t)&&/^\//.test(e))t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1");if(/^(https?:)?\/\//i.test(e))return e;if(/^data:.*,.*$/i.test(e))return e;if(/^blob:.*$/i.test(e))return e;return t+e}}var Vl=new WeakMap;class Pa extends di{constructor(e){super(e);if(this.isImageBitmapLoader=!0,typeof createImageBitmap>"u")we("ImageBitmapLoader: createImageBitmap() not supported.");if(typeof fetch>"u")we("ImageBitmapLoader: fetch() not supported.");this.options={premultiplyAlpha:"none"},this._abortController=new AbortController}setOptions(e){return this.options=e,this}load(e,t,n,i){if(e===void 0)e="";if(this.path!==void 0)e=this.path+e;e=this.manager.resolveURL(e);let s=this,r=Bn.get(`image-bitmap:${e}`);if(r!==void 0){if(s.manager.itemStart(e),r.then){r.then((l)=>{if(Vl.has(r)===!0){if(i)i(Vl.get(r));s.manager.itemError(e),s.manager.itemEnd(e)}else{if(t)t(l);s.manager.itemEnd(e)}});return}setTimeout(function(){if(t)t(r);s.manager.itemEnd(e)},0);return}let o={};o.credentials=this.withCredentials||this.crossOrigin!=="anonymous"?"include":"same-origin",o.headers=this.requestHeader,o.priority=this.priority,o.cache=this.cache,o.signal=typeof AbortSignal.any==="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;let a=fetch(e,o).then(function(l){return l.blob()}).then(function(l){return createImageBitmap(l,Object.assign({},s.options,{colorSpaceConversion:"none"}))}).then(function(l){if(Bn.add(`image-bitmap:${e}`,l),t)t(l);return s.manager.itemEnd(e),l}).catch(function(l){if(i)i(l);Vl.set(a,l),Bn.remove(`image-bitmap:${e}`),s.manager.itemError(e),s.manager.itemEnd(e)});Bn.add(`image-bitmap:${e}`,a),s.manager.itemStart(e)}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}var Cs=-90,Ps=1;class kr extends tt{constructor(e,t,n){super();this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let i=new Ut(Cs,Ps,e,t);i.layers=this.layers,this.add(i);let s=new Ut(Cs,Ps,e,t);s.layers=this.layers,this.add(s);let r=new Ut(Cs,Ps,e,t);r.layers=this.layers,this.add(r);let o=new Ut(Cs,Ps,e,t);o.layers=this.layers,this.add(o);let a=new Ut(Cs,Ps,e,t);a.layers=this.layers,this.add(a);let l=new Ut(Cs,Ps,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,i,s,r,o,a]=t;for(let l of t)this.remove(l);if(e===2000)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),r.up.set(0,0,1),r.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),a.up.set(0,1,0),a.lookAt(0,0,-1);else if(e===2001)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),r.up.set(0,0,-1),r.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),a.up.set(0,-1,0),a.lookAt(0,0,-1);else throw Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(let l of t)this.add(l),l.updateMatrixWorld()}update(e,t){if(this.parent===null)this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:i}=this;if(this.coordinateSystem!==e.coordinateSystem)this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem();let[s,r,o,a,l,c]=this.children,u=e.getRenderTarget(),h=e.getActiveCubeFace(),d=e.getActiveMipmapLevel(),f=e.xr.enabled;e.xr.enabled=!1;let m=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let x=!1;if(e.isWebGLRenderer===!0)x=e.state.buffers.depth.getReversed();else x=e.reversedDepthBuffer;if(e.setRenderTarget(n,0,i),x&&e.autoClear===!1)e.clearDepth();if(e.render(t,s),e.setRenderTarget(n,1,i),x&&e.autoClear===!1)e.clearDepth();if(e.render(t,r),e.setRenderTarget(n,2,i),x&&e.autoClear===!1)e.clearDepth();if(e.render(t,o),e.setRenderTarget(n,3,i),x&&e.autoClear===!1)e.clearDepth();if(e.render(t,a),e.setRenderTarget(n,4,i),x&&e.autoClear===!1)e.clearDepth();if(e.render(t,l),n.texture.mipmapsAutoUpdate=m,e.setRenderTarget(n,5,i),x&&e.autoClear===!1)e.clearDepth();e.render(t,c),e.setRenderTarget(u,h,d),e.xr.enabled=f,n.texture.needsPMREMUpdate=!0}}class lu extends Ut{constructor(e=[]){super();this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e,this.perCameraFrustumCulled=!1}}var cu="\\[\\]\\.:\\/",Mg=new RegExp("["+cu+"]","g"),uu="[^"+cu+"]",yg="[^"+cu.replace("\\.","")+"]",vg=/((?:WC+[\/:])*)/.source.replace("WC",uu),Eg=/(WCOD+)?/.source.replace("WCOD",yg),Tg=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",uu),Sg=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",uu),bg=new RegExp("^"+vg+Eg+Tg+Sg+"$"),Rg=["material","materials","bones","map"];class cf{constructor(e,t,n){let i=n||rt.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,i)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];if(i!==void 0)i.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,s=n.length;i!==s;++i)n[i].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}}class rt{constructor(e,t,n){this.path=t,this.parsedPath=n||rt.parseTrackName(t),this.node=rt.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){if(!(e&&e.isAnimationObjectGroup))return new rt(e,t,n);else return new rt.Composite(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(Mg,"")}static parseTrackName(e){let t=bg.exec(e);if(t===null)throw Error("THREE.PropertyBinding: Cannot parse trackName: "+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let s=n.nodeName.substring(i+1);if(Rg.indexOf(s)!==-1)n.nodeName=n.nodeName.substring(0,i),n.objectName=s}if(n.propertyName===null||n.propertyName.length===0)throw Error("THREE.PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(s){for(let r=0;r<s.length;r++){let o=s[r];if(o.name===t||o.uuid===t)return o;let a=n(o.children);if(a)return a}return null},i=n(e.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)e[t++]=n[i]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,{objectName:n,propertyName:i,propertyIndex:s}=t;if(!e)e=rt.findNode(this.rootNode,t.nodeName),this.node=e;if(this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){we("PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let l=t.objectIndex;switch(n){case"materials":if(!e.material){He("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){He("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){He("PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let c=0;c<e.length;c++)if(e[c].name===l){l=c;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){He("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){He("PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){He("PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(l!==void 0){if(e[l]===void 0){He("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[l]}}let r=e[i];if(r===void 0){let l=t.nodeName;He("PropertyBinding: Trying to update property for track: "+l+"."+i+" but it wasn't found.",e);return}let o=this.Versioning.None;if(this.targetObject=e,e.isMaterial===!0)o=this.Versioning.NeedsUpdate;else if(e.isObject3D===!0)o=this.Versioning.MatrixWorldNeedsUpdate;let a=this.BindingType.Direct;if(s!==void 0){if(i==="morphTargetInfluences"){if(!e.geometry){He("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){He("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}if(e.morphTargetDictionary[s]!==void 0)s=e.morphTargetDictionary[s]}a=this.BindingType.ArrayElement,this.resolvedProperty=r,this.propertyIndex=s}else if(r.fromArray!==void 0&&r.toArray!==void 0)a=this.BindingType.HasFromToArray,this.resolvedProperty=r;else if(Array.isArray(r))a=this.BindingType.EntireArray,this.resolvedProperty=r;else this.propertyName=i;this.getValue=this.GetterByBindingType[a],this.setValue=this.SetterByBindingTypeAndVersioning[a][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}rt.Composite=cf;rt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};rt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};rt.prototype.GetterByBindingType=[rt.prototype._getValue_direct,rt.prototype._getValue_array,rt.prototype._getValue_arrayElement,rt.prototype._getValue_toArray];rt.prototype.SetterByBindingTypeAndVersioning=[[rt.prototype._setValue_direct,rt.prototype._setValue_direct_setNeedsUpdate,rt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[rt.prototype._setValue_array,rt.prototype._setValue_array_setNeedsUpdate,rt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[rt.prototype._setValue_arrayElement,rt.prototype._setValue_arrayElement_setNeedsUpdate,rt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[rt.prototype._setValue_fromArray,rt.prototype._setValue_fromArray_setNeedsUpdate,rt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var sE=new Float32Array(1);class Gr{constructor(e,t,n,i,s,r=!1){this.isGLBufferAttribute=!0,this.name="",this.buffer=e,this.type=t,this.itemSize=n,this.elementSize=i,this.count=s,this.normalized=r,this.version=0}set needsUpdate(e){if(e===!0)this.version++}setBuffer(e){return this.buffer=e,this}setType(e,t){return this.type=e,this.elementSize=t,this}setItemSize(e){return this.itemSize=e,this}setCount(e){return this.count=e,this}}class zr{constructor(e=1,t=0,n=0){this.radius=e,this.phi=t,this.theta=n}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Ye(this.phi,0.000001,Math.PI-0.000001),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){if(this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0)this.theta=0,this.phi=0;else this.theta=Math.atan2(e,n),this.phi=Math.acos(Ye(t/this.radius,-1,1));return this}clone(){return new this.constructor().copy(this)}}class uf{static{this.prototype.isMatrix2=!0}constructor(e,t,n,i){if(this.elements=[1,0,0,1],e!==void 0)this.set(e,t,n,i)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,i){let s=this.elements;return s[0]=e,s[2]=t,s[1]=n,s[3]=i,this}}class La extends Un{constructor(e=1){let t=[0,0,0,e,0,0,0,0,0,0,e,0,0,0,0,0,0,e],n=[1,0,0,1,0.6,0,0,1,0,0.6,1,0,0,0,1,0,0.6,1],i=new Qe;i.setAttribute("position",new Rt(t,3)),i.setAttribute("color",new Rt(n,3));let s=new an({vertexColors:!0,toneMapped:!1});super(i,s);this.type="AxesHelper"}setColors(e,t,n){let i=new xe,s=this.geometry.attributes.color.array;return i.set(e),i.toArray(s,0),i.toArray(s,3),i.set(t),i.toArray(s,6),i.toArray(s,9),i.set(n),i.toArray(s,12),i.toArray(s,15),this.geometry.attributes.color.needsUpdate=!0,this}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}}class Ia extends Gn{constructor(e,t=null){super();this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(this.domElement!==null)this.disconnect();this.domElement=e}disconnect(){}dispose(){}update(){}}function hu(e,t,n,i){let s=Ag(i);switch(n){case 1021:return e*t;case 1028:return e*t/s.components*s.byteLength;case 1029:return e*t/s.components*s.byteLength;case 1030:return e*t*2/s.components*s.byteLength;case 1031:return e*t*2/s.components*s.byteLength;case 1022:return e*t*3/s.components*s.byteLength;case 1023:return e*t*4/s.components*s.byteLength;case 1033:return e*t*4/s.components*s.byteLength;case 33776:case 33777:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case 33778:case 33779:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case 35841:case 35843:return Math.max(e,16)*Math.max(t,8)/4;case 35840:case 35842:return Math.max(e,8)*Math.max(t,8)/2;case 36196:case 37492:case 37488:case 37489:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case 37496:case 37490:case 37491:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case 37808:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case 37809:return Math.floor((e+4)/5)*Math.floor((t+3)/4)*16;case 37810:return Math.floor((e+4)/5)*Math.floor((t+4)/5)*16;case 37811:return Math.floor((e+5)/6)*Math.floor((t+4)/5)*16;case 37812:return Math.floor((e+5)/6)*Math.floor((t+5)/6)*16;case 37813:return Math.floor((e+7)/8)*Math.floor((t+4)/5)*16;case 37814:return Math.floor((e+7)/8)*Math.floor((t+5)/6)*16;case 37815:return Math.floor((e+7)/8)*Math.floor((t+7)/8)*16;case 37816:return Math.floor((e+9)/10)*Math.floor((t+4)/5)*16;case 37817:return Math.floor((e+9)/10)*Math.floor((t+5)/6)*16;case 37818:return Math.floor((e+9)/10)*Math.floor((t+7)/8)*16;case 37819:return Math.floor((e+9)/10)*Math.floor((t+9)/10)*16;case 37820:return Math.floor((e+11)/12)*Math.floor((t+9)/10)*16;case 37821:return Math.floor((e+11)/12)*Math.floor((t+11)/12)*16;case 36492:case 36494:case 36495:return Math.ceil(e/4)*Math.ceil(t/4)*16;case 36283:case 36284:return Math.ceil(e/4)*Math.ceil(t/4)*8;case 36285:case 36286:return Math.ceil(e/4)*Math.ceil(t/4)*16}throw Error(`Unable to determine texture byte length for ${n} format.`)}function Ag(e){switch(e){case 1009:case 1010:return{byteLength:1,components:1};case 1012:case 1011:case 1016:return{byteLength:2,components:1};case 1017:case 1018:return{byteLength:2,components:4};case 1014:case 1013:case 1015:return{byteLength:4,components:1};case 35902:case 35899:return{byteLength:4,components:3}}throw Error(`THREE.TextureUtils: Unknown texture type ${e}.`)}if(typeof __THREE_DEVTOOLS__<"u")__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"188dev"}}));if(typeof window<"u")if(window.__THREE__)we("WARNING: Multiple instances of Three.js being imported.");else window.__THREE__="188dev";function If(){let e=null,t=!1,n=null,i=null;function s(r,o){i=e.requestAnimationFrame(s),n(r,o)}return{start:function(){if(t===!0)return;if(n===null)return;if(e===null)return;i=e.requestAnimationFrame(s),t=!0},stop:function(){if(e!==null)e.cancelAnimationFrame(i);t=!1},setAnimationLoop:function(r){n=r},setContext:function(r){e=r}}}function wg(e){let t=new WeakMap;function n(a,l){let{array:c,usage:u}=a,h=c.byteLength,d=e.createBuffer();e.bindBuffer(l,d),e.bufferData(l,c,u),a.onUploadCallback();let f;if(c instanceof Float32Array)f=e.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)f=e.HALF_FLOAT;else if(c instanceof Uint16Array)if(a.isFloat16BufferAttribute)f=e.HALF_FLOAT;else f=e.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=e.SHORT;else if(c instanceof Uint32Array)f=e.UNSIGNED_INT;else if(c instanceof Int32Array)f=e.INT;else if(c instanceof Int8Array)f=e.BYTE;else if(c instanceof Uint8Array)f=e.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=e.UNSIGNED_BYTE;else throw Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:h}}function i(a,l,c){let{array:u,updateRanges:h}=l;if(e.bindBuffer(c,a),h.length===0)e.bufferSubData(c,0,u);else{h.sort((f,m)=>f.start-m.start);let d=0;for(let f=1;f<h.length;f++){let m=h[d],x=h[f];if(x.start<=m.start+m.count+1)m.count=Math.max(m.count,x.start+x.count-m.start);else++d,h[d]=x}h.length=d+1;for(let f=0,m=h.length;f<m;f++){let x=h[f];e.bufferSubData(c,x.start*u.BYTES_PER_ELEMENT,u,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(a){if(a.isInterleavedBufferAttribute)a=a.data;return t.get(a)}function r(a){if(a.isInterleavedBufferAttribute)a=a.data;let l=t.get(a);if(l)e.deleteBuffer(l.buffer),t.delete(a)}function o(a,l){if(a.isInterleavedBufferAttribute)a=a.data;if(a.isGLBufferAttribute){let u=t.get(a);if(!u||u.version<a.version)t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let c=t.get(a);if(c===void 0)t.set(a,n(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(c.buffer,a,l),c.version=a.version}}return{get:s,remove:r,update:o}}var Cg=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Pg=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Lg=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Ig=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ng=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Dg=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ug=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Og=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Fg=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,Hg=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Bg=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Vg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,kg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Gg=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,zg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Wg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Xg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,qg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Yg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Zg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,jg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Jg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,Kg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,$g=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Qg=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,e_=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,t_=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,n_=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,i_=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,s_="gl_FragColor = linearToOutputTexel( gl_FragColor );",r_=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,o_=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,a_=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,l_=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,c_=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,u_=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,h_=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,d_=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,f_=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,p_=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,m_=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,g_=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,__=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,x_=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,M_=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,y_=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,v_=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,E_=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,T_=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,S_=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,b_=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,R_=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,A_=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,w_=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,C_=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,P_=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,L_=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,I_=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,N_=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,D_=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,U_=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,O_=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,F_=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,H_=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,B_=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,V_=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,k_=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,G_=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,z_=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,W_=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,X_=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,q_=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Y_=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Z_=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,j_=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,J_=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,K_=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,$_=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Q_=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,e0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,t0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,n0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,i0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,s0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,r0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,o0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,a0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,l0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,c0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,u0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,h0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,d0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,f0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,p0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,m0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,g0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,_0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,x0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,M0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,y0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,v0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,E0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,T0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,S0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,b0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,R0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`;var A0=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,w0=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,C0=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,P0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,L0=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,I0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,N0=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,D0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,U0=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,O0=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,F0=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,H0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,B0=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,V0=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,k0=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,G0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,z0=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,W0=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,X0=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,q0=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Y0=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Z0=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,j0=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,J0=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,K0=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$0=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Q0=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ex=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,tx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,nx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,ix=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sx=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,rx=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ox=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,ax=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Xe={alphahash_fragment:Cg,alphahash_pars_fragment:Pg,alphamap_fragment:Lg,alphamap_pars_fragment:Ig,alphatest_fragment:Ng,alphatest_pars_fragment:Dg,aomap_fragment:Ug,aomap_pars_fragment:Og,batching_pars_vertex:Fg,batching_vertex:Hg,begin_vertex:Bg,beginnormal_vertex:Vg,bsdfs:kg,iridescence_fragment:Gg,bumpmap_pars_fragment:zg,clipping_planes_fragment:Wg,clipping_planes_pars_fragment:Xg,clipping_planes_pars_vertex:qg,clipping_planes_vertex:Yg,color_fragment:Zg,color_pars_fragment:jg,color_pars_vertex:Jg,color_vertex:Kg,common:$g,defaultnormal_vertex:Qg,displacementmap_pars_vertex:e_,displacementmap_vertex:t_,emissivemap_fragment:n_,emissivemap_pars_fragment:i_,colorspace_fragment:s_,colorspace_pars_fragment:r_,envmap_fragment:o_,envmap_common_pars_fragment:a_,envmap_pars_fragment:l_,envmap_pars_vertex:c_,envmap_physical_pars_fragment:y_,envmap_vertex:u_,fog_vertex:h_,fog_pars_vertex:d_,fog_fragment:f_,fog_pars_fragment:p_,gradientmap_pars_fragment:m_,lightmap_pars_fragment:g_,lights_lambert_fragment:__,lights_lambert_pars_fragment:x_,lights_pars_begin:M_,lights_toon_fragment:v_,lights_toon_pars_fragment:E_,lights_phong_fragment:T_,lights_phong_pars_fragment:S_,lights_physical_fragment:b_,lights_physical_pars_fragment:R_,lights_fragment_begin:A_,lights_fragment_maps:w_,lights_fragment_end:C_,lightprobes_pars_fragment:P_,logdepthbuf_fragment:L_,logdepthbuf_pars_fragment:I_,logdepthbuf_pars_vertex:N_,logdepthbuf_vertex:D_,map_fragment:U_,map_pars_fragment:O_,map_particle_fragment:F_,map_particle_pars_fragment:H_,metalnessmap_fragment:B_,metalnessmap_pars_fragment:V_,morphinstance_vertex:k_,morphcolor_vertex:G_,morphnormal_vertex:z_,morphtarget_pars_vertex:W_,morphtarget_vertex:X_,normal_fragment_begin:q_,normal_fragment_maps:Y_,normal_pars_fragment:Z_,normal_pars_vertex:j_,normal_vertex:J_,normalmap_pars_fragment:K_,clearcoat_normal_fragment_begin:$_,clearcoat_normal_fragment_maps:Q_,clearcoat_pars_fragment:e0,iridescence_pars_fragment:t0,opaque_fragment:n0,packing:i0,premultiplied_alpha_fragment:s0,project_vertex:r0,dithering_fragment:o0,dithering_pars_fragment:a0,roughnessmap_fragment:l0,roughnessmap_pars_fragment:c0,shadowmap_pars_fragment:u0,shadowmap_pars_vertex:h0,shadowmap_vertex:d0,shadowmask_pars_fragment:f0,skinbase_vertex:p0,skinning_pars_vertex:m0,skinning_vertex:g0,skinnormal_vertex:_0,specularmap_fragment:x0,specularmap_pars_fragment:M0,tonemapping_fragment:y0,tonemapping_pars_fragment:v0,transmission_fragment:E0,transmission_pars_fragment:T0,uv_pars_fragment:S0,uv_pars_vertex:b0,uv_vertex:R0,worldpos_vertex:A0,background_vert:w0,background_frag:C0,backgroundCube_vert:P0,backgroundCube_frag:L0,cube_vert:I0,cube_frag:N0,depth_vert:D0,depth_frag:U0,distance_vert:O0,distance_frag:F0,equirect_vert:H0,equirect_frag:B0,linedashed_vert:V0,linedashed_frag:k0,meshbasic_vert:G0,meshbasic_frag:z0,meshlambert_vert:W0,meshlambert_frag:X0,meshmatcap_vert:q0,meshmatcap_frag:Y0,meshnormal_vert:Z0,meshnormal_frag:j0,meshphong_vert:J0,meshphong_frag:K0,meshphysical_vert:$0,meshphysical_frag:Q0,meshtoon_vert:ex,meshtoon_frag:tx,points_vert:nx,points_frag:ix,shadow_vert:sx,shadow_frag:rx,sprite_vert:ox,sprite_frag:ax},he={common:{diffuse:{value:new xe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Pe},alphaMap:{value:null},alphaMapTransform:{value:new Pe},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Pe}},envmap:{envMap:{value:null},envMapRotation:{value:new Pe},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:0.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Pe}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Pe}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Pe},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Pe},normalScale:{value:new Ce(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Pe},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Pe}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Pe}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Pe}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:0.00025},fogNear:{value:1},fogFar:{value:2000},fogColor:{value:new xe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new xe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Pe},alphaTest:{value:0},uvTransform:{value:new Pe}},sprite:{diffuse:{value:new xe(16777215)},opacity:{value:1},center:{value:new Ce(0.5,0.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Pe},alphaMap:{value:null},alphaMapTransform:{value:new Pe},alphaTest:{value:0}}},Xn={basic:{uniforms:Zt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.fog]),vertexShader:Xe.meshbasic_vert,fragmentShader:Xe.meshbasic_frag},lambert:{uniforms:Zt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.fog,he.lights,{emissive:{value:new xe(0)},envMapIntensity:{value:1}}]),vertexShader:Xe.meshlambert_vert,fragmentShader:Xe.meshlambert_frag},phong:{uniforms:Zt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.fog,he.lights,{emissive:{value:new xe(0)},specular:{value:new xe(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Xe.meshphong_vert,fragmentShader:Xe.meshphong_frag},standard:{uniforms:Zt([he.common,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.roughnessmap,he.metalnessmap,he.fog,he.lights,{emissive:{value:new xe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Xe.meshphysical_vert,fragmentShader:Xe.meshphysical_frag},toon:{uniforms:Zt([he.common,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.gradientmap,he.fog,he.lights,{emissive:{value:new xe(0)}}]),vertexShader:Xe.meshtoon_vert,fragmentShader:Xe.meshtoon_frag},matcap:{uniforms:Zt([he.common,he.bumpmap,he.normalmap,he.displacementmap,he.fog,{matcap:{value:null}}]),vertexShader:Xe.meshmatcap_vert,fragmentShader:Xe.meshmatcap_frag},points:{uniforms:Zt([he.points,he.fog]),vertexShader:Xe.points_vert,fragmentShader:Xe.points_frag},dashed:{uniforms:Zt([he.common,he.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Xe.linedashed_vert,fragmentShader:Xe.linedashed_frag},depth:{uniforms:Zt([he.common,he.displacementmap]),vertexShader:Xe.depth_vert,fragmentShader:Xe.depth_frag},normal:{uniforms:Zt([he.common,he.bumpmap,he.normalmap,he.displacementmap,{opacity:{value:1}}]),vertexShader:Xe.meshnormal_vert,fragmentShader:Xe.meshnormal_frag},sprite:{uniforms:Zt([he.sprite,he.fog]),vertexShader:Xe.sprite_vert,fragmentShader:Xe.sprite_frag},background:{uniforms:{uvTransform:{value:new Pe},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Xe.background_vert,fragmentShader:Xe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Pe}},vertexShader:Xe.backgroundCube_vert,fragmentShader:Xe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Xe.cube_vert,fragmentShader:Xe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Xe.equirect_vert,fragmentShader:Xe.equirect_frag},distance:{uniforms:Zt([he.common,he.displacementmap,{referencePosition:{value:new R},nearDistance:{value:1},farDistance:{value:1000}}]),vertexShader:Xe.distance_vert,fragmentShader:Xe.distance_frag},shadow:{uniforms:Zt([he.lights,he.fog,{color:{value:new xe(0)},opacity:{value:1}}]),vertexShader:Xe.shadow_vert,fragmentShader:Xe.shadow_frag}};Xn.physical={uniforms:Zt([Xn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Pe},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Pe},clearcoatNormalScale:{value:new Ce(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Pe},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new Pe},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Pe},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Pe},sheen:{value:0},sheenColor:{value:new xe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Pe},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Pe},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Pe},transmissionSamplerSize:{value:new Ce},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Pe},attenuationDistance:{value:0},attenuationColor:{value:new xe(0)},specularColor:{value:new xe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Pe},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Pe},anisotropyVector:{value:new Ce},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Pe}}]),vertexShader:Xe.meshphysical_vert,fragmentShader:Xe.meshphysical_frag};var Na={r:0,b:0,g:0},lx=new Re,Nf=new Pe;Nf.set(-1,0,0,0,1,0,0,0,1);function cx(e,t,n,i,s,r){let o=new xe(0),a=s===!0?0:1,l,c,u=null,h=0,d=null;function f(v){let S=v.isScene===!0?v.background:null;if(S&&S.isTexture){let T=v.backgroundBlurriness>0;S=t.get(S,T)}return S}function m(v){let S=!1,T=f(v);if(T===null)p(o,a);else if(T&&T.isColor)p(T,1),S=!0;let A=e.xr.getEnvironmentBlendMode();if(A==="additive")n.buffers.color.setClear(0,0,0,1,r);else if(A==="alpha-blend")n.buffers.color.setClear(0,0,0,0,r);if(e.autoClear||S)n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil)}function x(v,S){let T=f(S);if(T&&T.isCubeTexture){if(c===void 0)c=new bt(new Ws(1,1,1),new On({name:"BackgroundCubeMaterial",uniforms:os(Xn.backgroundCube.uniforms),vertexShader:Xn.backgroundCube.vertexShader,fragmentShader:Xn.backgroundCube.fragmentShader,side:qt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(A,w,_){this.matrixWorld.copyPosition(_.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(c);if(c.material.uniforms.envMap.value=T,c.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(lx.makeRotationFromEuler(S.backgroundRotation)).transpose(),T.isRenderTargetTexture===!1)c.material.uniforms.backgroundRotation.value.premultiply(Nf);if(c.material.toneMapped=qe.getTransfer(T.colorSpace)!==ft,u!==T||h!==T.version||d!==e.toneMapping)c.material.needsUpdate=!0,u=T,h=T.version,d=e.toneMapping;c.layers.enableAll(),v.unshift(c,c.geometry,c.material,0,0,null)}else if(T&&T.isTexture){if(l===void 0)l=new bt(new Fr(2,2),new On({name:"BackgroundMaterial",uniforms:os(Xn.background.uniforms),vertexShader:Xn.background.vertexShader,fragmentShader:Xn.background.fragmentShader,side:Si,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l);if(l.material.uniforms.t2D.value=T,l.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,l.material.toneMapped=qe.getTransfer(T.colorSpace)!==ft,T.matrixAutoUpdate===!0)T.updateMatrix();if(l.material.uniforms.uvTransform.value.copy(T.matrix),u!==T||h!==T.version||d!==e.toneMapping)l.material.needsUpdate=!0,u=T,h=T.version,d=e.toneMapping;l.layers.enableAll(),v.unshift(l,l.geometry,l.material,0,0,null)}}function p(v,S){v.getRGB(Na,$c(e)),n.buffers.color.setClear(Na.r,Na.g,Na.b,S,r)}function g(){if(c!==void 0)c.geometry.dispose(),c.material.dispose(),c=void 0;if(l!==void 0)l.geometry.dispose(),l.material.dispose(),l=void 0}return{getClearColor:function(){return o},setClearColor:function(v,S=1){o.set(v),a=S,p(o,a)},getClearAlpha:function(){return a},setClearAlpha:function(v){a=v,p(o,a)},render:m,addToRenderList:x,dispose:g}}function ux(e,t){let n=e.getParameter(e.MAX_VERTEX_ATTRIBS),i={},s=d(null),r=s,o=!1;function a(N,V,Q,C,q){let j=!1,F=h(N,C,Q,V);if(r!==F)r=F,c(r.object);if(j=f(N,C,Q,q),j)m(N,C,Q,q);if(q!==null)t.update(q,e.ELEMENT_ARRAY_BUFFER);if(j||o){if(o=!1,T(N,V,Q,C),q!==null)e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(q).buffer)}}function l(){return e.createVertexArray()}function c(N){return e.bindVertexArray(N)}function u(N){return e.deleteVertexArray(N)}function h(N,V,Q,C){let q=C.wireframe===!0,j=i[V.id];if(j===void 0)j={},i[V.id]=j;let F=N.isInstancedMesh===!0?N.id:0,re=j[F];if(re===void 0)re={},j[F]=re;let W=re[Q.id];if(W===void 0)W={},re[Q.id]=W;let J=W[q];if(J===void 0)J=d(l()),W[q]=J;return J}function d(N){let V=[],Q=[],C=[];for(let q=0;q<n;q++)V[q]=0,Q[q]=0,C[q]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:V,enabledAttributes:Q,attributeDivisors:C,object:N,attributes:{},index:null}}function f(N,V,Q,C){let q=r.attributes,j=V.attributes,F=0,re=Q.getAttributes();for(let W in re)if(re[W].location>=0){let ne=q[W],Me=j[W];if(Me===void 0){if(W==="instanceMatrix"&&N.instanceMatrix)Me=N.instanceMatrix;if(W==="instanceColor"&&N.instanceColor)Me=N.instanceColor}if(ne===void 0)return!0;if(ne.attribute!==Me)return!0;if(Me&&ne.data!==Me.data)return!0;F++}if(r.attributesNum!==F)return!0;if(r.index!==C)return!0;return!1}function m(N,V,Q,C){let q={},j=V.attributes,F=0,re=Q.getAttributes();for(let W in re)if(re[W].location>=0){let ne=j[W];if(ne===void 0){if(W==="instanceMatrix"&&N.instanceMatrix)ne=N.instanceMatrix;if(W==="instanceColor"&&N.instanceColor)ne=N.instanceColor}let Me={};if(Me.attribute=ne,ne&&ne.data)Me.data=ne.data;q[W]=Me,F++}r.attributes=q,r.attributesNum=F,r.index=C}function x(){let N=r.newAttributes;for(let V=0,Q=N.length;V<Q;V++)N[V]=0}function p(N){g(N,0)}function g(N,V){let Q=r.newAttributes,C=r.enabledAttributes,q=r.attributeDivisors;if(Q[N]=1,C[N]===0)e.enableVertexAttribArray(N),C[N]=1;if(q[N]!==V)e.vertexAttribDivisor(N,V),q[N]=V}function v(){let N=r.newAttributes,V=r.enabledAttributes;for(let Q=0,C=V.length;Q<C;Q++)if(V[Q]!==N[Q])e.disableVertexAttribArray(Q),V[Q]=0}function S(N,V,Q,C,q,j,F){if(F===!0)e.vertexAttribIPointer(N,V,Q,q,j);else e.vertexAttribPointer(N,V,Q,C,q,j)}function T(N,V,Q,C){x();let q=C.attributes,j=Q.getAttributes(),F=V.defaultAttributeValues;for(let re in j){let W=j[re];if(W.location>=0){let J=q[re];if(J===void 0){if(re==="instanceMatrix"&&N.instanceMatrix)J=N.instanceMatrix;if(re==="instanceColor"&&N.instanceColor)J=N.instanceColor}if(J!==void 0){let ne=J.normalized,Me=J.itemSize,Z=t.get(J);if(Z===void 0)continue;let{buffer:te,type:ye,bytesPerElement:Ne}=Z,De=ye===e.INT||ye===e.UNSIGNED_INT||J.gpuType===ec;if(J.isInterleavedBufferAttribute){let _e=J.data,it=_e.isInterleavedBuffer===!0?_e.stride:_e.itemSize,We=J.offset;if(_e.isInstancedInterleavedBuffer||_e.isInstancedBufferAttribute){for(let Be=0;Be<W.locationSize;Be++)g(W.location+Be,_e.meshPerAttribute);if(N.isInstancedMesh!==!0&&C._maxInstanceCount===void 0)C._maxInstanceCount=_e.meshPerAttribute*_e.count}else for(let Be=0;Be<W.locationSize;Be++)p(W.location+Be);e.bindBuffer(e.ARRAY_BUFFER,te);for(let Be=0;Be<W.locationSize;Be++)S(W.location+Be,Me/W.locationSize,ye,ne,it*Ne,(We+Me/W.locationSize*Be)*Ne,De)}else{if(J.isInstancedBufferAttribute){for(let _e=0;_e<W.locationSize;_e++)g(W.location+_e,J.meshPerAttribute);if(N.isInstancedMesh!==!0&&C._maxInstanceCount===void 0)C._maxInstanceCount=J.meshPerAttribute*J.count}else for(let _e=0;_e<W.locationSize;_e++)p(W.location+_e);e.bindBuffer(e.ARRAY_BUFFER,te);for(let _e=0;_e<W.locationSize;_e++)S(W.location+_e,Me/W.locationSize,ye,ne,Me*Ne,Me/W.locationSize*_e*Ne,De)}}else if(F!==void 0){let ne=F[re];if(ne!==void 0)switch(ne.length){case 2:e.vertexAttrib2fv(W.location,ne);break;case 3:e.vertexAttrib3fv(W.location,ne);break;case 4:e.vertexAttrib4fv(W.location,ne);break;default:e.vertexAttrib1fv(W.location,ne)}}}}v()}function A(){I();for(let N in i){let V=i[N];for(let Q in V){let C=V[Q];for(let q in C){let j=C[q];for(let F in j)u(j[F].object),delete j[F];delete C[q]}}delete i[N]}}function w(N){if(i[N.id]===void 0)return;let V=i[N.id];for(let Q in V){let C=V[Q];for(let q in C){let j=C[q];for(let F in j)u(j[F].object),delete j[F];delete C[q]}}delete i[N.id]}function _(N){for(let V in i){let Q=i[V];for(let C in Q){let q=Q[C];if(q[N.id]===void 0)continue;let j=q[N.id];for(let F in j)u(j[F].object),delete j[F];delete q[N.id]}}}function E(N){for(let V in i){let Q=i[V],C=N.isInstancedMesh===!0?N.id:0,q=Q[C];if(q===void 0)continue;for(let j in q){let F=q[j];for(let re in F)u(F[re].object),delete F[re];delete q[j]}if(delete Q[C],Object.keys(Q).length===0)delete i[V]}}function I(){if(k(),o=!0,r===s)return;r=s,c(r.object)}function k(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:I,resetDefaultState:k,dispose:A,releaseStatesOfGeometry:w,releaseStatesOfObject:E,releaseStatesOfProgram:_,initAttributes:x,enableAttribute:p,disableUnusedAttributes:v}}function hx(e,t,n){let i;function s(l){i=l}function r(l,c){e.drawArrays(i,l,c),n.update(c,i,1)}function o(l,c,u){if(u===0)return;e.drawArraysInstanced(i,l,c,u),n.update(c,i,u)}function a(l,c,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,l,0,c,0,u);let d=0;for(let f=0;f<u;f++)d+=c[f];n.update(d,i,1)}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a}function dx(e,t,n,i){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){let _=t.get("EXT_texture_filter_anisotropic");s=e.getParameter(_.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(_){if(_!==ci&&i.convert(_)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT))return!1;return!0}function a(_){let E=_===kn&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));if(_!==In&&_!==li&&!E&&i.convert(_)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE))return!1;return!0}function l(_){if(_==="highp"){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return"highp";_="mediump"}if(_==="mediump"){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0)return"mediump"}return"lowp"}let c=n.precision!==void 0?n.precision:"highp",u=l(c);if(u!==c)we("WebGLRenderer:",c,"not supported, using",u,"instead."),c=u;let h=n.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),d=n.logarithmicDepthBuffer===!0&&h===!1;if(n.reversedDepthBuffer===!0&&h===!1)we("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");if(n.logarithmicDepthBuffer===!0&&h===!0)we("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");let f=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),m=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=e.getParameter(e.MAX_TEXTURE_SIZE),p=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),g=e.getParameter(e.MAX_VERTEX_ATTRIBS),v=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),S=e.getParameter(e.MAX_VARYING_VECTORS),T=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),A=e.getParameter(e.MAX_SAMPLES),w=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:d,reversedDepthBuffer:h,maxTextures:f,maxVertexTextures:m,maxTextureSize:x,maxCubemapSize:p,maxAttributes:g,maxVertexUniforms:v,maxVaryings:S,maxFragmentUniforms:T,maxSamples:A,samples:w}}function fx(e){let t=this,n=null,i=0,s=!1,r=!1,o=new _n,a=new Pe,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,d){let f=h.length!==0||d||i!==0||s;return s=d,i=h.length,f},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(h,d){n=u(h,d,0)},this.setState=function(h,d,f){let{clippingPlanes:m,clipIntersection:x,clipShadows:p}=h,g=e.get(h);if(!s||m===null||m.length===0||r&&!p)if(r)u(null);else c();else{let v=r?0:i,S=v*4,T=g.clippingState||null;l.value=T,T=u(m,d,S,f);for(let A=0;A!==S;++A)T[A]=n[A];g.clippingState=T,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=v}};function c(){if(l.value!==n)l.value=n,l.needsUpdate=i>0;t.numPlanes=i,t.numIntersection=0}function u(h,d,f,m){let x=h!==null?h.length:0,p=null;if(x!==0){if(p=l.value,m!==!0||p===null){let g=f+x*4,v=d.matrixWorldInverse;if(a.getNormalMatrix(v),p===null||p.length<g)p=new Float32Array(g);for(let S=0,T=f;S!==x;++S,T+=4)o.copy(h[S]).applyMatrix4(v,a),o.normal.toArray(p,T),p[T+3]=o.constant}l.value=p,l.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,p}}class Oa extends Mn{constructor(e=1,t={}){super(e,e,t);this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},i=[n,n,n,n,n,n];this.texture=new xa(i),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new Ws(5,5,5),s=new On({name:"CubemapFromEquirect",uniforms:os(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:qt,blending:es});s.uniforms.tEquirect.value=t;let r=new bt(i,s),o=t.minFilter;if(t.minFilter===Ln)t.minFilter=Yt;return new kr(1,10,this).update(e,r),t.minFilter=o,r.geometry.dispose(),r.material.dispose(),this}clear(e,t=!0,n=!0,i=!0){let s=e.getRenderTarget();for(let r=0;r<6;r++)e.setRenderTarget(this,r),e.clear(t,n,i);e.setRenderTarget(s)}}var hf=256,px=3,mx=20,Df=256,Uf=16,gx=3,_x=new R,xx=new xe;class Ua{constructor(e){this._renderer=e,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new kr(1,10,null),this._boxMesh=new bt(new Ws(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(e,t=0,n=0.1,i=100,s={}){let{size:r=256,position:o=_x}=s,a=this._renderer;this._setSize(r);let l=this._allocateTarget(),c=this._getSourceTarget(!0);if(t>0)c.texture.mipmapsAutoUpdate=!1;let{autoClear:u,autoClearColor:h,autoClearDepth:d,autoClearStencil:f}=a,m=e.background;if(a.autoClear=!0,a.autoClearColor=!0,a.autoClearDepth=!0,a.autoClearStencil=!0,m===null)e.background=a.getClearColor(xx);let x=new kr(n,i,c);if(x.position.copy(o),x.update(a,e),a.autoClear=u,a.autoClearColor=h,a.autoClearDepth=d,a.autoClearStencil=f,e.background=m,t>0)c.texture.mipmapsAutoUpdate=!0,this._blur(l,t);return this._applyPMREM(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){if(this._cubemapMaterial===null)this._cubemapMaterial=pf(),this._compileMaterial(this._cubemapMaterial)}compileEquirectangularShader(){if(this._equirectMaterial===null)this._equirectMaterial=ff(),this._compileMaterial(this._equirectMaterial)}dispose(){if(this._sourceTarget!==null)this._sourceTarget.dispose();if(this._cubemapMaterial!==null)this._cubemapMaterial.dispose();if(this._equirectMaterial!==null)this._equirectMaterial.dispose();if(this._blurMaterial!==null)this._blurMaterial.dispose();if(this._ggxMaterial!==null)this._ggxMaterial.dispose();if(this._integrationMaterial!==null)this._integrationMaterial.dispose();this._boxMesh.geometry.dispose()}static lodToRoughness(e,t){return t>0?1-Math.sqrt(1-e/t):0}_setSize(e){this._cubeSize=Math.max(hf,qc(e))}_fromTexture(e,t){if(e.mapping===Cr||e.mapping===Os)this._setSize(e.image.length===0?hf:e.image[0].width||e.image[0].image.width);else this._setSize(e.image.width/4);let n=t||this._allocateTarget();return this._textureToCubemap(e),this._applyPMREM(n),n}_allocateTarget(){let e=this._cubeSize,t=df(e,!1,!1),n=Math.log2(e)-px;for(let i=0;i<=n;i++)t.texture.mipmaps.push({width:e>>i,height:e>>i});return t.texture.name="PMREM",t.texture.isPMREMTexture=!0,t}_getSourceTarget(e=!1){let t=this._cubeSize,n=this._sourceTarget;if(n===null||n.width!==t||e&&n.depthBuffer===!1){if(n!==null)n.dispose();this._sourceTarget=df(t,!0,e)}return this._sourceTarget}_compileMaterial(e){this._boxMesh.material=e,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(e,t,n){let i=this._boxMesh,s=this._cubeCamera;i.material=n,s.renderTarget=e,s.activeMipmapLevel=t;let r=e.width>>t;e.viewport.set(0,0,r,r),s.update(this._renderer,i),e.viewport.set(0,0,e.width,e.height)}_textureToCubemap(e){let t;if(e.mapping===Cr||e.mapping===Os){if(this._cubemapMaterial===null)this._cubemapMaterial=pf();t=this._cubemapMaterial,t.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1}else{if(this._equirectMaterial===null)this._equirectMaterial=ff();t=this._equirectMaterial}t.uniforms.envMap.value=e,this._renderCube(this._getSourceTarget(),0,t)}_applyPMREM(e){if(this._ggxMaterial===null)this._ggxMaterial=Mx(),this._integrationMaterial=yx();let t=this._cubeSize,n=e.texture.mipmaps.length-1,i=this._ggxMaterial.uniforms;i.envMap.value=this._sourceTarget.texture;let s=this._integrationMaterial.uniforms;s.envMap.value=this._sourceTarget.texture,s.sourceLod.value=Math.log2(t/Uf);for(let r=0;r<=n;r++){let o=Ua.lodToRoughness(r,n);if(r>n-gx)s.roughness.value=o,this._renderCube(e,r,this._integrationMaterial);else{let a=o>0?Math.log2(t)+0.5*Math.log2(6/(Df*Math.pow(o,4)))+0.5:0;i.roughness.value=o,i.lodBias.value=a,this._renderCube(e,r,this._ggxMaterial)}}}_blur(e,t){if(this._blurMaterial===null)this._blurMaterial=vx();let n=this._blurMaterial,i=n.uniforms,s=this._sourceTarget;i.sigma.value=Math.min(t,Math.PI)/Math.SQRT2,i.envMap.value=s.texture,this._renderCube(e,0,n),i.envMap.value=e.texture,this._renderCube(s,0,n)}}function df(e,t,n){return new Oa(e,{minFilter:Ln,generateMipmaps:t,type:kn,colorSpace:fn,depthBuffer:n})}function Yr(e,t,n){return new On({name:e,uniforms:t,vertexShader:Xe.cube_vert,fragmentShader:n,side:qt,blending:es,depthTest:!1,depthWrite:!1})}function Mx(){return Yr("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${Df}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function yx(){return Yr("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:Uf}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function vx(){return Yr("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${mx}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function ff(){return Yr("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function pf(){return Yr("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function Ex(e){let t=new WeakMap,n=new WeakMap,i=null;function s(d,f=!1){if(d===null||d===void 0)return null;if(f)return o(d);return r(d)}function r(d){if(d&&d.isTexture){let f=d.mapping;if(f===$o||f===Qo)if(t.has(d)){let m=t.get(d).texture;return a(m,d.mapping)}else{let m=d.image;if(m&&m.height>0){let x=new Oa(m.height);return x.fromEquirectangularTexture(e,d),t.set(d,x),d.addEventListener("dispose",c),a(x.texture,d.mapping)}else return null}}return d}function o(d){if(d&&d.isTexture&&d.isPMREMTexture!==!0){let f=d.mapping,m=f===$o||f===Qo,x=f===Cr||f===Os;if(m||x){let p=n.get(d),g=p!==void 0?p.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==g){if(i===null)i=new Ua(e);return p=m?i.fromEquirectangular(d,p):i.fromCubemap(d,p),p.texture.pmremVersion=d.pmremVersion,n.set(d,p),p.texture}else if(p!==void 0)return p.texture;else{let v=d.image;if(m&&v&&v.height>0||x&&v&&l(v)){if(i===null)i=new Ua(e);return p=m?i.fromEquirectangular(d):i.fromCubemap(d),p.texture.pmremVersion=d.pmremVersion,n.set(d,p),d.addEventListener("dispose",u),p.texture}else return null}}}return d}function a(d,f){if(f===$o)d.mapping=Cr;else if(f===Qo)d.mapping=Os;return d}function l(d){let f=0,m=6;for(let x=0;x<m;x++)if(d[x]!==void 0)f++;return f===m}function c(d){let f=d.target;f.removeEventListener("dispose",c);let m=t.get(f);if(m!==void 0)t.delete(f),m.dispose()}function u(d){let f=d.target;f.removeEventListener("dispose",u);let m=n.get(f);if(m!==void 0)n.delete(f),m.dispose()}function h(){if(t=new WeakMap,n=new WeakMap,i!==null)i.dispose(),i=null}return{get:s,dispose:h}}function Tx(e){let t={};function n(i){if(t[i]!==void 0)return t[i];let s=e.getExtension(i);return t[i]=s,s}return{has:function(i){return n(i)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(i){let s=n(i);if(s===null)Ki("WebGLRenderer: "+i+" extension not supported.");return s}}}function Sx(e,t,n,i){let s={},r=new WeakMap,o=new FinalizationRegistry((m)=>delete s[m]);function a(m){l(m.target)}function l(m){if(m.index!==null)t.remove(m.index);for(let p in m.attributes)t.remove(m.attributes[p]);m.removeEventListener("dispose",a),delete s[m.id],o.unregister(m);let x=r.get(m);if(x)t.remove(x),r.delete(m);if(i.releaseStatesOfGeometry(m),m.isInstancedBufferGeometry===!0)delete m._maxInstanceCount;n.memory.geometries--}function c(m,x){if(s[x.id]!==void 0)return x;return x.addEventListener("dispose",a),s[x.id]=new WeakRef(x),o.register(x,x.id,x),n.memory.geometries++,x}function u(m){let x=m.attributes;for(let p in x)t.update(x[p],e.ARRAY_BUFFER)}function h(m){let x=m.index,p=m.attributes.position,g=0;if(p===void 0)return;let v=x!==null?x.array.length:p.array.length/3-1,T=new(p.count>=65535?pa:fa)(Math.ceil(v/3)*6,1),A=T.array;if(x!==null){let _=x.array;g=x.version;for(let E=0,I=0;E<v;E+=3){let k=_[E+0],N=_[E+1],V=_[E+2];A[I++]=k,A[I++]=N,A[I++]=N,A[I++]=V,A[I++]=V,A[I++]=k}}else{g=p.version;for(let _=0,E=0;_<v;_+=3){let I=_+0,k=_+1,N=_+2;A[E++]=I,A[E++]=k,A[E++]=k,A[E++]=N,A[E++]=N,A[E++]=I}}T.version=g;let w=r.get(m);if(w)t.remove(w);r.set(m,T)}function d(m){let x=r.get(m);if(x){let p=m.index;if(p!==null){if(x.version<p.version)h(m)}}else h(m);return r.get(m)}function f(){for(let m in s){let x=s[m].deref();if(x!==void 0)l(x)}}return{get:c,update:u,getWireframeAttribute:d,dispose:f}}function bx(e,t,n){let i;function s(h){i=h}let r,o;function a(h){r=h.type,o=h.bytesPerElement}function l(h,d){e.drawElements(i,d,r,h*o),n.update(d,i,1)}function c(h,d,f){if(f===0)return;e.drawElementsInstanced(i,d,r,h*o,f),n.update(d,i,f)}function u(h,d,f){if(f===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,d,0,r,h,0,f);let x=0;for(let p=0;p<f;p++)x+=d[p];n.update(x,i,1)}this.setMode=s,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=u}function Rx(e){let t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,o,a){switch(n.calls++,o){case e.TRIANGLES:n.triangles+=a*(r/3);break;case e.LINES:n.lines+=a*(r/2);break;case e.LINE_STRIP:n.lines+=a*(r-1);break;case e.LINE_LOOP:n.lines+=a*r;break;case e.POINTS:n.points+=a*r;break;default:He("WebGLInfo: Unknown draw mode:",o);break}}function s(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:s,update:i}}function Ax(e,t,n){let i=new WeakMap,s=new ut;function r(o,a,l){let c=o.morphTargetInfluences,u=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,h=u!==void 0?u.length:0,d=i.get(a);if(d===void 0||d.count!==h){let I=function(){_.dispose(),i.delete(a),a.removeEventListener("dispose",I)};if(d!==void 0)d.texture.dispose();let f=a.morphAttributes.position!==void 0,m=a.morphAttributes.normal!==void 0,x=a.morphAttributes.color!==void 0,p=a.morphAttributes.position||[],g=a.morphAttributes.normal||[],v=a.morphAttributes.color||[],S=0;if(f===!0)S=1;if(m===!0)S=2;if(x===!0)S=3;let T=a.attributes.position.count*S,A=1;if(T>t.maxTextureSize)A=Math.ceil(T/t.maxTextureSize),T=t.maxTextureSize;let w=new Float32Array(T*A*4*h),_=new ua(w,T,A,h);_.type=li,_.needsUpdate=!0;let E=S*4;for(let k=0;k<h;k++){let N=p[k],V=g[k],Q=v[k],C=T*A*4*k;for(let q=0;q<N.count;q++){let j=q*E;if(f===!0)s.fromBufferAttribute(N,q),w[C+j+0]=s.x,w[C+j+1]=s.y,w[C+j+2]=s.z,w[C+j+3]=0;if(m===!0)s.fromBufferAttribute(V,q),w[C+j+4]=s.x,w[C+j+5]=s.y,w[C+j+6]=s.z,w[C+j+7]=0;if(x===!0)s.fromBufferAttribute(Q,q),w[C+j+8]=s.x,w[C+j+9]=s.y,w[C+j+10]=s.z,w[C+j+11]=Q.itemSize===4?s.w:1}}d={count:h,texture:_,size:new Ce(T,A)},i.set(a,d),a.addEventListener("dispose",I)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(e,"morphTexture",o.morphTexture,n);else{let f=0;for(let x=0;x<c.length;x++)f+=c[x];let m=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(e,"morphTargetBaseInfluence",m),l.getUniforms().setValue(e,"morphTargetInfluences",c)}l.getUniforms().setValue(e,"morphTargetsTexture",d.texture,n),l.getUniforms().setValue(e,"morphTargetsTextureSize",d.size)}return{update:r}}function wx(e,t,n,i,s){let r=new WeakMap;function o(c){let u=s.render.frame,h=c.geometry,d=t.get(c,h);if(r.get(d)!==u)t.update(d),r.set(d,u);if(c.isInstancedMesh){if(c.hasEventListener("dispose",l)===!1)c.addEventListener("dispose",l);if(r.get(c)!==u){if(n.update(c.instanceMatrix,e.ARRAY_BUFFER),c.instanceColor!==null)n.update(c.instanceColor,e.ARRAY_BUFFER);r.set(c,u)}}if(c.isSkinnedMesh){let f=c.skeleton;if(r.get(f)!==u)f.update(),r.set(f,u)}return d}function a(){r=new WeakMap}function l(c){let u=c.target;if(u.removeEventListener("dispose",l),i.releaseStatesOfObject(u),n.remove(u.instanceMatrix),u.instanceColor!==null)n.remove(u.instanceColor)}return{update:o,dispose:a}}var Cx={[Yl]:"LINEAR_TONE_MAPPING",[Zl]:"REINHARD_TONE_MAPPING",[jl]:"CINEON_TONE_MAPPING",[Jl]:"ACES_FILMIC_TONE_MAPPING",[$l]:"AGX_TONE_MAPPING",[Ql]:"NEUTRAL_TONE_MAPPING",[Kl]:"CUSTOM_TONE_MAPPING"};function Px(e,t,n,i,s,r){let o=new Mn(t,n,{type:e,depthBuffer:s,stencilBuffer:r,samples:i?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),a=null,l=null,c=null,u=new Qe;u.setAttribute("position",new Rt([-1,3,0,-1,-1,0,3,-1,0],3)),u.setAttribute("uv",new Rt([0,2,0,0,2,0],2));let h=new Qc({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new bt(u,h),f=new Zs(-1,1,1,-1,0,1),m=null,x=null,p=!1,g,v=null,S=[],T=!1;this.setSize=function(A,w){if(o.setSize(A,w),a!==null)a.setSize(A,w);if(l!==null)l.setSize(A,w);for(let _=0;_<S.length;_++){let E=S[_];if(E.setSize)E.setSize(A,w)}},this.setEffects=function(A){S=A,T=S.length>0&&S[0].isRenderPass===!0;let{width:w,height:_}=o;if(S.length>0&&a===null)a=new Mn(w,_,{type:kn,depthBuffer:!1,stencilBuffer:!1}),l=new Mn(w,_,{type:kn,depthBuffer:!1,stencilBuffer:!1});let E=s===!0&&S.some((I)=>I.needsDepthTexture===!0);if(E!==(o.depthTexture!==null)){if(E===!0&&c===null){if(c=new Pi(w,_),r===!0)c.format=Ri,c.type=ns}o.dispose(),o.depthTexture=E?c:null,o.resolveDepthBuffer=E,o.storeMultisampledDepthBuffer=E}for(let I=0;I<S.length;I++){let k=S[I];if(k.setSize)k.setSize(w,_);if(E&&k.needsDepthTexture===!0&&k.setDepthTexture)k.setDepthTexture(c)}},this.begin=function(A,w){if(p)return!1;if(A.toneMapping===Vn&&S.length===0)return!1;if(v=w,w!==null){let{width:_,height:E}=w;if(o.width!==_||o.height!==E)this.setSize(_,E)}if(T===!1)A.setRenderTarget(o);return g=A.toneMapping,A.toneMapping=Vn,!0},this.hasRenderPass=function(){return T},this.end=function(A,w){A.toneMapping=g,p=!0;let _=o,E=a;for(let I=0;I<S.length;I++){let k=S[I];if(k.enabled===!1)continue;if(k.render(A,E,_,w),k.needsSwap!==!1)_=E,E=E===a?l:a}if(m!==A.outputColorSpace||x!==A.toneMapping){if(m=A.outputColorSpace,x=A.toneMapping,h.defines={},qe.getTransfer(m)===ft)h.defines.SRGB_TRANSFER="";let I=Cx[x];if(I)h.defines[I]="";h.needsUpdate=!0}h.uniforms.tDiffuse.value=_.texture,A.setRenderTarget(v),A.render(d,f),v=null,p=!1},this.isCompositing=function(){return p},this.dispose=function(){if(o.dispose(),a!==null)a.dispose();if(l!==null)l.dispose();u.dispose(),h.dispose()}}var Of=new vt,Ff=new Pi(1,1),Hf=new ya(1),Bf=new ua,Vf=new Kc,kf=new xa,mf=[],gf=[],_f=new Float32Array(16),xf=new Float32Array(9),Mf=new Float32Array(4);function js(e,t,n){let i=e[0];if(i<=0||i>0)return e;let s=t*n,r=mf[s];if(r===void 0)r=new Float32Array(s),mf[s]=r;if(t!==0){i.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=n,e[o].toArray(r,a)}return r}function At(e,t){if(e.length!==t.length)return!1;for(let n=0,i=e.length;n<i;n++)if(e[n]!==t[n])return!1;return!0}function wt(e,t){for(let n=0,i=t.length;n<i;n++)e[n]=t[n]}function Fa(e,t){let n=gf[t];if(n===void 0)n=new Int32Array(t),gf[t]=n;for(let i=0;i!==t;++i)n[i]=e.allocateTextureUnit();return n}function Lx(e,t){let n=this.cache;if(n[0]===t)return;e.uniform1f(this.addr,t),n[0]=t}function Ix(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y)e.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y}else{if(At(n,t))return;e.uniform2fv(this.addr,t),wt(n,t)}}function Nx(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)e.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z}else if(t.r!==void 0){if(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)e.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b}else{if(At(n,t))return;e.uniform3fv(this.addr,t),wt(n,t)}}function Dx(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)e.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w}else{if(At(n,t))return;e.uniform4fv(this.addr,t),wt(n,t)}}function Ux(e,t){let n=this.cache,i=t.elements;if(i===void 0){if(At(n,t))return;e.uniformMatrix2fv(this.addr,!1,t),wt(n,t)}else{if(At(n,i))return;Mf.set(i),e.uniformMatrix2fv(this.addr,!1,Mf),wt(n,i)}}function Ox(e,t){let n=this.cache,i=t.elements;if(i===void 0){if(At(n,t))return;e.uniformMatrix3fv(this.addr,!1,t),wt(n,t)}else{if(At(n,i))return;xf.set(i),e.uniformMatrix3fv(this.addr,!1,xf),wt(n,i)}}function Fx(e,t){let n=this.cache,i=t.elements;if(i===void 0){if(At(n,t))return;e.uniformMatrix4fv(this.addr,!1,t),wt(n,t)}else{if(At(n,i))return;_f.set(i),e.uniformMatrix4fv(this.addr,!1,_f),wt(n,i)}}function Hx(e,t){let n=this.cache;if(n[0]===t)return;e.uniform1i(this.addr,t),n[0]=t}function Bx(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y)e.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y}else{if(At(n,t))return;e.uniform2iv(this.addr,t),wt(n,t)}}function Vx(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)e.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z}else{if(At(n,t))return;e.uniform3iv(this.addr,t),wt(n,t)}}function kx(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)e.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w}else{if(At(n,t))return;e.uniform4iv(this.addr,t),wt(n,t)}}function Gx(e,t){let n=this.cache;if(n[0]===t)return;e.uniform1ui(this.addr,t),n[0]=t}function zx(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y)e.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y}else{if(At(n,t))return;e.uniform2uiv(this.addr,t),wt(n,t)}}function Wx(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)e.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z}else{if(At(n,t))return;e.uniform3uiv(this.addr,t),wt(n,t)}}function Xx(e,t){let n=this.cache;if(t.x!==void 0){if(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w}else{if(At(n,t))return;e.uniform4uiv(this.addr,t),wt(n,t)}}function Ha(e){if(e.version===0)e.compareFunction=kc,e.needsUpdate=!0;return e}function qx(e,t,n){let i=this.cache,s=n.allocateTextureUnit();if(i[0]!==s)e.uniform1i(this.addr,s),i[0]=s;let r;if(this.type===e.SAMPLER_2D_SHADOW)r=Ha(Ff);else r=Of;n.setTexture2D(t||r,s)}function Yx(e,t,n){let i=this.cache,s=n.allocateTextureUnit();if(i[0]!==s)e.uniform1i(this.addr,s),i[0]=s;n.setTexture3D(t||Vf,s)}function Zx(e,t,n){let i=this.cache,s=n.allocateTextureUnit();if(i[0]!==s)e.uniform1i(this.addr,s),i[0]=s;let r;if(this.type===e.SAMPLER_CUBE_SHADOW)r=Ha(Hf);else r=kf;n.setTextureCube(t||r,s)}function jx(e,t,n){let i=this.cache,s=n.allocateTextureUnit();if(i[0]!==s)e.uniform1i(this.addr,s),i[0]=s;n.setTexture2DArray(t||Bf,s)}function Jx(e){switch(e){case 5126:return Lx;case 35664:return Ix;case 35665:return Nx;case 35666:return Dx;case 35674:return Ux;case 35675:return Ox;case 35676:return Fx;case 5124:case 35670:return Hx;case 35667:case 35671:return Bx;case 35668:case 35672:return Vx;case 35669:case 35673:return kx;case 5125:return Gx;case 36294:return zx;case 36295:return Wx;case 36296:return Xx;case 35678:case 36198:case 36298:case 36306:case 35682:return qx;case 35679:case 36299:case 36307:return Yx;case 35680:case 36300:case 36308:case 36293:return Zx;case 36289:case 36303:case 36311:case 36292:return jx}}function Kx(e,t){e.uniform1fv(this.addr,t)}function $x(e,t){let n=js(t,this.size,2);e.uniform2fv(this.addr,n)}function Qx(e,t){let n=js(t,this.size,3);e.uniform3fv(this.addr,n)}function eM(e,t){let n=js(t,this.size,4);e.uniform4fv(this.addr,n)}function tM(e,t){let n=js(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,n)}function nM(e,t){let n=js(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,n)}function iM(e,t){let n=js(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,n)}function sM(e,t){e.uniform1iv(this.addr,t)}function rM(e,t){e.uniform2iv(this.addr,t)}function oM(e,t){e.uniform3iv(this.addr,t)}function aM(e,t){e.uniform4iv(this.addr,t)}function lM(e,t){e.uniform1uiv(this.addr,t)}function cM(e,t){e.uniform2uiv(this.addr,t)}function uM(e,t){e.uniform3uiv(this.addr,t)}function hM(e,t){e.uniform4uiv(this.addr,t)}function dM(e,t,n){let i=this.cache,s=t.length,r=Fa(n,s);if(!At(i,r))e.uniform1iv(this.addr,r),wt(i,r);let o;if(this.type===e.SAMPLER_2D_SHADOW)o=Ha(Ff);else o=Of;for(let a=0;a!==s;++a)n.setTexture2D(t[a]||o,r[a])}function fM(e,t,n){let i=this.cache,s=t.length,r=Fa(n,s);if(!At(i,r))e.uniform1iv(this.addr,r),wt(i,r);for(let o=0;o!==s;++o)n.setTexture3D(t[o]||Vf,r[o])}function pM(e,t,n){let i=this.cache,s=t.length,r=Fa(n,s);if(!At(i,r))e.uniform1iv(this.addr,r),wt(i,r);let o;if(this.type===e.SAMPLER_CUBE_SHADOW)o=Ha(Hf);else o=kf;for(let a=0;a!==s;++a)n.setTextureCube(t[a]||o,r[a])}function mM(e,t,n){let i=this.cache,s=t.length,r=Fa(n,s);if(!At(i,r))e.uniform1iv(this.addr,r),wt(i,r);for(let o=0;o!==s;++o)n.setTexture2DArray(t[o]||Bf,r[o])}function gM(e){switch(e){case 5126:return Kx;case 35664:return $x;case 35665:return Qx;case 35666:return eM;case 35674:return tM;case 35675:return nM;case 35676:return iM;case 5124:case 35670:return sM;case 35667:case 35671:return rM;case 35668:case 35672:return oM;case 35669:case 35673:return aM;case 5125:return lM;case 36294:return cM;case 36295:return uM;case 36296:return hM;case 35678:case 36198:case 36298:case 36306:case 35682:return dM;case 35679:case 36299:case 36307:return fM;case 35680:case 36300:case 36308:case 36293:return pM;case 36289:case 36303:case 36311:case 36292:return mM}}class Gf{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=Jx(t.type)}}class zf{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=gM(t.type)}}class Wf{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let i=this.seq;for(let s=0,r=i.length;s!==r;++s){let o=i[s];o.setValue(e,t[o.id],n)}}}var du=/(\w+)(\])?(\[|\.)?/g;function yf(e,t){e.seq.push(t),e.map[t.id]=t}function _M(e,t,n){let i=e.name,s=i.length;du.lastIndex=0;while(!0){let r=du.exec(i),o=du.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l)a=a|0;if(c===void 0||c==="["&&o+2===s){yf(n,c===void 0?new Gf(a,e,t):new zf(a,e,t));break}else{let h=n.map[a];if(h===void 0)h=new Wf(a),yf(n,h);n=h}}}class qr{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){let o=e.getActiveUniform(t,r),a=e.getUniformLocation(t,o.name);_M(o,a,this)}let i=[],s=[];for(let r of this.seq)if(r.type===e.SAMPLER_2D_SHADOW||r.type===e.SAMPLER_CUBE_SHADOW||r.type===e.SAMPLER_2D_ARRAY_SHADOW)i.push(r);else s.push(r);if(i.length>0)this.seq=i.concat(s)}setValue(e,t,n,i){let s=this.map[t];if(s!==void 0)s.setValue(e,n,i)}setOptional(e,t,n){let i=t[n];if(i!==void 0)this.setValue(e,n,i)}static upload(e,t,n,i){for(let s=0,r=t.length;s!==r;++s){let o=t[s],a=n[o.id];if(a.needsUpdate!==!1)o.setValue(e,a.value,i)}}static seqWithValue(e,t){let n=[];for(let i=0,s=e.length;i!==s;++i){let r=e[i];if(r.id in t)n.push(r)}return n}}function vf(e,t,n){let i=e.createShader(t);return e.shaderSource(i,n),e.compileShader(i),i}var xM=37297,MM=0;function yM(e,t){let n=e.split(`
`),i=[],s=Math.max(t-6,0),r=Math.min(t+6,n.length);for(let o=s;o<r;o++){let a=o+1;i.push(`${a===t?">":" "} ${a}: ${n[o]}`)}return i.join(`
`)}var Ef=new Pe;function vM(e){qe._getMatrix(Ef,qe.workingColorSpace,e);let t=`mat3( ${Ef.elements.map((n)=>n.toFixed(4))} )`;switch(qe.getTransfer(e)){case Hc:return[t,"LinearTransferOETF"];case ft:return[t,"sRGBTransferOETF"];default:return we("WebGLProgram: Unsupported color space: ",e),[t,"LinearTransferOETF"]}}function Tf(e,t,n){let i=e.getShaderParameter(t,e.COMPILE_STATUS),r=(e.getShaderInfoLog(t)||"").trim();if(i&&r==="")return"";let o=/ERROR: 0:(\d+)/.exec(r);if(o){let a=parseInt(o[1]);return n.toUpperCase()+`

`+r+`

`+yM(e.getShaderSource(t),a)}else return r}function EM(e,t){let n=vM(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${n[1]}( vec4( ${n[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}var TM={[Yl]:"Linear",[Zl]:"Reinhard",[jl]:"Cineon",[Jl]:"ACESFilmic",[$l]:"AgX",[Ql]:"Neutral",[Kl]:"Custom"};function SM(e,t){let n=TM[t];if(n===void 0)return we("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+e+"( vec3 color ) { return LinearToneMapping( color ); }";return"vec3 "+e+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}var Da=new R;function bM(){qe.getLuminanceCoefficients(Da);let e=Da.x.toFixed(4),t=Da.y.toFixed(4),n=Da.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${e}, ${t}, ${n} );`,"\treturn dot( weights, rgb );","}"].join(`
`)}function RM(e){return[e.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",e.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Xr).join(`
`)}function AM(e){let t=[];for(let n in e){let i=e[n];if(i===!1)continue;t.push("#define "+n+" "+i)}return t.join(`
`)}function wM(e,t){let n={},i=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){let r=e.getActiveAttrib(t,s),o=r.name,a=1;if(r.type===e.FLOAT_MAT2)a=2;if(r.type===e.FLOAT_MAT3)a=3;if(r.type===e.FLOAT_MAT4)a=4;n[o]={type:r.type,location:e.getAttribLocation(t,o),locationSize:a}}return n}function Xr(e){return e!==""}function Sf(e,t){let n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,t.numLightProbeGrids)}function bf(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var CM=/^[ \t]*#include +<([\w\d./]+)>/gm;function pu(e){return e.replace(CM,PM)}function PM(e,t){let n=Xe[t];if(n===void 0)throw Error("THREE.WebGLProgram: Can not resolve #include <"+t+">");return pu(n)}var LM=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Rf(e){return e.replace(LM,IM)}function IM(e,t,n,i){let s="";for(let r=parseInt(t);r<parseInt(n);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Af(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;if(e.precision==="highp")t+=`
#define HIGH_PRECISION`;else if(e.precision==="mediump")t+=`
#define MEDIUM_PRECISION`;else if(e.precision==="lowp")t+=`
#define LOW_PRECISION`;return t}var NM={[Ar]:"SHADOWMAP_TYPE_PCF",[Ds]:"SHADOWMAP_TYPE_VSM"};function DM(e){return NM[e.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}var UM={[Os]:"ENVMAP_MODE_REFRACTION"};function OM(e){if(e.envMap===!1)return"ENVMAP_MODE_REFLECTION";return UM[e.envMapMode]||"ENVMAP_MODE_REFLECTION"}var FM={[Ud]:"ENVMAP_BLENDING_MULTIPLY",[Od]:"ENVMAP_BLENDING_MIX",[Fd]:"ENVMAP_BLENDING_ADD"};function HM(e){if(e.envMap===!1)return"ENVMAP_BLENDING_NONE";return FM[e.combine]||"ENVMAP_BLENDING_NONE"}function BM(e,t,n,i){let s=e.getContext(),{defines:r,vertexShader:o,fragmentShader:a}=n,l=DM(n),c=n.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",u=OM(n),h=HM(n),d=RM(n),f=AM(r),m=s.createProgram(),x,p,g=n.glslVersion?"#version "+n.glslVersion+`
`:"";if(n.isRawShaderMaterial){if(x=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,f].filter(Xr).join(`
`),x.length>0)x+=`
`;if(p=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,f].filter(Xr).join(`
`),p.length>0)p+=`
`}else x=[Af(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,f,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+u:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+n.diffuseRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexNormals?"#define HAS_NORMAL":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+l:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","\tattribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","\tattribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","\tuniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","\tattribute vec2 uv1;","#endif","#ifdef USE_UV2","\tattribute vec2 uv2;","#endif","#ifdef USE_UV3","\tattribute vec2 uv3;","#endif","#ifdef USE_TANGENT","\tattribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","\tattribute vec4 color;","#elif defined( USE_COLOR )","\tattribute vec3 color;","#endif","#ifdef USE_SKINNING","\tattribute vec4 skinIndex;","\tattribute vec4 skinWeight;","#endif",`
`].filter(Xr).join(`
`),p=[Af(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,f,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+c:"",n.envMap?"#define "+u:"",n.envMap?"#define "+h:"",n.envMapPMREM?"#define ENVMAP_MAX_LOD "+n.envMapMaxLod+".0":"",n.envMapPMREM?"#define ENVMAP_SIZE "+n.envMapSize+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",n.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.retroreflection?"#define USE_RETROREFLECTION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor?"#define USE_COLOR":"",n.vertexAlphas||n.batchingColor?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+l:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==Vn?"#define TONE_MAPPING":"",n.toneMapping!==Vn?Xe.tonemapping_pars_fragment:"",n.toneMapping!==Vn?SM("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",Xe.colorspace_pars_fragment,EM("linearToOutputTexel",n.outputColorSpace),bM(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(Xr).join(`
`);if(o=pu(o),o=Sf(o,n),o=bf(o,n),a=pu(a),a=Sf(a,n),a=bf(a,n),o=Rf(o),a=Rf(a),n.isRawShaderMaterial!==!0)g=`#version 300 es
`,x=[d,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,p=["#define varying in",n.glslVersion===zc?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===zc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p;let v=g+x+o,S=g+p+a,T=vf(s,s.VERTEX_SHADER,v),A=vf(s,s.FRAGMENT_SHADER,S);if(s.attachShader(m,T),s.attachShader(m,A),n.index0AttributeName!==void 0)s.bindAttribLocation(m,0,n.index0AttributeName);else if(n.hasPositionAttribute===!0)s.bindAttribLocation(m,0,"position");s.linkProgram(m);function w(k){if(e.debug.checkShaderErrors){let N=s.getProgramInfoLog(m)||"",V=s.getShaderInfoLog(T)||"",Q=s.getShaderInfoLog(A)||"",C=N.trim(),q=V.trim(),j=Q.trim(),F=!0,re=!0;if(s.getProgramParameter(m,s.LINK_STATUS)===!1)if(F=!1,typeof e.debug.onShaderError==="function")e.debug.onShaderError(s,m,T,A);else{let W=Tf(s,T,"vertex"),J=Tf(s,A,"fragment");He("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(m,s.VALIDATE_STATUS)+`

Material Name: `+k.name+`
Material Type: `+k.type+`

Program Info Log: `+C+`
`+W+`
`+J)}else if(C!=="")we("WebGLProgram: Program Info Log:",C);else if(q===""||j==="")re=!1;if(re)k.diagnostics={runnable:F,programLog:C,vertexShader:{log:q,prefix:x},fragmentShader:{log:j,prefix:p}}}s.deleteShader(T),s.deleteShader(A),_=new qr(s,m),E=wM(s,m)}let _;this.getUniforms=function(){if(_===void 0)w(this);return _};let E;this.getAttributes=function(){if(E===void 0)w(this);return E};let I=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){if(I===!1)I=s.getProgramParameter(m,xM);return I},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(m),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=MM++,this.cacheKey=t,this.usedTimes=1,this.program=m,this.vertexShader=T,this.fragmentShader=A,this}var VM=0;class Xf{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let i=this._getShaderCacheForMaterial(e);if(i.has(t)===!1)i.add(t),t.usedTimes++;if(i.has(n)===!1)i.add(n),n.usedTimes++;return this}remove(e){let t=this.materialCache.get(e);for(let n of t)if(n.usedTimes--,n.usedTimes===0)this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);if(n===void 0)n=new Set,t.set(e,n);return n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);if(n===void 0)n=new qf(e),t.set(e,n);return n}}class qf{constructor(e){this.id=VM++,this.code=e,this.usedTimes=0}}function kM(e){return e===is||e===oa||e===aa}function GM(e,t,n,i,s,r){let o=new ha,a=new Xf,l=new Set,c=[],u=new Map,h=i.logarithmicDepthBuffer,d={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function f(_){if(l.add(_),_===0)return"uv";return`uv${_}`}function m(_,E,I,k,N,V){let Q=k.fog,C=N.geometry,q=_.isMeshStandardMaterial||_.isMeshLambertMaterial||_.isMeshPhongMaterial?k.environment:null,j=_.isMeshStandardMaterial||_.isMeshLambertMaterial&&!_.envMap||_.isMeshPhongMaterial&&!_.envMap,F=t.get(_.envMap||q,j),re=d[_.type],W=i.precision;if(_.precision!==null){if(W=i.getMaxPrecision(_.precision),W!==_.precision)we("WebGLProgram.getParameters:",_.precision,"not supported, using",W,"instead.")}let J=C.morphAttributes.position||C.morphAttributes.normal||C.morphAttributes.color,ne=J!==void 0?J.length:0,Me=0;if(C.morphAttributes.position!==void 0)Me=1;if(C.morphAttributes.normal!==void 0)Me=2;if(C.morphAttributes.color!==void 0)Me=3;let Z,te,ye,Ne;if(re){let me=Xn[re];Z=me.vertexShader,te=me.fragmentShader}else{Z=_.vertexShader,te=_.fragmentShader;let me=a.getVertexShaderStage(_),ct=a.getFragmentShaderStage(_);a.update(_,me,ct),ye=me.id,Ne=ct.id}let De=e.getRenderTarget(),_e=e.state.buffers.depth.getReversed(),it=N.isInstancedMesh===!0,We=N.isBatchedMesh===!0,Be=!!_.map,ht=!!_.matcap,et=!!F,gt=et&&F.isPMREMTexture===!0,Mt=!!_.aoMap,sn=!!_.lightMap,un=!!_.bumpMap&&_.wireframe===!1,Et=!!_.normalMap,Vt=!!_.displacementMap,rn=!!_.emissiveMap,on=!!_.metalnessMap,Sn=!!_.roughnessMap,D=_.anisotropy>0,bn=_.clearcoat>0,lt=_.diffuseRoughness>0,Lt=_.dispersion>0,fe=_.retroreflectivity>0,pt=_.iridescence>0,Oe=_.sheen>0,Ve=_.transmission>0,kt=D&&!!_.anisotropyMap,b=bn&&!!_.clearcoatMap,M=bn&&!!_.clearcoatNormalMap,U=bn&&!!_.clearcoatRoughnessMap,ee=lt&&!!_.diffuseRoughnessMap,K=pt&&!!_.iridescenceMap,oe=pt&&!!_.iridescenceThicknessMap,le=Oe&&!!_.sheenColorMap,G=Oe&&!!_.sheenRoughnessMap,Y=!!_.specularMap,ae=!!_.specularColorMap,P=!!_.specularIntensityMap,X=Ve&&!!_.transmissionMap,z=Ve&&!!_.thicknessMap,ie=!!_.gradientMap,se=!!_.alphaMap,de=_.alphaTest>0,Le=!!_.alphaHash,Ae=!!_.extensions,pe=Vn;if(_.toneMapped){if(De===null||De.isXRRenderTarget===!0)pe=e.toneMapping}let Ie=gt?F.isCompressedCubeTexture?F.image[0].mipmaps:F.mipmaps:null,ze={shaderID:re,shaderType:_.type,shaderName:_.name,vertexShader:Z,fragmentShader:te,defines:_.defines,customVertexShaderID:ye,customFragmentShaderID:Ne,isRawShaderMaterial:_.isRawShaderMaterial===!0,glslVersion:_.glslVersion,precision:W,batching:We,batchingColor:We&&N._colorsTexture!==null,instancing:it,instancingColor:it&&N.instanceColor!==null,instancingMorph:it&&N.morphTexture!==null,outputColorSpace:De===null?e.outputColorSpace:De.isXRRenderTarget===!0?De.texture.colorSpace:qe.workingColorSpace,alphaToCoverage:!!_.alphaToCoverage,map:Be,matcap:ht,envMap:et,envMapMode:et&&F.mapping,envMapPMREM:gt,envMapMaxLod:gt?Ie.length-1:null,envMapSize:gt?Ie[0].width:null,aoMap:Mt,lightMap:sn,bumpMap:un,normalMap:Et,displacementMap:Vt,emissiveMap:rn,normalMapObjectSpace:Et&&_.normalMapType===Xd,normalMapTangentSpace:Et&&_.normalMapType===Ir,packedNormalMap:Et&&_.normalMapType===Ir&&kM(_.normalMap.format),metalnessMap:on,roughnessMap:Sn,anisotropy:D,anisotropyMap:kt,clearcoat:bn,clearcoatMap:b,clearcoatNormalMap:M,clearcoatRoughnessMap:U,diffuseRoughness:lt,diffuseRoughnessMap:ee,dispersion:Lt,retroreflection:fe,iridescence:pt,iridescenceMap:K,iridescenceThicknessMap:oe,sheen:Oe,sheenColorMap:le,sheenRoughnessMap:G,specularMap:Y,specularColorMap:ae,specularIntensityMap:P,transmission:Ve,transmissionMap:X,thicknessMap:z,gradientMap:ie,opaque:_.transparent===!1&&_.blending===wr&&_.alphaToCoverage===!1,alphaMap:se,alphaTest:de,alphaHash:Le,combine:_.combine,mapUv:Be&&f(_.map.channel),aoMapUv:Mt&&f(_.aoMap.channel),lightMapUv:sn&&f(_.lightMap.channel),bumpMapUv:un&&f(_.bumpMap.channel),normalMapUv:Et&&f(_.normalMap.channel),displacementMapUv:Vt&&f(_.displacementMap.channel),emissiveMapUv:rn&&f(_.emissiveMap.channel),metalnessMapUv:on&&f(_.metalnessMap.channel),roughnessMapUv:Sn&&f(_.roughnessMap.channel),anisotropyMapUv:kt&&f(_.anisotropyMap.channel),clearcoatMapUv:b&&f(_.clearcoatMap.channel),clearcoatNormalMapUv:M&&f(_.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:U&&f(_.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:ee&&f(_.diffuseRoughnessMap.channel),iridescenceMapUv:K&&f(_.iridescenceMap.channel),iridescenceThicknessMapUv:oe&&f(_.iridescenceThicknessMap.channel),sheenColorMapUv:le&&f(_.sheenColorMap.channel),sheenRoughnessMapUv:G&&f(_.sheenRoughnessMap.channel),specularMapUv:Y&&f(_.specularMap.channel),specularColorMapUv:ae&&f(_.specularColorMap.channel),specularIntensityMapUv:P&&f(_.specularIntensityMap.channel),transmissionMapUv:X&&f(_.transmissionMap.channel),thicknessMapUv:z&&f(_.thicknessMap.channel),alphaMapUv:se&&f(_.alphaMap.channel),vertexTangents:!!C.attributes.tangent&&(Et||D),vertexNormals:!!C.attributes.normal,vertexColors:_.vertexColors,vertexAlphas:_.vertexColors===!0&&!!C.attributes.color&&C.attributes.color.itemSize===4,pointsUvs:N.isPoints===!0&&!!C.attributes.uv&&(Be||se),fog:!!Q,useFog:_.fog===!0,fogExp2:!!Q&&Q.isFogExp2,flatShading:_.wireframe===!1&&(_.flatShading===!0||C.attributes.normal===void 0&&Et===!1&&(_.isMeshLambertMaterial||_.isMeshPhongMaterial||_.isMeshStandardMaterial||_.isMeshPhysicalMaterial)),sizeAttenuation:_.sizeAttenuation===!0,logarithmicDepthBuffer:h,reversedDepthBuffer:_e,skinning:N.isSkinnedMesh===!0,hasPositionAttribute:C.attributes.position!==void 0,morphTargets:C.morphAttributes.position!==void 0,morphNormals:C.morphAttributes.normal!==void 0,morphColors:C.morphAttributes.color!==void 0,morphTargetsCount:ne,morphTextureStride:Me,numSunLights:E.sun.length,numDirLights:E.directional.length,numPointLights:E.point.length,numSpotLights:E.spot.length,numSpotLightMaps:E.spotLightMap.length,numRectAreaLights:E.rectArea.length,numHemiLights:E.hemi.length,numSunLightShadows:E.sunShadowMap.length,numDirLightShadows:E.directionalShadowMap.length,numPointLightShadows:E.pointShadowMap.length,numSpotLightShadows:E.spotShadowMap.length,numSpotLightShadowsWithMaps:E.numSpotLightShadowsWithMaps,numLightProbes:E.numLightProbes,numLightProbeGrids:V.filter((me)=>me.texture!==null).length,numClippingPlanes:r.numPlanes,numClipIntersection:r.numIntersection,dithering:_.dithering,shadowMapEnabled:e.shadowMap.enabled&&I.length>0,shadowMapType:e.shadowMap.type,toneMapping:pe,decodeVideoTexture:Be&&_.map.isVideoTexture===!0&&qe.getTransfer(_.map.colorSpace)===ft,decodeVideoTextureEmissive:rn&&_.emissiveMap.isVideoTexture===!0&&qe.getTransfer(_.emissiveMap.colorSpace)===ft,premultipliedAlpha:_.premultipliedAlpha,doubleSided:_.side===en,flipSided:_.side===qt,useDepthPacking:_.depthPacking>=0,depthPacking:_.depthPacking||0,index0AttributeName:_.index0AttributeName,extensionClipCullDistance:Ae&&_.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ae&&_.extensions.multiDraw===!0||We)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:_.customProgramCacheKey()};return ze.vertexUv1s=l.has(1),ze.vertexUv2s=l.has(2),ze.vertexUv3s=l.has(3),l.clear(),ze}function x(_){let E=[];if(_.shaderID)E.push(_.shaderID);else E.push(_.customVertexShaderID),E.push(_.customFragmentShaderID);if(_.defines!==void 0)for(let I in _.defines)E.push(I),E.push(_.defines[I]);if(_.isRawShaderMaterial===!1)p(E,_),g(E,_),E.push(e.outputColorSpace);return E.push(_.customProgramCacheKey),E.join()}function p(_,E){_.push(E.precision),_.push(E.outputColorSpace),_.push(E.envMapMode),_.push(E.envMapPMREM),_.push(E.envMapMaxLod),_.push(E.envMapSize),_.push(E.mapUv),_.push(E.alphaMapUv),_.push(E.lightMapUv),_.push(E.aoMapUv),_.push(E.bumpMapUv),_.push(E.normalMapUv),_.push(E.displacementMapUv),_.push(E.emissiveMapUv),_.push(E.metalnessMapUv),_.push(E.roughnessMapUv),_.push(E.anisotropyMapUv),_.push(E.clearcoatMapUv),_.push(E.clearcoatNormalMapUv),_.push(E.clearcoatRoughnessMapUv),_.push(E.diffuseRoughnessMapUv),_.push(E.iridescenceMapUv),_.push(E.iridescenceThicknessMapUv),_.push(E.sheenColorMapUv),_.push(E.sheenRoughnessMapUv),_.push(E.specularMapUv),_.push(E.specularColorMapUv),_.push(E.specularIntensityMapUv),_.push(E.transmissionMapUv),_.push(E.thicknessMapUv),_.push(E.combine),_.push(E.fogExp2),_.push(E.sizeAttenuation),_.push(E.morphTargetsCount),_.push(E.numSunLights),_.push(E.numDirLights),_.push(E.numPointLights),_.push(E.numSpotLights),_.push(E.numSpotLightMaps),_.push(E.numHemiLights),_.push(E.numRectAreaLights),_.push(E.numSunLightShadows),_.push(E.numDirLightShadows),_.push(E.numPointLightShadows),_.push(E.numSpotLightShadows),_.push(E.numSpotLightShadowsWithMaps),_.push(E.numLightProbes),_.push(E.numLightProbeGrids),_.push(E.shadowMapType),_.push(E.toneMapping),_.push(E.numClippingPlanes),_.push(E.numClipIntersection),_.push(E.depthPacking)}function g(_,E){if(o.disableAll(),E.instancing)o.enable(0);if(E.instancingColor)o.enable(1);if(E.instancingMorph)o.enable(2);if(E.matcap)o.enable(3);if(E.envMap)o.enable(4);if(E.normalMapObjectSpace)o.enable(5);if(E.normalMapTangentSpace)o.enable(6);if(E.clearcoat)o.enable(7);if(E.iridescence)o.enable(8);if(E.alphaTest)o.enable(9);if(E.vertexColors)o.enable(10);if(E.vertexAlphas)o.enable(11);if(E.vertexUv1s)o.enable(12);if(E.vertexUv2s)o.enable(13);if(E.vertexUv3s)o.enable(14);if(E.vertexTangents)o.enable(15);if(E.anisotropy)o.enable(16);if(E.alphaHash)o.enable(17);if(E.batching)o.enable(18);if(E.dispersion)o.enable(19);if(E.retroreflection)o.enable(24);if(E.diffuseRoughness)o.enable(25);if(E.batchingColor)o.enable(20);if(E.gradientMap)o.enable(21);if(E.packedNormalMap)o.enable(22);if(E.vertexNormals)o.enable(23);if(_.push(o.mask),o.disableAll(),E.fog)o.enable(0);if(E.useFog)o.enable(1);if(E.flatShading)o.enable(2);if(E.logarithmicDepthBuffer)o.enable(3);if(E.reversedDepthBuffer)o.enable(4);if(E.skinning)o.enable(5);if(E.morphTargets)o.enable(6);if(E.morphNormals)o.enable(7);if(E.morphColors)o.enable(8);if(E.premultipliedAlpha)o.enable(9);if(E.shadowMapEnabled)o.enable(10);if(E.doubleSided)o.enable(11);if(E.flipSided)o.enable(12);if(E.useDepthPacking)o.enable(13);if(E.dithering)o.enable(14);if(E.transmission)o.enable(15);if(E.sheen)o.enable(16);if(E.opaque)o.enable(17);if(E.pointsUvs)o.enable(18);if(E.decodeVideoTexture)o.enable(19);if(E.decodeVideoTextureEmissive)o.enable(20);if(E.alphaToCoverage)o.enable(21);if(E.numLightProbeGrids>0)o.enable(22);if(E.hasPositionAttribute)o.enable(23);_.push(o.mask)}function v(_){let E=d[_.type],I;if(E){let k=Xn[E];I=Ea.clone(k.uniforms)}else I=_.uniforms;return I}function S(_,E){let I=u.get(E);if(I!==void 0)++I.usedTimes;else I=new BM(e,E,_,s),c.push(I),u.set(E,I);return I}function T(_){if(--_.usedTimes===0){let E=c.indexOf(_);c[E]=c[c.length-1],c.pop(),u.delete(_.cacheKey),_.destroy()}}function A(_){a.remove(_)}function w(){a.dispose()}return{getParameters:m,getProgramCacheKey:x,getUniforms:v,acquireProgram:S,releaseProgram:T,releaseShaderCache:A,programs:c,dispose:w}}function zM(){let e=new WeakMap;function t(o){return e.has(o)}function n(o){let a=e.get(o);if(a===void 0)a={},e.set(o,a);return a}function i(o){e.delete(o)}function s(o,a,l){e.get(o)[a]=l}function r(){e=new WeakMap}return{has:t,get:n,remove:i,update:s,dispose:r}}function WM(e,t){if(e.groupOrder!==t.groupOrder)return e.groupOrder-t.groupOrder;else if(e.renderOrder!==t.renderOrder)return e.renderOrder-t.renderOrder;else if(e.material.id!==t.material.id)return e.material.id-t.material.id;else if(e.materialVariant!==t.materialVariant)return e.materialVariant-t.materialVariant;else if(e.z!==t.z)return e.z-t.z;else return e.id-t.id}function wf(e,t){if(e.groupOrder!==t.groupOrder)return e.groupOrder-t.groupOrder;else if(e.renderOrder!==t.renderOrder)return e.renderOrder-t.renderOrder;else if(e.z!==t.z)return t.z-e.z;else return e.id-t.id}function Cf(){let e=[],t=0,n=[],i=[],s=[];function r(){t=0,n.length=0,i.length=0,s.length=0}function o(d){let f=0;if(d.isInstancedMesh)f+=2;if(d.isSkinnedMesh)f+=1;return f}function a(d,f,m,x,p,g){let v=e[t];if(v===void 0)v={id:d.id,object:d,geometry:f,material:m,materialVariant:o(d),groupOrder:x,renderOrder:d.renderOrder,z:p,group:g},e[t]=v;else v.id=d.id,v.object=d,v.geometry=f,v.material=m,v.materialVariant=o(d),v.groupOrder=x,v.renderOrder=d.renderOrder,v.z=p,v.group=g;return t++,v}function l(d,f,m,x,p,g,v){if(v.reversedDepth===!0)p=-p;let S=a(d,f,m,x,p,g);if(m.transmission>0)i.push(S);else if(m.transparent===!0)s.push(S);else n.push(S)}function c(d,f,m,x,p,g){let v=a(d,f,m,x,p,g);if(m.transmission>0)i.unshift(v);else if(m.transparent===!0)s.unshift(v);else n.unshift(v)}function u(d,f){if(n.length>1)n.sort(d||WM);if(i.length>1)i.sort(f||wf);if(s.length>1)s.sort(f||wf)}function h(){for(let d=t,f=e.length;d<f;d++){let m=e[d];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:n,transmissive:i,transparent:s,init:r,push:l,unshift:c,finish:h,sort:u}}function XM(){let e=new WeakMap;function t(i,s){let r=e.get(i),o;if(r===void 0)o=new Cf,e.set(i,[o]);else if(s>=r.length)o=new Cf,r.push(o);else o=r[s];return o}function n(){e=new WeakMap}return{get:t,dispose:n}}function qM(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case"SunLight":case"DirectionalLight":n={direction:new R,color:new xe};break;case"SpotLight":n={position:new R,direction:new R,color:new xe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new R,color:new xe,distance:0,decay:0};break;case"HemisphereLight":n={direction:new R,skyColor:new xe,groundColor:new xe};break;case"RectAreaLight":n={color:new xe,position:new R,halfWidth:new R,halfHeight:new R};break}return e[t.id]=n,n}}}function YM(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case"SunLight":case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce,shadowCameraNear:1,shadowCameraFar:1000};break}return e[t.id]=n,n}}}var ZM=0;function jM(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+(t.map?1:0)-(e.map?1:0)}function JM(e){let t=new qM,n=YM(),i={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)i.probe.push(new R);let s=new R,r=new Re,o=new Re;function a(c){let u=0,h=0,d=0;for(let V=0;V<9;V++)i.probe[V].set(0,0,0);let f=0,m=0,x=0,p=0,g=0,v=0,S=0,T=0,A=0,w=0,_=0,E=0,I=0,k=0;c.sort(jM);for(let V=0,Q=c.length;V<Q;V++){let C=c[V],{color:q,intensity:j,distance:F}=C,re=null;if(C.shadow&&C.shadow.map)if(C.shadow.map.texture.format===is)re=C.shadow.map.texture;else re=C.shadow.map.depthTexture||C.shadow.map.texture;if(C.isAmbientLight)u+=q.r*j,h+=q.g*j,d+=q.b*j;else if(C.isLightProbe){for(let W=0;W<9;W++)i.probe[W].addScaledVector(C.sh.coefficients[W],j);k++}else if(C.isSunLight){let W=t.get(C);if(W.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){let J=C.shadow,ne=n.get(C);ne.shadowIntensity=J.intensity,ne.shadowBias=J.bias,ne.shadowNormalBias=J.normalBias,ne.shadowRadius=J.radius,ne.shadowMapSize.copy(J.mapSize).multiply(J.getFrameExtents()),i.sunShadow[m]=ne,i.sunShadowMap[m]=re;let Me=J.getViewportCount();for(let Z=0;Z<Me;Z++)i.sunShadowMatrix[x+Z]=J.getMatrix(Z),i.sunShadowCascade[x+Z]=J._cascadeData[Z];x+=Me,m++}i.sun[f]=W,f++}else if(C.isDirectionalLight){let W=t.get(C);if(W.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){let J=C.shadow,ne=n.get(C);ne.shadowIntensity=J.intensity,ne.shadowBias=J.bias,ne.shadowNormalBias=J.normalBias,ne.shadowRadius=J.radius,ne.shadowMapSize=J.mapSize,i.directionalShadow[p]=ne,i.directionalShadowMap[p]=re,i.directionalShadowMatrix[p]=C.shadow.matrix,A++}i.directional[p]=W,p++}else if(C.isSpotLight){let W=t.get(C);W.position.setFromMatrixPosition(C.matrixWorld),W.color.copy(q).multiplyScalar(j),W.distance=F,W.coneCos=Math.cos(C.angle),W.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),W.decay=C.decay,i.spot[v]=W;let J=C.shadow;if(C.map){if(i.spotLightMap[E]=C.map,E++,J.updateMatrices(C),C.castShadow)I++}if(i.spotLightMatrix[v]=J.matrix,C.castShadow){let ne=n.get(C);ne.shadowIntensity=J.intensity,ne.shadowBias=J.bias,ne.shadowNormalBias=J.normalBias,ne.shadowRadius=J.radius,ne.shadowMapSize=J.mapSize,i.spotShadow[v]=ne,i.spotShadowMap[v]=re,_++}v++}else if(C.isRectAreaLight){let W=t.get(C);W.color.copy(q).multiplyScalar(j),W.halfWidth.set(C.width*0.5,0,0),W.halfHeight.set(0,C.height*0.5,0),i.rectArea[S]=W,S++}else if(C.isPointLight){let W=t.get(C);if(W.color.copy(C.color).multiplyScalar(C.intensity),W.distance=C.distance,W.decay=C.decay,C.castShadow){let J=C.shadow,ne=n.get(C);ne.shadowIntensity=J.intensity,ne.shadowBias=J.bias,ne.shadowNormalBias=J.normalBias,ne.shadowRadius=J.radius,ne.shadowMapSize=J.mapSize,ne.shadowCameraNear=J.camera.near,ne.shadowCameraFar=J.camera.far,i.pointShadow[g]=ne,i.pointShadowMap[g]=re,i.pointShadowMatrix[g]=C.shadow.matrix,w++}i.point[g]=W,g++}else if(C.isHemisphereLight){let W=t.get(C);W.skyColor.copy(C.color).multiplyScalar(j),W.groundColor.copy(C.groundColor).multiplyScalar(j),i.hemi[T]=W,T++}}if(S>0)if(e.has("OES_texture_float_linear")===!0)i.rectAreaLTC1=he.LTC_FLOAT_1,i.rectAreaLTC2=he.LTC_FLOAT_2;else i.rectAreaLTC1=he.LTC_HALF_1,i.rectAreaLTC2=he.LTC_HALF_2;i.ambient[0]=u,i.ambient[1]=h,i.ambient[2]=d;let N=i.hash;if(N.sunLength!==f||N.directionalLength!==p||N.pointLength!==g||N.spotLength!==v||N.rectAreaLength!==S||N.hemiLength!==T||N.numSunShadows!==m||N.numDirectionalShadows!==A||N.numPointShadows!==w||N.numSpotShadows!==_||N.numSpotMaps!==E||N.numLightProbes!==k)i.sun.length=f,i.directional.length=p,i.spot.length=v,i.rectArea.length=S,i.point.length=g,i.hemi.length=T,i.sunShadow.length=m,i.sunShadowMap.length=m,i.sunShadowMatrix.length=x,i.sunShadowCascade.length=x,i.directionalShadow.length=A,i.directionalShadowMap.length=A,i.directionalShadowMatrix.length=A,i.pointShadow.length=w,i.pointShadowMap.length=w,i.pointShadowMatrix.length=w,i.spotShadow.length=_,i.spotShadowMap.length=_,i.spotLightMatrix.length=_+E-I,i.spotLightMap.length=E,i.numSpotLightShadowsWithMaps=I,i.numLightProbes=k,N.sunLength=f,N.directionalLength=p,N.pointLength=g,N.spotLength=v,N.rectAreaLength=S,N.hemiLength=T,N.numSunShadows=m,N.numDirectionalShadows=A,N.numPointShadows=w,N.numSpotShadows=_,N.numSpotMaps=E,N.numLightProbes=k,i.version=ZM++}function l(c,u){let h=0,d=0,f=0,m=0,x=0,p=0,g=u.matrixWorldInverse;for(let v=0,S=c.length;v<S;v++){let T=c[v];if(T.isSunLight){let A=i.sun[h];A.direction.setFromMatrixPosition(T.matrixWorld),A.direction.transformDirection(g),h++}else if(T.isDirectionalLight){let A=i.directional[d];A.direction.setFromMatrixPosition(T.matrixWorld),s.setFromMatrixPosition(T.target.matrixWorld),A.direction.sub(s),A.direction.transformDirection(g),d++}else if(T.isSpotLight){let A=i.spot[m];A.position.setFromMatrixPosition(T.matrixWorld),A.position.applyMatrix4(g),A.direction.setFromMatrixPosition(T.matrixWorld),s.setFromMatrixPosition(T.target.matrixWorld),A.direction.sub(s),A.direction.transformDirection(g),m++}else if(T.isRectAreaLight){let A=i.rectArea[x];A.position.setFromMatrixPosition(T.matrixWorld),A.position.applyMatrix4(g),o.identity(),r.copy(T.matrixWorld),r.premultiply(g),o.extractRotation(r),A.halfWidth.set(T.width*0.5,0,0),A.halfHeight.set(0,T.height*0.5,0),A.halfWidth.applyMatrix4(o),A.halfHeight.applyMatrix4(o),x++}else if(T.isPointLight){let A=i.point[f];A.position.setFromMatrixPosition(T.matrixWorld),A.position.applyMatrix4(g),f++}else if(T.isHemisphereLight){let A=i.hemi[p];A.direction.setFromMatrixPosition(T.matrixWorld),A.direction.transformDirection(g),p++}}}return{setup:a,setupView:l,state:i}}function Pf(e){let t=new JM(e),n=[],i=[],s=[];function r(h){u.camera=h,n.length=0,i.length=0,s.length=0}function o(h){if(h.isLightProbeGrid)s.push(h);else n.push(h)}function a(h){i.push(h)}function l(){t.setup(n),s.sort((h,d)=>h.priority-d.priority||h.id-d.id)}function c(h){t.setupView(n,h)}let u={lightsArray:n,shadowsArray:i,lightProbeGridArray:s,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:r,state:u,setupLights:l,setupLightsView:c,pushLight:o,pushShadow:a}}function KM(e){let t=new WeakMap;function n(s,r=0){let o=t.get(s),a;if(o===void 0)a=new Pf(e),t.set(s,[a]);else if(r>=o.length)a=new Pf(e),o.push(a);else a=o[r];return a}function i(){t=new WeakMap}return{get:n,dispose:i}}var $M=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,QM=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,ey=[new R(1,0,0),new R(-1,0,0),new R(0,1,0),new R(0,-1,0),new R(0,0,1),new R(0,0,-1)],ty=[new R(0,-1,0),new R(0,-1,0),new R(0,0,1),new R(0,0,-1),new R(0,-1,0),new R(0,-1,0)],Lf=new Re,Wr=new R,fu=new R;function ny(e,t,n){let i=new Qi,s=new Ce,r=new Ce,o=new ut,a=new eu,l=new tu,c={},u=n.maxTextureSize,h={[Si]:qt,[qt]:Si,[en]:en},d=new On({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ce},radius:{value:4}},vertexShader:$M,fragmentShader:QM}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let m=new Qe;m.setAttribute("position",new Ge(new Float32Array([-1,-1,0.5,3,-1,0.5,-1,3,0.5]),3));let x=new bt(m,d),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ar;let g=this.type;this.render=function(w,_,E){if(p.enabled===!1)return;if(p.autoUpdate===!1&&p.needsUpdate===!1)return;if(w.length===0)return;if(this.type===ad)we("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Ar;let I=e.getRenderTarget(),k=e.getActiveCubeFace(),N=e.getActiveMipmapLevel(),V=e.state;if(V.setBlending(es),V.buffers.depth.getReversed()===!0)V.buffers.color.setClear(0,0,0,0);else V.buffers.color.setClear(1,1,1,1);V.buffers.depth.setTest(!0),V.setScissorTest(!1);let Q=g!==this.type;if(Q)_.traverse(function(C){if(C.material)if(Array.isArray(C.material))C.material.forEach((q)=>q.needsUpdate=!0);else C.material.needsUpdate=!0});for(let C=0,q=w.length;C<q;C++){let j=w[C],F=j.shadow;if(F===void 0){we("WebGLShadowMap:",j,"has no shadow.");continue}if(F.autoUpdate===!1&&F.needsUpdate===!1)continue;s.copy(F.mapSize);let re=F.getFrameExtents();if(s.multiply(re),r.copy(F.mapSize),s.x>u||s.y>u){if(s.x>u)r.x=Math.floor(u/re.x),s.x=r.x*re.x,F.mapSize.x=r.x;if(s.y>u)r.y=Math.floor(u/re.y),s.y=r.y*re.y,F.mapSize.y=r.y}let W=e.state.buffers.depth.getReversed();if(F.camera._reversedDepth=W,F.map===null||Q===!0){if(F.map!==null){if(F.map.depthTexture!==null)F.map.depthTexture.dispose(),F.map.depthTexture=null;F.map.dispose()}if(this.type===Ds){if(j.isPointLight){we("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}F.map=new Mn(s.x,s.y,{format:is,type:kn,minFilter:Yt,magFilter:Yt,generateMipmaps:!1}),F.map.texture.name=j.name+".shadowMap",F.map.depthTexture=new Pi(s.x,s.y,li),F.map.depthTexture.name=j.name+".shadowMapDepth",F.map.depthTexture.format=Vs,F.map.depthTexture.compareFunction=null,F.map.depthTexture.minFilter=Pn,F.map.depthTexture.magFilter=Pn}else{if(j.isPointLight)F.map=new Oa(s.x),F.map.depthTexture=new ya(s.x,bi);else F.map=new Mn(s.x,s.y),F.map.depthTexture=new Pi(s.x,s.y,bi);if(F.map.depthTexture.name=j.name+".shadowMap",F.map.depthTexture.format=Vs,this.type===Ar)F.map.depthTexture.compareFunction=W?Vc:Bc,F.map.depthTexture.minFilter=Yt,F.map.depthTexture.magFilter=Yt;else F.map.depthTexture.compareFunction=null,F.map.depthTexture.minFilter=Pn,F.map.depthTexture.magFilter=Pn}F.camera.updateProjectionMatrix()}if(F.map.isWebGLCubeRenderTarget!==!0&&(F.map.width!==s.x||F.map.height!==s.y))F.map.setSize(s.x,s.y);let J=F.map.isWebGLCubeRenderTarget?6:F.getViewportCount();if(j.isPointLight!==!0)F.updateMatrices(j,E);let ne=(F.camera.layers.mask&4294967294)!==0?F.camera.layers:E.layers;for(let Me=0;Me<J;Me++){let Z=F.getCamera(Me);if(j.isPointLight){let{camera:te,matrix:ye}=F,Ne=j.distance||te.far;if(Ne!==te.far)te.far=Ne,te.updateProjectionMatrix();Wr.setFromMatrixPosition(j.matrixWorld),te.position.copy(Wr),fu.copy(te.position),fu.add(ey[Me]),te.up.copy(ty[Me]),te.lookAt(fu),te.updateMatrixWorld(),ye.makeTranslation(-Wr.x,-Wr.y,-Wr.z),Lf.multiplyMatrices(te.projectionMatrix,te.matrixWorldInverse),F._frustum.setFromProjectionMatrix(Lf,te.coordinateSystem,te.reversedDepth)}if(F.map.isWebGLCubeRenderTarget)e.setRenderTarget(F.map,Me),e.clear();else{if(Me===0)e.setRenderTarget(F.map),e.clear();let te=F.getViewport(Me);o.set(r.x*te.x,r.y*te.y,r.x*te.z,r.y*te.w),V.viewport(o)}i=F.getFrustum(Me),T(_,E,Z,j,ne,this.type)}if(F.isPointLightShadow!==!0&&this.type===Ds)v(F,E);F.needsUpdate=!1}g=this.type,p.needsUpdate=!1,e.setRenderTarget(I,k,N)};function v(w,_){let E=t.update(x);if(d.defines.VSM_SAMPLES!==w.blurSamples)d.defines.VSM_SAMPLES=w.blurSamples,f.defines.VSM_SAMPLES=w.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0;if(w.mapPass===null)w.mapPass=new Mn(s.x,s.y,{format:is,type:kn});else if(w.mapPass.width!==w.map.width||w.mapPass.height!==w.map.height)w.mapPass.setSize(w.map.width,w.map.height);d.uniforms.shadow_pass.value=w.map.depthTexture,d.uniforms.resolution.value.set(w.map.width,w.map.height),d.uniforms.radius.value=w.radius,e.setRenderTarget(w.mapPass),e.clear(),e.renderBufferDirect(_,null,E,d,x,null),f.uniforms.shadow_pass.value=w.mapPass.texture,f.uniforms.resolution.value.set(w.map.width,w.map.height),f.uniforms.radius.value=w.radius,e.setRenderTarget(w.map),e.clear(),e.renderBufferDirect(_,null,E,f,x,null)}function S(w,_,E,I){let k=null,N=E.isPointLight===!0?w.customDistanceMaterial:w.customDepthMaterial;if(N!==void 0)k=N;else if(k=E.isPointLight===!0?l:a,e.localClippingEnabled&&_.clipShadows===!0&&Array.isArray(_.clippingPlanes)&&_.clippingPlanes.length!==0||_.displacementMap&&_.displacementScale!==0||_.alphaMap&&_.alphaTest>0||_.map&&_.alphaTest>0||_.alphaToCoverage===!0){let V=k.uuid,Q=_.uuid,C=c[V];if(C===void 0)C={},c[V]=C;let q=C[Q];if(q===void 0)q=k.clone(),C[Q]=q,_.addEventListener("dispose",A);k=q}if(k.visible=_.visible,k.wireframe=_.wireframe,I===Ds)k.side=_.shadowSide!==null?_.shadowSide:_.side;else k.side=_.shadowSide!==null?_.shadowSide:h[_.side];if(k.alphaMap=_.alphaMap,k.alphaTest=_.alphaToCoverage===!0?0.5:_.alphaTest,k.map=_.map,k.clipShadows=_.clipShadows,k.clippingPlanes=_.clippingPlanes,k.clipIntersection=_.clipIntersection,k.displacementMap=_.displacementMap,k.displacementScale=_.displacementScale,k.displacementBias=_.displacementBias,k.wireframeLinewidth=_.wireframeLinewidth,k.linewidth=_.linewidth,E.isPointLight===!0&&k.isMeshDistanceMaterial===!0){let V=e.properties.get(k);V.light=E}return k}function T(w,_,E,I,k,N){if(w.visible===!1)return;if(w.layers.test(k)&&(w.isMesh||w.isLine||w.isPoints)){if((w.castShadow||w.receiveShadow&&N===Ds)&&(!w.frustumCulled||w.intersectsFrustum(i))){w.modelViewMatrix.multiplyMatrices(E.matrixWorldInverse,w.matrixWorld);let C=t.update(w),q=w.material;if(Array.isArray(q)){let j=C.groups;for(let F=0,re=j.length;F<re;F++){let W=j[F],J=q[W.materialIndex];if(J&&J.visible){let ne=S(w,J,I,N);w.onBeforeShadow(e,w,_,E,C,ne,W),e.renderBufferDirect(E,null,C,ne,w,W),w.onAfterShadow(e,w,_,E,C,ne,W)}}}else if(q.visible){let j=S(w,q,I,N);w.onBeforeShadow(e,w,_,E,C,j,null),e.renderBufferDirect(E,null,C,j,w,null),w.onAfterShadow(e,w,_,E,C,j,null)}}}let Q=w.children;for(let C=0,q=Q.length;C<q;C++)T(Q[C],_,E,I,k,N)}function A(w){w.target.removeEventListener("dispose",A);for(let E in c){let I=c[E],k=w.target.uuid;if(k in I)I[k].dispose(),delete I[k]}}}function iy(e,t){function n(){let P=!1,X=new ut,z=null,ie=new ut(0,0,0,0);return{setMask:function(se){if(z!==se&&!P)e.colorMask(se,se,se,se),z=se},setLocked:function(se){P=se},setClear:function(se,de,Le,Ae,pe){if(pe===!0)se*=Ae,de*=Ae,Le*=Ae;if(X.set(se,de,Le,Ae),ie.equals(X)===!1)e.clearColor(se,de,Le,Ae),ie.copy(X)},reset:function(){P=!1,z=null,ie.set(-1,0,0,0)}}}function i(){let P=!1,X=!1,z=null,ie=null,se=null;return{setReversed:function(de){if(X!==de){let Le=t.get("EXT_clip_control");if(de)Le.clipControlEXT(Le.LOWER_LEFT_EXT,Le.ZERO_TO_ONE_EXT);else Le.clipControlEXT(Le.LOWER_LEFT_EXT,Le.NEGATIVE_ONE_TO_ONE_EXT);X=de;let Ae=se;se=null,this.setClear(Ae)}},getReversed:function(){return X},setTest:function(de){if(de)_e(e.DEPTH_TEST);else it(e.DEPTH_TEST)},setMask:function(de){if(z!==de&&!P)e.depthMask(de),z=de},setFunc:function(de){if(X)de=ef[de];if(ie!==de){switch(de){case wd:e.depthFunc(e.NEVER);break;case Cd:e.depthFunc(e.ALWAYS);break;case Pd:e.depthFunc(e.LESS);break;case ql:e.depthFunc(e.LEQUAL);break;case Ld:e.depthFunc(e.EQUAL);break;case Id:e.depthFunc(e.GEQUAL);break;case Nd:e.depthFunc(e.GREATER);break;case Dd:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}ie=de}},setLocked:function(de){P=de},setClear:function(de){if(se!==de){if(se=de,X)de=1-de;e.clearDepth(de)}},reset:function(){P=!1,z=null,ie=null,se=null,X=!1}}}function s(){let P=!1,X=null,z=null,ie=null,se=null,de=null,Le=null,Ae=null,pe=null;return{setTest:function(Ie){if(!P)if(Ie)_e(e.STENCIL_TEST);else it(e.STENCIL_TEST)},setMask:function(Ie){if(X!==Ie&&!P)e.stencilMask(Ie),X=Ie},setFunc:function(Ie,ze,me){if(z!==Ie||ie!==ze||se!==me)e.stencilFunc(Ie,ze,me),z=Ie,ie=ze,se=me},setOp:function(Ie,ze,me){if(de!==Ie||Le!==ze||Ae!==me)e.stencilOp(Ie,ze,me),de=Ie,Le=ze,Ae=me},setLocked:function(Ie){P=Ie},setClear:function(Ie){if(pe!==Ie)e.clearStencil(Ie),pe=Ie},reset:function(){P=!1,X=null,z=null,ie=null,se=null,de=null,Le=null,Ae=null,pe=null}}}let r=new n,o=new i,a=new s,l={},c=new WeakMap,u={},h={},d={},f=new WeakMap,m=[],x=null,p=!1,g=null,v=null,S=null,T=null,A=null,w=null,_=null,E=new xe(0,0,0),I=0,k=!1,N=null,V=null,Q=null,C=null,q=null,j=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),F=!1,re=0,W=e.getParameter(e.VERSION);if(W.indexOf("WebGL")!==-1)re=parseFloat(/^WebGL (\d)/.exec(W)[1]),F=re>=1;else if(W.indexOf("OpenGL ES")!==-1)re=parseFloat(/^OpenGL ES (\d)/.exec(W)[1]),F=re>=2;let J=null,ne={},Me=e.getParameter(e.SCISSOR_BOX),Z=e.getParameter(e.VIEWPORT),te=new ut().fromArray(Me),ye=new ut().fromArray(Z);function Ne(P,X,z,ie){let se=new Uint8Array(4),de=e.createTexture();e.bindTexture(P,de),e.texParameteri(P,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(P,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let Le=0;Le<z;Le++)if(P===e.TEXTURE_3D||P===e.TEXTURE_2D_ARRAY)e.texImage3D(X,0,e.RGBA,1,1,ie,0,e.RGBA,e.UNSIGNED_BYTE,se);else e.texImage2D(X+Le,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,se);return de}let De={};De[e.TEXTURE_2D]=Ne(e.TEXTURE_2D,e.TEXTURE_2D,1),De[e.TEXTURE_CUBE_MAP]=Ne(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),De[e.TEXTURE_2D_ARRAY]=Ne(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),De[e.TEXTURE_3D]=Ne(e.TEXTURE_3D,e.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),_e(e.DEPTH_TEST),o.setFunc(ql),un(!1),Et(Gl),_e(e.CULL_FACE),Mt(es);function _e(P){if(u[P]!==!0)e.enable(P),u[P]=!0}function it(P){if(u[P]!==!1)e.disable(P),u[P]=!1}function We(P,X){if(d[P]!==X){if(e.bindFramebuffer(P,X),d[P]=X,P===e.DRAW_FRAMEBUFFER)d[e.FRAMEBUFFER]=X;if(P===e.FRAMEBUFFER)d[e.DRAW_FRAMEBUFFER]=X;return!0}return!1}function Be(P,X){let z=m,ie=!1;if(P){if(z=f.get(X),z===void 0)z=[],f.set(X,z);let se=P.textures;if(z.length!==se.length||z[0]!==e.COLOR_ATTACHMENT0){for(let de=0,Le=se.length;de<Le;de++)z[de]=e.COLOR_ATTACHMENT0+de;z.length=se.length,ie=!0}}else if(z[0]!==e.BACK)z[0]=e.BACK,ie=!0;if(ie)e.drawBuffers(z)}function ht(P){if(x!==P)return e.useProgram(P),x=P,!0;return!1}let et={[Us]:e.FUNC_ADD,[cd]:e.FUNC_SUBTRACT,[ud]:e.FUNC_REVERSE_SUBTRACT};et[hd]=e.MIN,et[dd]=e.MAX;let gt={[fd]:e.ZERO,[pd]:e.ONE,[md]:e.SRC_COLOR,[_d]:e.SRC_ALPHA,[Td]:e.SRC_ALPHA_SATURATE,[vd]:e.DST_COLOR,[Md]:e.DST_ALPHA,[gd]:e.ONE_MINUS_SRC_COLOR,[xd]:e.ONE_MINUS_SRC_ALPHA,[Ed]:e.ONE_MINUS_DST_COLOR,[yd]:e.ONE_MINUS_DST_ALPHA,[Sd]:e.CONSTANT_COLOR,[bd]:e.ONE_MINUS_CONSTANT_COLOR,[Rd]:e.CONSTANT_ALPHA,[Ad]:e.ONE_MINUS_CONSTANT_ALPHA};function Mt(P,X,z,ie,se,de,Le,Ae,pe,Ie){if(P===es){if(p===!0)it(e.BLEND),p=!1;return}if(p===!1)_e(e.BLEND),p=!0;if(P!==ld){if(P!==g||Ie!==k){if(v!==Us||A!==Us)e.blendEquation(e.FUNC_ADD),v=Us,A=Us;if(Ie)switch(P){case wr:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case zl:e.blendFunc(e.ONE,e.ONE);break;case Wl:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case Xl:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:He("WebGLState: Invalid blending: ",P);break}else switch(P){case wr:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case zl:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case Wl:He("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Xl:He("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:He("WebGLState: Invalid blending: ",P);break}S=null,T=null,w=null,_=null,E.set(0,0,0),I=0,g=P,k=Ie}return}if(se=se||X,de=de||z,Le=Le||ie,X!==v||se!==A)e.blendEquationSeparate(et[X],et[se]),v=X,A=se;if(z!==S||ie!==T||de!==w||Le!==_)e.blendFuncSeparate(gt[z],gt[ie],gt[de],gt[Le]),S=z,T=ie,w=de,_=Le;if(Ae.equals(E)===!1||pe!==I)e.blendColor(Ae.r,Ae.g,Ae.b,pe),E.copy(Ae),I=pe;g=P,k=!1}function sn(P,X){P.side===en?it(e.CULL_FACE):_e(e.CULL_FACE);let z=P.side===qt;if(X)z=!z;un(z),P.blending===wr&&P.transparent===!1?Mt(es):Mt(P.blending,P.blendEquation,P.blendSrc,P.blendDst,P.blendEquationAlpha,P.blendSrcAlpha,P.blendDstAlpha,P.blendColor,P.blendAlpha,P.premultipliedAlpha),o.setFunc(P.depthFunc),o.setTest(P.depthTest),o.setMask(P.depthWrite),r.setMask(P.colorWrite);let ie=P.stencilWrite;if(a.setTest(ie),ie)a.setMask(P.stencilWriteMask),a.setFunc(P.stencilFunc,P.stencilRef,P.stencilFuncMask),a.setOp(P.stencilFail,P.stencilZFail,P.stencilZPass);rn(P.polygonOffset,P.polygonOffsetFactor,P.polygonOffsetUnits),P.alphaToCoverage===!0?_e(e.SAMPLE_ALPHA_TO_COVERAGE):it(e.SAMPLE_ALPHA_TO_COVERAGE)}function un(P){if(N!==P){if(P)e.frontFace(e.CW);else e.frontFace(e.CCW);N=P}}function Et(P){if(P!==rd){if(_e(e.CULL_FACE),P!==V)if(P===Gl)e.cullFace(e.BACK);else if(P===od)e.cullFace(e.FRONT);else e.cullFace(e.FRONT_AND_BACK)}else it(e.CULL_FACE);V=P}function Vt(P){if(P!==Q){if(F)e.lineWidth(P);Q=P}}function rn(P,X,z){if(P){if(_e(e.POLYGON_OFFSET_FILL),C!==X||q!==z){if(C=X,q=z,o.getReversed())X=-X,z=-z;e.polygonOffset(X,z)}}else it(e.POLYGON_OFFSET_FILL)}function on(P){if(P)_e(e.SCISSOR_TEST);else it(e.SCISSOR_TEST)}function Sn(P){if(P===void 0)P=e.TEXTURE0+j-1;if(J!==P)e.activeTexture(P),J=P}function D(P,X,z){if(z===void 0)if(J===null)z=e.TEXTURE0+j-1;else z=J;let ie=ne[z];if(ie===void 0)ie={type:void 0,texture:void 0},ne[z]=ie;if(ie.type!==P||ie.texture!==X){if(J!==z)e.activeTexture(z),J=z;e.bindTexture(P,X||De[P]),ie.type=P,ie.texture=X}}function bn(){let P=ne[J];if(P!==void 0&&P.type!==void 0)e.bindTexture(P.type,null),P.type=void 0,P.texture=void 0}function lt(){try{e.compressedTexImage2D(...arguments)}catch(P){He("WebGLState:",P)}}function Lt(){try{e.compressedTexImage3D(...arguments)}catch(P){He("WebGLState:",P)}}function fe(){try{e.texSubImage2D(...arguments)}catch(P){He("WebGLState:",P)}}function pt(){try{e.texSubImage3D(...arguments)}catch(P){He("WebGLState:",P)}}function Oe(){try{e.compressedTexSubImage2D(...arguments)}catch(P){He("WebGLState:",P)}}function Ve(){try{e.compressedTexSubImage3D(...arguments)}catch(P){He("WebGLState:",P)}}function kt(){try{e.texStorage2D(...arguments)}catch(P){He("WebGLState:",P)}}function b(){try{e.texStorage3D(...arguments)}catch(P){He("WebGLState:",P)}}function M(){try{e.texImage2D(...arguments)}catch(P){He("WebGLState:",P)}}function U(){try{e.texImage3D(...arguments)}catch(P){He("WebGLState:",P)}}function ee(P){if(h[P]!==void 0)return h[P];else return e.getParameter(P)}function K(P,X){if(h[P]!==X)e.pixelStorei(P,X),h[P]=X}function oe(P){if(te.equals(P)===!1)e.scissor(P.x,P.y,P.z,P.w),te.copy(P)}function le(P){if(ye.equals(P)===!1)e.viewport(P.x,P.y,P.z,P.w),ye.copy(P)}function G(P,X){let z=c.get(X);if(z===void 0)z=new WeakMap,c.set(X,z);let ie=z.get(P);if(ie===void 0)ie=e.getUniformBlockIndex(X,P.name),e.uniformBlockBinding(X,ie,ie),z.set(P,ie)}function Y(P,X,z){let se=c.get(X).get(P);if(l[se]!==z)e.bindBufferBase(e.UNIFORM_BUFFER,se,z),l[se]=z}function ae(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),o.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),u={},h={},J=null,ne={},d={},l={},f=new WeakMap,m=[],x=null,p=!1,g=null,v=null,S=null,T=null,A=null,w=null,_=null,E=new xe(0,0,0),I=0,k=!1,N=null,V=null,Q=null,C=null,q=null,te.set(0,0,e.canvas.width,e.canvas.height),ye.set(0,0,e.canvas.width,e.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:_e,disable:it,bindFramebuffer:We,drawBuffers:Be,useProgram:ht,setBlending:Mt,setMaterial:sn,setFlipSided:un,setCullFace:Et,setLineWidth:Vt,setPolygonOffset:rn,setScissorTest:on,activeTexture:Sn,bindTexture:D,unbindTexture:bn,compressedTexImage2D:lt,compressedTexImage3D:Lt,texImage2D:M,texImage3D:U,pixelStorei:K,getParameter:ee,updateUBOMapping:G,uniformBlockBinding:Y,texStorage2D:kt,texStorage3D:b,texSubImage2D:fe,texSubImage3D:pt,compressedTexSubImage2D:Oe,compressedTexSubImage3D:Ve,scissor:oe,viewport:le,reset:ae}}function sy(e,t,n,i,s,r,o){let a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Ce,u=new WeakMap,h=new Set,d,f=new WeakMap,m=new Set,x=new FinalizationRegistry((b)=>m.delete(b)),p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch(b){}function g(b,M){return p?new OffscreenCanvas(b,M):Is("canvas")}function v(b,M,U){let ee=1,K=kt(b);if(K.width>U||K.height>U)ee=U/Math.max(K.width,K.height);if(ee<1)if(typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&b instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&b instanceof ImageBitmap||typeof VideoFrame<"u"&&b instanceof VideoFrame){let oe=Math.floor(ee*K.width),le=Math.floor(ee*K.height);if(d===void 0)d=g(oe,le);let G=M?g(oe,le):d;return G.width=oe,G.height=le,G.getContext("2d").drawImage(b,0,0,oe,le),we("WebGLRenderer: Texture has been resized from ("+K.width+"x"+K.height+") to ("+oe+"x"+le+")."),G}else{if("data"in b)we("WebGLRenderer: Image in DataTexture is too big ("+K.width+"x"+K.height+").");return b}return b}function S(b){return b.generateMipmaps}function T(b){e.generateMipmap(b)}function A(b){if(b.isWebGLCubeRenderTarget)return e.TEXTURE_CUBE_MAP;if(b.isWebGL3DRenderTarget)return e.TEXTURE_3D;if(b.isWebGLArrayRenderTarget||b.isCompressedArrayTexture)return e.TEXTURE_2D_ARRAY;return e.TEXTURE_2D}function w(b,M,U,ee,K,oe=!1){if(b!==null){if(e[b]!==void 0)return e[b];we("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+b+"'")}let le;if(ee){if(le=t.get("EXT_texture_norm16"),!le)we("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension")}let G=M;if(M===e.RED){if(U===e.FLOAT)G=e.R32F;if(U===e.HALF_FLOAT)G=e.R16F;if(U===e.UNSIGNED_BYTE)G=e.R8;if(U===e.UNSIGNED_SHORT&&le)G=le.R16_EXT;if(U===e.SHORT&&le)G=le.R16_SNORM_EXT}if(M===e.RED_INTEGER){if(U===e.UNSIGNED_BYTE)G=e.R8UI;if(U===e.UNSIGNED_SHORT)G=e.R16UI;if(U===e.UNSIGNED_INT)G=e.R32UI;if(U===e.BYTE)G=e.R8I;if(U===e.SHORT)G=e.R16I;if(U===e.INT)G=e.R32I}if(M===e.RG){if(U===e.FLOAT)G=e.RG32F;if(U===e.HALF_FLOAT)G=e.RG16F;if(U===e.UNSIGNED_BYTE)G=e.RG8;if(U===e.UNSIGNED_SHORT&&le)G=le.RG16_EXT;if(U===e.SHORT&&le)G=le.RG16_SNORM_EXT}if(M===e.RG_INTEGER){if(U===e.UNSIGNED_BYTE)G=e.RG8UI;if(U===e.UNSIGNED_SHORT)G=e.RG16UI;if(U===e.UNSIGNED_INT)G=e.RG32UI;if(U===e.BYTE)G=e.RG8I;if(U===e.SHORT)G=e.RG16I;if(U===e.INT)G=e.RG32I}if(M===e.RGB_INTEGER){if(U===e.UNSIGNED_BYTE)G=e.RGB8UI;if(U===e.UNSIGNED_SHORT)G=e.RGB16UI;if(U===e.UNSIGNED_INT)G=e.RGB32UI;if(U===e.BYTE)G=e.RGB8I;if(U===e.SHORT)G=e.RGB16I;if(U===e.INT)G=e.RGB32I}if(M===e.RGBA_INTEGER){if(U===e.UNSIGNED_BYTE)G=e.RGBA8UI;if(U===e.UNSIGNED_SHORT)G=e.RGBA16UI;if(U===e.UNSIGNED_INT)G=e.RGBA32UI;if(U===e.BYTE)G=e.RGBA8I;if(U===e.SHORT)G=e.RGBA16I;if(U===e.INT)G=e.RGBA32I}if(M===e.RGB){if(U===e.UNSIGNED_SHORT&&le)G=le.RGB16_EXT;if(U===e.SHORT&&le)G=le.RGB16_SNORM_EXT;if(U===e.UNSIGNED_INT_5_9_9_9_REV)G=e.RGB9_E5;if(U===e.UNSIGNED_INT_10F_11F_11F_REV)G=e.R11F_G11F_B10F}if(M===e.RGBA){let Y=oe?Hc:qe.getTransfer(K);if(U===e.FLOAT)G=e.RGBA32F;if(U===e.HALF_FLOAT)G=e.RGBA16F;if(U===e.UNSIGNED_BYTE)G=Y===ft?e.SRGB8_ALPHA8:e.RGBA8;if(U===e.UNSIGNED_SHORT&&le)G=le.RGBA16_EXT;if(U===e.SHORT&&le)G=le.RGBA16_SNORM_EXT;if(U===e.UNSIGNED_SHORT_4_4_4_4)G=e.RGBA4;if(U===e.UNSIGNED_SHORT_5_5_5_1)G=e.RGB5_A1}if(G===e.R16F||G===e.R32F||G===e.RG16F||G===e.RG32F||G===e.RGBA16F||G===e.RGBA32F)t.get("EXT_color_buffer_float");return G}function _(b,M){let U;if(b){if(M===null||M===bi||M===ns)U=e.DEPTH24_STENCIL8;else if(M===li)U=e.DEPTH32F_STENCIL8;else if(M===Pr)U=e.DEPTH24_STENCIL8,we("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")}else if(M===null||M===bi||M===ns)U=e.DEPTH_COMPONENT24;else if(M===li)U=e.DEPTH_COMPONENT32F;else if(M===Pr)U=e.DEPTH_COMPONENT16;return U}function E(b,M){if(S(b)===!0||b.isFramebufferTexture&&b.minFilter!==Pn&&b.minFilter!==Yt)return Math.log2(Math.max(M.width,M.height))+1;else if(b.mipmaps.length>0)return b.mipmaps.length;else if(b.isCompressedTexture&&Array.isArray(b.image))return M.mipmaps.length;else return 1}function I(b){let M=new WeakRef(b);i.get(b).__ref=M,m.add(M),x.register(b,M,M)}function k(b){let M=i.get(b).__ref;if(M===void 0)return;m.delete(M),x.unregister(M)}function N(b){Q(b.target)}function V(b){C(b.target)}function Q(b){if(b.removeEventListener("dispose",N),k(b),j(b),b.isVideoTexture)u.delete(b);if(b.isHTMLTexture)h.delete(b)}function C(b){b.removeEventListener("dispose",V),k(b),re(b)}function q(){for(let b of m){let M=b.deref();if(M===void 0)continue;if(M.isRenderTarget===!0)C(M);else Q(M)}m.clear(),h.clear()}function j(b){let M=i.get(b);if(M.__webglInit===void 0)return;let U=b.source,ee=f.get(U);if(ee){let K=ee[M.__cacheKey];if(K.usedTimes--,K.usedTimes===0)F(b);if(Object.keys(ee).length===0)f.delete(U)}i.remove(b)}function F(b){let M=i.get(b);e.deleteTexture(M.__webglTexture);let U=b.source,ee=f.get(U);delete ee[M.__cacheKey],o.memory.textures--}function re(b){let M=i.get(b);if(M.__depthDisposeCallback)M.__depthDisposeCallback();let U=b.depthTexture;if(U&&U.renderTarget===b)Q(U);if(b.isWebGLCubeRenderTarget)for(let K=0;K<6;K++){if(Array.isArray(M.__webglFramebuffer[K]))for(let oe=0;oe<M.__webglFramebuffer[K].length;oe++)e.deleteFramebuffer(M.__webglFramebuffer[K][oe]);else e.deleteFramebuffer(M.__webglFramebuffer[K]);if(M.__webglDepthbuffer)e.deleteRenderbuffer(M.__webglDepthbuffer[K])}else{if(Array.isArray(M.__webglFramebuffer))for(let K=0;K<M.__webglFramebuffer.length;K++)e.deleteFramebuffer(M.__webglFramebuffer[K]);else e.deleteFramebuffer(M.__webglFramebuffer);if(M.__webglDepthbuffer)e.deleteRenderbuffer(M.__webglDepthbuffer);if(M.__webglMultisampledFramebuffer)e.deleteFramebuffer(M.__webglMultisampledFramebuffer);if(M.__webglColorRenderbuffer){for(let K=0;K<M.__webglColorRenderbuffer.length;K++)if(M.__webglColorRenderbuffer[K])e.deleteRenderbuffer(M.__webglColorRenderbuffer[K])}if(M.__webglDepthRenderbuffer)e.deleteRenderbuffer(M.__webglDepthRenderbuffer)}let ee=b.textures;for(let K=0,oe=ee.length;K<oe;K++){let le=i.get(ee[K]);if(le.__webglTexture)e.deleteTexture(le.__webglTexture),o.memory.textures--;i.remove(ee[K])}i.remove(b)}let W=0;function J(){W=0}function ne(){return W}function Me(b){W=b}function Z(){let b=W;if(b>=s.maxTextures)we("WebGLTextures: Trying to use "+(b+1)+" texture units while this GPU supports only "+s.maxTextures);return W+=1,b}function te(b){let M=[];return M.push(b.wrapS),M.push(b.wrapT),M.push(b.wrapR||0),M.push(b.magFilter),M.push(b.minFilter),M.push(b.anisotropy),M.push(b.internalFormat),M.push(b.format),M.push(b.type),M.push(b.generateMipmaps),M.push(b.mipmapsAutoUpdate),M.push(b.premultiplyAlpha),M.push(b.flipY),M.push(b.unpackAlignment),M.push(b.colorSpace),M.join()}function ye(b,M){let U=i.get(b);if(b.isVideoTexture)Oe(b);if(b.isRenderTargetTexture===!1&&b.isExternalTexture!==!0&&b.version>0&&U.__version!==b.version){let ee=b.image;if(ee===null)we("WebGLRenderer: Texture marked for update but no image data found.");else if(ee.complete===!1)we("WebGLRenderer: Texture marked for update but image is incomplete");else{sn(U,b,M);return}}else if(b.isExternalTexture)U.__webglTexture=b.sourceTexture?b.sourceTexture:null;n.bindTexture(e.TEXTURE_2D,U.__webglTexture,e.TEXTURE0+M)}function Ne(b,M){let U=i.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&U.__version!==b.version){sn(U,b,M);return}else if(b.isExternalTexture)U.__webglTexture=b.sourceTexture?b.sourceTexture:null;n.bindTexture(e.TEXTURE_2D_ARRAY,U.__webglTexture,e.TEXTURE0+M)}function De(b,M){let U=i.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&U.__version!==b.version){sn(U,b,M);return}n.bindTexture(e.TEXTURE_3D,U.__webglTexture,e.TEXTURE0+M)}function _e(b,M){let U=i.get(b);if(b.version>0&&U.__version!==b.version){un(U,b,M);return}n.bindTexture(e.TEXTURE_CUBE_MAP,U.__webglTexture,e.TEXTURE0+M)}let it={[Fs]:e.REPEAT,[Hs]:e.CLAMP_TO_EDGE,[ea]:e.MIRRORED_REPEAT},We={[Pn]:e.NEAREST,[ta]:e.NEAREST_MIPMAP_NEAREST,[ts]:e.NEAREST_MIPMAP_LINEAR,[Yt]:e.LINEAR,[Bs]:e.LINEAR_MIPMAP_NEAREST,[Ln]:e.LINEAR_MIPMAP_LINEAR},Be={[qd]:e.NEVER,[kc]:e.ALWAYS,[Yd]:e.LESS,[Bc]:e.LEQUAL,[Zd]:e.EQUAL,[Vc]:e.GEQUAL,[jd]:e.GREATER,[Jd]:e.NOTEQUAL};function ht(b,M){if(M.type===li&&t.has("OES_texture_float_linear")===!1&&(M.magFilter===Yt||M.magFilter===Bs||M.magFilter===ts||M.magFilter===Ln||M.minFilter===Yt||M.minFilter===Bs||M.minFilter===ts||M.minFilter===Ln))we("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.");if(e.texParameteri(b,e.TEXTURE_WRAP_S,it[M.wrapS]),e.texParameteri(b,e.TEXTURE_WRAP_T,it[M.wrapT]),b===e.TEXTURE_3D||b===e.TEXTURE_2D_ARRAY)e.texParameteri(b,e.TEXTURE_WRAP_R,it[M.wrapR]);if(e.texParameteri(b,e.TEXTURE_MAG_FILTER,We[M.magFilter]),e.texParameteri(b,e.TEXTURE_MIN_FILTER,We[M.minFilter]),M.compareFunction)e.texParameteri(b,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(b,e.TEXTURE_COMPARE_FUNC,Be[M.compareFunction]);if(t.has("EXT_texture_filter_anisotropic")===!0){if(M.magFilter===Pn)return;if(M.minFilter!==ts&&M.minFilter!==Ln)return;if(M.type===li&&t.has("OES_texture_float_linear")===!1)return;if(M.anisotropy>1||i.get(M).__currentAnisotropy){let U=t.get("EXT_texture_filter_anisotropic");e.texParameterf(b,U.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(M.anisotropy,s.getMaxAnisotropy())),i.get(M).__currentAnisotropy=M.anisotropy}}}function et(b,M){let U=!1;if(b.__webglInit===void 0)b.__webglInit=!0,M.addEventListener("dispose",N),I(M);let ee=M.source,K=f.get(ee);if(K===void 0)K={},f.set(ee,K);let oe=te(M);if(oe!==b.__cacheKey){if(K[oe]===void 0)K[oe]={texture:e.createTexture(),usedTimes:0},o.memory.textures++,U=!0;K[oe].usedTimes++;let le=K[b.__cacheKey];if(le!==void 0){if(K[b.__cacheKey].usedTimes--,le.usedTimes===0)F(M)}b.__cacheKey=oe,b.__webglTexture=K[oe].texture}return U}function gt(b,M,U){return Math.floor(Math.floor(b/U)/M)}function Mt(b,M,U,ee){let oe=b.updateRanges;if(oe.length===0)n.texSubImage2D(e.TEXTURE_2D,0,0,0,M.width,M.height,U,ee,M.data);else{oe.sort((P,X)=>P.start-X.start);let le=0;for(let P=1;P<oe.length;P++){let X=oe[le],z=oe[P],ie=X.start+X.count,se=gt(z.start,M.width,4),de=gt(X.start,M.width,4);if(z.start<=ie+1&&se===de&&gt(z.start+z.count-1,M.width,4)===se)X.count=Math.max(X.count,z.start+z.count-X.start);else++le,oe[le]=z}oe.length=le+1;let G=n.getParameter(e.UNPACK_ROW_LENGTH),Y=n.getParameter(e.UNPACK_SKIP_PIXELS),ae=n.getParameter(e.UNPACK_SKIP_ROWS);n.pixelStorei(e.UNPACK_ROW_LENGTH,M.width);for(let P=0,X=oe.length;P<X;P++){let z=oe[P],ie=Math.floor(z.start/4),se=Math.ceil(z.count/4),de=ie%M.width,Le=Math.floor(ie/M.width),Ae=se,pe=1;n.pixelStorei(e.UNPACK_SKIP_PIXELS,de),n.pixelStorei(e.UNPACK_SKIP_ROWS,Le),n.texSubImage2D(e.TEXTURE_2D,0,de,Le,Ae,1,U,ee,M.data)}b.clearUpdateRanges(),n.pixelStorei(e.UNPACK_ROW_LENGTH,G),n.pixelStorei(e.UNPACK_SKIP_PIXELS,Y),n.pixelStorei(e.UNPACK_SKIP_ROWS,ae)}}function sn(b,M,U){let ee=e.TEXTURE_2D;if(M.isDataArrayTexture||M.isCompressedArrayTexture)ee=e.TEXTURE_2D_ARRAY;if(M.isData3DTexture)ee=e.TEXTURE_3D;let K=et(b,M),oe=M.source;n.bindTexture(ee,b.__webglTexture,e.TEXTURE0+U);let le=i.get(oe);if(oe.version!==le.__version||K===!0){if(n.activeTexture(e.TEXTURE0+U),(typeof ImageBitmap<"u"&&M.image instanceof ImageBitmap)===!1){let pe=qe.getPrimaries(qe.workingColorSpace),Ie=M.colorSpace===ss?null:qe.getPrimaries(M.colorSpace),ze=M.colorSpace===ss||pe===Ie?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,M.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,ze)}n.pixelStorei(e.UNPACK_ALIGNMENT,M.unpackAlignment);let Y=v(M.image,!1,s.maxTextureSize);Y=Ve(M,Y);let ae=r.convert(M.format,M.colorSpace),P=r.convert(M.type),X=w(M.internalFormat,ae,P,M.normalized,M.colorSpace,M.isVideoTexture);ht(ee,M);let z,ie=M.mipmaps,se=M.isVideoTexture!==!0,de=le.__version===void 0||K===!0,Le=oe.dataReady,Ae=E(M,Y);if(M.isDepthTexture){if(X=_(M.format===Ri,M.type),de)if(se)n.texStorage2D(e.TEXTURE_2D,1,X,Y.width,Y.height);else n.texImage2D(e.TEXTURE_2D,0,X,Y.width,Y.height,0,ae,P,null)}else if(M.isDataTexture)if(ie.length>0){if(se&&de)n.texStorage2D(e.TEXTURE_2D,Ae,X,ie[0].width,ie[0].height);for(let pe=0,Ie=ie.length;pe<Ie;pe++)if(z=ie[pe],se){if(Le)n.texSubImage2D(e.TEXTURE_2D,pe,0,0,z.width,z.height,ae,P,z.data)}else n.texImage2D(e.TEXTURE_2D,pe,X,z.width,z.height,0,ae,P,z.data);M.generateMipmaps=!1}else if(se){if(de)n.texStorage2D(e.TEXTURE_2D,Ae,X,Y.width,Y.height);if(Le)Mt(M,Y,ae,P)}else n.texImage2D(e.TEXTURE_2D,0,X,Y.width,Y.height,0,ae,P,Y.data);else if(M.isCompressedTexture)if(M.isCompressedArrayTexture){if(se&&de)n.texStorage3D(e.TEXTURE_2D_ARRAY,Ae,X,ie[0].width,ie[0].height,Y.depth);for(let pe=0,Ie=ie.length;pe<Ie;pe++)if(z=ie[pe],M.format!==ci)if(ae!==null)if(se){if(Le)if(M.layerUpdates.size>0){let ze=hu(z.width,z.height,M.format,M.type);for(let me of M.layerUpdates){let ct=z.data.subarray(me*ze/z.data.BYTES_PER_ELEMENT,(me+1)*ze/z.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,pe,0,0,me,z.width,z.height,1,ae,ct)}}else n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,pe,0,0,0,z.width,z.height,Y.depth,ae,z.data)}else n.compressedTexImage3D(e.TEXTURE_2D_ARRAY,pe,X,z.width,z.height,Y.depth,0,z.data,0,0);else we("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else if(se){if(Le)n.texSubImage3D(e.TEXTURE_2D_ARRAY,pe,0,0,0,z.width,z.height,Y.depth,ae,P,z.data)}else n.texImage3D(e.TEXTURE_2D_ARRAY,pe,X,z.width,z.height,Y.depth,0,ae,P,z.data);if(M.layerUpdates.size>0)M.clearLayerUpdates()}else{if(se&&de)n.texStorage2D(e.TEXTURE_2D,Ae,X,ie[0].width,ie[0].height);for(let pe=0,Ie=ie.length;pe<Ie;pe++)if(z=ie[pe],M.format!==ci)if(ae!==null)if(se){if(Le)n.compressedTexSubImage2D(e.TEXTURE_2D,pe,0,0,z.width,z.height,ae,z.data)}else n.compressedTexImage2D(e.TEXTURE_2D,pe,X,z.width,z.height,0,z.data);else we("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else if(se){if(Le)n.texSubImage2D(e.TEXTURE_2D,pe,0,0,z.width,z.height,ae,P,z.data)}else n.texImage2D(e.TEXTURE_2D,pe,X,z.width,z.height,0,ae,P,z.data)}else if(M.isDataArrayTexture)if(se){if(de)n.texStorage3D(e.TEXTURE_2D_ARRAY,Ae,X,Y.width,Y.height,Y.depth);if(Le)if(M.layerUpdates.size>0){let pe=hu(Y.width,Y.height,M.format,M.type);for(let Ie of M.layerUpdates){let ze=Y.data.subarray(Ie*pe/Y.data.BYTES_PER_ELEMENT,(Ie+1)*pe/Y.data.BYTES_PER_ELEMENT);n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,Ie,Y.width,Y.height,1,ae,P,ze)}M.clearLayerUpdates()}else n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,Y.width,Y.height,Y.depth,ae,P,Y.data)}else n.texImage3D(e.TEXTURE_2D_ARRAY,0,X,Y.width,Y.height,Y.depth,0,ae,P,Y.data);else if(M.isData3DTexture)if(se){if(de)n.texStorage3D(e.TEXTURE_3D,Ae,X,Y.width,Y.height,Y.depth);if(Le)n.texSubImage3D(e.TEXTURE_3D,0,0,0,0,Y.width,Y.height,Y.depth,ae,P,Y.data)}else n.texImage3D(e.TEXTURE_3D,0,X,Y.width,Y.height,Y.depth,0,ae,P,Y.data);else if(M.isFramebufferTexture){if(de)if(se)n.texStorage2D(e.TEXTURE_2D,Ae,X,Y.width,Y.height);else{let pe=Y.width,Ie=Y.height;for(let ze=0;ze<Ae;ze++)n.texImage2D(e.TEXTURE_2D,ze,X,pe,Ie,0,ae,P,null),pe>>=1,Ie>>=1}}else if(M.isHTMLTexture){if("texElementImage2D"in e){let pe=e.canvas;if(!pe.hasAttribute("layoutsubtree"))pe.setAttribute("layoutsubtree","true");if(Y.parentNode!==pe){pe.appendChild(Y),h.add(M),pe.onpaint=(Ie)=>{let ze=Ie.changedElements;for(let me of h)if(ze.includes(me.image))me.needsUpdate=!0},pe.requestPaint();return}if(e.texElementImage2D.length===3)e.texElementImage2D(e.TEXTURE_2D,e.RGBA8,Y);else{let{RGBA:ze,RGBA:me,UNSIGNED_BYTE:ct}=e;e.texElementImage2D(e.TEXTURE_2D,0,ze,me,ct,Y)}e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)}}else if(ie.length>0){if(se&&de){let pe=kt(ie[0]);n.texStorage2D(e.TEXTURE_2D,Ae,X,pe.width,pe.height)}for(let pe=0,Ie=ie.length;pe<Ie;pe++)if(z=ie[pe],se){if(Le)n.texSubImage2D(e.TEXTURE_2D,pe,0,0,ae,P,z)}else n.texImage2D(e.TEXTURE_2D,pe,X,ae,P,z);M.generateMipmaps=!1}else if(se){if(de){let pe=kt(Y);n.texStorage2D(e.TEXTURE_2D,Ae,X,pe.width,pe.height)}if(Le)n.texSubImage2D(e.TEXTURE_2D,0,0,0,ae,P,Y)}else n.texImage2D(e.TEXTURE_2D,0,X,ae,P,Y);if(S(M)&&M.mipmapsAutoUpdate===!0)T(ee);if(le.__version=oe.version,M.onUpdate)M.onUpdate(M)}b.__version=M.version}function un(b,M,U){if(M.image.length!==6)return;let ee=et(b,M),K=M.source;n.bindTexture(e.TEXTURE_CUBE_MAP,b.__webglTexture,e.TEXTURE0+U);let oe=i.get(K);if(K.version!==oe.__version||ee===!0){n.activeTexture(e.TEXTURE0+U);let le=qe.getPrimaries(qe.workingColorSpace),G=M.colorSpace===ss?null:qe.getPrimaries(M.colorSpace),Y=M.colorSpace===ss||le===G?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,M.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),n.pixelStorei(e.UNPACK_ALIGNMENT,M.unpackAlignment),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,Y);let ae=M.isCompressedTexture||M.image[0].isCompressedTexture,P=M.image[0]&&M.image[0].isDataTexture,X=[];for(let me=0;me<6;me++){if(!ae&&!P)X[me]=v(M.image[me],!0,s.maxCubemapSize);else X[me]=P?M.image[me].image:M.image[me];X[me]=Ve(M,X[me])}let z=X[0],ie=r.convert(M.format,M.colorSpace),se=r.convert(M.type),de=w(M.internalFormat,ie,se,M.normalized,M.colorSpace),Le=M.isVideoTexture!==!0,Ae=oe.__version===void 0||ee===!0,pe=K.dataReady,Ie=E(M,z);ht(e.TEXTURE_CUBE_MAP,M);let ze;if(M.isDepthTexture){if(de=_(M.format===Ri,M.type),Ae)if(Le)n.texStorage2D(e.TEXTURE_CUBE_MAP,1,de,z.width,z.height);else for(let me=0;me<6;me++)n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,de,z.width,z.height,0,ie,se,null)}else if(ae){if(Le&&Ae)n.texStorage2D(e.TEXTURE_CUBE_MAP,Ie,de,z.width,z.height);for(let me=0;me<6;me++){ze=X[me].mipmaps;for(let ct=0;ct<ze.length;ct++){let It=ze[ct];if(M.format!==ci)if(ie!==null)if(Le){if(pe)n.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,ct,0,0,It.width,It.height,ie,It.data)}else n.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,ct,de,It.width,It.height,0,It.data);else we("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()");else if(Le){if(pe)n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,ct,0,0,It.width,It.height,ie,se,It.data)}else n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,ct,de,It.width,It.height,0,ie,se,It.data)}}}else{if(ze=M.mipmaps,Le&&Ae){if(ze.length>0)Ie++;let me=kt(X[0]);n.texStorage2D(e.TEXTURE_CUBE_MAP,Ie,de,me.width,me.height)}for(let me=0;me<6;me++)if(P){if(Le){if(pe)n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,0,0,X[me].width,X[me].height,ie,se,X[me].data)}else n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,de,X[me].width,X[me].height,0,ie,se,X[me].data);for(let ct=0;ct<ze.length;ct++){let $n=ze[ct].image[me].image;if(Le){if(pe)n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,ct+1,0,0,$n.width,$n.height,ie,se,$n.data)}else n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,ct+1,de,$n.width,$n.height,0,ie,se,$n.data)}}else{if(Le){if(pe)n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,0,0,ie,se,X[me])}else n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,de,ie,se,X[me]);for(let ct=0;ct<ze.length;ct++){let It=ze[ct];if(Le){if(pe)n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,ct+1,0,0,ie,se,It.image[me])}else n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+me,ct+1,de,ie,se,It.image[me])}}}if(S(M)&&M.mipmapsAutoUpdate===!0)T(e.TEXTURE_CUBE_MAP);if(oe.__version=K.version,M.onUpdate)M.onUpdate(M)}b.__version=M.version}function Et(b,M,U,ee,K,oe){let le=r.convert(U.format,U.colorSpace),G=r.convert(U.type),Y=w(U.internalFormat,le,G,U.normalized,U.colorSpace),ae=i.get(M),P=i.get(U);if(P.__renderTarget=M,!ae.__hasExternalTextures){let X=Math.max(1,M.width>>oe),z=Math.max(1,M.height>>oe);if(K===e.TEXTURE_3D||K===e.TEXTURE_2D_ARRAY)n.texImage3D(K,oe,Y,X,z,M.depth,0,le,G,null);else n.texImage2D(K,oe,Y,X,z,0,le,G,null)}if(n.bindFramebuffer(e.FRAMEBUFFER,b),pt(M))a.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,ee,K,P.__webglTexture,0,fe(M));else if(K===e.TEXTURE_2D||K>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&K<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)e.framebufferTexture2D(e.FRAMEBUFFER,ee,K,P.__webglTexture,oe);n.bindFramebuffer(e.FRAMEBUFFER,null)}function Vt(b,M,U){if(e.bindRenderbuffer(e.RENDERBUFFER,b),M.depthBuffer){let ee=M.depthTexture,K=ee&&ee.isDepthTexture?ee.type:null,oe=_(M.stencilBuffer,K),le=M.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(pt(M))a.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,fe(M),oe,M.width,M.height);else if(U)e.renderbufferStorageMultisample(e.RENDERBUFFER,fe(M),oe,M.width,M.height);else e.renderbufferStorage(e.RENDERBUFFER,oe,M.width,M.height);e.framebufferRenderbuffer(e.FRAMEBUFFER,le,e.RENDERBUFFER,b)}else{let ee=M.textures;for(let K=0;K<ee.length;K++){let oe=ee[K],le=r.convert(oe.format,oe.colorSpace),G=r.convert(oe.type),Y=w(oe.internalFormat,le,G,oe.normalized,oe.colorSpace);if(pt(M))a.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,fe(M),Y,M.width,M.height);else if(U)e.renderbufferStorageMultisample(e.RENDERBUFFER,fe(M),Y,M.width,M.height);else e.renderbufferStorage(e.RENDERBUFFER,Y,M.width,M.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function rn(b,M,U){let ee=M.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(e.FRAMEBUFFER,b),!(M.depthTexture&&M.depthTexture.isDepthTexture))throw Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");let K=i.get(M.depthTexture);K.__renderTarget=M;let oe=ee?M.depthTexture.image[0]:M.depthTexture.image;if(!K.__webglTexture||oe.width!==M.width||oe.height!==M.height)oe.width=M.width,oe.height=M.height,M.depthTexture.needsUpdate=!0;if(ee)_e(M.depthTexture,0);else ye(M.depthTexture,0);let le=K.__webglTexture,G=fe(M),Y=ee?e.TEXTURE_CUBE_MAP_POSITIVE_X+U:e.TEXTURE_2D,ae=M.depthTexture.format===Ri?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(M.depthTexture.format===Vs)if(pt(M))a.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,ae,Y,le,0,G);else e.framebufferTexture2D(e.FRAMEBUFFER,ae,Y,le,0);else if(M.depthTexture.format===Ri)if(pt(M))a.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,ae,Y,le,0,G);else e.framebufferTexture2D(e.FRAMEBUFFER,ae,Y,le,0);else throw Error("THREE.WebGLTextures: Unknown depthTexture format.")}function on(b){let M=i.get(b),U=b.isWebGLCubeRenderTarget===!0;if(M.__boundDepthTexture!==b.depthTexture){let ee=b.depthTexture;if(M.__depthDisposeCallback)M.__depthDisposeCallback();if(ee){let K=()=>{delete M.__boundDepthTexture,delete M.__depthDisposeCallback,ee.removeEventListener("dispose",K)};ee.addEventListener("dispose",K),M.__depthDisposeCallback=K}M.__boundDepthTexture=ee}if(b.depthTexture&&!M.__autoAllocateDepthBuffer)if(U)for(let ee=0;ee<6;ee++)rn(M.__webglFramebuffer[ee],b,ee);else if(b.texture.mipmaps.length>0)rn(M.__webglFramebuffer[0],b,0);else rn(M.__webglFramebuffer,b,0);else if(U){M.__webglDepthbuffer=[];for(let ee=0;ee<6;ee++)if(n.bindFramebuffer(e.FRAMEBUFFER,M.__webglFramebuffer[ee]),M.__webglDepthbuffer[ee]===void 0)M.__webglDepthbuffer[ee]=e.createRenderbuffer(),Vt(M.__webglDepthbuffer[ee],b,!1);else{let K=b.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,oe=M.__webglDepthbuffer[ee];e.bindRenderbuffer(e.RENDERBUFFER,oe),e.framebufferRenderbuffer(e.FRAMEBUFFER,K,e.RENDERBUFFER,oe)}}else{if(b.texture.mipmaps.length>0)n.bindFramebuffer(e.FRAMEBUFFER,M.__webglFramebuffer[0]);else n.bindFramebuffer(e.FRAMEBUFFER,M.__webglFramebuffer);if(M.__webglDepthbuffer===void 0)M.__webglDepthbuffer=e.createRenderbuffer(),Vt(M.__webglDepthbuffer,b,!1);else{let K=b.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,oe=M.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,oe),e.framebufferRenderbuffer(e.FRAMEBUFFER,K,e.RENDERBUFFER,oe)}}n.bindFramebuffer(e.FRAMEBUFFER,null)}function Sn(b,M,U){let ee=i.get(b);if(M!==void 0)Et(ee.__webglFramebuffer,b,b.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0);if(U!==void 0)on(b)}function D(b){let M=b.texture,U=i.get(b),ee=i.get(M);b.addEventListener("dispose",V),I(b);let K=b.textures,oe=b.isWebGLCubeRenderTarget===!0,le=K.length>1;if(!le){if(ee.__webglTexture===void 0)ee.__webglTexture=e.createTexture();ee.__version=M.version,o.memory.textures++}if(oe){U.__webglFramebuffer=[];for(let G=0;G<6;G++)if(M.mipmaps.length>0){U.__webglFramebuffer[G]=[];for(let Y=0;Y<M.mipmaps.length;Y++)U.__webglFramebuffer[G][Y]=e.createFramebuffer()}else U.__webglFramebuffer[G]=e.createFramebuffer()}else{if(M.mipmaps.length>0){U.__webglFramebuffer=[];for(let G=0;G<M.mipmaps.length;G++)U.__webglFramebuffer[G]=e.createFramebuffer()}else U.__webglFramebuffer=e.createFramebuffer();if(le)for(let G=0,Y=K.length;G<Y;G++){let ae=i.get(K[G]);if(ae.__webglTexture===void 0)ae.__webglTexture=e.createTexture(),o.memory.textures++}if(b.samples>0&&pt(b)===!1){U.__webglMultisampledFramebuffer=e.createFramebuffer(),U.__webglColorRenderbuffer=[],n.bindFramebuffer(e.FRAMEBUFFER,U.__webglMultisampledFramebuffer);for(let G=0;G<K.length;G++){let Y=K[G];U.__webglColorRenderbuffer[G]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,U.__webglColorRenderbuffer[G]);let ae=r.convert(Y.format,Y.colorSpace),P=r.convert(Y.type),X=w(Y.internalFormat,ae,P,Y.normalized,Y.colorSpace,b.isXRRenderTarget===!0),z=fe(b);e.renderbufferStorageMultisample(e.RENDERBUFFER,z,X,b.width,b.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+G,e.RENDERBUFFER,U.__webglColorRenderbuffer[G])}if(e.bindRenderbuffer(e.RENDERBUFFER,null),b.depthBuffer)U.__webglDepthRenderbuffer=e.createRenderbuffer(),Vt(U.__webglDepthRenderbuffer,b,!0);n.bindFramebuffer(e.FRAMEBUFFER,null)}}if(oe){n.bindTexture(e.TEXTURE_CUBE_MAP,ee.__webglTexture),ht(e.TEXTURE_CUBE_MAP,M);for(let G=0;G<6;G++)if(M.mipmaps.length>0)for(let Y=0;Y<M.mipmaps.length;Y++)Et(U.__webglFramebuffer[G][Y],b,M,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+G,Y);else Et(U.__webglFramebuffer[G],b,M,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+G,0);if(S(M))T(e.TEXTURE_CUBE_MAP);else if(M.mipmaps.length>0)e.texParameteri(e.TEXTURE_CUBE_MAP,e.TEXTURE_MAX_LEVEL,M.mipmaps.length-1);n.unbindTexture()}else if(le){for(let G=0,Y=K.length;G<Y;G++){let ae=K[G],P=i.get(ae),X=e.TEXTURE_2D;if(b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)X=b.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY;if(n.bindTexture(X,P.__webglTexture),ht(X,ae),Et(U.__webglFramebuffer,b,ae,e.COLOR_ATTACHMENT0+G,X,0),S(ae))T(X)}n.unbindTexture()}else{let G=e.TEXTURE_2D;if(b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)G=b.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY;if(n.bindTexture(G,ee.__webglTexture),ht(G,M),M.mipmaps.length>0)for(let Y=0;Y<M.mipmaps.length;Y++)Et(U.__webglFramebuffer[Y],b,M,e.COLOR_ATTACHMENT0,G,Y);else Et(U.__webglFramebuffer,b,M,e.COLOR_ATTACHMENT0,G,0);if(S(M))T(G);else if(M.mipmaps.length>0)e.texParameteri(G,e.TEXTURE_MAX_LEVEL,M.mipmaps.length-1);n.unbindTexture()}if(b.depthBuffer)on(b)}function bn(b){let M=b.textures;for(let U=0,ee=M.length;U<ee;U++){let K=M[U];if(S(K)&&K.mipmapsAutoUpdate===!0){let oe=A(b),le=i.get(K).__webglTexture;n.bindTexture(oe,le),T(oe),n.unbindTexture()}}}let lt=[];function Lt(b){if(b.samples>0){if(pt(b)===!1){let{textures:M,width:U,height:ee}=b,K=e.COLOR_BUFFER_BIT,oe=b.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,le=i.get(b),G=M.length>1;if(G)for(let ae=0;ae<M.length;ae++)n.bindFramebuffer(e.FRAMEBUFFER,le.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+ae,e.RENDERBUFFER,null),n.bindFramebuffer(e.FRAMEBUFFER,le.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+ae,e.TEXTURE_2D,null,0);if(n.bindFramebuffer(e.READ_FRAMEBUFFER,le.__webglMultisampledFramebuffer),b.texture.mipmaps.length>0)n.bindFramebuffer(e.DRAW_FRAMEBUFFER,le.__webglFramebuffer[0]);else n.bindFramebuffer(e.DRAW_FRAMEBUFFER,le.__webglFramebuffer);for(let ae=0;ae<M.length;ae++){if(b.resolveDepthBuffer){if(b.depthBuffer)K|=e.DEPTH_BUFFER_BIT;if(b.stencilBuffer&&b.resolveStencilBuffer)K|=e.STENCIL_BUFFER_BIT}if(G){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,le.__webglColorRenderbuffer[ae]);let P=i.get(M[ae]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,P,0)}if(e.blitFramebuffer(0,0,U,ee,0,0,U,ee,K,e.NEAREST),l===!0){if(lt.length=0,lt.push(e.COLOR_ATTACHMENT0+ae),b.depthBuffer&&b.storeMultisampledDepthBuffer===!1)lt.push(oe);e.invalidateFramebuffer(e.READ_FRAMEBUFFER,lt)}}if(n.bindFramebuffer(e.READ_FRAMEBUFFER,null),n.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),G)for(let ae=0;ae<M.length;ae++){n.bindFramebuffer(e.FRAMEBUFFER,le.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+ae,e.RENDERBUFFER,le.__webglColorRenderbuffer[ae]);let P=i.get(M[ae]).__webglTexture;n.bindFramebuffer(e.FRAMEBUFFER,le.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+ae,e.TEXTURE_2D,P,0)}n.bindFramebuffer(e.DRAW_FRAMEBUFFER,le.__webglMultisampledFramebuffer)}else if(b.depthBuffer&&b.storeMultisampledDepthBuffer===!1&&l){let M=b.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[M])}}}function fe(b){return Math.min(s.maxSamples,b.samples)}function pt(b){let M=i.get(b);return b.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&M.__useRenderToTexture!==!1}function Oe(b){let M=o.render.frame;if(u.get(b)!==M)u.set(b,M),b.update()}function Ve(b,M){let{colorSpace:U,format:ee,type:K}=b;if(b.isCompressedTexture===!0||b.isVideoTexture===!0)return M;if(U!==fn&&U!==ss)if(qe.getTransfer(U)===ft){if(ee!==ci||K!==In)we("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.")}else He("WebGLTextures: Unsupported texture color space:",U);return M}function kt(b){if(typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement)c.width=b.naturalWidth||b.width,c.height=b.naturalHeight||b.height;else if(typeof VideoFrame<"u"&&b instanceof VideoFrame)c.width=b.displayWidth,c.height=b.displayHeight;else c.width=b.width,c.height=b.height;return c}this.allocateTextureUnit=Z,this.resetTextureUnits=J,this.getTextureUnits=ne,this.setTextureUnits=Me,this.setTexture2D=ye,this.setTexture2DArray=Ne,this.setTexture3D=De,this.setTextureCube=_e,this.rebindTextures=Sn,this.setupRenderTarget=D,this.updateRenderTargetMipmap=bn,this.updateMultisampleRenderTarget=Lt,this.setupDepthRenderbuffer=on,this.setupFrameBufferTexture=Et,this.useMultisampledRTT=pt,this.dispose=q}function ry(e,t){function n(i,s=ss){let r,o=qe.getTransfer(s);if(i===In)return e.UNSIGNED_BYTE;if(i===tc)return e.UNSIGNED_SHORT_4_4_4_4;if(i===nc)return e.UNSIGNED_SHORT_5_5_5_1;if(i===Vd)return e.UNSIGNED_INT_5_9_9_9_REV;if(i===kd)return e.UNSIGNED_INT_10F_11F_11F_REV;if(i===Hd)return e.BYTE;if(i===Bd)return e.SHORT;if(i===Pr)return e.UNSIGNED_SHORT;if(i===ec)return e.INT;if(i===bi)return e.UNSIGNED_INT;if(i===li)return e.FLOAT;if(i===kn)return e.HALF_FLOAT;if(i===Gd)return e.ALPHA;if(i===zd)return e.RGB;if(i===ci)return e.RGBA;if(i===Vs)return e.DEPTH_COMPONENT;if(i===Ri)return e.DEPTH_STENCIL;if(i===Wd)return e.RED;if(i===ic)return e.RED_INTEGER;if(i===is)return e.RG;if(i===sc)return e.RG_INTEGER;if(i===rc)return e.RGBA_INTEGER;if(i===na||i===ia||i===sa||i===ra)if(o===ft)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(i===na)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===ia)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===sa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===ra)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(i===na)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===ia)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===sa)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===ra)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===oc||i===ac||i===lc||i===cc)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(i===oc)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===ac)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===lc)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===cc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===uc||i===hc||i===dc||i===fc||i===pc||i===oa||i===mc)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(i===uc||i===hc)return o===ft?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(i===dc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC;if(i===fc)return r.COMPRESSED_R11_EAC;if(i===pc)return r.COMPRESSED_SIGNED_R11_EAC;if(i===oa)return r.COMPRESSED_RG11_EAC;if(i===mc)return r.COMPRESSED_SIGNED_RG11_EAC}else return null;if(i===gc||i===_c||i===xc||i===Mc||i===yc||i===vc||i===Ec||i===Tc||i===Sc||i===bc||i===Rc||i===Ac||i===wc||i===Cc)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(i===gc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===_c)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===xc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===Mc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===yc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===vc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===Ec)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===Tc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===Sc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===bc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===Rc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===Ac)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===wc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===Cc)return o===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===Pc||i===Lc||i===Ic)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(i===Pc)return o===ft?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===Lc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===Ic)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===Nc||i===Dc||i===aa||i===Uc)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(i===Nc)return r.COMPRESSED_RED_RGTC1_EXT;if(i===Dc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===aa)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===Uc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;if(i===ns)return e.UNSIGNED_INT_24_8;return e[i]!==void 0?e[i]:null}return{convert:n}}var oy=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,ay=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Yf{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new va(e.texture);if(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)this.depthNear=e.depthNear,this.depthFar=e.depthFar;this.texture=n}}getMesh(e){if(this.texture!==null){if(this.mesh===null){let t=e.cameras[0].viewport,n=new On({vertexShader:oy,fragmentShader:ay,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new bt(new Fr(20,20),n)}}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Zf extends Gn{constructor(e,t){super();let n=this,i=null,s=1,r=null,o="local-floor",a=1,l=null,c=null,u=null,h=null,d=null,f=null,m=typeof XRWebGLBinding<"u",x=new Yf,p={},g=t.getContextAttributes(),v=null,S=null,T=[],A=[],w=new Ce,_=null,E=null,I=new Ut;I.viewport=new ut;let k=new Ut;k.viewport=new ut;let N=[I,k],V=new lu,Q=null,C=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let te=T[Z];if(te===void 0)te=new Dr,T[Z]=te;return te.getTargetRaySpace()},this.getControllerGrip=function(Z){let te=T[Z];if(te===void 0)te=new Dr,T[Z]=te;return te.getGripSpace()},this.getHand=function(Z){let te=T[Z];if(te===void 0)te=new Dr,T[Z]=te;return te.getHandSpace()};function q(Z){let te=A.indexOf(Z.inputSource);if(te===-1)return;let ye=T[te];if(ye!==void 0)ye.update(Z.inputSource,Z.frame,l||r),ye.dispatchEvent({type:Z.type,data:Z.inputSource})}function j(){i.removeEventListener("select",q),i.removeEventListener("selectstart",q),i.removeEventListener("selectend",q),i.removeEventListener("squeeze",q),i.removeEventListener("squeezestart",q),i.removeEventListener("squeezeend",q),i.removeEventListener("end",j),i.removeEventListener("inputsourceschange",F);for(let Z=0;Z<T.length;Z++){let te=A[Z];if(te===null)continue;A[Z]=null,T[Z].disconnect(te)}Q=null,C=null,x.reset();for(let Z in p)delete p[Z];if(e.setRenderTarget(v),d=null,h=null,u=null,i=null,S=null,Me.stop(),n.isPresenting=!1,e.setPixelRatio(_),e.setSize(w.width,w.height,!1),E!==null){let Z=E.camera;Z.fov=E.fov,Z.zoom=E.zoom,Z.updateProjectionMatrix(),E=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){if(s=Z,n.isPresenting===!0)we("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){if(o=Z,n.isPresenting===!0)we("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||r},this.setReferenceSpace=function(Z){l=Z},this.getBaseLayer=function(){return h!==null?h:d},this.getBinding=function(){if(u===null&&m)u=new XRWebGLBinding(i,t);return u},this.getFrame=function(){return f},this.getSession=function(){return i},this.setSession=async function(Z){if(i=Z,i!==null){if(v=e.getRenderTarget(),i.addEventListener("select",q),i.addEventListener("selectstart",q),i.addEventListener("selectend",q),i.addEventListener("squeeze",q),i.addEventListener("squeezestart",q),i.addEventListener("squeezeend",q),i.addEventListener("end",j),i.addEventListener("inputsourceschange",F),g.xrCompatible!==!0)await t.makeXRCompatible();if(_=e.getPixelRatio(),e.getSize(w),!(m&&("createProjectionLayer"in XRWebGLBinding.prototype))){let ye={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:s};d=new XRWebGLLayer(i,t,ye),i.updateRenderState({baseLayer:d}),e.setPixelRatio(1),e.setSize(d.framebufferWidth,d.framebufferHeight,!1),S=new Mn(d.framebufferWidth,d.framebufferHeight,{format:ci,type:In,colorSpace:e.outputColorSpace,stencilBuffer:g.stencil,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1,storeMultisampledDepthBuffer:d.ignoreDepthValues===!1,storeMultisampledStencilBuffer:d.ignoreDepthValues===!1})}else{let ye=null,Ne=null,De=null;if(g.depth)De=g.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ye=g.stencil?Ri:Vs,Ne=g.stencil?ns:bi;let _e={colorFormat:t.RGBA8,depthFormat:De,scaleFactor:s};u=this.getBinding(),h=u.createProjectionLayer(_e),i.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),S=new Mn(h.textureWidth,h.textureHeight,{format:ci,type:In,depthTexture:new Pi(h.textureWidth,h.textureHeight,Ne,void 0,void 0,void 0,void 0,void 0,void 0,ye),stencilBuffer:g.stencil,colorSpace:e.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1,storeMultisampledDepthBuffer:h.ignoreDepthValues===!1,storeMultisampledStencilBuffer:h.ignoreDepthValues===!1})}S.isXRRenderTarget=!0,this.setFoveation(a),l=null,r=await i.requestReferenceSpace(o),Me.setContext(i),Me.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return x.getDepthTexture()};function F(Z){for(let te=0;te<Z.removed.length;te++){let ye=Z.removed[te],Ne=A.indexOf(ye);if(Ne>=0)A[Ne]=null,T[Ne].disconnect(ye)}for(let te=0;te<Z.added.length;te++){let ye=Z.added[te],Ne=A.indexOf(ye);if(Ne===-1){for(let _e=0;_e<T.length;_e++)if(_e>=A.length){A.push(ye),Ne=_e;break}else if(A[_e]===null){A[_e]=ye,Ne=_e;break}if(Ne===-1)break}let De=T[Ne];if(De)De.connect(ye)}}function re(Z,te){if(te===null)Z.matrixWorld.copy(Z.matrix);else Z.matrixWorld.multiplyMatrices(te.matrixWorld,Z.matrix);Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(i===null)return;let{near:te,far:ye}=Z;if(x.texture!==null){if(x.depthNear>0)te=x.depthNear;if(x.depthFar>0)ye=x.depthFar}if(V.near=k.near=I.near=te,V.far=k.far=I.far=ye,Q!==V.near||C!==V.far)i.updateRenderState({depthNear:V.near,depthFar:V.far}),Q=V.near,C=V.far;V.layers.mask=Z.layers.mask|6,I.layers.mask=V.layers.mask&-5,k.layers.mask=V.layers.mask&-3;let Ne=Z.parent,De=V.cameras;re(V,Ne);for(let _e=0;_e<De.length;_e++)re(De[_e],Ne);if(V.projectionMatrix.copy(I.projectionMatrix),V.projectionMatrixInverse.copy(I.projectionMatrixInverse),E===null&&Z.isPerspectiveCamera)E={camera:Z,fov:Z.fov,zoom:Z.zoom};W(Z,V,Ne)};function W(Z,te,ye){if(ye===null)Z.matrix.copy(te.matrixWorld);else Z.matrix.copy(ye.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(te.matrixWorld);if(Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(te.projectionMatrix),Z.projectionMatrixInverse.copy(te.projectionMatrixInverse),Z.isPerspectiveCamera)Z.fov=$i*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1}this.getCamera=function(){return V},this.getFoveation=function(){if(h===null&&d===null)return;return a},this.setFoveation=function(Z){if(a=Z,h!==null)h.fixedFoveation=Z;if(d!==null&&d.fixedFoveation!==void 0)d.fixedFoveation=Z},this.hasDepthSensing=function(){return x.texture!==null},this.getDepthSensingMesh=function(){return x.getMesh(V)},this.getCameraTexture=function(Z){return p[Z]};let J=null;function ne(Z,te){if(c=te.getViewerPose(l||r),f=te,c!==null){let ye=c.views;if(d!==null)e.setRenderTargetFramebuffer(S,d.framebuffer),e.setRenderTarget(S);let Ne=!1;if(ye.length!==V.cameras.length)V.cameras.length=0,Ne=!0;for(let We=0;We<ye.length;We++){let Be=ye[We],ht=null;if(d!==null)ht=d.getViewport(Be);else{let gt=u.getViewSubImage(h,Be);if(ht=gt.viewport,We===0)e.setRenderTargetTextures(S,gt.colorTexture,gt.depthStencilTexture),e.setRenderTarget(S)}let et=N[We];if(et===void 0)et=new Ut,et.layers.enable(We),et.viewport=new ut,N[We]=et;if(et.matrix.fromArray(Be.transform.matrix),et.matrix.decompose(et.position,et.quaternion,et.scale),et.projectionMatrix.fromArray(Be.projectionMatrix),et.projectionMatrixInverse.copy(et.projectionMatrix).invert(),et.viewport.set(ht.x,ht.y,ht.width,ht.height),We===0)V.matrix.copy(et.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale);if(Ne===!0)V.cameras.push(et)}let De=i.enabledFeatures;if(De&&De.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&m){u=n.getBinding();let We=u.getDepthInformation(ye[0]);if(We&&We.isValid&&We.texture)x.init(We,i.renderState)}if(De&&De.includes("camera-access")&&m){e.state.unbindTexture(),u=n.getBinding();for(let We=0;We<ye.length;We++){let Be=ye[We].camera;if(Be){let ht=p[Be];if(!ht)ht=new va,p[Be]=ht;let et=u.getCameraImage(Be);ht.sourceTexture=et}}}}for(let ye=0;ye<T.length;ye++){let Ne=A[ye],De=T[ye];if(Ne!==null&&De!==void 0)De.update(Ne,te,l||r)}if(J)J(Z,te);if(te.detectedPlanes)n.dispatchEvent({type:"planesdetected",data:te});f=null}let Me=new If;Me.setAnimationLoop(ne),this.setAnimationLoop=function(Z){J=Z},this.dispose=function(){}}}var ly=new Re,jf=new Pe;jf.set(-1,0,0,0,1,0,0,0,1);function cy(e,t){function n(p,g){if(p.matrixAutoUpdate===!0)p.updateMatrix();g.value.copy(p.matrix)}function i(p,g){if(g.color.getRGB(p.fogColor.value,$c(e)),g.isFog)p.fogNear.value=g.near,p.fogFar.value=g.far;else if(g.isFogExp2)p.fogDensity.value=g.density}function s(p,g,v,S,T){if(g.isNodeMaterial)g.uniformsNeedUpdate=!1;else if(g.isMeshBasicMaterial)r(p,g);else if(g.isMeshLambertMaterial){if(r(p,g),g.envMap)p.envMapIntensity.value=g.envMapIntensity}else if(g.isMeshToonMaterial)r(p,g),h(p,g);else if(g.isMeshPhongMaterial){if(r(p,g),u(p,g),g.envMap)p.envMapIntensity.value=g.envMapIntensity}else if(g.isMeshStandardMaterial){if(r(p,g),d(p,g),g.isMeshPhysicalMaterial)f(p,g,T)}else if(g.isMeshMatcapMaterial)r(p,g),m(p,g);else if(g.isMeshDepthMaterial)r(p,g);else if(g.isMeshDistanceMaterial)r(p,g),x(p,g);else if(g.isMeshNormalMaterial)r(p,g);else if(g.isLineBasicMaterial){if(o(p,g),g.isLineDashedMaterial)a(p,g)}else if(g.isPointsMaterial)l(p,g,v,S);else if(g.isSpriteMaterial)c(p,g);else if(g.isShadowMaterial)p.color.value.copy(g.color),p.opacity.value=g.opacity;else if(g.isShaderMaterial)g.uniformsNeedUpdate=!1}function r(p,g){if(p.opacity.value=g.opacity,g.color)p.diffuse.value.copy(g.color);if(g.emissive)p.emissive.value.copy(g.emissive).multiplyScalar(g.emissiveIntensity);if(g.map)p.map.value=g.map,n(g.map,p.mapTransform);if(g.alphaMap)p.alphaMap.value=g.alphaMap,n(g.alphaMap,p.alphaMapTransform);if(g.bumpMap){if(p.bumpMap.value=g.bumpMap,n(g.bumpMap,p.bumpMapTransform),p.bumpScale.value=g.bumpScale,g.side===qt)p.bumpScale.value*=-1}if(g.normalMap){if(p.normalMap.value=g.normalMap,n(g.normalMap,p.normalMapTransform),p.normalScale.value.copy(g.normalScale),g.side===qt)p.normalScale.value.negate()}if(g.displacementMap)p.displacementMap.value=g.displacementMap,n(g.displacementMap,p.displacementMapTransform),p.displacementScale.value=g.displacementScale,p.displacementBias.value=g.displacementBias;if(g.emissiveMap)p.emissiveMap.value=g.emissiveMap,n(g.emissiveMap,p.emissiveMapTransform);if(g.specularMap)p.specularMap.value=g.specularMap,n(g.specularMap,p.specularMapTransform);if(g.alphaTest>0)p.alphaTest.value=g.alphaTest;let v=t.get(g),{envMap:S,envMapRotation:T}=v;if(S){if(p.envMap.value=S,p.envMapRotation.value.setFromMatrix4(ly.makeRotationFromEuler(T)).transpose(),S.isCubeTexture&&S.isRenderTargetTexture===!1)p.envMapRotation.value.premultiply(jf);p.reflectivity.value=g.reflectivity,p.ior.value=g.ior,p.refractionRatio.value=g.refractionRatio}if(g.lightMap)p.lightMap.value=g.lightMap,p.lightMapIntensity.value=g.lightMapIntensity,n(g.lightMap,p.lightMapTransform);if(g.aoMap)p.aoMap.value=g.aoMap,p.aoMapIntensity.value=g.aoMapIntensity,n(g.aoMap,p.aoMapTransform)}function o(p,g){if(p.diffuse.value.copy(g.color),p.opacity.value=g.opacity,g.map)p.map.value=g.map,n(g.map,p.mapTransform)}function a(p,g){p.dashSize.value=g.dashSize,p.totalSize.value=g.dashSize+g.gapSize,p.scale.value=g.scale}function l(p,g,v,S){if(p.diffuse.value.copy(g.color),p.opacity.value=g.opacity,p.size.value=g.size*v,p.scale.value=S*0.5,g.map)p.map.value=g.map,n(g.map,p.uvTransform);if(g.alphaMap)p.alphaMap.value=g.alphaMap,n(g.alphaMap,p.alphaMapTransform);if(g.alphaTest>0)p.alphaTest.value=g.alphaTest}function c(p,g){if(p.diffuse.value.copy(g.color),p.opacity.value=g.opacity,p.rotation.value=g.rotation,g.map)p.map.value=g.map,n(g.map,p.mapTransform);if(g.alphaMap)p.alphaMap.value=g.alphaMap,n(g.alphaMap,p.alphaMapTransform);if(g.alphaTest>0)p.alphaTest.value=g.alphaTest}function u(p,g){p.specular.value.copy(g.specular),p.shininess.value=Math.max(g.shininess,0.0001)}function h(p,g){if(g.gradientMap)p.gradientMap.value=g.gradientMap}function d(p,g){if(p.metalness.value=g.metalness,g.metalnessMap)p.metalnessMap.value=g.metalnessMap,n(g.metalnessMap,p.metalnessMapTransform);if(p.roughness.value=g.roughness,g.roughnessMap)p.roughnessMap.value=g.roughnessMap,n(g.roughnessMap,p.roughnessMapTransform);if(g.envMap)p.envMapIntensity.value=g.envMapIntensity}function f(p,g,v){if(p.ior.value=g.ior,g.diffuseRoughness>0){if(p.diffuseRoughness.value=g.diffuseRoughness,g.diffuseRoughnessMap)p.diffuseRoughnessMap.value=g.diffuseRoughnessMap,n(g.diffuseRoughnessMap,p.diffuseRoughnessMapTransform)}if(g.sheen>0){if(p.sheenColor.value.copy(g.sheenColor).multiplyScalar(g.sheen),p.sheenRoughness.value=g.sheenRoughness,g.sheenColorMap)p.sheenColorMap.value=g.sheenColorMap,n(g.sheenColorMap,p.sheenColorMapTransform);if(g.sheenRoughnessMap)p.sheenRoughnessMap.value=g.sheenRoughnessMap,n(g.sheenRoughnessMap,p.sheenRoughnessMapTransform)}if(g.clearcoat>0){if(p.clearcoat.value=g.clearcoat,p.clearcoatRoughness.value=g.clearcoatRoughness,g.clearcoatMap)p.clearcoatMap.value=g.clearcoatMap,n(g.clearcoatMap,p.clearcoatMapTransform);if(g.clearcoatRoughnessMap)p.clearcoatRoughnessMap.value=g.clearcoatRoughnessMap,n(g.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform);if(g.clearcoatNormalMap){if(p.clearcoatNormalMap.value=g.clearcoatNormalMap,n(g.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(g.clearcoatNormalScale),g.side===qt)p.clearcoatNormalScale.value.negate()}}if(g.dispersion>0)p.dispersion.value=g.dispersion;if(g.retroreflectivity>0)p.retroreflectivity.value=g.retroreflectivity;if(g.iridescence>0){if(p.iridescence.value=g.iridescence,p.iridescenceIOR.value=g.iridescenceIOR,p.iridescenceThicknessMinimum.value=g.iridescenceThicknessMinimum,p.iridescenceThicknessMaximum.value=g.iridescenceThicknessMaximum,g.iridescenceMap)p.iridescenceMap.value=g.iridescenceMap,n(g.iridescenceMap,p.iridescenceMapTransform);if(g.iridescenceThicknessMap)p.iridescenceThicknessMap.value=g.iridescenceThicknessMap,n(g.iridescenceThicknessMap,p.iridescenceThicknessMapTransform)}if(g.transmission>0){if(p.transmission.value=g.transmission,p.transmissionSamplerMap.value=v.texture,p.transmissionSamplerSize.value.set(v.width,v.height),g.transmissionMap)p.transmissionMap.value=g.transmissionMap,n(g.transmissionMap,p.transmissionMapTransform);if(p.thickness.value=g.thickness,g.thicknessMap)p.thicknessMap.value=g.thicknessMap,n(g.thicknessMap,p.thicknessMapTransform);p.attenuationDistance.value=g.attenuationDistance,p.attenuationColor.value.copy(g.attenuationColor)}if(g.anisotropy>0){if(p.anisotropyVector.value.set(g.anisotropy*Math.cos(g.anisotropyRotation),g.anisotropy*Math.sin(g.anisotropyRotation)),g.anisotropyMap)p.anisotropyMap.value=g.anisotropyMap,n(g.anisotropyMap,p.anisotropyMapTransform)}if(p.specularIntensity.value=g.specularIntensity,p.specularColor.value.copy(g.specularColor),g.specularColorMap)p.specularColorMap.value=g.specularColorMap,n(g.specularColorMap,p.specularColorMapTransform);if(g.specularIntensityMap)p.specularIntensityMap.value=g.specularIntensityMap,n(g.specularIntensityMap,p.specularIntensityMapTransform)}function m(p,g){if(g.matcap)p.matcap.value=g.matcap}function x(p,g){let v=t.get(g).light;p.referencePosition.value.setFromMatrixPosition(v.matrixWorld),p.nearDistance.value=v.shadow.camera.near,p.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function uy(e,t,n,i){let s={},r={};function o(v,S){let T=S.program;i.uniformBlockBinding(v,T,s[v.id])}function a(v,S){let T=s[v.id];if(T===void 0)m(v),T=l(v),s[v.id]=T,v.addEventListener("dispose",p);let A=S.program;i.updateUBOMapping(v,A);let w=t.render.frame;if(r[v.id]!==w)c(v),r[v.id]=w}function l(v){let S=e.createBuffer(),{__size:T,usage:A}=v;return e.bindBuffer(e.UNIFORM_BUFFER,S),e.bufferData(e.UNIFORM_BUFFER,T,A),e.bindBuffer(e.UNIFORM_BUFFER,null),S}function c(v){let S=s[v.id],{uniforms:T,__cache:A}=v;e.bindBuffer(e.UNIFORM_BUFFER,S);for(let w=0,_=T.length;w<_;w++){let E=T[w];if(Array.isArray(E))for(let I=0,k=E.length;I<k;I++)u(E[I],w,I,A);else u(E,w,0,A)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function u(v,S,T,A){if(d(v,S,T,A)===!0){let{__offset:w,value:_}=v;if(Array.isArray(_)){let E=0;for(let I=0;I<_.length;I++){let k=_[I],N=x(k,!0);h(k,v.__data,E),E+=N.storage/Float32Array.BYTES_PER_ELEMENT}}else h(_,v.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,w,v.__data)}}function h(v,S,T){if(typeof v==="number"||typeof v==="boolean")S[T]=v;else if(v.isMatrix3)S[T]=v.elements[0],S[T+1]=v.elements[1],S[T+2]=v.elements[2],S[T+3]=0,S[T+4]=v.elements[3],S[T+5]=v.elements[4],S[T+6]=v.elements[5],S[T+7]=0,S[T+8]=v.elements[6],S[T+9]=v.elements[7],S[T+10]=v.elements[8],S[T+11]=0;else if(ArrayBuffer.isView(v))S.set(v.subarray(0,S.length-T),T);else v.toArray(S,T)}function d(v,S,T,A){let w=v.value,_=S+"_"+T;if(Array.isArray(w)){if(A[_]===void 0)A[_]=[];let E=A[_],I=!1;for(let k=0;k<w.length;k++)if(f(w[k],E,k)===!0)I=!0;return I}return f(w,A,_)}function f(v,S,T){if(S[T]===void 0){if(typeof v==="number"||typeof v==="boolean")S[T]=v;else if(ArrayBuffer.isView(v))S[T]=v.slice();else S[T]=v.clone();return!0}else{let A=S[T];if(typeof v==="number"||typeof v==="boolean"){if(A!==v)return S[T]=v,!0}else if(ArrayBuffer.isView(v))return!0;else if(A.equals(v)===!1)return A.copy(v),!0}return!1}function m(v){let S=v.uniforms,T=0,A=16;for(let _=0,E=S.length;_<E;_++){let I=Array.isArray(S[_])?S[_]:[S[_]];for(let k=0,N=I.length;k<N;k++){let V=I[k],Q=Array.isArray(V.value)?V.value:[V.value],C=Array.isArray(S[_])||Array.isArray(V.value),q=T;for(let F=0,re=Q.length;F<re;F++){let W=Q[F],J=x(W,C),ne=T%A,Me=ne%J.boundary,Z=ne+Me;if(T+=Me,Z!==0&&A-Z<J.storage)T+=A-Z;if(F===0)q=T;T+=J.storage}let j=V.type==="int"?Int32Array:V.type==="uint"?Uint32Array:Float32Array;V.__data=new j((T-q)/Float32Array.BYTES_PER_ELEMENT),V.__offset=q}}let w=T%A;if(w>0)T+=A-w;return v.__size=T,v.__cache={},this}function x(v,S){let T={boundary:0,storage:0};if(typeof v==="number"||typeof v==="boolean")T.boundary=4,T.storage=4;else if(v.isVector2)T.boundary=8,T.storage=8;else if(v.isVector3||v.isColor)T.boundary=16,T.storage=12;else if(v.isVector4)T.boundary=16,T.storage=16;else if(v.isMatrix3)T.boundary=16,T.storage=48;else if(v.isMatrix4)T.boundary=16,T.storage=64;else if(v.isTexture)we("WebGLRenderer: Texture samplers can not be part of an uniforms group.");else if(ArrayBuffer.isView(v))T.boundary=16,T.storage=v.byteLength;else we("WebGLRenderer: Unsupported uniform value type.",v);if(S===!0)T.boundary=16,T.storage=Math.ceil(T.storage/16)*16;return T}function p(v){let S=v.target;S.removeEventListener("dispose",p),e.deleteBuffer(s[S.id]),delete s[S.id],delete r[S.id]}function g(){for(let v in s)e.deleteBuffer(s[v]);s={},r={}}return{bind:o,update:a,dispose:g}}var hy=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),Wn=null;function dy(){if(Wn===null)Wn=new Or(hy,16,16,is,kn),Wn.name="DFG_LUT",Wn.minFilter=Yt,Wn.magFilter=Yt,Wn.wrapS=Hs,Wn.wrapT=Hs,Wn.generateMipmaps=!1,Wn.needsUpdate=!0;return Wn}class mu{constructor(e={}){let{canvas:t=Kd(),context:n=null,depth:i=!0,stencil:s=!1,alpha:r=!1,antialias:o=!1,premultipliedAlpha:a=!0,preserveDrawingBuffer:l=!1,powerPreference:c="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:h=!1,outputBufferType:d=In}=e;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=r;let m=d,x=new Set([rc,sc,ic]),p=new Set([In,bi,Pr,ns,tc,nc]),g=new Uint32Array(4),v=new Int32Array(4),S={textures:[],min:[],max:[],resolution:[]},T=null,A=null,w=[],_=[],E=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Vn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let I=this,k=!1,N=null,V=null,Q=null,C=null;this._outputColorSpace=Nn;let q=0,j=0,F=null,re=-1,W=null,J=new ut,ne=new ut,Me=null,Z=new xe(0),te=0,{width:ye,height:Ne}=t,De=1,_e=null,it=null,We=new ut(0,0,ye,Ne),Be=new ut(0,0,ye,Ne),ht=!1,et=new Qi,gt=new ga,Mt=!1,sn=!1,un=new Re,Et=new R,Vt=new ut,rn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},on=!1;function Sn(){return F===null?De:1}let D=n;function bn(y,L){return t.getContext(y,L)}let lt,Lt,fe,pt,Oe,Ve,kt,b,M,U,ee,K,oe,le,G,Y,ae,P,X,z,ie,se,de;try{let y={alpha:!0,depth:i,stencil:s,antialias:o,premultipliedAlpha:a,preserveDrawingBuffer:l,powerPreference:c,failIfMajorPerformanceCaveat:u};if("setAttribute"in t)t.setAttribute("data-engine",`three.js r${ai}`);if(t.addEventListener("webglcontextlost",pe,!1),t.addEventListener("webglcontextrestored",Ie,!1),t.addEventListener("webglcontextcreationerror",ze,!1),D===null){if(D=bn("webgl2",y),D===null)if(bn("webgl2"))throw Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.");else throw Error("THREE.WebGLRenderer: Error creating WebGL context.")}Le()}catch(y){throw t.removeEventListener("webglcontextlost",pe,!1),t.removeEventListener("webglcontextrestored",Ie,!1),t.removeEventListener("webglcontextcreationerror",ze,!1),He("WebGLRenderer: "+y.message),y}function Le(){if(lt=new Tx(D),lt.init(),ie=new ry(D,lt),Lt=new dx(D,lt,e,ie),fe=new iy(D,lt),Lt.reversedDepthBuffer&&h)fe.buffers.depth.setReversed(!0);V=D.createFramebuffer(),Q=D.createFramebuffer(),C=D.createFramebuffer(),pt=new Rx(D),Oe=new zM,Ve=new sy(D,lt,fe,Oe,Lt,ie,pt),kt=new Ex(I),b=new wg(D),se=new ux(D,b),M=new Sx(D,b,pt,se),U=new wx(D,M,b,se,pt),P=new Ax(D,Lt,Ve),G=new fx(Oe),ee=new GM(I,kt,lt,Lt,se,G),K=new cy(I,Oe),oe=new XM,le=new KM(lt),ae=new cx(I,kt,fe,U,f,a),Y=new ny(I,U,Lt),de=new uy(D,pt,Lt,fe),X=new hx(D,lt,pt),z=new bx(D,lt,pt),pt.programs=ee.programs,I.capabilities=Lt,I.extensions=lt,I.properties=Oe,I.renderLists=oe,I.shadowMap=Y,I.state=fe,I.info=pt}if(m!==In)E=new Px(m,t.width,t.height,o,i,s);let Ae=new Zf(I,D);this.xr=Ae,this.getContext=function(){return D},this.getContextAttributes=function(){return D.getContextAttributes()},this.forceContextLoss=function(){let y=lt.get("WEBGL_lose_context");if(y)y.loseContext()},this.forceContextRestore=function(){let y=lt.get("WEBGL_lose_context");if(y)y.restoreContext()},this.getPixelRatio=function(){return De},this.setPixelRatio=function(y){if(y===void 0)return;De=y,this.setSize(ye,Ne,!1)},this.getSize=function(y){return y.set(ye,Ne)},this.setSize=function(y,L,B=!0){if(Ae.isPresenting){we("WebGLRenderer: Can't change size while VR device is presenting.");return}if(ye=y,Ne=L,t.width=Math.floor(y*De),t.height=Math.floor(L*De),B===!0)t.style.width=y+"px",t.style.height=L+"px";if(E!==null)E.setSize(t.width,t.height);this.setViewport(0,0,y,L)},this.getDrawingBufferSize=function(y){return y.set(ye*De,Ne*De).floor()},this.setDrawingBufferSize=function(y,L,B){ye=y,Ne=L,De=B,t.width=Math.floor(y*B),t.height=Math.floor(L*B),this.setViewport(0,0,y,L)},this.setEffects=function(y){if(m===In){He("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(y){for(let L=0;L<y.length;L++)if(y[L].isOutputPass===!0){we("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}E.setEffects(y||[])},this.getCurrentViewport=function(y){return y.copy(J)},this.getViewport=function(y){return y.copy(We)},this.setViewport=function(y,L,B,O){if(y.isVector4)We.set(y.x,y.y,y.z,y.w);else We.set(y,L,B,O);fe.viewport(J.copy(We).multiplyScalar(Sn()).round())},this.getScissor=function(y){return y.copy(Be)},this.setScissor=function(y,L,B,O){if(y.isVector4)Be.set(y.x,y.y,y.z,y.w);else Be.set(y,L,B,O);fe.scissor(ne.copy(Be).multiplyScalar(Sn()).round())},this.getScissorTest=function(){return ht},this.setScissorTest=function(y){fe.setScissorTest(ht=y)},this.setOpaqueSort=function(y){_e=y},this.setTransparentSort=function(y){it=y},this.getClearColor=function(y){return y.copy(ae.getClearColor())},this.setClearColor=function(){ae.setClearColor(...arguments)},this.getClearAlpha=function(){return ae.getClearAlpha()},this.setClearAlpha=function(){ae.setClearAlpha(...arguments)},this.clear=function(y=!0,L=!0,B=!0){let O=0;if(y){let H=!1;if(F!==null){let ce=F.texture.format;H=x.has(ce)}if(H){let ce=F.texture.type,ve=p.has(ce),ue=ae.getClearColor(),ge=ae.getClearAlpha(),{r:Se,g:ke,b:Je}=ue;if(ve)g[0]=Se,g[1]=ke,g[2]=Je,g[3]=ge,D.clearBufferuiv(D.COLOR,0,g);else v[0]=Se,v[1]=ke,v[2]=Je,v[3]=ge,D.clearBufferiv(D.COLOR,0,v)}else O|=D.COLOR_BUFFER_BIT}if(L)O|=D.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0);if(B)O|=D.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295);if(O!==0)D.clear(O)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(y){y.setRenderer(this),N=y},this.dispose=function(){t.removeEventListener("webglcontextlost",pe,!1),t.removeEventListener("webglcontextrestored",Ie,!1),t.removeEventListener("webglcontextcreationerror",ze,!1),ae.dispose(),oe.dispose(),le.dispose(),Ve.dispose(),Oe.dispose(),kt.dispose(),U.dispose(),M.dispose(),se.dispose(),de.dispose(),ee.dispose(),Ae.dispose(),Ae.removeEventListener("sessionstart",ch),Ae.removeEventListener("sessionend",uh),Wi.stop()};function pe(y){y.preventDefault(),Rr("WebGLRenderer: Context Lost."),k=!0}function Ie(){Rr("WebGLRenderer: Context Restored."),k=!1;let y=pt.autoReset,L=Y.enabled,B=Y.autoUpdate,O=Y.needsUpdate,H=Y.type;Le(),pt.autoReset=y,Y.enabled=L,Y.autoUpdate=B,Y.needsUpdate=O,Y.type=H}function ze(y){He("WebGLRenderer: A WebGL context could not be created. Reason: ",y.statusMessage)}function me(y){let L=y.target;L.removeEventListener("dispose",me),ct(L)}function ct(y){It(y),Oe.remove(y)}function It(y){let L=Oe.get(y).programs;if(L!==void 0){if(L.forEach(function(B){ee.releaseProgram(B)}),y.isShaderMaterial)ee.releaseShaderCache(y)}}this.renderBufferDirect=function(y,L,B,O,H,ce){if(L===null)L=rn;let ve=H.isMesh&&H.matrixWorld.determinantAffine()<0,ue=Tm(y,L,B,O,H);fe.setMaterial(O,ve);let ge=B.index,Se=1;if(O.wireframe===!0){if(ge=M.getWireframeAttribute(B),ge===void 0)return;Se=2}let ke=B.drawRange,Je=B.attributes.position,Ee=ke.start*Se,Ke=(ke.start+ke.count)*Se;if(ce!==null)Ee=Math.max(Ee,ce.start*Se),Ke=Math.min(Ke,(ce.start+ce.count)*Se);if(ge!==null)Ee=Math.max(Ee,0),Ke=Math.min(Ke,ge.count);else if(Je!==void 0&&Je!==null)Ee=Math.max(Ee,0),Ke=Math.min(Ke,Je.count);let Tt=Ke-Ee;if(Tt<0||Tt===1/0)return;se.setup(H,O,ue,B,ge);let mt,dt=X;if(ge!==null)mt=b.get(ge),dt=z,dt.setIndex(mt);if(H.isMesh)if(O.wireframe===!0)fe.setLineWidth(O.wireframeLinewidth*Sn()),dt.setMode(D.LINES);else dt.setMode(D.TRIANGLES);else if(H.isLine){let Gt=O.linewidth;if(Gt===void 0)Gt=1;if(fe.setLineWidth(Gt*Sn()),H.isLineSegments)dt.setMode(D.LINES);else if(H.isLineLoop)dt.setMode(D.LINE_LOOP);else dt.setMode(D.LINE_STRIP)}else if(H.isPoints)dt.setMode(D.POINTS);else if(H.isSprite)dt.setMode(D.TRIANGLES);if(H.isBatchedMesh)if(!lt.get("WEBGL_multi_draw")){let{_multiDrawStarts:Gt,_multiDrawCounts:Te,_multiDrawCount:$t}=H,st=ge?b.get(ge).bytesPerElement:1,Xi=Oe.get(O).currentProgram.getUniforms();for(let zt=0;zt<$t;zt++)Xi.setValue(D,"_gl_DrawID",zt),dt.render(Gt[zt]/st,Te[zt])}else dt.renderMultiDraw(H._multiDrawStarts,H._multiDrawCounts,H._multiDrawCount);else if(H.isInstancedMesh)dt.renderInstances(Ee,Tt,H.count);else if(B.isInstancedBufferGeometry){let Gt=B._maxInstanceCount!==void 0?B._maxInstanceCount:1/0,Te=Math.min(B.instanceCount,Gt);dt.renderInstances(Ee,Tt,Te)}else dt.render(Ee,Tt)};function $n(y,L,B,O){if(N!==null&&y.isNodeMaterial)N.setObject(O,y);if(Mt===!0)G.setState(y,B,!1);if(y.transparent===!0&&y.side===en&&y.forceSinglePass===!1)y.side=qt,y.needsUpdate=!0,pr(y,L,O),y.side=Si,y.needsUpdate=!0,pr(y,L,O),y.side=en;else pr(y,L,O)}this.compile=function(y,L,B=null){if(B===null)B=y;if(N!==null)N.renderStart(y,L,B);if(A=le.get(B),A.init(L),_.push(A),B.traverseVisible(function(H){if(H.isLight&&H.layers.test(L.layers)){if(A.pushLight(H),H.castShadow)A.pushShadow(H)}}),y!==B)y.traverseVisible(function(H){if(H.isLight&&H.layers.test(L.layers)){if(A.pushLight(H),H.castShadow)A.pushShadow(H)}});if(A.setupLights(),N!==null)N.updateLights(A.state.lightsArray);if(sn=this.localClippingEnabled,Mt=G.init(this.clippingPlanes,sn),Mt===!0)G.setGlobalState(this.clippingPlanes,L);if(N!==null)Y.render(A.state.shadowsArray,B,L);let O=new Set;if(y.traverse(function(H){if(!(H.isMesh||H.isPoints||H.isLine||H.isSprite))return;let ce=H.material;if(ce)if(Array.isArray(ce))for(let ve=0;ve<ce.length;ve++){let ue=ce[ve];$n(ue,B,L,H),O.add(ue)}else $n(ce,B,L,H),O.add(ce)}),A=_.pop(),N!==null)N.renderEnd();return O},this.compileAsync=function(y,L,B=null){let O=this.compile(y,L,B);return new Promise((H)=>{function ce(){if(O.forEach(function(ve){let ge=Oe.get(ve).currentProgram;if(ge===void 0||ge.isReady())O.delete(ve)}),O.size===0){H(y);return}setTimeout(ce,10)}if(lt.get("KHR_parallel_shader_compile")!==null)ce();else setTimeout(ce,10)})};let ml=null;function vm(y){if(ml)ml(y)}function ch(){Wi.stop()}function uh(){Wi.start()}let Wi=new If;if(Wi.setAnimationLoop(vm),typeof self<"u")Wi.setContext(self);this.setAnimationLoop=function(y){ml=y,Ae.setAnimationLoop(y),y===null?Wi.stop():Wi.start()},Ae.addEventListener("sessionstart",ch),Ae.addEventListener("sessionend",uh),this.render=function(y,L){if(L!==void 0&&L.isCamera!==!0){He("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(k===!0)return;if(N!==null)N.renderStart(y,L);let B=Ae.enabled===!0&&Ae.isPresenting===!0,O=E!==null&&(F===null||B)&&E.begin(I,F);if(y.matrixWorldAutoUpdate===!0)y.updateMatrixWorld();if(L.parent===null&&L.matrixWorldAutoUpdate===!0)L.updateMatrixWorld();if(Ae.enabled===!0&&Ae.isPresenting===!0&&(E===null||E.isCompositing()===!1)){if(Ae.cameraAutoUpdate===!0)Ae.updateCamera(L);L=Ae.getCamera()}if(y.isScene===!0)y.onBeforeRender(I,y,L,F);if(A=le.get(y,_.length),A.init(L),A.state.textureUnits=Ve.getTextureUnits(),_.push(A),un.multiplyMatrices(L.projectionMatrix,L.matrixWorldInverse),L.isArrayCamera)gt.setFromArrayCamera(L);else et.setFromProjectionMatrix(un,Wc,L.reversedDepth);if(sn=this.localClippingEnabled,Mt=G.init(this.clippingPlanes,sn),T=oe.get(y,w.length),T.init(),w.push(T),this.info.render.frame++,Ae.enabled===!0&&Ae.isPresenting===!0){let ve=I.xr.getDepthSensingMesh();if(ve!==null)gl(ve,L,-1/0,I.sortObjects)}if(gl(y,L,0,I.sortObjects),T.finish(),N!==null)N.updateLights(A.state.lightsArray);if(I.sortObjects===!0)T.sort(_e,it);if(on=Ae.enabled===!1||Ae.isPresenting===!1||Ae.hasDepthSensing()===!1,on)ae.addToRenderList(T,y);if(this.info.autoReset===!0)this.info.reset();if(Mt===!0)G.beginShadows();let H=A.state.shadowsArray;if(Y.render(H,y,L),Mt===!0)G.endShadows();if((O&&E.hasRenderPass())===!1){let ve=T.opaque,ue=T.transmissive;if(A.setupLights(),L.isArrayCamera){let ge=L.cameras;if(ue.length>0)for(let Se=0,ke=ge.length;Se<ke;Se++){let Je=ge[Se];dh(ve,ue,y,Je)}if(on)ae.render(y);for(let Se=0,ke=ge.length;Se<ke;Se++){let Je=ge[Se];hh(T,y,Je,Je.viewport)}}else{if(ue.length>0)dh(ve,ue,y,L);if(on)ae.render(y);hh(T,y,L)}}if(F!==null&&j===0)Ve.updateMultisampleRenderTarget(F),Ve.updateRenderTargetMipmap(F);if(O)E.end(I);if(y.isScene===!0)y.onAfterRender(I,y,L);if(se.resetDefaultState(),re=-1,W=null,_.pop(),_.length>0){if(A=_[_.length-1],Ve.setTextureUnits(A.state.textureUnits),Mt===!0)G.setGlobalState(I.clippingPlanes,A.state.camera)}else A=null;if(w.pop(),w.length>0)T=w[w.length-1];else T=null;if(N!==null)N.renderEnd()};function gl(y,L,B,O){if(y.visible===!1)return;if(y.layers.test(L.layers)){if(y.isGroup)B=y.renderOrder;else if(y.isLOD){if(y.autoUpdate===!0)y.update(L)}else if(y.isLight){if(A.pushLight(y),y.castShadow)A.pushShadow(y)}else if(y.isSprite){let ve=L.isArrayCamera?gt:et;if(!y.frustumCulled||y.intersectsFrustum(ve)){if(O)Vt.setFromMatrixPosition(y.matrixWorld).applyMatrix4(un);let ue=U.update(y),ge=y.material;if(ge.visible)T.push(y,ue,ge,B,Vt.z,null,L)}}else if(y.isMesh||y.isLine||y.isPoints){let ve=L.isArrayCamera?gt:et;if(!y.frustumCulled||y.intersectsFrustum(ve)){let ue=U.update(y),ge=y.material;if(O){if(y.boundingSphere!==void 0){if(y.boundingSphere===null)y.computeBoundingSphere();Vt.copy(y.boundingSphere.center)}else{if(ue.boundingSphere===null)ue.computeBoundingSphere();Vt.copy(ue.boundingSphere.center)}Vt.applyMatrix4(y.matrixWorld).applyMatrix4(un)}if(Array.isArray(ge)){let Se=ue.groups;for(let ke=0,Je=Se.length;ke<Je;ke++){let Ee=Se[ke],Ke=ge[Ee.materialIndex];if(Ke&&Ke.visible)T.push(y,ue,Ke,B,Vt.z,Ee,L)}}else if(ge.visible)T.push(y,ue,ge,B,Vt.z,null,L)}}}let ce=y.children;for(let ve=0,ue=ce.length;ve<ue;ve++)gl(ce[ve],L,B,O)}function hh(y,L,B,O){let{opaque:H,transmissive:ce,transparent:ve}=y;if(A.setupLightsView(B),Mt===!0)G.setGlobalState(I.clippingPlanes,B);if(O)fe.viewport(J.copy(O));if(H.length>0)To(H,L,B);if(ce.length>0)To(ce,L,B);if(ve.length>0)To(ve,L,B);fe.buffers.depth.setTest(!0),fe.buffers.depth.setMask(!0),fe.buffers.color.setMask(!0),fe.setPolygonOffset(!1)}function dh(y,L,B,O){if((B.isScene===!0?B.overrideMaterial:null)!==null)return;if(A.state.transmissionRenderTarget[O.id]===void 0){let Ee=lt.has("EXT_color_buffer_half_float")||lt.has("EXT_color_buffer_float");A.state.transmissionRenderTarget[O.id]=new Mn(1,1,{generateMipmaps:!0,type:Ee?kn:In,minFilter:Ln,samples:Math.max(4,Lt.samples),stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:qe.workingColorSpace})}let ce=A.state.transmissionRenderTarget[O.id],ve=O.viewport||J;ce.setSize(ve.z*I.transmissionResolutionScale,ve.w*I.transmissionResolutionScale);let ue=I.getRenderTarget(),ge=I.getActiveCubeFace(),Se=I.getActiveMipmapLevel();if(I.setRenderTarget(ce),I.getClearColor(Z),te=I.getClearAlpha(),te<1)I.setClearColor(16777215,0.5);if(I.clear(),on)ae.render(B);let ke=I.toneMapping;I.toneMapping=Vn;let Je=O.viewport;if(O.viewport!==void 0)O.viewport=void 0;if(A.setupLightsView(O),Mt===!0)G.setGlobalState(I.clippingPlanes,O);if(To(y,B,O),Ve.updateMultisampleRenderTarget(ce),Ve.updateRenderTargetMipmap(ce),lt.has("WEBGL_multisampled_render_to_texture")===!1){let Ee=!1;for(let Ke=0,Tt=L.length;Ke<Tt;Ke++){let mt=L[Ke],{object:dt,geometry:Gt,material:Te,group:$t}=mt;if(Te.side===en&&dt.layers.test(O.layers)){let st=Te.side;Te.side=qt,Te.needsUpdate=!0,fh(dt,B,O,Gt,Te,$t),Te.side=st,Te.needsUpdate=!0,Ee=!0}}if(Ee===!0)Ve.updateMultisampleRenderTarget(ce),Ve.updateRenderTargetMipmap(ce)}if(I.setRenderTarget(ue,ge,Se),I.setClearColor(Z,te),Je!==void 0)O.viewport=Je;I.toneMapping=ke}function To(y,L,B){let O=L.isScene===!0?L.overrideMaterial:null;for(let H=0,ce=y.length;H<ce;H++){let ve=y[H],{object:ue,geometry:ge,group:Se}=ve,ke=ve.material;if(ke.allowOverride===!0&&O!==null)ke=O;if(ue.layers.test(B.layers))fh(ue,L,B,ge,ke,Se)}}function fh(y,L,B,O,H,ce){if(N!==null&&H.isNodeMaterial)N.setObject(y,H);if(y.onBeforeRender(I,L,B,O,H,ce),y.modelViewMatrix.multiplyMatrices(B.matrixWorldInverse,y.matrixWorld),y.normalMatrix.getNormalMatrix(y.modelViewMatrix),H.onBeforeRender(I,L,B,O,y,ce),H.transparent===!0&&H.side===en&&H.forceSinglePass===!1)H.side=qt,H.needsUpdate=!0,I.renderBufferDirect(B,L,O,H,y,ce),H.side=Si,H.needsUpdate=!0,I.renderBufferDirect(B,L,O,H,y,ce),H.side=en;else I.renderBufferDirect(B,L,O,H,y,ce);y.onAfterRender(I,L,B,O,H,ce)}function ph(y){let L=0;for(let B of y)if(B.texture!==null)L++;return L}function pr(y,L,B){if(L.isScene!==!0)L=rn;let O=Oe.get(y),H=A.state.lights,ce=A.state.shadowsArray,ve=H.state.version,ue=ee.getParameters(y,H.state,ce,L,B,A.state.lightProbeGridArray),ge=ee.getProgramCacheKey(ue),Se=O.programs;O.environment=y.isMeshStandardMaterial||y.isMeshLambertMaterial||y.isMeshPhongMaterial?L.environment:null,O.fog=L.fog;let ke=y.isMeshStandardMaterial||y.isMeshLambertMaterial&&!y.envMap||y.isMeshPhongMaterial&&!y.envMap;if(O.envMap=kt.get(y.envMap||O.environment,ke),O.envMapRotation=O.environment!==null&&y.envMap===null?L.environmentRotation:y.envMapRotation,Se===void 0)y.addEventListener("dispose",me),Se=new Map,O.programs=Se,O.programVariants=new Map;let Je=Se.get(ge);if(Je!==void 0){if(O.currentProgram===Je&&O.lightsStateVersion===ve)return gh(y,ue),Je}else{if(ue.uniforms=ee.getUniforms(y),N!==null&&y.isNodeMaterial)N.build(y,B,ue);y.onBeforeCompile(ue,I),Je=ee.acquireProgram(ue,ge),Se.set(ge,Je),O.uniforms=ue.uniforms}let Ee=O.uniforms;if(!y.isShaderMaterial&&!y.isRawShaderMaterial||y.clipping===!0)Ee.clippingPlanes=G.uniform;if(gh(y,ue),O.needsLights=bm(y),O.lightsStateVersion=ve,O.needsLights)Ee.ambientLightColor.value=H.state.ambient,Ee.lightProbe.value=H.state.probe,Ee.sunLights.value=H.state.sun,Ee.sunLightShadows.value=H.state.sunShadow,Ee.directionalLights.value=H.state.directional,Ee.directionalLightShadows.value=H.state.directionalShadow,Ee.spotLights.value=H.state.spot,Ee.spotLightShadows.value=H.state.spotShadow,Ee.rectAreaLights.value=H.state.rectArea,Ee.ltc_1.value=H.state.rectAreaLTC1,Ee.ltc_2.value=H.state.rectAreaLTC2,Ee.pointLights.value=H.state.point,Ee.pointLightShadows.value=H.state.pointShadow,Ee.hemisphereLights.value=H.state.hemi,Ee.sunShadowMatrix.value=H.state.sunShadowMatrix,Ee.sunShadowCascade.value=H.state.sunShadowCascade,Ee.directionalShadowMatrix.value=H.state.directionalShadowMatrix,Ee.spotLightMatrix.value=H.state.spotLightMatrix,Ee.spotLightMap.value=H.state.spotLightMap,Ee.pointShadowMatrix.value=H.state.pointShadowMatrix;return O.numLightProbeGrids=ph(A.state.lightProbeGridArray),O.currentProgram=Je,O.uniformsList=null,Je}function Em(y,L,B,O,H){let ce=Oe.get(y),ve=ce.currentProgram.id+","+O+","+H,ue=ce.programVariants.get(ve);if(ue===void 0)ue=pr(y,L,B),ce.programVariants.set(ve,ue);else ce.currentProgram=ue,ce.uniformsList=null,ce.outputColorSpace=O,ce.toneMapping=H;return ue}function mh(y){if(y.uniformsList===null){let L=y.currentProgram.getUniforms();y.uniformsList=qr.seqWithValue(L.seq,y.uniforms)}return y.uniformsList}function gh(y,L){let B=Oe.get(y);B.outputColorSpace=L.outputColorSpace,B.batching=L.batching,B.batchingColor=L.batchingColor,B.instancing=L.instancing,B.instancingColor=L.instancingColor,B.instancingMorph=L.instancingMorph,B.skinning=L.skinning,B.morphTargets=L.morphTargets,B.morphNormals=L.morphNormals,B.morphColors=L.morphColors,B.morphTargetsCount=L.morphTargetsCount,B.numClippingPlanes=L.numClippingPlanes,B.numIntersection=L.numClipIntersection,B.vertexAlphas=L.vertexAlphas,B.vertexTangents=L.vertexTangents,B.toneMapping=L.toneMapping}function Tm(y,L,B,O,H){if(L.isScene!==!0)L=rn;Ve.resetTextureUnits();let ce=L.fog,ve=O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial?L.environment:null,ue=F===null?I.outputColorSpace:F.isXRRenderTarget===!0?F.texture.colorSpace:qe.workingColorSpace,ge=O.isMeshStandardMaterial||O.isMeshLambertMaterial&&!O.envMap||O.isMeshPhongMaterial&&!O.envMap,Se=kt.get(O.envMap||ve,ge),ke=O.vertexColors===!0&&!!B.attributes.color&&B.attributes.color.itemSize===4,Je=!!B.attributes.tangent&&(!!O.normalMap||O.anisotropy>0),Ee=!!B.morphAttributes.position,Ke=!!B.morphAttributes.normal,Tt=!!B.morphAttributes.color,mt=Vn;if(O.toneMapped){if(F===null||F.isXRRenderTarget===!0)mt=I.toneMapping}let dt=B.morphAttributes.position||B.morphAttributes.normal||B.morphAttributes.color,Gt=dt!==void 0?dt.length:0,Te=Oe.get(O),$t=A.state.lights;if(Mt===!0){if(sn===!0||y!==W){let _t=y===W&&O.id===re;G.setState(O,y,_t)}}let st=!1,Xi=!1;if(O.version===Te.__version){if(Te.needsLights&&Te.lightsStateVersion!==$t.state.version)st=!0;else if(H.isBatchedMesh&&Te.batching===!1)st=!0;else if(!H.isBatchedMesh&&Te.batching===!0)st=!0;else if(H.isBatchedMesh&&Te.batchingColor===!0&&H._colorsTexture===null)st=!0;else if(H.isBatchedMesh&&Te.batchingColor===!1&&H._colorsTexture!==null)st=!0;else if(H.isInstancedMesh&&Te.instancing===!1)st=!0;else if(!H.isInstancedMesh&&Te.instancing===!0)st=!0;else if(H.isSkinnedMesh&&Te.skinning===!1)st=!0;else if(!H.isSkinnedMesh&&Te.skinning===!0)st=!0;else if(H.isInstancedMesh&&Te.instancingColor===!0&&H.instanceColor===null)st=!0;else if(H.isInstancedMesh&&Te.instancingColor===!1&&H.instanceColor!==null)st=!0;else if(H.isInstancedMesh&&Te.instancingMorph===!0&&H.morphTexture===null)st=!0;else if(H.isInstancedMesh&&Te.instancingMorph===!1&&H.morphTexture!==null)st=!0;else if(Te.envMap!==Se)st=!0;else if(O.fog===!0&&Te.fog!==ce)st=!0;else if(Te.numClippingPlanes!==void 0&&(Te.numClippingPlanes!==G.numPlanes||Te.numIntersection!==G.numIntersection))st=!0;else if(Te.vertexAlphas!==ke)st=!0;else if(Te.vertexTangents!==Je)st=!0;else if(Te.morphTargets!==Ee)st=!0;else if(Te.morphNormals!==Ke)st=!0;else if(Te.morphColors!==Tt)st=!0;else if(Te.morphTargetsCount!==Gt)st=!0;else if(Te.numLightProbeGrids!==ph(A.state.lightProbeGridArray))st=!0;else if(Te.outputColorSpace!==ue||Te.toneMapping!==mt)Xi=!0}else st=!0,Te.__version=O.version;let zt=Te.currentProgram;if(st===!0||Xi===!0){if(zt=Xi===!0?Em(O,L,H,ue,mt):pr(O,L,H),N&&O.isNodeMaterial)N.onUpdateProgram(O,zt,Te)}let So=!1,pi=!1,qi=!1,nt=zt.getUniforms(),Ft=Te.uniforms;if(fe.useProgram(zt.program))So=!0,pi=!0,qi=!0;if(O.id!==re)re=O.id,pi=!0;if(So||W!==y){if(fe.buffers.depth.getReversed()&&y.reversedDepth!==!0)y._reversedDepth=!0,y.updateProjectionMatrix();nt.setValue(D,"projectionMatrix",y.projectionMatrix),nt.setValue(D,"viewMatrix",y.matrixWorldInverse);let Nt=nt.map.cameraPosition;if(Nt!==void 0)Nt.setValue(D,Et.setFromMatrixPosition(y.matrixWorld));if(Lt.logarithmicDepthBuffer)nt.setValue(D,"logDepthBufFC",2/(Math.log(y.far+1)/Math.LN2));if(O.isMeshPhongMaterial||O.isMeshToonMaterial||O.isMeshLambertMaterial||O.isMeshBasicMaterial||O.isMeshStandardMaterial||O.isShaderMaterial)nt.setValue(D,"isOrthographic",y.isOrthographicCamera===!0);if(W!==y)W=y,pi=!0,qi=!0}if(Te.needsLights){if($t.state.sunShadowMap.length>0)nt.setValue(D,"sunShadowMap",$t.state.sunShadowMap,Ve);if($t.state.directionalShadowMap.length>0)nt.setValue(D,"directionalShadowMap",$t.state.directionalShadowMap,Ve);if($t.state.spotShadowMap.length>0)nt.setValue(D,"spotShadowMap",$t.state.spotShadowMap,Ve);if($t.state.pointShadowMap.length>0)nt.setValue(D,"pointShadowMap",$t.state.pointShadowMap,Ve)}if(H.isSkinnedMesh){nt.setOptional(D,H,"bindMatrix"),nt.setOptional(D,H,"bindMatrixInverse");let _t=H.skeleton;if(_t){if(_t.boneTexture===null)_t.computeBoneTexture();nt.setValue(D,"boneTexture",_t.boneTexture,Ve)}}if(H.isBatchedMesh){if(nt.setOptional(D,H,"batchingTexture"),nt.setValue(D,"batchingTexture",H._matricesTexture,Ve),nt.setOptional(D,H,"batchingIdTexture"),nt.setValue(D,"batchingIdTexture",H._indirectTexture,Ve),nt.setOptional(D,H,"batchingColorTexture"),H._colorsTexture!==null)nt.setValue(D,"batchingColorTexture",H._colorsTexture,Ve)}let Rn=B.morphAttributes;if(Rn.position!==void 0||Rn.normal!==void 0||Rn.color!==void 0)P.update(H,B,zt);if(pi||Te.receiveShadow!==H.receiveShadow)Te.receiveShadow=H.receiveShadow,nt.setValue(D,"receiveShadow",H.receiveShadow);if((O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial)&&O.envMap===null&&L.environment!==null)Ft.envMapIntensity.value=L.environmentIntensity;if(Ft.dfgLUT!==void 0)Ft.dfgLUT.value=dy();if(pi){if(nt.setValue(D,"toneMappingExposure",I.toneMappingExposure),Te.needsLights)Sm(Ft,qi);if(ce&&O.fog===!0)K.refreshFogUniforms(Ft,ce);if(K.refreshMaterialUniforms(Ft,O,De,Ne,A.state.transmissionRenderTarget[y.id]),Te.needsLights&&Te.numLightProbeGrids>0){let _t=S,Nt=0;for(let Qn of A.state.lightProbeGridArray){if(Qn.texture===null)continue;_t.textures[Nt]=Qn.texture,_t.min[Nt]=Qn.boundingBox.min,_t.max[Nt]=Qn.boundingBox.max,_t.resolution[Nt]=Qn.resolution,Nt++}for(let Qn in _t)_t[Qn].length=Nt;Ft.probesSH.value=_t.textures,Ft.probesMin.value=_t.min,Ft.probesMax.value=_t.max,Ft.probesResolution.value=_t.resolution}qr.upload(D,mh(Te),Ft,Ve)}if(O.isShaderMaterial&&O.uniformsNeedUpdate===!0)qr.upload(D,mh(Te),Ft,Ve),O.uniformsNeedUpdate=!1;if(O.isSpriteMaterial)nt.setValue(D,"center",H.center);if(nt.setValue(D,"modelViewMatrix",H.modelViewMatrix),nt.setValue(D,"normalMatrix",H.normalMatrix),nt.setValue(D,"modelMatrix",H.matrixWorld),O.uniformsGroups!==void 0){let _t=O.uniformsGroups;for(let Nt=0,Qn=_t.length;Nt<Qn;Nt++){let xh=_t[Nt];de.update(xh,zt),de.bind(xh,zt)}}return zt}function Sm(y,L){y.ambientLightColor.needsUpdate=L,y.lightProbe.needsUpdate=L,y.sunLights.needsUpdate=L,y.sunLightShadows.needsUpdate=L,y.directionalLights.needsUpdate=L,y.directionalLightShadows.needsUpdate=L,y.pointLights.needsUpdate=L,y.pointLightShadows.needsUpdate=L,y.spotLights.needsUpdate=L,y.spotLightShadows.needsUpdate=L,y.rectAreaLights.needsUpdate=L,y.hemisphereLights.needsUpdate=L}function bm(y){return y.isMeshLambertMaterial||y.isMeshToonMaterial||y.isMeshPhongMaterial||y.isMeshStandardMaterial||y.isShadowMaterial||y.isShaderMaterial&&y.lights===!0}this.getActiveCubeFace=function(){return q},this.getActiveMipmapLevel=function(){return j},this.getRenderTarget=function(){return F},this.setRenderTargetTextures=function(y,L,B){let O=Oe.get(y);if(O.__autoAllocateDepthBuffer=y.resolveDepthBuffer===!1,O.__autoAllocateDepthBuffer===!1)O.__useRenderToTexture=!1;Oe.get(y.texture).__webglTexture=L,Oe.get(y.depthTexture).__webglTexture=O.__autoAllocateDepthBuffer?void 0:B,O.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(y,L){let B=Oe.get(y);B.__webglFramebuffer=L,B.__useDefaultFramebuffer=L===void 0},this.setRenderTarget=function(y,L=0,B=0){F=y,q=L,j=B;let O=null,H=!1,ce=!1;if(y){let ue=Oe.get(y);if(ue.__useDefaultFramebuffer!==void 0){fe.bindFramebuffer(D.FRAMEBUFFER,ue.__webglFramebuffer),J.copy(y.viewport),ne.copy(y.scissor),Me=y.scissorTest,fe.viewport(J),fe.scissor(ne),fe.setScissorTest(Me),re=-1;return}else if(ue.__webglFramebuffer===void 0)Ve.setupRenderTarget(y);else if(ue.__hasExternalTextures)Ve.rebindTextures(y,Oe.get(y.texture).__webglTexture,Oe.get(y.depthTexture).__webglTexture);else if(y.depthBuffer){let ke=y.depthTexture;if(ue.__boundDepthTexture!==ke){if(ke!==null&&Oe.has(ke)&&(y.width!==ke.image.width||y.height!==ke.image.height))throw Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Ve.setupDepthRenderbuffer(y)}}let ge=y.texture;if(ge.isData3DTexture||ge.isDataArrayTexture||ge.isCompressedArrayTexture)ce=!0;let Se=Oe.get(y).__webglFramebuffer;if(y.isWebGLCubeRenderTarget){if(Array.isArray(Se[L]))O=Se[L][B];else O=Se[L];H=!0}else if(y.samples>0&&Ve.useMultisampledRTT(y)===!1)O=Oe.get(y).__webglMultisampledFramebuffer;else if(Array.isArray(Se))O=Se[B];else O=Se;J.copy(y.viewport),ne.copy(y.scissor),Me=y.scissorTest}else J.copy(We).multiplyScalar(De).floor(),ne.copy(Be).multiplyScalar(De).floor(),Me=ht;if(B!==0)O=V;if(fe.bindFramebuffer(D.FRAMEBUFFER,O))fe.drawBuffers(y,O);if(fe.viewport(J),fe.scissor(ne),fe.setScissorTest(Me),H){let ue=Oe.get(y.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_CUBE_MAP_POSITIVE_X+L,ue.__webglTexture,B)}else if(ce){let ue=L;for(let ge=0;ge<y.textures.length;ge++){let Se=Oe.get(y.textures[ge]);D.framebufferTextureLayer(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0+ge,Se.__webglTexture,B,ue)}}else if(y!==null&&B!==0){let ue=Oe.get(y.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,ue.__webglTexture,B)}re=-1};function _h(y){let L=Oe.get(y);if(L.__readFormat!==y.format||L.__readType!==y.type)L.__readFormat=y.format,L.__readType=y.type,L.__formatReadable=Lt.textureFormatReadable(y.format),L.__typeReadable=Lt.textureTypeReadable(y.type);return L}if(this.readRenderTargetPixels=function(y,L,B,O,H,ce,ve,ue=0){if(!(y&&y.isWebGLRenderTarget)){He("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ge=Oe.get(y).__webglFramebuffer;if(y.isWebGLCubeRenderTarget&&ve!==void 0){if(ge=ge[ve],Array.isArray(ge))ge=ge[0]}if(ge){fe.bindFramebuffer(D.FRAMEBUFFER,ge);try{let Se=y.textures[ue],{format:ke,type:Je}=Se;if(y.textures.length>1)D.readBuffer(D.COLOR_ATTACHMENT0+ue);let Ee=_h(Se);if(Ee.__formatReadable===!1){He("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Ee.__typeReadable===!1){He("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}if(L>=0&&L<=y.width-O&&(B>=0&&B<=y.height-H))D.readPixels(L,B,O,H,ie.convert(ke),ie.convert(Je),ce)}finally{let Se=F!==null?Oe.get(F).__webglFramebuffer:null;fe.bindFramebuffer(D.FRAMEBUFFER,Se)}}},this.readRenderTargetPixelsAsync=async function(y,L,B,O,H,ce,ve,ue=0){if(!(y&&y.isWebGLRenderTarget))throw Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let ge=Oe.get(y).__webglFramebuffer;if(y.isWebGLCubeRenderTarget&&ve!==void 0){if(ge=ge[ve],Array.isArray(ge))ge=ge[0]}if(ge)if(L>=0&&L<=y.width-O&&(B>=0&&B<=y.height-H)){fe.bindFramebuffer(D.FRAMEBUFFER,ge);let Se=y.textures[ue],{format:ke,type:Je}=Se;if(y.textures.length>1)D.readBuffer(D.COLOR_ATTACHMENT0+ue);let Ee=_h(Se);if(Ee.__formatReadable===!1)throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Ee.__typeReadable===!1)throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");let Ke=D.createBuffer();D.bindBuffer(D.PIXEL_PACK_BUFFER,Ke),D.bufferData(D.PIXEL_PACK_BUFFER,ce.byteLength,D.STREAM_READ),D.readPixels(L,B,O,H,ie.convert(ke),ie.convert(Je),0),D.bindBuffer(D.PIXEL_PACK_BUFFER,null);let Tt=F!==null?Oe.get(F).__webglFramebuffer:null;fe.bindFramebuffer(D.FRAMEBUFFER,Tt);let mt=D.fenceSync(D.SYNC_GPU_COMMANDS_COMPLETE,0);return D.flush(),await Qd(D,mt,4),D.bindBuffer(D.PIXEL_PACK_BUFFER,Ke),D.getBufferSubData(D.PIXEL_PACK_BUFFER,0,ce),D.bindBuffer(D.PIXEL_PACK_BUFFER,null),D.deleteBuffer(Ke),D.deleteSync(mt),ce}else throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(y,L=null,B=0){let O=Math.pow(2,-B),H=Math.floor(y.image.width*O),ce=Math.floor(y.image.height*O),ve=L!==null?L.x:0,ue=L!==null?L.y:0;Ve.setTexture2D(y,0),D.copyTexSubImage2D(D.TEXTURE_2D,B,0,0,ve,ue,H,ce),fe.unbindTexture()},this.copyTextureToTexture=function(y,L,B=null,O=null,H=0,ce=0){let ve,ue,ge,Se,ke,Je,Ee,Ke,Tt,mt=y.isCompressedTexture?y.mipmaps[ce]:y.image;if(B!==null)ve=B.max.x-B.min.x,ue=B.max.y-B.min.y,ge=B.isBox3?B.max.z-B.min.z:1,Se=B.min.x,ke=B.min.y,Je=B.isBox3?B.min.z:0;else{let nt=Math.pow(2,-H);if(ve=Math.floor(y.width*nt),ue=Math.floor(y.height*nt),y.isDataArrayTexture)ge=mt.depth;else if(y.isData3DTexture)ge=Math.floor(mt.depth*nt);else ge=1;Se=0,ke=0,Je=0}if(O!==null)Ee=O.x,Ke=O.y,Tt=O.z;else Ee=0,Ke=0,Tt=0;let dt=ie.convert(L.format),Gt=ie.convert(L.type),Te;if(L.isData3DTexture)Ve.setTexture3D(L,0),Te=D.TEXTURE_3D;else if(L.isDataArrayTexture||L.isCompressedArrayTexture)Ve.setTexture2DArray(L,0),Te=D.TEXTURE_2D_ARRAY;else Ve.setTexture2D(L,0),Te=D.TEXTURE_2D;fe.activeTexture(D.TEXTURE0),fe.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,L.flipY),fe.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,L.premultiplyAlpha),fe.pixelStorei(D.UNPACK_ALIGNMENT,L.unpackAlignment);let $t=fe.getParameter(D.UNPACK_ROW_LENGTH),st=fe.getParameter(D.UNPACK_IMAGE_HEIGHT),Xi=fe.getParameter(D.UNPACK_SKIP_PIXELS),zt=fe.getParameter(D.UNPACK_SKIP_ROWS),So=fe.getParameter(D.UNPACK_SKIP_IMAGES);fe.pixelStorei(D.UNPACK_ROW_LENGTH,mt.width),fe.pixelStorei(D.UNPACK_IMAGE_HEIGHT,mt.height),fe.pixelStorei(D.UNPACK_SKIP_PIXELS,Se),fe.pixelStorei(D.UNPACK_SKIP_ROWS,ke),fe.pixelStorei(D.UNPACK_SKIP_IMAGES,Je);let pi=y.isDataArrayTexture||y.isData3DTexture,qi=L.isDataArrayTexture||L.isData3DTexture;if(y.isDepthTexture){let nt=Oe.get(y),Ft=Oe.get(L),Rn=Oe.get(nt.__renderTarget),_t=Oe.get(Ft.__renderTarget);fe.bindFramebuffer(D.READ_FRAMEBUFFER,Rn.__webglFramebuffer),fe.bindFramebuffer(D.DRAW_FRAMEBUFFER,_t.__webglFramebuffer);for(let Nt=0;Nt<ge;Nt++){if(pi)D.framebufferTextureLayer(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Oe.get(y).__webglTexture,H,Je+Nt),D.framebufferTextureLayer(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Oe.get(L).__webglTexture,ce,Tt+Nt);D.blitFramebuffer(Se,ke,Se+ve,ke+ue,Ee,Ke,Ee+ve,Ke+ue,D.DEPTH_BUFFER_BIT,D.NEAREST)}fe.bindFramebuffer(D.READ_FRAMEBUFFER,null),fe.bindFramebuffer(D.DRAW_FRAMEBUFFER,null)}else if(H!==0||y.isRenderTargetTexture||Oe.has(y)){let nt=Oe.get(y),Ft=Oe.get(L);fe.bindFramebuffer(D.READ_FRAMEBUFFER,Q),fe.bindFramebuffer(D.DRAW_FRAMEBUFFER,C);for(let Rn=0;Rn<ge;Rn++){if(pi)D.framebufferTextureLayer(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,nt.__webglTexture,H,Je+Rn);else D.framebufferTexture2D(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,nt.__webglTexture,H);if(qi)D.framebufferTextureLayer(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Ft.__webglTexture,ce,Tt+Rn);else D.framebufferTexture2D(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,Ft.__webglTexture,ce);if(H!==0)D.blitFramebuffer(Se,ke,Se+ve,ke+ue,Ee,Ke,Ee+ve,Ke+ue,D.COLOR_BUFFER_BIT,D.NEAREST);else if(qi)D.copyTexSubImage3D(Te,ce,Ee,Ke,Tt+Rn,Se,ke,ve,ue);else D.copyTexSubImage2D(Te,ce,Ee,Ke,Se,ke,ve,ue)}fe.bindFramebuffer(D.READ_FRAMEBUFFER,null),fe.bindFramebuffer(D.DRAW_FRAMEBUFFER,null)}else if(qi)if(y.isDataTexture||y.isData3DTexture)D.texSubImage3D(Te,ce,Ee,Ke,Tt,ve,ue,ge,dt,Gt,mt.data);else if(L.isCompressedArrayTexture)D.compressedTexSubImage3D(Te,ce,Ee,Ke,Tt,mt.width,mt.height,ge,dt,mt.data);else D.texSubImage3D(Te,ce,Ee,Ke,Tt,ve,ue,ge,dt,Gt,mt);else if(y.isDataTexture)D.texSubImage2D(D.TEXTURE_2D,ce,Ee,Ke,ve,ue,dt,Gt,mt.data);else if(y.isCompressedTexture)D.compressedTexSubImage2D(D.TEXTURE_2D,ce,Ee,Ke,mt.width,mt.height,dt,mt.data);else D.texSubImage2D(D.TEXTURE_2D,ce,Ee,Ke,ve,ue,dt,Gt,mt);if(fe.pixelStorei(D.UNPACK_ROW_LENGTH,$t),fe.pixelStorei(D.UNPACK_IMAGE_HEIGHT,st),fe.pixelStorei(D.UNPACK_SKIP_PIXELS,Xi),fe.pixelStorei(D.UNPACK_SKIP_ROWS,zt),fe.pixelStorei(D.UNPACK_SKIP_IMAGES,So),ce===0&&L.generateMipmaps===!0&&L.mipmapsAutoUpdate===!0)D.generateMipmap(Te);fe.unbindTexture()},this.initRenderTarget=function(y){if(Oe.get(y).__webglFramebuffer===void 0)Ve.setupRenderTarget(y)},this.initTexture=function(y){if(y.isCubeTexture)Ve.setTextureCube(y,0);else if(y.isData3DTexture)Ve.setTexture3D(y,0);else if(y.isDataArrayTexture||y.isCompressedArrayTexture)Ve.setTexture2DArray(y,0);else Ve.setTexture2D(y,0);fe.unbindTexture()},this.resetState=function(){q=0,j=0,F=null,fe.reset(),se.reset()},typeof __THREE_DEVTOOLS__<"u")__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Wc}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=qe._getDrawingBufferColorSpace(e),t.unpackColorSpace=qe._getUnpackColorSpace()}}function gu(e,t){if(t===Fc)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),e;if(t===ks||t===Lr){let n=e.getIndex();if(n===null){let r=[],o=e.getAttribute("position");if(o!==void 0){for(let a=0;a<o.count;a++)r.push(a);e.setIndex(r),n=e.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),e}let i=n.count-2,s=[];if(t===ks)for(let r=1;r<=i;r++)s.push(n.getX(0)),s.push(n.getX(r)),s.push(n.getX(r+1));else for(let r=0;r<i;r++)if(r%2===0)s.push(n.getX(r)),s.push(n.getX(r+1)),s.push(n.getX(r+2));else s.push(n.getX(r+2)),s.push(n.getX(r+1)),s.push(n.getX(r));if(s.length/3!==i)console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");return e.setIndex(s),e.clearGroups(),e}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",t),e}function Jf(e){let t=new Map,n=new Map,i=e.clone();return Kf(e,i,function(s,r){t.set(r,s),n.set(s,r)}),i.traverse(function(s){if(!s.isSkinnedMesh)return;let r=s,o=t.get(s),a=o.skeleton.bones;r.skeleton=o.skeleton.clone(),r.bindMatrix.copy(o.bindMatrix),r.skeleton.bones=a.map(function(l){return n.get(l)}),r.bind(r.skeleton,r.bindMatrix)}),i}function Kf(e,t,n){n(e,t);for(let i=0;i<e.children.length;i++)Kf(e.children[i],t.children[i],n)}class Tu extends di{constructor(e){super(e);this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new rp(t)}),this.register(function(t){return new op(t)}),this.register(function(t){return new ap(t)}),this.register(function(t){return new gp(t)}),this.register(function(t){return new _p(t)}),this.register(function(t){return new xp(t)}),this.register(function(t){return new cp(t)}),this.register(function(t){return new up(t)}),this.register(function(t){return new hp(t)}),this.register(function(t){return new dp(t)}),this.register(function(t){return new sp(t)}),this.register(function(t){return new fp(t)}),this.register(function(t){return new lp(t)}),this.register(function(t){return new mp(t)}),this.register(function(t){return new pp(t)}),this.register(function(t){return new np(t)}),this.register(function(t){return new yu(t,Ze.EXT_MESHOPT_COMPRESSION)}),this.register(function(t){return new yu(t,Ze.KHR_MESHOPT_COMPRESSION)}),this.register(function(t){return new Mp(t)})}load(e,t,n,i){let s=this,r;if(this.resourcePath!=="")r=this.resourcePath;else if(this.path!==""){let l=Ui.extractUrlBase(e);r=Ui.resolveURL(l,this.path)}else r=Ui.extractUrlBase(e);this.manager.itemStart(e);let o=function(l){if(i)i(l);else console.error(l);s.manager.itemError(e),s.manager.itemEnd(e)},a=new Hr(this.manager);a.setPriority(this.priority),a.setCache(this.cache),a.setPath(this.path),a.setResponseType("arraybuffer"),a.setRequestHeader(this.requestHeader),a.setWithCredentials(this.withCredentials),a.load(e,function(l){try{s.parse(l,r,function(c){t(c),s.manager.itemEnd(e)},o)}catch(c){o(c)}},n,o)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){if(this.pluginCallbacks.indexOf(e)===-1)this.pluginCallbacks.push(e);return this}unregister(e){if(this.pluginCallbacks.indexOf(e)!==-1)this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1);return this}parse(e,t,n,i){let s,r={},o={},a=new TextDecoder;if(typeof e==="string")s=JSON.parse(e);else if(e instanceof ArrayBuffer)if(a.decode(new Uint8Array(e,0,4))===yp){try{r[Ze.KHR_BINARY_GLTF]=new vp(e)}catch(u){if(i)i(u);return}s=JSON.parse(r[Ze.KHR_BINARY_GLTF].content)}else s=JSON.parse(a.decode(e));else s=e;if(s.asset===void 0||s.asset.version[0]<2){if(i)i(Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}let l=new Rp(s,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,priority:this.priority,cache:this.cache,withCredentials:this.withCredentials,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let c=0;c<this.pluginCallbacks.length;c++){let u=this.pluginCallbacks[c](l);if(!u.name)console.error("THREE.GLTFLoader: Invalid plugin found: missing name");o[u.name]=u,r[u.name]=!0}if(s.extensionsUsed)for(let c=0;c<s.extensionsUsed.length;++c){let u=s.extensionsUsed[c],h=s.extensionsRequired||[];switch(u){case Ze.KHR_MATERIALS_UNLIT:r[u]=new ip;break;case Ze.KHR_DRACO_MESH_COMPRESSION:r[u]=new Ep(s,this.dracoLoader);break;case Ze.KHR_TEXTURE_TRANSFORM:r[u]=new Tp;break;case Ze.KHR_MESH_QUANTIZATION:r[u]=new Sp;break;default:if(h.indexOf(u)>=0&&o[u]===void 0)console.warn('THREE.GLTFLoader: Unknown extension "'+u+'".')}}l.setExtensions(r),l.setPlugins(o),l.parse(n,i)}parseAsync(e,t){let n=this;return new Promise(function(i,s){n.parse(e,t,i,s)})}}function fy(){let e={};return{get:function(t){return e[t]},add:function(t,n){e[t]=n},remove:function(t){delete e[t]},removeAll:function(){e={}}}}function xt(e,t,n){let i=e.json.materials[t];if(i.extensions&&i.extensions[n])return i.extensions[n];return null}var Ze={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DIFFUSE_ROUGHNESS:"KHR_materials_diffuse_roughness",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",KHR_MESHOPT_COMPRESSION:"KHR_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class np{constructor(e){this.parser=e,this.name=Ze.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let n=0,i=t.length;n<i;n++){let s=t[n];if(s.extensions&&s.extensions[this.name]&&s.extensions[this.name].light!==void 0)e._addNodeRef(this.cache,s.extensions[this.name].light)}}_loadLight(e){let t=this.parser,n="light:"+e,i=t.cache.get(n);if(i)return i;let s=t.json,a=((s.extensions&&s.extensions[this.name]||{}).lights||[])[e],l,c=new xe(16777215);if(a.color!==void 0)c.setRGB(a.color[0],a.color[1],a.color[2],fn);let u=a.range!==void 0?a.range:0;switch(a.type){case"directional":l=new ls(c),l.target.position.set(0,0,-1),l.add(l.target);break;case"point":l=new Ca(c),l.distance=u;break;case"spot":l=new wa(c),l.distance=u,a.spot=a.spot||{},a.spot.innerConeAngle=a.spot.innerConeAngle!==void 0?a.spot.innerConeAngle:0,a.spot.outerConeAngle=a.spot.outerConeAngle!==void 0?a.spot.outerConeAngle:Math.PI/4,l.angle=a.spot.outerConeAngle,l.penumbra=1-a.spot.innerConeAngle/a.spot.outerConeAngle,l.target.position.set(0,0,-1),l.add(l.target);break;default:throw Error("THREE.GLTFLoader: Unexpected light type: "+a.type)}if(l.position.set(0,0,0),qn(l,a),a.intensity!==void 0)l.intensity=a.intensity;return l.name=t.createUniqueName(a.name||"light_"+e),i=Promise.resolve(l),t.cache.add(n,i),i}getDependency(e,t){if(e!=="light")return;return this._loadLight(t)}createNodeAttachment(e){let t=this,n=this.parser,s=n.json.nodes[e],o=(s.extensions&&s.extensions[this.name]||{}).light;if(o===void 0)return null;return this._loadLight(o).then(function(a){return n._getNodeRef(t.cache,o,a)})}}class ip{constructor(){this.name=Ze.KHR_MATERIALS_UNLIT}getMaterialType(){return nn}extendParams(e,t,n){let i=[];e.color=new xe(1,1,1),e.opacity=1;let s=t.pbrMetallicRoughness;if(s){if(Array.isArray(s.baseColorFactor)){let r=s.baseColorFactor;e.color.setRGB(r[0],r[1],r[2],fn),e.opacity=r[3]}if(s.baseColorTexture!==void 0)i.push(n.assignTexture(e,"map",s.baseColorTexture,Nn))}return Promise.all(i)}}class sp{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();if(n.emissiveStrength!==void 0)t.emissiveIntensity=n.emissiveStrength;return Promise.resolve()}}class rp{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(n.clearcoatFactor!==void 0)t.clearcoat=n.clearcoatFactor;if(n.clearcoatTexture!==void 0)i.push(this.parser.assignTexture(t,"clearcoatMap",n.clearcoatTexture));if(n.clearcoatRoughnessFactor!==void 0)t.clearcoatRoughness=n.clearcoatRoughnessFactor;if(n.clearcoatRoughnessTexture!==void 0)i.push(this.parser.assignTexture(t,"clearcoatRoughnessMap",n.clearcoatRoughnessTexture));if(n.clearcoatNormalTexture!==void 0){if(i.push(this.parser.assignTexture(t,"clearcoatNormalMap",n.clearcoatNormalTexture)),n.clearcoatNormalTexture.scale!==void 0){let s=n.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new Ce(s,s)}}return Promise.all(i)}}class op{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_DIFFUSE_ROUGHNESS}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(t.diffuseRoughness=n.diffuseRoughnessFactor!==void 0?n.diffuseRoughnessFactor:0,n.diffuseRoughnessTexture!==void 0)i.push(this.parser.assignTexture(t,"diffuseRoughnessMap",n.diffuseRoughnessTexture));return Promise.all(i)}}class ap{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_DISPERSION}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();return t.dispersion=n.dispersion!==void 0?n.dispersion:0,Promise.resolve()}}class lp{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(n.iridescenceFactor!==void 0)t.iridescence=n.iridescenceFactor;if(n.iridescenceTexture!==void 0)i.push(this.parser.assignTexture(t,"iridescenceMap",n.iridescenceTexture));if(n.iridescenceIor!==void 0)t.iridescenceIOR=n.iridescenceIor;if(n.iridescenceThicknessMinimum!==void 0)t.iridescenceThicknessMinimum=n.iridescenceThicknessMinimum;if(n.iridescenceThicknessMaximum!==void 0)t.iridescenceThicknessMaximum=n.iridescenceThicknessMaximum;if(n.iridescenceThicknessTexture!==void 0)i.push(this.parser.assignTexture(t,"iridescenceThicknessMap",n.iridescenceThicknessTexture));return Promise.all(i)}}class cp{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_SHEEN}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(t.sheenColor=new xe(0,0,0),t.sheenRoughness=0,t.sheen=1,n.sheenColorFactor!==void 0){let s=n.sheenColorFactor;t.sheenColor.setRGB(s[0],s[1],s[2],fn)}if(n.sheenRoughnessFactor!==void 0)t.sheenRoughness=n.sheenRoughnessFactor;if(n.sheenColorTexture!==void 0)i.push(this.parser.assignTexture(t,"sheenColorMap",n.sheenColorTexture,Nn));if(n.sheenRoughnessTexture!==void 0)i.push(this.parser.assignTexture(t,"sheenRoughnessMap",n.sheenRoughnessTexture));return Promise.all(i)}}class up{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(n.transmissionFactor!==void 0)t.transmission=n.transmissionFactor;if(n.transmissionTexture!==void 0)i.push(this.parser.assignTexture(t,"transmissionMap",n.transmissionTexture));return Promise.all(i)}}class hp{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_VOLUME}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(t.thickness=n.thicknessFactor!==void 0?n.thicknessFactor:0,n.thicknessTexture!==void 0)i.push(this.parser.assignTexture(t,"thicknessMap",n.thicknessTexture));t.attenuationDistance=n.attenuationDistance||1/0;let s=n.attenuationColor||[1,1,1];return t.attenuationColor=new xe().setRGB(s[0],s[1],s[2],fn),Promise.all(i)}}class dp{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_IOR}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();if(t.ior=n.ior!==void 0?n.ior:1.5,t.ior===0)t.ior=1000;return Promise.resolve()}}class fp{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_SPECULAR}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(t.specularIntensity=n.specularFactor!==void 0?n.specularFactor:1,n.specularTexture!==void 0)i.push(this.parser.assignTexture(t,"specularIntensityMap",n.specularTexture));let s=n.specularColorFactor||[1,1,1];if(t.specularColor=new xe().setRGB(s[0],s[1],s[2],fn),n.specularColorTexture!==void 0)i.push(this.parser.assignTexture(t,"specularColorMap",n.specularColorTexture,Nn));return Promise.all(i)}}class pp{constructor(e){this.parser=e,this.name=Ze.EXT_MATERIALS_BUMP}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(t.bumpScale=n.bumpFactor!==void 0?n.bumpFactor:1,n.bumpTexture!==void 0)i.push(this.parser.assignTexture(t,"bumpMap",n.bumpTexture));return Promise.all(i)}}class mp{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){return xt(this.parser,e,this.name)!==null?ln:null}extendMaterialParams(e,t){let n=xt(this.parser,e,this.name);if(n===null)return Promise.resolve();let i=[];if(n.anisotropyStrength!==void 0)t.anisotropy=n.anisotropyStrength;if(n.anisotropyRotation!==void 0)t.anisotropyRotation=n.anisotropyRotation;if(n.anisotropyTexture!==void 0)i.push(this.parser.assignTexture(t,"anisotropyMap",n.anisotropyTexture));return Promise.all(i)}}class gp{constructor(e){this.parser=e,this.name=Ze.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,n=t.json,i=n.textures[e];if(!i.extensions||!i.extensions[this.name])return null;let s=i.extensions[this.name],r=t.options.ktx2Loader;if(!r)if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");else return null;return t.loadTextureImage(e,s.source,r)}}class _p{constructor(e){this.parser=e,this.name=Ze.EXT_TEXTURE_WEBP}loadTexture(e){let t=this.name,n=this.parser,i=n.json,s=i.textures[e];if(!s.extensions||!s.extensions[t])return null;let r=s.extensions[t],o=i.images[r.source],a=n.textureLoader;if(o.uri){let l=n.options.manager.getHandler(o.uri);if(l!==null)a=l}return n.loadTextureImage(e,r.source,a)}}class xp{constructor(e){this.parser=e,this.name=Ze.EXT_TEXTURE_AVIF}loadTexture(e){let t=this.name,n=this.parser,i=n.json,s=i.textures[e];if(!s.extensions||!s.extensions[t])return null;let r=s.extensions[t],o=i.images[r.source],a=n.textureLoader;if(o.uri){let l=n.options.manager.getHandler(o.uri);if(l!==null)a=l}return n.loadTextureImage(e,r.source,a)}}class yu{constructor(e,t){this.name=t,this.parser=e}loadBufferView(e){let t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){let i=n.extensions[this.name],s=this.parser.getDependency("buffer",i.buffer),r=this.parser.options.meshoptDecoder;if(!r||!r.supported)if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");else return null;return s.then(function(o){let a=i.byteOffset||0,l=i.byteLength||0,{count:c,byteStride:u}=i,h=new Uint8Array(o,a,l);if(r.decodeGltfBufferAsync)return r.decodeGltfBufferAsync(c,u,h,i.mode,i.filter).then(function(d){return d.buffer});else return r.ready.then(function(){let d=new ArrayBuffer(c*u);return r.decodeGltfBuffer(new Uint8Array(d),c,u,h,i.mode,i.filter),d})})}else return null}}class Mp{constructor(e){this.name=Ze.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;let i=t.meshes[n.mesh];for(let l of i.primitives)if(l.mode!==vn.TRIANGLES&&l.mode!==vn.TRIANGLE_STRIP&&l.mode!==vn.TRIANGLE_FAN&&l.mode!==void 0)return null;let r=n.extensions[this.name].attributes,o=[],a={};for(let l in r)o.push(this.parser.getDependency("accessor",r[l]).then((c)=>(a[l]=c,a[l])));if(o.length<1)return null;return o.push(this.parser.createNodeMesh(e)),Promise.all(o).then((l)=>{let c=l.pop(),u=c.isGroup?c.children:[c],h=l[0].count,d=[];for(let f of u){let m=new Re,x=new R,p=new be,g=new R(1,1,1),v=new ma(f.geometry,f.material,h);for(let T=0;T<h;T++){if(a.TRANSLATION)x.fromBufferAttribute(a.TRANSLATION,T);if(a.ROTATION)p.fromBufferAttribute(a.ROTATION,T);if(a.SCALE)g.fromBufferAttribute(a.SCALE,T);v.setMatrixAt(T,m.compose(x,p,g))}let S=null;for(let T in a)if(T==="_COLOR_0"){let A=a[T];v.instanceColor=new vi(A.array,A.itemSize,A.normalized)}else if(T!=="TRANSLATION"&&T!=="ROTATION"&&T!=="SCALE"){if(S===null){let w=v.geometry;S=new Qe,S.name=w.name;for(let _ in w.attributes)S.setAttribute(_,w.attributes[_]);for(let _ in w.morphAttributes)S.morphAttributes[_]=w.morphAttributes[_];if(w.index!==null)S.setIndex(w.index);S.morphTargetsRelative=w.morphTargetsRelative;for(let _ of w.groups)S.addGroup(_.start,_.count,_.materialIndex);if(w.boundingBox!==null)S.boundingBox=w.boundingBox.clone();if(w.boundingSphere!==null)S.boundingSphere=w.boundingSphere.clone();S.drawRange.start=w.drawRange.start,S.drawRange.count=w.drawRange.count,S.userData=Object.assign({},w.userData),v.geometry=S}let A=a[T];S.setAttribute(T,new vi(A.array,A.itemSize,A.normalized))}tt.prototype.copy.call(v,f),this.parser.assignFinalMaterial(v),d.push(v)}if(c.isGroup)return c.clear(),c.add(...d),c;return d[0]})}}var yp="glTF",Zr=12,$f={JSON:1313821514,BIN:5130562};class vp{constructor(e){this.name=Ze.KHR_BINARY_GLTF,this.content=null,this.body=null;let t=new DataView(e,0,Zr),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==yp)throw Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");else if(this.header.version<2)throw Error("THREE.GLTFLoader: Legacy binary file detected.");let i=this.header.length-Zr,s=new DataView(e,Zr),r=0;while(r<i){let o=s.getUint32(r,!0);r+=4;let a=s.getUint32(r,!0);if(r+=4,a===$f.JSON){let l=new Uint8Array(e,Zr+r,o);this.content=n.decode(l)}else if(a===$f.BIN){let l=Zr+r;this.body=e.slice(l,l+o)}r+=o}if(this.content===null)throw Error("THREE.GLTFLoader: JSON content not found.")}}class Ep{constructor(e,t){if(!t)throw Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=Ze.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let n=this.json,i=this.dracoLoader,s=e.extensions[this.name].bufferView,r=e.extensions[this.name].attributes,o={},a={},l={};for(let c in r){let u=vu[c]||c.toLowerCase();o[u]=r[c]}for(let c in e.attributes){let u=vu[c]||c.toLowerCase();if(r[c]!==void 0){let h=n.accessors[e.attributes[c]],d=Js[h.componentType];l[u]=d.name,a[u]=h.normalized===!0}}return t.getDependency("bufferView",s).then(function(c){return new Promise(function(u,h){i.decodeDracoFile(c,function(d){for(let f in d.attributes){let m=d.attributes[f],x=a[f];if(x!==void 0)m.normalized=x}u(d)},o,l,fn,h)})})}}class Tp{constructor(){this.name=Ze.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){if((t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0)return e;if(e=e.clone(),t.texCoord!==void 0)e.channel=t.texCoord;if(t.offset!==void 0)e.offset.fromArray(t.offset);if(t.rotation!==void 0)e.rotation=t.rotation;if(t.scale!==void 0)e.repeat.fromArray(t.scale);if(t.rotation!==void 0){let n=Math.cos(e.rotation),i=Math.sin(e.rotation);e.matrix.set(e.repeat.x*n,e.repeat.y*i,e.offset.x,-e.repeat.x*i,e.repeat.y*n,e.offset.y,0,0,1),e.matrixAutoUpdate=!1}return e.needsUpdate=!0,e}}class Sp{constructor(){this.name=Ze.KHR_MESH_QUANTIZATION}}class Su extends hi{constructor(e,t,n,i){super(e,t,n,i)}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,i=this.valueSize,s=e*i*3+i;for(let r=0;r!==i;r++)t[r]=n[s+r];return t}interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=o*2,l=o*3,c=i-t,u=(n-t)/c,h=u*u,d=h*u,f=e*l,m=f-l,x=-2*d+3*h,p=d-h,g=1-x,v=p-h+u;for(let S=0;S!==o;S++){let T=r[m+S+o],A=r[m+S+a]*c,w=r[f+S+o],_=r[f+S]*c;s[S]=g*T+v*A+x*w+p*_}return s}}var py=new be;class bp extends Su{interpolate_(e,t,n,i){let s=super.interpolate_(e,t,n,i);return py.fromArray(s).normalize().toArray(s),s}}var vn={FLOAT:5126,FLOAT_MAT3:35675,FLOAT_MAT4:35676,FLOAT_VEC2:35664,FLOAT_VEC3:35665,FLOAT_VEC4:35666,LINEAR:9729,REPEAT:10497,SAMPLER_2D:35678,POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,UNSIGNED_BYTE:5121,UNSIGNED_SHORT:5123},Js={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Qf={9728:Pn,9729:Yt,9984:ta,9985:Bs,9986:ts,9987:Ln},ep={33071:Hs,33648:ea,10497:Fs},_u={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},vu={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},Oi={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},my={CUBICSPLINE:void 0,LINEAR:la,STEP:Oc},xu={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function gy(e){if(e.DefaultMaterial===void 0)e.DefaultMaterial=new qs({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:Si});return e.DefaultMaterial}function cs(e,t,n){for(let i in n.extensions)if(e[i]===void 0)t.userData.gltfExtensions=t.userData.gltfExtensions||{},t.userData.gltfExtensions[i]=n.extensions[i]}function qn(e,t){if(t.extras!==void 0)if(typeof t.extras==="object")Object.assign(e.userData,t.extras);else console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+t.extras)}function _y(e,t,n){let i=!1,s=!1,r=!1;for(let c=0,u=t.length;c<u;c++){let h=t[c];if(h.POSITION!==void 0)i=!0;if(h.NORMAL!==void 0)s=!0;if(h.COLOR_0!==void 0)r=!0;if(i&&s&&r)break}if(!i&&!s&&!r)return Promise.resolve(e);let o=[],a=[],l=[];for(let c=0,u=t.length;c<u;c++){let h=t[c];if(i){let d=h.POSITION!==void 0?n.getDependency("accessor",h.POSITION):e.attributes.position;o.push(d)}if(s){let d=h.NORMAL!==void 0?n.getDependency("accessor",h.NORMAL):e.attributes.normal;a.push(d)}if(r){let d=h.COLOR_0!==void 0?n.getDependency("accessor",h.COLOR_0):e.attributes.color;l.push(d)}}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(l)]).then(function(c){let u=c[0],h=c[1],d=c[2];if(i)e.morphAttributes.position=u;if(s)e.morphAttributes.normal=h;if(r)e.morphAttributes.color=d;return e.morphTargetsRelative=!0,e})}function xy(e,t){if(e.updateMorphTargets(),t.weights!==void 0)for(let n=0,i=t.weights.length;n<i;n++)e.morphTargetInfluences[n]=t.weights[n];if(t.extras&&Array.isArray(t.extras.targetNames)){let n=t.extras.targetNames;if(e.morphTargetInfluences.length===n.length){e.morphTargetDictionary={};for(let i=0,s=n.length;i<s;i++)e.morphTargetDictionary[n[i]]=i}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function My(e){let t,n=e.extensions&&e.extensions[Ze.KHR_DRACO_MESH_COMPRESSION];if(n)t="draco:"+n.bufferView+":"+n.indices+":"+Mu(n.attributes);else t=e.indices+":"+Mu(e.attributes)+":"+e.mode;if(e.targets!==void 0)for(let i=0,s=e.targets.length;i<s;i++)t+=":"+Mu(e.targets[i]);return t}function Mu(e){let t="",n=Object.keys(e).sort();for(let i=0,s=n.length;i<s;i++)t+=n[i]+":"+e[n[i]]+";";return t}function Eu(e){switch(e){case Int8Array:return 0.007874015748031496;case Uint8Array:return 0.00392156862745098;case Int16Array:return 0.00003051850947599719;case Uint16Array:return 0.000015259021896696422;default:throw Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function yy(e){if(e.search(/\.jpe?g($|\?)/i)>0||e.search(/^data\:image\/jpeg/)===0)return"image/jpeg";if(e.search(/\.webp($|\?)/i)>0||e.search(/^data\:image\/webp/)===0)return"image/webp";if(e.search(/\.ktx2($|\?)/i)>0||e.search(/^data\:image\/ktx2/)===0)return"image/ktx2";return"image/png"}var vy=new Re;class Rp{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new fy,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,i=-1,s=!1,r=-1;if(typeof navigator<"u"&&typeof navigator.userAgent<"u"){let o=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(o)===!0;let a=o.match(/Version\/(\d+)/);i=n&&a?parseInt(a[1],10):-1,s=o.indexOf("Firefox")>-1,r=s?o.match(/Firefox\/([0-9]+)\./)[1]:-1}if(typeof createImageBitmap>"u"||n&&i<17||s&&r<98)this.textureLoader=new ba(this.options.manager),this.textureLoader.setPriority(this.options.priority),this.textureLoader.setCache(this.options.cache);else this.textureLoader=new Pa(this.options.manager),this.textureLoader.setPriority(this.options.priority),this.textureLoader.setCache(this.options.cache);if(this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setWithCredentials(this.options.withCredentials),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new Hr(this.options.manager),this.fileLoader.setPriority(this.options.priority),this.fileLoader.setCache(this.options.cache),this.fileLoader.setResponseType("arraybuffer"),this.options.withCredentials||this.options.crossOrigin==="use-credentials")this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let n=this,i=this.json,s=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(r){return r._markDefs&&r._markDefs()}),Promise.all(this._invokeAll(function(r){return r.beforeRoot&&r.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(r){let o={scene:r[0][i.scene||0],scenes:r[0],animations:r[1],cameras:r[2],asset:i.asset,parser:n,userData:{}};return cs(s,o,i),qn(o,i),Promise.all(n._invokeAll(function(a){return a.afterRoot&&a.afterRoot(o)})).then(function(){for(let a of o.scenes)a.updateMatrixWorld();e(o)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let i=0,s=t.length;i<s;i++){let r=t[i].joints;for(let o=0,a=r.length;o<a;o++)e[r[o]].isBone=!0}for(let i=0,s=e.length;i<s;i++){let r=e[i];if(r.mesh!==void 0){if(this._addNodeRef(this.meshCache,r.mesh),r.skin!==void 0)n[r.mesh].isSkinnedMesh=!0}if(r.camera!==void 0)this._addNodeRef(this.cameraCache,r.camera)}}_addNodeRef(e,t){if(t===void 0)return;if(e.refs[t]===void 0)e.refs[t]=e.uses[t]=0;e.refs[t]++}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;let i=n.clone(),s=(r,o)=>{let a=this.associations.get(r);if(a!=null)this.associations.set(o,a);for(let[l,c]of r.children.entries())s(c,o.children[l])};return s(n,i),i.name+="_instance_"+e.uses[t]++,i}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){let i=e(t[n]);if(i)return i}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let n=[];for(let i=0;i<t.length;i++){let s=e(t[i]);if(s)n.push(s)}return n}getDependency(e,t){let n=e+":"+t,i=this.cache.get(n);if(!i){switch(e){case"scene":i=this.loadScene(t);break;case"node":i=this._invokeOne(function(s){return s.loadNode&&s.loadNode(t)});break;case"mesh":i=this._invokeOne(function(s){return s.loadMesh&&s.loadMesh(t)});break;case"accessor":i=this.loadAccessor(t);break;case"bufferView":i=this._invokeOne(function(s){return s.loadBufferView&&s.loadBufferView(t)});break;case"buffer":i=this.loadBuffer(t);break;case"material":i=this._invokeOne(function(s){return s.loadMaterial&&s.loadMaterial(t)});break;case"texture":i=this._invokeOne(function(s){return s.loadTexture&&s.loadTexture(t)});break;case"skin":i=this.loadSkin(t);break;case"animation":i=this._invokeOne(function(s){return s.loadAnimation&&s.loadAnimation(t)});break;case"camera":i=this.loadCamera(t);break;default:if(i=this._invokeOne(function(s){return s!=this&&s.getDependency&&s.getDependency(e,t)}),!i)throw Error("Unknown type: "+e);break}this.cache.add(n,i)}return i}getDependencies(e){let t=this.cache.get(e);if(!t){let n=this,i=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(i.map(function(s,r){return n.getDependency(e,r)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[Ze.KHR_BINARY_GLTF].body);let i=this.options;return new Promise(function(s,r){n.load(Ui.resolveURL(t.uri,i.path),s,void 0,function(){r(Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){let i=t.byteLength||0,s=t.byteOffset||0;return n.slice(s,s+i)})}loadAccessor(e){let t=this,n=this.json,i=this.json.accessors[e];if(i.bufferView===void 0&&i.sparse===void 0){let r=_u[i.type],o=Js[i.componentType],a=i.normalized===!0,l=new o(i.count*r);return Promise.resolve(new Ge(l,r,a))}let s=[];if(i.bufferView!==void 0)s.push(this.getDependency("bufferView",i.bufferView));else s.push(null);if(i.sparse!==void 0)s.push(this.getDependency("bufferView",i.sparse.indices.bufferView)),s.push(this.getDependency("bufferView",i.sparse.values.bufferView));return Promise.all(s).then(function(r){let o=r[0],a=_u[i.type],l=Js[i.componentType],c=l.BYTES_PER_ELEMENT,u=c*a,h=i.byteOffset||0,d=i.bufferView!==void 0?n.bufferViews[i.bufferView].byteStride:void 0,f=i.normalized===!0,m,x;if(d&&d!==u){let p=Math.floor(h/d),g="InterleavedBuffer:"+i.bufferView+":"+i.componentType+":"+p+":"+i.count,v=t.cache.get(g);if(!v)m=new l(o,p*d,i.count*d/c),v=new Ai(m,d/c),t.cache.add(g,v);x=new ui(v,a,h%d/c,f)}else{if(o===null)m=new l(i.count*a);else m=new l(o,h,i.count*a);x=new Ge(m,a,f)}if(i.sparse!==void 0){let p=_u.SCALAR,g=Js[i.sparse.indices.componentType],v=i.sparse.indices.byteOffset||0,S=i.sparse.values.byteOffset||0,T=new g(r[1],v,i.sparse.count*p),A=new l(r[2],S,i.sparse.count*a);if(o!==null)x=new Ge(x.array.slice(),x.itemSize,x.normalized);x.normalized=!1;for(let w=0,_=T.length;w<_;w++){let E=T[w];if(x.setX(E,A[w*a]),a>=2)x.setY(E,A[w*a+1]);if(a>=3)x.setZ(E,A[w*a+2]);if(a>=4)x.setW(E,A[w*a+3]);if(a>=5)throw Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}x.normalized=f}return x})}loadTexture(e){let t=this.json,n=this.options,s=t.textures[e].source,r=t.images[s],o=this.textureLoader;if(r.uri){let a=n.manager.getHandler(r.uri);if(a!==null)o=a}return this.loadTextureImage(e,s,o)}loadTextureImage(e,t,n){let i=this,s=this.json,r=s.textures[e],o=s.images[t],a=(o.uri||o.bufferView)+":"+r.sampler;if(this.textureCache[a])return this.textureCache[a];let l=this.loadImageSource(t,n).then(function(c){if(c.flipY=!1,c.name=r.name||o.name||"",c.name===""&&typeof o.uri==="string"&&o.uri.startsWith("data:image/")===!1)c.name=o.uri;let h=(s.samplers||{})[r.sampler]||{};return c.magFilter=Qf[h.magFilter]||Yt,c.minFilter=Qf[h.minFilter]||Ln,c.wrapS=ep[h.wrapS]||Fs,c.wrapT=ep[h.wrapT]||Fs,c.generateMipmaps=!c.isCompressedTexture&&c.minFilter!==Pn&&c.minFilter!==Yt,i.associations.set(c,{textures:e}),c}).catch(function(){return null});return this.textureCache[a]=l,l}loadImageSource(e,t){let n=this,i=this.json,s=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then((h)=>h.clone());let r=i.images[e],o=self.URL||self.webkitURL,a=r.uri||"",l=!1,c;if(t.isKTX2Loader===!0&&r.bufferView!==void 0)c=n.getDependency("bufferView",r.bufferView).then(function(h){return new Promise(function(d,f){t.parse(h,d,f)})});else{if(r.bufferView!==void 0)a=n.getDependency("bufferView",r.bufferView).then(function(h){l=!0;let d=new Blob([h],{type:r.mimeType});return a=o.createObjectURL(d),a});else if(r.uri===void 0)throw Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");c=Promise.resolve(a).then(function(h){return new Promise(function(d,f){let m=d;if(t.isImageBitmapLoader===!0)m=function(x){let p=new vt(x);p.needsUpdate=!0,d(p)};t.load(Ui.resolveURL(h,s.path),m,void 0,f)})})}let u=c.then(function(h){if(l===!0)o.revokeObjectURL(a);return qn(h,r),h.userData.mimeType=r.mimeType||yy(r.uri),h}).catch(function(h){throw console.error("THREE.GLTFLoader: Couldn't load texture",a),h});return this.sourceCache[e]=u,u}assignTexture(e,t,n,i){let s=this;return this.getDependency("texture",n.index).then(function(r){if(!r)return null;if(n.texCoord!==void 0&&n.texCoord>0)r=r.clone(),r.channel=n.texCoord;if(s.extensions[Ze.KHR_TEXTURE_TRANSFORM]){let o=n.extensions!==void 0?n.extensions[Ze.KHR_TEXTURE_TRANSFORM]:void 0;if(o){let a=s.associations.get(r);r=s.extensions[Ze.KHR_TEXTURE_TRANSFORM].extendTexture(r,o),s.associations.set(r,a)}}if(i!==void 0)r.colorSpace=i;return e[t]=r,r})}assignFinalMaterial(e){let{geometry:t,material:n}=e,i=t.attributes.tangent===void 0,s=t.attributes.color!==void 0,r=t.attributes.normal===void 0;if(e.isPoints){let o="PointsMaterial:"+n.uuid,a=this.cache.get(o);if(!a)a=new rs,tn.prototype.copy.call(a,n),a.color.copy(n.color),a.map=n.map,a.sizeAttenuation=!1,this.cache.add(o,a);n=a}else if(e.isLine){let o="LineBasicMaterial:"+n.uuid,a=this.cache.get(o);if(!a)a=new an,tn.prototype.copy.call(a,n),a.color.copy(n.color),a.map=n.map,this.cache.add(o,a);n=a}if(i||s||r){let o="ClonedMaterial:"+n.uuid+":";if(i)o+="derivative-tangents:";if(s)o+="vertex-colors:";if(r)o+="flat-shading:";let a=this.cache.get(o);if(!a){if(a=n.clone(),s)a.vertexColors=!0;if(r)a.flatShading=!0;if(i){if(a.normalScale)a.normalScale.y*=-1;if(a.clearcoatNormalScale)a.clearcoatNormalScale.y*=-1}this.cache.add(o,a),this.associations.set(a,this.associations.get(n))}n=a}e.material=n}getMaterialType(){return qs}loadMaterial(e){let t=this,n=this.json,i=this.extensions,s=n.materials[e],r,o={},a=s.extensions||{},l=[];if(a[Ze.KHR_MATERIALS_UNLIT]){let u=i[Ze.KHR_MATERIALS_UNLIT];r=u.getMaterialType(),l.push(u.extendParams(o,s,t))}else{let u=s.pbrMetallicRoughness||{};if(o.color=new xe(1,1,1),o.opacity=1,Array.isArray(u.baseColorFactor)){let h=u.baseColorFactor;o.color.setRGB(h[0],h[1],h[2],fn),o.opacity=h[3]}if(u.baseColorTexture!==void 0)l.push(t.assignTexture(o,"map",u.baseColorTexture,Nn));if(o.metalness=u.metallicFactor!==void 0?u.metallicFactor:1,o.roughness=u.roughnessFactor!==void 0?u.roughnessFactor:1,u.metallicRoughnessTexture!==void 0)l.push(t.assignTexture(o,"metalnessMap",u.metallicRoughnessTexture)),l.push(t.assignTexture(o,"roughnessMap",u.metallicRoughnessTexture));r=this._invokeOne(function(h){return h.getMaterialType&&h.getMaterialType(e)}),l.push(Promise.all(this._invokeAll(function(h){return h.extendMaterialParams&&h.extendMaterialParams(e,o)})))}if(s.doubleSided===!0)o.side=en;let c=s.alphaMode||xu.OPAQUE;if(c===xu.BLEND)o.transparent=!0,o.depthWrite=!1;else if(o.transparent=!1,c===xu.MASK)o.alphaTest=s.alphaCutoff!==void 0?s.alphaCutoff:0.5;if(s.normalTexture!==void 0&&r!==nn){if(l.push(t.assignTexture(o,"normalMap",s.normalTexture)),o.normalScale=new Ce(1,1),s.normalTexture.scale!==void 0){let u=s.normalTexture.scale;o.normalScale.set(u,u)}}if(s.occlusionTexture!==void 0&&r!==nn){if(l.push(t.assignTexture(o,"aoMap",s.occlusionTexture)),s.occlusionTexture.strength!==void 0)o.aoMapIntensity=s.occlusionTexture.strength}if(s.emissiveFactor!==void 0&&r!==nn){let u=s.emissiveFactor;o.emissive=new xe().setRGB(u[0],u[1],u[2],fn)}if(s.emissiveTexture!==void 0&&r!==nn)l.push(t.assignTexture(o,"emissiveMap",s.emissiveTexture,Nn));return Promise.all(l).then(function(){let u=new r(o);if(s.name)u.name=s.name;if(qn(u,s),t.associations.set(u,{materials:e}),s.extensions)cs(i,u,s);return u})}createUniqueName(e){let t=rt.sanitizeNodeName(e||"");if(t in this.nodeNamesUsed)return t+"_"+ ++this.nodeNamesUsed[t];else return this.nodeNamesUsed[t]=0,t}loadGeometries(e){let t=this,n=this.extensions,i=this.primitiveCache;function s(o){return n[Ze.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(o,t).then(function(a){return tp(a,o,t)})}let r=[];for(let o=0,a=e.length;o<a;o++){let l=e[o],c=My(l),u=i[c];if(u)r.push(u.promise);else{let h;if(l.extensions&&l.extensions[Ze.KHR_DRACO_MESH_COMPRESSION])h=s(l);else h=tp(new Qe,l,t);if(l.mode===vn.TRIANGLE_STRIP)h=h.then((d)=>gu(d,Lr));else if(l.mode===vn.TRIANGLE_FAN)h=h.then((d)=>gu(d,ks));i[c]={primitive:l,promise:h},r.push(h)}}return Promise.all(r)}loadMesh(e){let t=this,n=this.json,i=this.extensions,s=n.meshes[e],r=s.primitives,o=[];for(let a=0,l=r.length;a<l;a++){let c=r[a].material===void 0?gy(this.cache):this.getDependency("material",r[a].material);o.push(c)}return o.push(t.loadGeometries(r)),Promise.all(o).then(async function(a){let l=a.slice(0,a.length-1),c=a[a.length-1],u=[];for(let d=0,f=c.length;d<f;d++){let m=c[d],x=r[d],p,g=l[d];if(x.mode===vn.TRIANGLES||x.mode===vn.TRIANGLE_STRIP||x.mode===vn.TRIANGLE_FAN||x.mode===void 0){let v=s.isSkinnedMesh===!0,S=m.hasAttribute("skinIndex")&&m.hasAttribute("skinWeight");if(v&&S===!1)console.warn("THREE.GLTFLoader: Missing skinIndex or skinWeight attributes. Skinning disabled.");if(p=v&&S?new Gs(m,g):new bt(m,g),p.isSkinnedMesh===!0)p.normalizeSkinWeights()}else if(x.mode===vn.LINES)p=new Un(m,g);else if(x.mode===vn.LINE_STRIP)p=new Ci(m,g);else if(x.mode===vn.LINE_LOOP)p=new _a(m,g);else if(x.mode===vn.POINTS)p=new zs(m,g);else throw Error("THREE.GLTFLoader: Primitive mode unsupported: "+x.mode);if(Object.keys(p.geometry.morphAttributes).length>0)xy(p,s);if(p.name=t.createUniqueName(s.name||"mesh_"+e),qn(p,s),x.extensions)cs(i,p,x);t.assignFinalMaterial(p),u.push(p)}for(let d=0,f=u.length;d<f;d++)t.associations.set(u[d],{meshes:e,primitives:d});if(u.length===1){if(s.extensions)cs(i,u[0],s);return u[0]}let h=new yt;if(s.extensions)cs(i,h,s);t.associations.set(h,{meshes:e});for(let d=0,f=u.length;d<f;d++)h.add(u[d]);return h})}loadCamera(e){let t,n=this.json.cameras[e],i=n[n.type];if(!i){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}if(n.type==="perspective")t=new Ut($e.radToDeg(i.yfov),i.aspectRatio||1,i.znear||1,i.zfar||2000000);else if(n.type==="orthographic")t=new Zs(-i.xmag,i.xmag,i.ymag,-i.ymag,i.znear,i.zfar);if(n.name)t.name=this.createUniqueName(n.name);return qn(t,n),Promise.resolve(t)}loadSkin(e){let t=this.json.skins[e],n=[];for(let i=0,s=t.joints.length;i<s;i++)n.push(this._loadNodeShallow(t.joints[i]));if(t.inverseBindMatrices!==void 0)n.push(this.getDependency("accessor",t.inverseBindMatrices));else n.push(null);return Promise.all(n).then(function(i){let s=i.pop(),r=i,o=[],a=[];for(let l=0,c=r.length;l<c;l++){let u=r[l];if(u){o.push(u);let h=new Re;if(s!==null)h.fromArray(s.array,l*16);a.push(h)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[l])}return new Dn(o,a)})}loadAnimation(e){let t=this.json,n=this,i=t.animations[e],s=i.name?i.name:"animation_"+e,r=[],o=[],a=[],l=[],c=[];for(let u=0,h=i.channels.length;u<h;u++){let d=i.channels[u],f=i.samplers[d.sampler],m=d.target,x=m.node,p=i.parameters!==void 0?i.parameters[f.input]:f.input,g=i.parameters!==void 0?i.parameters[f.output]:f.output;if(m.node===void 0)continue;r.push(this.getDependency("node",x)),o.push(this.getDependency("accessor",p)),a.push(this.getDependency("accessor",g)),l.push(f),c.push(m)}return Promise.all([Promise.all(r),Promise.all(o),Promise.all(a),Promise.all(l),Promise.all(c)]).then(function(u){let h=u[0],d=u[1],f=u[2],m=u[3],x=u[4],p=[];for(let v=0,S=h.length;v<S;v++){let T=h[v],A=d[v],w=f[v],_=m[v],E=x[v];if(T===void 0)continue;if(T.updateMatrix)T.updateMatrix();let I=n._createAnimationTracks(T,A,w,_,E);if(I)for(let k=0;k<I.length;k++)p.push(I[k])}let g=new Sa(s,void 0,p);return qn(g,i),g})}createNodeMesh(e){let t=this.json,n=this,i=t.nodes[e];if(i.mesh===void 0)return null;return n.getDependency("mesh",i.mesh).then(function(s){let r=n._getNodeRef(n.meshCache,i.mesh,s);if(i.weights!==void 0)r.traverse(function(o){if(!o.isMesh)return;for(let a=0,l=i.weights.length;a<l;a++)o.morphTargetInfluences[a]=i.weights[a]});return r})}loadNode(e){let t=this.json,n=this,i=t.nodes[e],s=n._loadNodeShallow(e),r=[],o=i.children||[];for(let l=0,c=o.length;l<c;l++)r.push(n.getDependency("node",o[l]));let a=i.skin===void 0?Promise.resolve(null):n.getDependency("skin",i.skin);return Promise.all([s,Promise.all(r),a]).then(function(l){let c=l[0],u=l[1],h=l[2];if(h!==null)c.traverse(function(d){if(!d.isSkinnedMesh)return;d.bind(h,vy)});for(let d=0,f=u.length;d<f;d++)c.add(u[d]);if(c.userData.pivot!==void 0&&u.length>0){let d=c.userData.pivot,f=u[0];c.pivot=new R().fromArray(d),c.position.x-=d[0],c.position.y-=d[1],c.position.z-=d[2],f.position.set(0,0,0),delete c.userData.pivot}return c})}_loadNodeShallow(e){let t=this.json,n=this.extensions,i=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];let s=t.nodes[e],r=s.name?i.createUniqueName(s.name):"",o=[],a=i._invokeOne(function(l){return l.createNodeMesh&&l.createNodeMesh(e)});if(a)o.push(a);if(s.camera!==void 0)o.push(i.getDependency("camera",s.camera).then(function(l){return i._getNodeRef(i.cameraCache,s.camera,l)}));return i._invokeAll(function(l){return l.createNodeAttachment&&l.createNodeAttachment(e)}).forEach(function(l){o.push(l)}),this.nodeCache[e]=Promise.all(o).then(function(l){let c;if(s.isBone===!0)c=new Ur;else if(l.length>1)c=new yt;else if(l.length===1)c=l[0];else c=new tt;if(c!==l[0])for(let u=0,h=l.length;u<h;u++)c.add(l[u]);if(s.name)c.userData.name=s.name,c.name=r;if(qn(c,s),s.extensions)cs(n,c,s);if(s.matrix!==void 0){let u=new Re;u.fromArray(s.matrix),c.applyMatrix4(u)}else{if(s.translation!==void 0)c.position.fromArray(s.translation);if(s.rotation!==void 0)c.quaternion.fromArray(s.rotation);if(s.scale!==void 0)c.scale.fromArray(s.scale)}if(!i.associations.has(c))i.associations.set(c,{});else if(s.mesh!==void 0&&i.meshCache.refs[s.mesh]>1){let u=i.associations.get(c);i.associations.set(c,{...u})}return i.associations.get(c).nodes=e,c}),this.nodeCache[e]}loadScene(e){let t=this.extensions,n=this.json.scenes[e],i=this,s=new yt;if(n.name)s.name=i.createUniqueName(n.name);if(qn(s,n),n.extensions)cs(t,s,n);let r=n.nodes||[],o=[];for(let a=0,l=r.length;a<l;a++)o.push(i.getDependency("node",r[a]));return Promise.all(o).then(function(a){for(let c=0,u=a.length;c<u;c++){let h=a[c];if(h.parent!==null)s.add(Jf(h));else s.add(h)}let l=(c)=>{let u=new Map;for(let[h,d]of i.associations)if(h instanceof tn||h instanceof vt)u.set(h,d);return c.traverse((h)=>{let d=i.associations.get(h);if(d!=null)u.set(h,d)}),u};return i.associations=l(s),s})}_createAnimationTracks(e,t,n,i,s){let r=[],o=e.name?e.name:e.uuid,a=[];function l(d){if(d.morphTargetInfluences)a.push(d.name?d.name:d.uuid)}if(Oi[s.path]===Oi.weights){if(l(e),e.isGroup)e.children.forEach(l)}else a.push(o);let c;switch(Oi[s.path]){case Oi.weights:c=Ii;break;case Oi.rotation:c=Ni;break;case Oi.translation:case Oi.scale:c=as;break;default:switch(n.itemSize){case 1:c=Ii;break;case 2:case 3:default:c=as;break}break}let u=i.interpolation!==void 0?my[i.interpolation]:la,h=this._getArrayFromAccessor(n);for(let d=0,f=a.length;d<f;d++){let m=new c(a[d]+"."+Oi[s.path],t.array,h,u);if(i.interpolation==="CUBICSPLINE")this._createCubicSplineTrackInterpolant(m);r.push(m)}return r}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let n=Eu(t.constructor),i=new Float32Array(t.length);for(let s=0,r=t.length;s<r;s++)i[s]=t[s]*n;t=i}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){return new(this instanceof Ni?bp:Su)(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function Ey(e,t,n){let i=t.attributes,s=new yn;if(i.POSITION!==void 0){let a=n.json.accessors[i.POSITION],{min:l,max:c}=a;if(l!==void 0&&c!==void 0){if(s.set(new R(l[0],l[1],l[2]),new R(c[0],c[1],c[2])),a.normalized){let u=Eu(Js[a.componentType]);s.min.multiplyScalar(u),s.max.multiplyScalar(u)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;let r=t.targets;if(r!==void 0){let a=new R,l=new R;for(let c=0,u=r.length;c<u;c++){let h=r[c];if(h.POSITION!==void 0){let d=n.json.accessors[h.POSITION],{min:f,max:m}=d;if(f!==void 0&&m!==void 0){if(l.setX(Math.max(Math.abs(f[0]),Math.abs(m[0]))),l.setY(Math.max(Math.abs(f[1]),Math.abs(m[1]))),l.setZ(Math.max(Math.abs(f[2]),Math.abs(m[2]))),d.normalized){let x=Eu(Js[d.componentType]);l.multiplyScalar(x)}a.max(l)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}s.expandByVector(a)}e.boundingBox=s;let o=new pn;s.getCenter(o.center),o.radius=s.min.distanceTo(s.max)/2,e.boundingSphere=o}function tp(e,t,n){let i=t.attributes,s=[];function r(o,a){return n.getDependency("accessor",o).then(function(l){e.setAttribute(a,l)})}for(let o in i){let a=vu[o]||o.toLowerCase();if(a in e.attributes)continue;s.push(r(i[o],a))}if(t.indices!==void 0&&!e.index){let o=n.getDependency("accessor",t.indices).then(function(a){e.setIndex(a)});s.push(o)}if(qe.workingColorSpace!==fn&&"COLOR_0"in i)console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${qe.workingColorSpace}" not supported.`);return qn(e,t),Ey(e,t,n),Promise.all(s).then(function(){return t.targets!==void 0?_y(e,t.targets,n):e})}var Ap={type:"change"},Ru={type:"start"},Cp={type:"end"},Ba=new wi,wp=new _n,Ty=Math.cos(70*$e.DEG2RAD),Ct=new R,cn=2*Math.PI,ot={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},bu=0.000001;class Au extends Ia{constructor(e,t=null){super(e,t);if(this.state=ot.NONE,this.target=new R,this.cursor=new R,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=0.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Ei.ROTATE,MIDDLE:Ei.DOLLY,RIGHT:Ei.PAN},this.touches={ONE:Ti.ROTATE,TWO:Ti.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="",this._domElementKeyEvents=null,this._lastPosition=new R,this._lastQuaternion=new be,this._lastTargetPosition=new R,this._quat=new be().setFromUnitVectors(e.up,new R(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new zr,this._sphericalDelta=new zr,this._scale=1,this._panOffset=new R,this._rotateStart=new Ce,this._rotateEnd=new Ce,this._rotateDelta=new Ce,this._panStart=new Ce,this._panEnd=new Ce,this._panDelta=new Ce,this._dollyStart=new Ce,this._dollyEnd=new Ce,this._dollyDelta=new Ce,this._dollyDirection=new R,this._mouse=new Ce,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=by.bind(this),this._onPointerDown=Sy.bind(this),this._onPointerUp=Ry.bind(this),this._onContextMenu=Ny.bind(this),this._onMouseWheel=Cy.bind(this),this._onKeyDown=Py.bind(this),this._onTouchStart=Ly.bind(this),this._onTouchMove=Iy.bind(this),this._onMouseDown=Ay.bind(this),this._onMouseMove=wy.bind(this),this._interceptControlDown=Dy.bind(this),this._interceptControlUp=Uy.bind(this),this.domElement!==null)this.connect(this.domElement);this.update()}set cursorStyle(e){if(this._cursorStyle=e,e==="grab")this.domElement.style.cursor="grab";else this.domElement.style.cursor=""}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.ownerDocument.addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){if(this.state=ot.NONE,this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.ownerDocument.removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.ownerDocument.removeEventListener("keyup",this._interceptControlUp,{capture:!0}),this._controlActive=!1,this._pointers.length=0,this._pointerPositions={},this.domElement.style.touchAction="",this._cursorStyle==="grab")this.domElement.style.cursor=""}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){if(this._domElementKeyEvents!==null)this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Ap),this.update(),this.state=ot.NONE}pan(e,t){this._pan(e,t),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){let t=this.object.position;if(Ct.copy(t).sub(this.target),Ct.applyQuaternion(this._quat),this._spherical.setFromVector3(Ct),this.autoRotate&&this.state===ot.NONE)this._rotateLeft(this._getAutoRotationAngle(e));if(this.enableDamping)this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor;else this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi;let n=this.minAzimuthAngle,i=this.maxAzimuthAngle;if(isFinite(n)&&isFinite(i)){if(n<-Math.PI)n+=cn;else if(n>Math.PI)n-=cn;if(i<-Math.PI)i+=cn;else if(i>Math.PI)i-=cn;if(n<=i)this._spherical.theta=Math.max(n,Math.min(i,this._spherical.theta));else this._spherical.theta=this._spherical.theta>(n+i)/2?Math.max(n,this._spherical.theta):Math.min(i,this._spherical.theta)}if(this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0)this.target.addScaledVector(this._panOffset,this.dampingFactor);else this.target.add(this._panOffset);this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let s=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{let r=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),s=r!=this._spherical.radius}if(Ct.setFromSpherical(this._spherical),Ct.applyQuaternion(this._quatInverse),t.copy(this.target).add(Ct),this.object.lookAt(this.target),this.enableDamping===!0)this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor);else this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0);if(this.zoomToCursor&&this._performCursorZoom){let r=null;if(this.object.isPerspectiveCamera){let o=Ct.length();r=this._clampDistance(o*this._scale);let a=o-r;this.object.position.addScaledVector(this._dollyDirection,a),this.object.updateMatrixWorld(),s=!!a}else if(this.object.isOrthographicCamera){let o=new R(this._mouse.x,this._mouse.y,0);o.unproject(this.object);let a=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),s=a!==this.object.zoom;let l=new R(this._mouse.x,this._mouse.y,0);l.unproject(this.object),this.object.position.sub(l).add(o),this.object.updateMatrixWorld(),r=Ct.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;if(r!==null)if(this.screenSpacePanning)this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(r).add(this.object.position);else if(Ba.origin.copy(this.object.position),Ba.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(Ba.direction))<Ty)this.object.lookAt(this.target);else wp.setFromNormalAndCoplanarPoint(this.object.up,this.target),Ba.intersectPlane(wp,this.target)}else if(this.object.isOrthographicCamera){let r=this.object.zoom;if(this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),r!==this.object.zoom)this.object.updateProjectionMatrix(),s=!0}if(this._scale=1,this._performCursorZoom=!1,s||this._lastPosition.distanceToSquared(this.object.position)>bu||8*(1-this._lastQuaternion.dot(this.object.quaternion))>bu||this._lastTargetPosition.distanceToSquared(this.target)>bu)return this.dispatchEvent(Ap),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0;return!1}_getAutoRotationAngle(e){if(e!==null)return cn/60*this.autoRotateSpeed*e;else return cn/60/60*this.autoRotateSpeed}_getZoomScale(e){let t=Math.abs(e*0.01);return Math.pow(0.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){Ct.setFromMatrixColumn(t,0),Ct.multiplyScalar(-e),this._panOffset.add(Ct)}_panUp(e,t){if(this.screenSpacePanning===!0)Ct.setFromMatrixColumn(t,1);else Ct.setFromMatrixColumn(t,0),Ct.crossVectors(this.object.up,Ct);Ct.multiplyScalar(e),this._panOffset.add(Ct)}_pan(e,t){let n=this.domElement;if(this.object.isPerspectiveCamera){let i=this.object.position;Ct.copy(i).sub(this.target);let s=Ct.length();s*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*s/n.clientHeight,this.object.matrix),this._panUp(2*t*s/n.clientHeight,this.object.matrix)}else if(this.object.isOrthographicCamera)this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix);else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1}_dollyOut(e){if(this.object.isPerspectiveCamera||this.object.isOrthographicCamera)this._scale/=e;else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1}_dollyIn(e){if(this.object.isPerspectiveCamera||this.object.isOrthographicCamera)this._scale*=e;else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;let n=this.domElement.getBoundingClientRect(),i=e-n.left,s=t-n.top,{width:r,height:o}=n;this._mouse.x=i/r*2-1,this._mouse.y=-(s/o)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientY),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(cn*this._rotateDelta.x/t.clientHeight),this._rotateUp(cn*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){if(this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0)this._dollyOut(this._getZoomScale(this._dollyDelta.y));else if(this._dollyDelta.y<0)this._dollyIn(this._getZoomScale(this._dollyDelta.y));if(this._dollyStart.copy(this._dollyEnd),this.zoomToCursor)this._performCursorZoom=!0,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize();this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){if(this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0)this._dollyIn(this._getZoomScale(e.deltaY));else if(e.deltaY>0)this._dollyOut(this._getZoomScale(e.deltaY));this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:if(e.ctrlKey||e.metaKey||e.shiftKey){if(this.enableRotate)this._rotateUp(cn*this.keyRotateSpeed/this.domElement.clientHeight)}else if(this.enablePan)this._pan(0,this.keyPanSpeed);t=!0;break;case this.keys.BOTTOM:if(e.ctrlKey||e.metaKey||e.shiftKey){if(this.enableRotate)this._rotateUp(-cn*this.keyRotateSpeed/this.domElement.clientHeight)}else if(this.enablePan)this._pan(0,-this.keyPanSpeed);t=!0;break;case this.keys.LEFT:if(e.ctrlKey||e.metaKey||e.shiftKey){if(this.enableRotate)this._rotateLeft(cn*this.keyRotateSpeed/this.domElement.clientHeight)}else if(this.enablePan)this._pan(this.keyPanSpeed,0);t=!0;break;case this.keys.RIGHT:if(e.ctrlKey||e.metaKey||e.shiftKey){if(this.enableRotate)this._rotateLeft(-cn*this.keyRotateSpeed/this.domElement.clientHeight)}else if(this.enablePan)this._pan(-this.keyPanSpeed,0);t=!0;break}if(t)e.preventDefault(),this.update()}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=0.5*(e.pageX+t.x),i=0.5*(e.pageY+t.y);this._rotateStart.set(n,i)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=0.5*(e.pageX+t.x),i=0.5*(e.pageY+t.y);this._panStart.set(n,i)}}_handleTouchStartDolly(e){let t=this._getSecondPointerPosition(e),n=e.pageX-t.x,i=e.pageY-t.y,s=Math.sqrt(n*n+i*i);this._dollyStart.set(0,s)}_handleTouchStartDollyPan(e){if(this.enableZoom)this._handleTouchStartDolly(e);if(this.enablePan)this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){if(this.enableZoom)this._handleTouchStartDolly(e);if(this.enableRotate)this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{let n=this._getSecondPointerPosition(e),i=0.5*(e.pageX+n.x),s=0.5*(e.pageY+n.y);this._rotateEnd.set(i,s)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(cn*this._rotateDelta.x/t.clientHeight),this._rotateUp(cn*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=0.5*(e.pageX+t.x),i=0.5*(e.pageY+t.y);this._panEnd.set(n,i)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){let t=this._getSecondPointerPosition(e),n=e.pageX-t.x,i=e.pageY-t.y,s=Math.sqrt(n*n+i*i);this._dollyEnd.set(0,s),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);let r=(e.pageX+t.x)*0.5,o=(e.pageY+t.y)*0.5;this._updateZoomParameters(r,o)}_handleTouchMoveDollyPan(e){if(this.enableZoom)this._handleTouchMoveDolly(e);if(this.enablePan)this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){if(this.enableZoom)this._handleTouchMoveDolly(e);if(this.enableRotate)this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];if(t===void 0)t=new Ce,this._pointerPositions[e.pointerId]=t;t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){let t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){let t=e.deltaMode,n={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}if(e.ctrlKey&&!this._controlActive)n.deltaY*=10;return n}}function Sy(e){if(this.enabled===!1)return;if(this._pointers.length===0)this.domElement.setPointerCapture(e.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp);if(this._isTrackingPointer(e))return;if(this._addPointer(e),e.pointerType==="touch")this._onTouchStart(e);else this._onMouseDown(e);if(this._cursorStyle==="grab")this.domElement.style.cursor="grabbing"}function by(e){if(this.enabled===!1)return;if(e.pointerType==="touch")this._onTouchMove(e);else this._onMouseMove(e)}function Ry(e){switch(this._removePointer(e),this._pointers.length){case 0:if(this.domElement.releasePointerCapture(e.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(Cp),this.state=ot.NONE,this._cursorStyle==="grab")this.domElement.style.cursor="grab";break;case 1:let t=this._pointers[0],n=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:n.x,pageY:n.y});break}}function Ay(e){let t;switch(e.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case Ei.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(e),this.state=ot.DOLLY;break;case Ei.ROTATE:if(e.ctrlKey||e.metaKey||e.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(e),this.state=ot.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(e),this.state=ot.ROTATE}break;case Ei.PAN:if(e.ctrlKey||e.metaKey||e.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(e),this.state=ot.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(e),this.state=ot.PAN}break;default:this.state=ot.NONE}if(this.state!==ot.NONE)this.dispatchEvent(Ru)}function wy(e){switch(this.state){case ot.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(e);break;case ot.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(e);break;case ot.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(e);break}}function Cy(e){if(this.enabled===!1||this.enableZoom===!1||this.state!==ot.NONE)return;e.preventDefault(),this.dispatchEvent(Ru),this._handleMouseWheel(this._customWheelEvent(e)),this.dispatchEvent(Cp)}function Py(e){if(this.enabled===!1)return;this._handleKeyDown(e)}function Ly(e){switch(this._trackPointer(e),this._pointers.length){case 1:switch(this.touches.ONE){case Ti.ROTATE:if(this.enableRotate===!1){this.state=ot.NONE;break}this._handleTouchStartRotate(e),this.state=ot.TOUCH_ROTATE;break;case Ti.PAN:if(this.enablePan===!1){this.state=ot.NONE;break}this._handleTouchStartPan(e),this.state=ot.TOUCH_PAN;break;default:this.state=ot.NONE}break;case 2:switch(this.touches.TWO){case Ti.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(e),this.state=ot.TOUCH_DOLLY_PAN;break;case Ti.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(e),this.state=ot.TOUCH_DOLLY_ROTATE;break;default:this.state=ot.NONE}break;default:this.state=ot.NONE}if(this.state!==ot.NONE)this.dispatchEvent(Ru)}function Iy(e){switch(this._trackPointer(e),this.state){case ot.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(e),this.update();break;case ot.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(e),this.update();break;case ot.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(e),this.update();break;case ot.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(e),this.update();break;default:this.state=ot.NONE}}function Ny(e){if(this.enabled===!1)return;e.preventDefault()}function Dy(e){if(e.key==="Control")this._controlActive=!0,this.domElement.ownerDocument.addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0})}function Uy(e){if(e.key==="Control")this._controlActive=!1,this.domElement.ownerDocument.removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0})}class jr extends tt{expressionName;weight=0;isBinary=!1;overrideBlink="none";overrideLookAt="none";overrideMouth="none";_binds=[];get binds(){return this._binds}type;get overrideBlinkAmount(){if(this.overrideBlink==="block")return 0<this.outputWeight?1:0;else if(this.overrideBlink==="blend")return this.outputWeight;else return 0}get overrideLookAtAmount(){if(this.overrideLookAt==="block")return 0<this.outputWeight?1:0;else if(this.overrideLookAt==="blend")return this.outputWeight;else return 0}get overrideMouthAmount(){if(this.overrideMouth==="block")return 0<this.outputWeight?1:0;else if(this.overrideMouth==="blend")return this.outputWeight;else return 0}get outputWeight(){if(this.isBinary)return this.weight>0.5?1:0;return this.weight}constructor(e){super();this.name=`VRMExpression_${e}`,this.expressionName=e,this.type="VRMExpression",this.visible=!1}addBind(e){this._binds.push(e)}deleteBind(e){let t=this._binds.indexOf(e);if(t>=0)this._binds.splice(t,1)}applyWeight(e){let t=this.outputWeight;if(t*=e?.multiplier??1,this.isBinary&&t<1)t=0;this._binds.forEach((n)=>n.applyWeight(t))}clearAppliedWeight(){this._binds.forEach((e)=>e.clearAppliedWeight())}}function Pp(e,t,n){let i=e.parser.json,s=i.nodes?.[t];if(s==null)return console.warn(`extractPrimitivesInternal: Attempt to use nodes[${t}] of glTF but the node doesn't exist`),null;let r=s.mesh;if(r==null)return null;let o=i.meshes?.[r];if(o==null)return console.warn(`extractPrimitivesInternal: Attempt to use meshes[${r}] of glTF but the mesh doesn't exist`),null;let a=o.primitives.length,l=[];return n.traverse((c)=>{if(l.length<a){if(c.isMesh)l.push(c)}}),l}async function wu(e,t){let n=await e.parser.getDependency("node",t);return Pp(e,t,n)}async function Cu(e){let t=await e.parser.getDependencies("node"),n=new Map;return t.forEach((i,s)=>{let r=Pp(e,s,i);if(r!=null)n.set(s,r)}),n}var Ks={Aa:"aa",Ih:"ih",Ou:"ou",Ee:"ee",Oh:"oh",Blink:"blink",Happy:"happy",Angry:"angry",Sad:"sad",Relaxed:"relaxed",LookUp:"lookUp",Surprised:"surprised",LookDown:"lookDown",LookLeft:"lookLeft",LookRight:"lookRight",BlinkLeft:"blinkLeft",BlinkRight:"blinkRight",Neutral:"neutral"};function Va(e){return Math.max(Math.min(e,1),0)}class $s{blinkExpressionNames=["blink","blinkLeft","blinkRight"];lookAtExpressionNames=["lookLeft","lookRight","lookUp","lookDown"];mouthExpressionNames=["aa","ee","ih","oh","ou"];_expressions=[];get expressions(){return this._expressions.concat()}_expressionMap={};get expressionMap(){return Object.assign({},this._expressionMap)}get presetExpressionMap(){let e={},t=new Set(Object.values(Ks));return Object.entries(this._expressionMap).forEach(([n,i])=>{if(t.has(n))e[n]=i}),e}get customExpressionMap(){let e={},t=new Set(Object.values(Ks));return Object.entries(this._expressionMap).forEach(([n,i])=>{if(!t.has(n))e[n]=i}),e}constructor(){}copy(e){return this._expressions.concat().forEach((n)=>{this.unregisterExpression(n)}),e._expressions.forEach((n)=>{this.registerExpression(n)}),this.blinkExpressionNames=e.blinkExpressionNames.concat(),this.lookAtExpressionNames=e.lookAtExpressionNames.concat(),this.mouthExpressionNames=e.mouthExpressionNames.concat(),this}clone(){return new $s().copy(this)}getExpression(e){return this._expressionMap[e]??null}registerExpression(e){this._expressions.push(e),this._expressionMap[e.expressionName]=e}unregisterExpression(e){let t=this._expressions.indexOf(e);if(t===-1)console.warn("VRMExpressionManager: The specified expressions is not registered");this._expressions.splice(t,1),delete this._expressionMap[e.expressionName]}getValue(e){return this.getExpression(e)?.weight??null}setValue(e,t){let n=this.getExpression(e);if(n)n.weight=Va(t)}resetValues(){this._expressions.forEach((e)=>{e.weight=0})}getExpressionTrackName(e){let t=this.getExpression(e);return t?`${t.name}.weight`:null}update(){let e=this._calculateWeightMultipliers();this._expressions.forEach((t)=>{t.clearAppliedWeight()}),this._expressions.forEach((t)=>{let n=1,i=t.expressionName;if(this.blinkExpressionNames.indexOf(i)!==-1)n*=e.blink;if(this.lookAtExpressionNames.indexOf(i)!==-1)n*=e.lookAt;if(this.mouthExpressionNames.indexOf(i)!==-1)n*=e.mouth;t.applyWeight({multiplier:n})})}_calculateWeightMultipliers(){let e=1,t=1,n=1;return this._expressions.forEach((i)=>{e-=i.overrideBlinkAmount,t-=i.overrideLookAtAmount,n-=i.overrideMouthAmount}),e=Math.max(0,e),t=Math.max(0,t),n=Math.max(0,n),{blink:e,lookAt:t,mouth:n}}}var Qs={Color:"color",EmissionColor:"emissionColor",ShadeColor:"shadeColor",MatcapColor:"matcapColor",RimColor:"rimColor",OutlineColor:"outlineColor"},Lp={_Color:Qs.Color,_EmissionColor:Qs.EmissionColor,_ShadeColor:Qs.ShadeColor,_RimColor:Qs.RimColor,_OutlineColor:Qs.OutlineColor};var Oy=new xe;class er{static _propertyNameMapMap={isMeshStandardMaterial:{color:["color","opacity"],emissionColor:["emissive",null]},isMeshBasicMaterial:{color:["color","opacity"]},isMToonMaterial:{color:["color","opacity"],emissionColor:["emissive",null],outlineColor:["outlineColorFactor",null],matcapColor:["matcapFactor",null],rimColor:["parametricRimColorFactor",null],shadeColor:["shadeColorFactor",null]}};material;type;targetValue;targetAlpha;_state;constructor({material:e,type:t,targetValue:n,targetAlpha:i}){this.material=e,this.type=t,this.targetValue=n,this.targetAlpha=i??1;let s=this._initColorBindState(),r=this._initAlphaBindState();this._state={color:s,alpha:r}}applyWeight(e){let{color:t,alpha:n}=this._state;if(t!=null){let{propertyName:i,deltaValue:s}=t,r=this.material[i];if(r!=null)r.add(Oy.copy(s).multiplyScalar(e))}if(n!=null){let{propertyName:i,deltaValue:s}=n;if(this.material[i]!=null)this.material[i]+=s*e}}clearAppliedWeight(){let{color:e,alpha:t}=this._state;if(e!=null){let{propertyName:n,initialValue:i}=e,s=this.material[n];if(s!=null)s.copy(i)}if(t!=null){let{propertyName:n,initialValue:i}=t;if(this.material[n]!=null)this.material[n]=i}}_initColorBindState(){let{material:e,type:t,targetValue:n}=this,s=this._getPropertyNameMap()?.[t]?.[0]??null;if(s==null)return console.warn(`Tried to add a material color bind to the material ${e.name??"(no name)"}, the type ${t} but the material or the type is not supported.`),null;let o=e[s].clone(),a=new xe(n.r-o.r,n.g-o.g,n.b-o.b);return{propertyName:s,initialValue:o,deltaValue:a}}_initAlphaBindState(){let{material:e,type:t,targetAlpha:n}=this,s=this._getPropertyNameMap()?.[t]?.[1]??null;if(s==null&&n!==1)return console.warn(`Tried to add a material alpha bind to the material ${e.name??"(no name)"}, the type ${t} but the material or the type does not support alpha.`),null;if(s==null)return null;let r=e[s],o=n-r;return{propertyName:s,initialValue:r,deltaValue:o}}_getPropertyNameMap(){return Object.entries(er._propertyNameMapMap).find(([e])=>this.material[e]===!0)?.[1]??null}}class Fi{primitives;index;weight;constructor({primitives:e,index:t,weight:n}){this.primitives=e,this.index=t,this.weight=n}applyWeight(e){this.primitives.forEach((t)=>{if(t.morphTargetInfluences?.[this.index]!=null)t.morphTargetInfluences[this.index]+=this.weight*e})}clearAppliedWeight(){this.primitives.forEach((e)=>{if(e.morphTargetInfluences?.[this.index]!=null)e.morphTargetInfluences[this.index]=0})}}var Ip=new Ce;class tr{static _propertyNamesMap={isMeshStandardMaterial:["map","emissiveMap","bumpMap","normalMap","displacementMap","roughnessMap","metalnessMap","alphaMap"],isMeshBasicMaterial:["map","specularMap","alphaMap"],isMToonMaterial:["map","normalMap","emissiveMap","shadeMultiplyTexture","rimMultiplyTexture","outlineWidthMultiplyTexture","uvAnimationMaskTexture"]};material;scale;offset;_properties;constructor({material:e,scale:t,offset:n}){this.material=e,this.scale=t,this.offset=n;let i=Object.entries(tr._propertyNamesMap).find(([s])=>e[s]===!0)?.[1];if(i==null)console.warn(`Tried to add a texture transform bind to the material ${e.name??"(no name)"} but the material is not supported.`),this._properties=[];else this._properties=[],i.forEach((s)=>{let r=e[s]?.clone();if(!r)return null;e[s]=r;let o=r.offset.clone(),a=r.repeat.clone(),l=n.clone().sub(o),c=t.clone().sub(a);this._properties.push({name:s,initialOffset:o,deltaOffset:l,initialScale:a,deltaScale:c})})}applyWeight(e){this._properties.forEach((t)=>{let n=this.material[t.name];if(n===void 0)return;n.offset.add(Ip.copy(t.deltaOffset).multiplyScalar(e)),n.repeat.add(Ip.copy(t.deltaScale).multiplyScalar(e))})}clearAppliedWeight(){this._properties.forEach((e)=>{let t=this.material[e.name];if(t===void 0)return;t.offset.copy(e.initialOffset),t.repeat.copy(e.initialScale)})}}var Fy=new Set(["1.0","1.0-beta"]);class nr{static v0v1PresetNameMap={a:"aa",e:"ee",i:"ih",o:"oh",u:"ou",blink:"blink",joy:"happy",angry:"angry",sorrow:"sad",fun:"relaxed",lookup:"lookUp",lookdown:"lookDown",lookleft:"lookLeft",lookright:"lookRight",blink_l:"blinkLeft",blink_r:"blinkRight",neutral:"neutral"};parser;get name(){return"VRMExpressionLoaderPlugin"}constructor(e){this.parser=e}async afterRoot(e){e.userData.vrmExpressionManager=await this._import(e)}async _import(e){let t=await this._v1Import(e);if(t)return t;let n=await this._v0Import(e);if(n)return n;return null}async _v1Import(e){let t=this.parser.json;if(t.extensionsUsed?.indexOf("VRMC_vrm")===-1)return null;let i=t.extensions?.VRMC_vrm;if(!i)return null;let s=i.specVersion;if(!Fy.has(s))return console.warn(`VRMExpressionLoaderPlugin: Unknown VRMC_vrm specVersion "${s}"`),null;let r=i.expressions;if(!r)return null;let o=new Set(Object.values(Ks)),a=new Map;if(r.preset!=null)Object.entries(r.preset).forEach(([c,u])=>{if(u==null)return;if(!o.has(c)){console.warn(`VRMExpressionLoaderPlugin: Unknown preset name "${c}" detected. Ignoring the expression`);return}a.set(c,u)});if(r.custom!=null)Object.entries(r.custom).forEach(([c,u])=>{if(o.has(c)){console.warn(`VRMExpressionLoaderPlugin: Custom expression cannot have preset name "${c}". Ignoring the expression`);return}a.set(c,u)});let l=new $s;return await Promise.all(Array.from(a.entries()).map(async([c,u])=>{let h=new jr(c);if(e.scene.add(h),h.isBinary=u.isBinary??!1,h.overrideBlink=u.overrideBlink??"none",h.overrideLookAt=u.overrideLookAt??"none",h.overrideMouth=u.overrideMouth??"none",u.morphTargetBinds?.forEach(async(d)=>{if(d.node===void 0||d.index===void 0)return;let f=await wu(e,d.node),m=d.index;if(!f.every((x)=>Array.isArray(x.morphTargetInfluences)&&m<x.morphTargetInfluences.length)){console.warn(`VRMExpressionLoaderPlugin: ${u.name} attempts to index morph #${m} but not found.`);return}h.addBind(new Fi({primitives:f,index:m,weight:d.weight??1}))}),u.materialColorBinds||u.textureTransformBinds){let d=[];e.scene.traverse((f)=>{let m=f.material;if(m)if(Array.isArray(m))d.push(...m);else d.push(m)}),u.materialColorBinds?.forEach(async(f)=>{d.filter((x)=>{let p=this.parser.associations.get(x)?.materials;return f.material===p}).forEach((x)=>{h.addBind(new er({material:x,type:f.type,targetValue:new xe().fromArray(f.targetValue),targetAlpha:f.targetValue[3]}))})}),u.textureTransformBinds?.forEach(async(f)=>{d.filter((x)=>{let p=this.parser.associations.get(x)?.materials;return f.material===p}).forEach((x)=>{h.addBind(new tr({material:x,offset:new Ce().fromArray(f.offset??[0,0]),scale:new Ce().fromArray(f.scale??[1,1])}))})})}l.registerExpression(h)})),l}async _v0Import(e){let t=this.parser.json,n=t.extensions?.VRM;if(!n)return null;let i=n.blendShapeMaster;if(!i)return null;let s=new $s,r=i.blendShapeGroups;if(!r)return s;let o=new Set;return await Promise.all(r.map(async(a)=>{let l=a.presetName,u=(l!=null&&nr.v0v1PresetNameMap[l]||null)??a.name;if(u==null){console.warn("VRMExpressionLoaderPlugin: One of custom expressions has no name. Ignoring the expression");return}if(o.has(u)){console.warn(`VRMExpressionLoaderPlugin: An expression preset ${l} has duplicated entries. Ignoring the expression`);return}o.add(u);let h=new jr(u);if(e.scene.add(h),h.isBinary=a.isBinary??!1,a.binds)a.binds.forEach(async(f)=>{if(f.mesh===void 0||f.index===void 0)return;let m=[];if(t.nodes?.forEach((p,g)=>{if(p.mesh===f.mesh)m.push(g)}),m.length===0){console.warn(`VRMExpressionLoaderPlugin: ${a.name} attempts to bind a morph target to the mesh #${f.mesh} but the mesh is not found or not used in the scene. Ignoring the bind.`);return}let x=f.index;await Promise.all(m.map(async(p)=>{let g=await wu(e,p);if(!g.every((v)=>Array.isArray(v.morphTargetInfluences)&&x<v.morphTargetInfluences.length)){console.warn(`VRMExpressionLoaderPlugin: ${a.name} attempts to index ${x}th morph but not found.`);return}h.addBind(new Fi({primitives:g,index:x,weight:0.01*(f.weight??100)}))}))});let d=a.materialValues;if(d&&d.length!==0)d.forEach((f)=>{if(f.materialName===void 0||f.propertyName===void 0||f.targetValue===void 0)return;let m=[];e.scene.traverse((p)=>{if(p.material){let g=p.material;if(Array.isArray(g))m.push(...g.filter((v)=>(v.name===f.materialName||v.name===f.materialName+" (Outline)")&&m.indexOf(v)===-1));else if(g.name===f.materialName&&m.indexOf(g)===-1)m.push(g)}});let x=f.propertyName;m.forEach((p)=>{if(x==="_MainTex_ST"){let v=new Ce(f.targetValue[0],f.targetValue[1]),S=new Ce(f.targetValue[2],f.targetValue[3]);S.y=1-S.y-v.y,h.addBind(new tr({material:p,scale:v,offset:S}));return}let g=Lp[x];if(g){h.addBind(new er({material:p,type:g,targetValue:new xe().fromArray(f.targetValue),targetAlpha:f.targetValue[3]}));return}console.warn(x+" is not supported")})});s.registerExpression(h)})),s}}class Yn{static DEFAULT_FIRSTPERSON_ONLY_LAYER=9;static DEFAULT_THIRDPERSON_ONLY_LAYER=10;humanoid;meshAnnotations;_firstPersonOnlyLayer=Yn.DEFAULT_FIRSTPERSON_ONLY_LAYER;_thirdPersonOnlyLayer=Yn.DEFAULT_THIRDPERSON_ONLY_LAYER;_initializedLayers=!1;constructor(e,t){this.humanoid=e,this.meshAnnotations=t}copy(e){if(this.humanoid!==e.humanoid)throw Error("VRMFirstPerson: humanoid must be same in order to copy");return this.meshAnnotations=e.meshAnnotations.map((t)=>({meshes:t.meshes.concat(),type:t.type})),this}clone(){return new Yn(this.humanoid,this.meshAnnotations).copy(this)}get firstPersonOnlyLayer(){return this._firstPersonOnlyLayer}get thirdPersonOnlyLayer(){return this._thirdPersonOnlyLayer}setup({firstPersonOnlyLayer:e=Yn.DEFAULT_FIRSTPERSON_ONLY_LAYER,thirdPersonOnlyLayer:t=Yn.DEFAULT_THIRDPERSON_ONLY_LAYER}={}){if(this._initializedLayers)return;this._firstPersonOnlyLayer=e,this._thirdPersonOnlyLayer=t,this.meshAnnotations.forEach((n)=>{n.meshes.forEach((i)=>{if(n.type==="firstPersonOnly")i.layers.set(this._firstPersonOnlyLayer),i.traverse((s)=>s.layers.set(this._firstPersonOnlyLayer));else if(n.type==="thirdPersonOnly")i.layers.set(this._thirdPersonOnlyLayer),i.traverse((s)=>s.layers.set(this._thirdPersonOnlyLayer));else if(n.type==="auto")this._createHeadlessModel(i)})}),this._initializedLayers=!0}_excludeTriangles(e,t,n,i){let s=0;if(t!=null&&t.length>0)for(let r=0;r<e.length;r+=3){let o=e[r],a=e[r+1],l=e[r+2],c=t[o],u=n[o];if(c[0]>0&&i.includes(u[0]))continue;if(c[1]>0&&i.includes(u[1]))continue;if(c[2]>0&&i.includes(u[2]))continue;if(c[3]>0&&i.includes(u[3]))continue;let h=t[a],d=n[a];if(h[0]>0&&i.includes(d[0]))continue;if(h[1]>0&&i.includes(d[1]))continue;if(h[2]>0&&i.includes(d[2]))continue;if(h[3]>0&&i.includes(d[3]))continue;let f=t[l],m=n[l];if(f[0]>0&&i.includes(m[0]))continue;if(f[1]>0&&i.includes(m[1]))continue;if(f[2]>0&&i.includes(m[2]))continue;if(f[3]>0&&i.includes(m[3]))continue;e[s++]=o,e[s++]=a,e[s++]=l}return s}_createErasedMesh(e,t){let n=new Gs(e.geometry.clone(),e.material);n.name=`${e.name}(erase)`,n.frustumCulled=e.frustumCulled,n.layers.set(this._firstPersonOnlyLayer);let i=n.geometry,s=i.getAttribute("skinIndex"),r=s instanceof Gr?[]:s.array,o=[];for(let m=0;m<r.length;m+=4)o.push([r[m],r[m+1],r[m+2],r[m+3]]);let a=i.getAttribute("skinWeight"),l=a instanceof Gr?[]:a.array,c=[];for(let m=0;m<l.length;m+=4)c.push([l[m],l[m+1],l[m+2],l[m+3]]);let u=i.getIndex();if(!u)throw Error("The geometry doesn't have an index buffer");let h=Array.from(u.array),d=this._excludeTriangles(h,c,o,t),f=[];for(let m=0;m<d;m++)f[m]=h[m];if(i.setIndex(f),e.onBeforeRender)n.onBeforeRender=e.onBeforeRender;return n.bind(new Dn(e.skeleton.bones,e.skeleton.boneInverses),new Re),n}_createHeadlessModelForSkinnedMesh(e,t){let n=[];if(t.skeleton.bones.forEach((s,r)=>{if(this._isEraseTarget(s))n.push(r)}),!n.length){t.layers.enable(this._thirdPersonOnlyLayer),t.layers.enable(this._firstPersonOnlyLayer);return}t.layers.set(this._thirdPersonOnlyLayer);let i=this._createErasedMesh(t,n);e.add(i)}_createHeadlessModel(e){if(e.type==="Group")if(e.layers.set(this._thirdPersonOnlyLayer),this._isEraseTarget(e))e.traverse((t)=>t.layers.set(this._thirdPersonOnlyLayer));else{let t=new yt;t.name=`_headless_${e.name}`,t.layers.set(this._firstPersonOnlyLayer),e.parent.add(t),e.children.filter((n)=>n.type==="SkinnedMesh").forEach((n)=>{let i=n;this._createHeadlessModelForSkinnedMesh(t,i)})}else if(e.type==="SkinnedMesh"){let t=e;this._createHeadlessModelForSkinnedMesh(e.parent,t)}else if(this._isEraseTarget(e))e.layers.set(this._thirdPersonOnlyLayer),e.traverse((t)=>t.layers.set(this._thirdPersonOnlyLayer))}_isEraseTarget(e){if(e===this.humanoid.getRawBoneNode("head"))return!0;else if(!e.parent)return!1;else return this._isEraseTarget(e.parent)}}var Hy=new Set(["1.0","1.0-beta"]);class Jr{parser;get name(){return"VRMFirstPersonLoaderPlugin"}constructor(e){this.parser=e}async afterRoot(e){let t=e.userData.vrmHumanoid;if(t===null)return;else if(t===void 0)throw Error("VRMFirstPersonLoaderPlugin: vrmHumanoid is undefined. VRMHumanoidLoaderPlugin have to be used first");e.userData.vrmFirstPerson=await this._import(e,t)}async _import(e,t){if(t==null)return null;let n=await this._v1Import(e,t);if(n)return n;let i=await this._v0Import(e,t);if(i)return i;return null}async _v1Import(e,t){let n=this.parser.json;if(n.extensionsUsed?.indexOf("VRMC_vrm")===-1)return null;let s=n.extensions?.VRMC_vrm;if(!s)return null;let r=s.specVersion;if(!Hy.has(r))return console.warn(`VRMFirstPersonLoaderPlugin: Unknown VRMC_vrm specVersion "${r}"`),null;let o=s.firstPerson,a=[],l=await Cu(e);return Array.from(l.entries()).forEach(([c,u])=>{let h=o?.meshAnnotations?.find((d)=>d.node===c);a.push({meshes:u,type:h?.type??"auto"})}),new Yn(t,a)}async _v0Import(e,t){let n=this.parser.json,i=n.extensions?.VRM;if(!i)return null;let s=i.firstPerson;if(!s)return null;let r=[],o=await Cu(e);return Array.from(o.entries()).forEach(([a,l])=>{let c=n.nodes[a],u=s.meshAnnotations?s.meshAnnotations.find((h)=>h.mesh===c.mesh):void 0;r.push({meshes:l,type:this._convertV0FlagToV1Type(u?.firstPersonFlag)})}),new Yn(t,r)}_convertV0FlagToV1Type(e){if(e==="FirstPersonOnly")return"firstPersonOnly";else if(e==="ThirdPersonOnly")return"thirdPersonOnly";else if(e==="Both")return"both";else return"auto"}}var Np=new R,Dp=new R,By=new be;class Kr extends yt{vrmHumanoid;_boneAxesMap;constructor(e){super();this.vrmHumanoid=e,this._boneAxesMap=new Map,Object.values(e.humanBones).forEach((t)=>{let n=new La(1);n.matrixAutoUpdate=!1,n.material.depthTest=!1,n.material.depthWrite=!1,this.add(n),this._boneAxesMap.set(t,n)})}dispose(){Array.from(this._boneAxesMap.values()).forEach((e)=>{e.geometry.dispose(),e.material.dispose()})}updateMatrixWorld(e){Array.from(this._boneAxesMap.entries()).forEach(([t,n])=>{t.node.updateWorldMatrix(!0,!1),t.node.matrixWorld.decompose(Np,By,Dp);let i=Np.set(0.1,0.1,0.1).divide(Dp);n.matrix.copy(t.node.matrixWorld).scale(i)}),super.updateMatrixWorld(e)}}var $r=["hips","spine","chest","upperChest","neck","head","leftEye","rightEye","jaw","leftUpperLeg","leftLowerLeg","leftFoot","leftToes","rightUpperLeg","rightLowerLeg","rightFoot","rightToes","leftShoulder","leftUpperArm","leftLowerArm","leftHand","rightShoulder","rightUpperArm","rightLowerArm","rightHand","leftThumbMetacarpal","leftThumbProximal","leftThumbDistal","leftIndexProximal","leftIndexIntermediate","leftIndexDistal","leftMiddleProximal","leftMiddleIntermediate","leftMiddleDistal","leftRingProximal","leftRingIntermediate","leftRingDistal","leftLittleProximal","leftLittleIntermediate","leftLittleDistal","rightThumbMetacarpal","rightThumbProximal","rightThumbDistal","rightIndexProximal","rightIndexIntermediate","rightIndexDistal","rightMiddleProximal","rightMiddleIntermediate","rightMiddleDistal","rightRingProximal","rightRingIntermediate","rightRingDistal","rightLittleProximal","rightLittleIntermediate","rightLittleDistal"];var Pu={hips:null,spine:"hips",chest:"spine",upperChest:"chest",neck:"upperChest",head:"neck",leftEye:"head",rightEye:"head",jaw:"head",leftUpperLeg:"hips",leftLowerLeg:"leftUpperLeg",leftFoot:"leftLowerLeg",leftToes:"leftFoot",rightUpperLeg:"hips",rightLowerLeg:"rightUpperLeg",rightFoot:"rightLowerLeg",rightToes:"rightFoot",leftShoulder:"upperChest",leftUpperArm:"leftShoulder",leftLowerArm:"leftUpperArm",leftHand:"leftLowerArm",rightShoulder:"upperChest",rightUpperArm:"rightShoulder",rightLowerArm:"rightUpperArm",rightHand:"rightLowerArm",leftThumbMetacarpal:"leftHand",leftThumbProximal:"leftThumbMetacarpal",leftThumbDistal:"leftThumbProximal",leftIndexProximal:"leftHand",leftIndexIntermediate:"leftIndexProximal",leftIndexDistal:"leftIndexIntermediate",leftMiddleProximal:"leftHand",leftMiddleIntermediate:"leftMiddleProximal",leftMiddleDistal:"leftMiddleIntermediate",leftRingProximal:"leftHand",leftRingIntermediate:"leftRingProximal",leftRingDistal:"leftRingIntermediate",leftLittleProximal:"leftHand",leftLittleIntermediate:"leftLittleProximal",leftLittleDistal:"leftLittleIntermediate",rightThumbMetacarpal:"rightHand",rightThumbProximal:"rightThumbMetacarpal",rightThumbDistal:"rightThumbProximal",rightIndexProximal:"rightHand",rightIndexIntermediate:"rightIndexProximal",rightIndexDistal:"rightIndexIntermediate",rightMiddleProximal:"rightHand",rightMiddleIntermediate:"rightMiddleProximal",rightMiddleDistal:"rightMiddleIntermediate",rightRingProximal:"rightHand",rightRingIntermediate:"rightRingProximal",rightRingDistal:"rightRingIntermediate",rightLittleProximal:"rightHand",rightLittleIntermediate:"rightLittleProximal",rightLittleDistal:"rightLittleIntermediate"};function ka(e){if(e.invert)e.invert();else e.inverse();return e}var us=new R,hs=new be;class ir{humanBones;restPose;constructor(e){this.humanBones=e,this.restPose=this.getAbsolutePose()}getAbsolutePose(){let e={};return Object.keys(this.humanBones).forEach((t)=>{let n=t,i=this.getBoneNode(n);if(!i)return;us.copy(i.position),hs.copy(i.quaternion),e[n]={position:us.toArray(),rotation:hs.toArray()}}),e}getPose(){let e={};return Object.keys(this.humanBones).forEach((t)=>{let n=t,i=this.getBoneNode(n);if(!i)return;us.set(0,0,0),hs.identity();let s=this.restPose[n];if(s?.position)us.fromArray(s.position).negate();if(s?.rotation)ka(hs.fromArray(s.rotation));us.add(i.position),hs.premultiply(i.quaternion),e[n]={position:us.toArray(),rotation:hs.toArray()}}),e}setPose(e){Object.entries(e).forEach(([t,n])=>{let i=t,s=this.getBoneNode(i);if(!s)return;let r=this.restPose[i];if(!r)return;if(n?.position){if(s.position.fromArray(n.position),r.position)s.position.add(us.fromArray(r.position))}if(n?.rotation){if(s.quaternion.fromArray(n.rotation),r.rotation)s.quaternion.multiply(hs.fromArray(r.rotation))}})}resetPose(){Object.entries(this.restPose).forEach(([e,t])=>{let n=this.getBoneNode(e);if(!n)return;if(t?.position)n.position.fromArray(t.position);if(t?.rotation)n.quaternion.fromArray(t.rotation)})}getBone(e){return this.humanBones[e]??void 0}getBoneNode(e){return this.humanBones[e]?.node??null}}var Lu=new R,Vy=new be,ky=new R;class Qr extends ir{static _setupTransforms(e){let t=new tt;t.name="VRMHumanoidRig";let n={},i={},s={},r={};$r.forEach((a)=>{let l=e.getBoneNode(a);if(l){let c=new R,u=new be;l.updateWorldMatrix(!0,!1),l.matrixWorld.decompose(c,u,Lu),n[a]=c,i[a]=u,s[a]=l.quaternion.clone();let h=new be;l.parent?.matrixWorld.decompose(Lu,h,Lu),r[a]=h}});let o={};return $r.forEach((a)=>{let l=e.getBoneNode(a);if(l){let c=n[a],u=a,h;while(h==null){if(u=Pu[u],u==null)break;h=n[u]}let d=new tt;if(d.name="Normalized_"+l.name,(u?o[u]?.node:t).add(d),d.position.copy(c),h)d.position.sub(h);o[a]={node:d}}}),{rigBones:o,root:t,parentWorldRotations:r,boneRotations:s}}original;root;_parentWorldRotations;_boneRotations;constructor(e){let{rigBones:t,root:n,parentWorldRotations:i,boneRotations:s}=Qr._setupTransforms(e);super(t);this.original=e,this.root=n,this._parentWorldRotations=i,this._boneRotations=s}update(){$r.forEach((e)=>{let t=this.original.getBoneNode(e);if(t!=null){let n=this.getBoneNode(e),i=this._parentWorldRotations[e],s=Vy.copy(i).invert(),r=this._boneRotations[e];if(t.quaternion.copy(n.quaternion).multiply(i).premultiply(s).multiply(r),e==="hips"){let o=n.getWorldPosition(ky);t.parent.updateWorldMatrix(!0,!1);let a=t.parent.matrixWorld,l=o.applyMatrix4(a.invert());t.position.copy(l)}}})}}class sr{autoUpdateHumanBones;_rawHumanBones;_normalizedHumanBones;get restPose(){return console.warn("VRMHumanoid: restPose is deprecated. Use either rawRestPose or normalizedRestPose instead."),this.rawRestPose}get rawRestPose(){return this._rawHumanBones.restPose}get normalizedRestPose(){return this._normalizedHumanBones.restPose}get humanBones(){return this._rawHumanBones.humanBones}get rawHumanBones(){return this._rawHumanBones.humanBones}get normalizedHumanBones(){return this._normalizedHumanBones.humanBones}get normalizedHumanBonesRoot(){return this._normalizedHumanBones.root}constructor(e,t){this.autoUpdateHumanBones=t?.autoUpdateHumanBones??!0,this._rawHumanBones=new ir(e),this._normalizedHumanBones=new Qr(this._rawHumanBones)}copy(e){return this.autoUpdateHumanBones=e.autoUpdateHumanBones,this._rawHumanBones=new ir(e.humanBones),this._normalizedHumanBones=new Qr(this._rawHumanBones),this}clone(){return new sr(this.humanBones,{autoUpdateHumanBones:this.autoUpdateHumanBones}).copy(this)}getAbsolutePose(){return console.warn("VRMHumanoid: getAbsolutePose() is deprecated. Use either getRawAbsolutePose() or getNormalizedAbsolutePose() instead."),this.getRawAbsolutePose()}getRawAbsolutePose(){return this._rawHumanBones.getAbsolutePose()}getNormalizedAbsolutePose(){return this._normalizedHumanBones.getAbsolutePose()}getPose(){return console.warn("VRMHumanoid: getPose() is deprecated. Use either getRawPose() or getNormalizedPose() instead."),this.getRawPose()}getRawPose(){return this._rawHumanBones.getPose()}getNormalizedPose(){return this._normalizedHumanBones.getPose()}setPose(e){return console.warn("VRMHumanoid: setPose() is deprecated. Use either setRawPose() or setNormalizedPose() instead."),this.setRawPose(e)}setRawPose(e){return this._rawHumanBones.setPose(e)}setNormalizedPose(e){return this._normalizedHumanBones.setPose(e)}resetPose(){return console.warn("VRMHumanoid: resetPose() is deprecated. Use either resetRawPose() or resetNormalizedPose() instead."),this.resetRawPose()}resetRawPose(){return this._rawHumanBones.resetPose()}resetNormalizedPose(){return this._normalizedHumanBones.resetPose()}getBone(e){return console.warn("VRMHumanoid: getBone() is deprecated. Use either getRawBone() or getNormalizedBone() instead."),this.getRawBone(e)}getRawBone(e){return this._rawHumanBones.getBone(e)}getNormalizedBone(e){return this._normalizedHumanBones.getBone(e)}getBoneNode(e){return console.warn("VRMHumanoid: getBoneNode() is deprecated. Use either getRawBoneNode() or getNormalizedBoneNode() instead."),this.getRawBoneNode(e)}getRawBoneNode(e){return this._rawHumanBones.getBoneNode(e)}getNormalizedBoneNode(e){return this._normalizedHumanBones.getBoneNode(e)}update(){if(this.autoUpdateHumanBones)this._normalizedHumanBones.update()}}var Iu={Hips:"hips",Spine:"spine",Head:"head",LeftUpperLeg:"leftUpperLeg",LeftLowerLeg:"leftLowerLeg",LeftFoot:"leftFoot",RightUpperLeg:"rightUpperLeg",RightLowerLeg:"rightLowerLeg",RightFoot:"rightFoot",LeftUpperArm:"leftUpperArm",LeftLowerArm:"leftLowerArm",LeftHand:"leftHand",RightUpperArm:"rightUpperArm",RightLowerArm:"rightLowerArm",RightHand:"rightHand"};var Gy=new Set(["1.0","1.0-beta"]),Up={leftThumbProximal:"leftThumbMetacarpal",leftThumbIntermediate:"leftThumbProximal",rightThumbProximal:"rightThumbMetacarpal",rightThumbIntermediate:"rightThumbProximal"};class eo{helperRoot;autoUpdateHumanBones;parser;get name(){return"VRMHumanoidLoaderPlugin"}constructor(e,t){this.parser=e,this.helperRoot=t?.helperRoot,this.autoUpdateHumanBones=t?.autoUpdateHumanBones}async afterRoot(e){e.userData.vrmHumanoid=await this._import(e)}async _import(e){let t=await this._v1Import(e);if(t)return t;let n=await this._v0Import(e);if(n)return n;return null}async _v1Import(e){let t=this.parser.json;if(t.extensionsUsed?.indexOf("VRMC_vrm")===-1)return null;let i=t.extensions?.VRMC_vrm;if(!i)return null;let s=i.specVersion;if(!Gy.has(s))return console.warn(`VRMHumanoidLoaderPlugin: Unknown VRMC_vrm specVersion "${s}"`),null;let r=i.humanoid;if(!r)return null;let o=r.humanBones.leftThumbIntermediate!=null||r.humanBones.rightThumbIntermediate!=null,a={};if(r.humanBones!=null)await Promise.all(Object.entries(r.humanBones).map(async([c,u])=>{let h=c,d=u.node;if(o){let m=Up[h];if(m!=null)h=m}let f=await this.parser.getDependency("node",d);if(f==null){console.warn(`A glTF node bound to the humanoid bone ${h} (index = ${d}) does not exist`);return}a[h]={node:f}}));let l=new sr(this._ensureRequiredBonesExist(a),{autoUpdateHumanBones:this.autoUpdateHumanBones});if(e.scene.add(l.normalizedHumanBonesRoot),this.helperRoot){let c=new Kr(l);this.helperRoot.add(c),c.renderOrder=this.helperRoot.renderOrder}return l}async _v0Import(e){let n=this.parser.json.extensions?.VRM;if(!n)return null;let i=n.humanoid;if(!i)return null;let s={};if(i.humanBones!=null)await Promise.all(i.humanBones.map(async(o)=>{let{bone:a,node:l}=o;if(a==null||l==null)return;if(l<0){console.warn(`A glTF node index for the humanoid bone ${a} is negative (${l}), ignoring this bone.`);return}let c=await this.parser.getDependency("node",l);if(c==null){console.warn(`A glTF node bound to the humanoid bone ${a} (index = ${l}) does not exist`);return}let h=Up[a]??a;if(s[h]!=null){console.warn(`Multiple bone entries for ${h} detected (index = ${l}), ignoring duplicated entries.`);return}s[h]={node:c}}));let r=new sr(this._ensureRequiredBonesExist(s),{autoUpdateHumanBones:this.autoUpdateHumanBones});if(e.scene.add(r.normalizedHumanBonesRoot),this.helperRoot){let o=new Kr(r);this.helperRoot.add(o),o.renderOrder=this.helperRoot.renderOrder}return r}_ensureRequiredBonesExist(e){let t=Object.values(Iu).filter((n)=>e[n]==null);if(t.length>0)throw Error(`VRMHumanoidLoaderPlugin: These humanoid bones are required but not exist: ${t.join(", ")}`);return e}}class Ga extends Qe{theta;radius;_currentTheta=0;_currentRadius=0;_attrPos;_attrIndex;constructor(){super();this.theta=0,this.radius=0,this._currentTheta=0,this._currentRadius=0,this._attrPos=new Ge(new Float32Array(195),3),this.setAttribute("position",this._attrPos),this._attrIndex=new Ge(new Uint16Array(189),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let e=!1;if(this._currentTheta!==this.theta)this._currentTheta=this.theta,e=!0;if(this._currentRadius!==this.radius)this._currentRadius=this.radius,e=!0;if(e)this._buildPosition()}_buildPosition(){this._attrPos.setXYZ(0,0,0,0);for(let e=0;e<64;e++){let t=e/63*this._currentTheta;this._attrPos.setXYZ(e+1,this._currentRadius*Math.sin(t),0,this._currentRadius*Math.cos(t))}this._attrPos.needsUpdate=!0}_buildIndex(){for(let e=0;e<63;e++)this._attrIndex.setXYZ(e*3,0,e+1,e+2);this._attrIndex.needsUpdate=!0}}class Nu extends Qe{radius;tail;_currentRadius;_currentTail;_attrPos;_attrIndex;constructor(){super();this.radius=0,this._currentRadius=0,this.tail=new R,this._currentTail=new R,this._attrPos=new Ge(new Float32Array(294),3),this.setAttribute("position",this._attrPos),this._attrIndex=new Ge(new Uint16Array(194),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let e=!1;if(this._currentRadius!==this.radius)this._currentRadius=this.radius,e=!0;if(!this._currentTail.equals(this.tail))this._currentTail.copy(this.tail),e=!0;if(e)this._buildPosition()}_buildPosition(){for(let e=0;e<32;e++){let t=e/16*Math.PI;this._attrPos.setXYZ(e,Math.cos(t),Math.sin(t),0),this._attrPos.setXYZ(32+e,0,Math.cos(t),Math.sin(t)),this._attrPos.setXYZ(64+e,Math.sin(t),0,Math.cos(t))}this.scale(this._currentRadius,this._currentRadius,this._currentRadius),this.translate(this._currentTail.x,this._currentTail.y,this._currentTail.z),this._attrPos.setXYZ(96,0,0,0),this._attrPos.setXYZ(97,this._currentTail.x,this._currentTail.y,this._currentTail.z),this._attrPos.needsUpdate=!0}_buildIndex(){for(let e=0;e<32;e++){let t=(e+1)%32;this._attrIndex.setXY(e*2,e,t),this._attrIndex.setXY(64+e*2,32+e,32+t),this._attrIndex.setXY(128+e*2,64+e,64+t)}this._attrIndex.setXY(192,96,97),this._attrIndex.needsUpdate=!0}}var za=new be,Op=new be,to=new R,Fp=new R,Hp=Math.sqrt(2)/2,zy=new be(0,0,-Hp,Hp),Wy=new R(0,1,0);class Wa extends yt{vrmLookAt;_meshYaw;_meshPitch;_lineTarget;constructor(e){super();this.matrixAutoUpdate=!1,this.vrmLookAt=e;{let t=new Ga;t.radius=0.5;let n=new nn({color:65280,transparent:!0,opacity:0.5,side:en,depthTest:!1,depthWrite:!1});this._meshPitch=new bt(t,n),this.add(this._meshPitch)}{let t=new Ga;t.radius=0.5;let n=new nn({color:16711680,transparent:!0,opacity:0.5,side:en,depthTest:!1,depthWrite:!1});this._meshYaw=new bt(t,n),this.add(this._meshYaw)}{let t=new Nu;t.radius=0.1;let n=new an({color:16777215,depthTest:!1,depthWrite:!1});this._lineTarget=new Un(t,n),this._lineTarget.frustumCulled=!1,this.add(this._lineTarget)}}dispose(){this._meshYaw.geometry.dispose(),this._meshYaw.material.dispose(),this._meshPitch.geometry.dispose(),this._meshPitch.material.dispose(),this._lineTarget.geometry.dispose(),this._lineTarget.material.dispose()}updateMatrixWorld(e){let t=$e.DEG2RAD*this.vrmLookAt.yaw;this._meshYaw.geometry.theta=t,this._meshYaw.geometry.update();let n=$e.DEG2RAD*this.vrmLookAt.pitch;this._meshPitch.geometry.theta=n,this._meshPitch.geometry.update(),this.vrmLookAt.getLookAtWorldPosition(to),this.vrmLookAt.getLookAtWorldQuaternion(za),za.multiply(this.vrmLookAt.getFaceFrontQuaternion(Op)),this._meshYaw.position.copy(to),this._meshYaw.quaternion.copy(za),this._meshPitch.position.copy(to),this._meshPitch.quaternion.copy(za),this._meshPitch.quaternion.multiply(Op.setFromAxisAngle(Wy,t)),this._meshPitch.quaternion.multiply(zy);let{target:i,autoUpdate:s}=this.vrmLookAt;if(i!=null&&s)i.getWorldPosition(Fp).sub(to),this._lineTarget.geometry.tail.copy(Fp),this._lineTarget.geometry.update(),this._lineTarget.position.copy(to);super.updateMatrixWorld(e)}}var Xy=new R,qy=new R;function no(e,t){return e.matrixWorld.decompose(Xy,t,qy),t}function rr(e){return[Math.atan2(-e.z,e.x),Math.atan2(e.y,Math.sqrt(e.x*e.x+e.z*e.z))]}function Du(e){let t=Math.round(e/2/Math.PI);return e-2*Math.PI*t}var Bp=new R(0,0,1),Yy=new R,Zy=new R,jy=new R,Jy=new be,Uu=new be,Vp=new be,Ky=new be,Ou=new Ht;class io{static EULER_ORDER="YXZ";offsetFromHeadBone=new R;humanoid;applier;autoUpdate=!0;target;faceFront=new R(0,0,1);_yaw;get yaw(){return this._yaw}set yaw(e){this._yaw=e,this._needsUpdate=!0}_pitch;get pitch(){return this._pitch}set pitch(e){this._pitch=e,this._needsUpdate=!0}_needsUpdate;_restHeadWorldQuaternion;get euler(){return console.warn("VRMLookAt: euler is deprecated. use getEuler() instead."),this.getEuler(new Ht)}constructor(e,t){this.humanoid=e,this.applier=t,this._yaw=0,this._pitch=0,this._needsUpdate=!0,this._restHeadWorldQuaternion=this.getLookAtWorldQuaternion(new be)}getEuler(e){return e.set($e.DEG2RAD*this._pitch,$e.DEG2RAD*this._yaw,0,"YXZ")}copy(e){if(this.humanoid!==e.humanoid)throw Error("VRMLookAt: humanoid must be same in order to copy");return this.offsetFromHeadBone.copy(e.offsetFromHeadBone),this.applier=e.applier,this.autoUpdate=e.autoUpdate,this.target=e.target,this.faceFront.copy(e.faceFront),this}clone(){return new io(this.humanoid,this.applier).copy(this)}reset(){this._yaw=0,this._pitch=0,this._needsUpdate=!0}getLookAtWorldPosition(e){let t=this.humanoid.getRawBoneNode("head");return e.copy(this.offsetFromHeadBone).applyMatrix4(t.matrixWorld)}getLookAtWorldQuaternion(e){let t=this.humanoid.getRawBoneNode("head");return no(t,e)}getFaceFrontQuaternion(e){if(this.faceFront.distanceToSquared(Bp)<0.01)return e.copy(this._restHeadWorldQuaternion).invert();let[t,n]=rr(this.faceFront);return Ou.set(0,0.5*Math.PI+t,n,"YZX"),e.setFromEuler(Ou).premultiply(Ky.copy(this._restHeadWorldQuaternion).invert())}getLookAtWorldDirection(e){return this.getLookAtWorldQuaternion(Uu),this.getFaceFrontQuaternion(Vp),e.copy(Bp).applyQuaternion(Uu).applyQuaternion(Vp).applyEuler(this.getEuler(Ou))}lookAt(e){let t=Jy.copy(this._restHeadWorldQuaternion).multiply(ka(this.getLookAtWorldQuaternion(Uu))),n=this.getLookAtWorldPosition(Zy),i=jy.copy(e).sub(n).applyQuaternion(t).normalize(),[s,r]=rr(this.faceFront),[o,a]=rr(i),l=Du(o-s),c=Du(r-a);this._yaw=$e.RAD2DEG*l,this._pitch=$e.RAD2DEG*c,this._needsUpdate=!0}update(e){if(this.target!=null&&this.autoUpdate)this.lookAt(this.target.getWorldPosition(Yy));if(this._needsUpdate)this._needsUpdate=!1,this.applier.applyYawPitch(this._yaw,this._pitch)}}var $y=new R(0,0,1),Zn=new be,or=new be,En=new Ht(0,0,0,"YXZ");class ar{static type="bone";humanoid;rangeMapHorizontalInner;rangeMapHorizontalOuter;rangeMapVerticalDown;rangeMapVerticalUp;faceFront;_restQuatLeftEye;_restQuatRightEye;_restLeftEyeParentWorldQuat;_restRightEyeParentWorldQuat;constructor(e,t,n,i,s){this.humanoid=e,this.rangeMapHorizontalInner=t,this.rangeMapHorizontalOuter=n,this.rangeMapVerticalDown=i,this.rangeMapVerticalUp=s,this.faceFront=new R(0,0,1),this._restQuatLeftEye=new be,this._restQuatRightEye=new be,this._restLeftEyeParentWorldQuat=new be,this._restRightEyeParentWorldQuat=new be;let r=this.humanoid.getRawBoneNode("leftEye"),o=this.humanoid.getRawBoneNode("rightEye");if(r)this._restQuatLeftEye.copy(r.quaternion),no(r.parent,this._restLeftEyeParentWorldQuat);if(o)this._restQuatRightEye.copy(o.quaternion),no(o.parent,this._restRightEyeParentWorldQuat)}applyYawPitch(e,t){let n=this.humanoid.getRawBoneNode("leftEye"),i=this.humanoid.getRawBoneNode("rightEye"),s=this.humanoid.getNormalizedBoneNode("leftEye"),r=this.humanoid.getNormalizedBoneNode("rightEye");if(n){if(t<0)En.x=-$e.DEG2RAD*this.rangeMapVerticalDown.map(-t);else En.x=$e.DEG2RAD*this.rangeMapVerticalUp.map(t);if(e<0)En.y=-$e.DEG2RAD*this.rangeMapHorizontalInner.map(-e);else En.y=$e.DEG2RAD*this.rangeMapHorizontalOuter.map(e);Zn.setFromEuler(En),this._getWorldFaceFrontQuat(or),s.quaternion.copy(or).multiply(Zn).multiply(or.invert()),Zn.copy(this._restLeftEyeParentWorldQuat),n.quaternion.copy(s.quaternion).multiply(Zn).premultiply(Zn.invert()).multiply(this._restQuatLeftEye)}if(i){if(t<0)En.x=-$e.DEG2RAD*this.rangeMapVerticalDown.map(-t);else En.x=$e.DEG2RAD*this.rangeMapVerticalUp.map(t);if(e<0)En.y=-$e.DEG2RAD*this.rangeMapHorizontalOuter.map(-e);else En.y=$e.DEG2RAD*this.rangeMapHorizontalInner.map(e);Zn.setFromEuler(En),this._getWorldFaceFrontQuat(or),r.quaternion.copy(or).multiply(Zn).multiply(or.invert()),Zn.copy(this._restRightEyeParentWorldQuat),i.quaternion.copy(r.quaternion).multiply(Zn).premultiply(Zn.invert()).multiply(this._restQuatRightEye)}}lookAt(e){console.warn("VRMLookAtBoneApplier: lookAt() is deprecated. use apply() instead.");let t=$e.RAD2DEG*e.y,n=$e.RAD2DEG*e.x;this.applyYawPitch(t,n)}_getWorldFaceFrontQuat(e){if(this.faceFront.distanceToSquared($y)<0.01)return e.identity();let[t,n]=rr(this.faceFront);return En.set(0,0.5*Math.PI+t,n,"YZX"),e.setFromEuler(En)}}class so{static type="expression";expressions;rangeMapHorizontalInner;rangeMapHorizontalOuter;rangeMapVerticalDown;rangeMapVerticalUp;constructor(e,t,n,i,s){this.expressions=e,this.rangeMapHorizontalInner=t,this.rangeMapHorizontalOuter=n,this.rangeMapVerticalDown=i,this.rangeMapVerticalUp=s}applyYawPitch(e,t){if(t<0)this.expressions.setValue("lookDown",0),this.expressions.setValue("lookUp",this.rangeMapVerticalUp.map(-t));else this.expressions.setValue("lookUp",0),this.expressions.setValue("lookDown",this.rangeMapVerticalDown.map(t));if(e<0)this.expressions.setValue("lookLeft",0),this.expressions.setValue("lookRight",this.rangeMapHorizontalOuter.map(-e));else this.expressions.setValue("lookRight",0),this.expressions.setValue("lookLeft",this.rangeMapHorizontalOuter.map(e))}lookAt(e){console.warn("VRMLookAtBoneApplier: lookAt() is deprecated. use apply() instead.");let t=$e.RAD2DEG*e.y,n=$e.RAD2DEG*e.x;this.applyYawPitch(t,n)}}class ro{inputMaxValue;outputScale;constructor(e,t){this.inputMaxValue=e,this.outputScale=t}map(e){return this.outputScale*Va(e/this.inputMaxValue)}}var Qy=new Set(["1.0","1.0-beta"]),Xa=0.01;class oo{helperRoot;parser;get name(){return"VRMLookAtLoaderPlugin"}constructor(e,t){this.parser=e,this.helperRoot=t?.helperRoot}async afterRoot(e){let t=e.userData.vrmHumanoid;if(t===null)return;else if(t===void 0)throw Error("VRMLookAtLoaderPlugin: vrmHumanoid is undefined. VRMHumanoidLoaderPlugin have to be used first");let n=e.userData.vrmExpressionManager;if(n===null)return;else if(n===void 0)throw Error("VRMLookAtLoaderPlugin: vrmExpressionManager is undefined. VRMExpressionLoaderPlugin have to be used first");e.userData.vrmLookAt=await this._import(e,t,n)}async _import(e,t,n){if(t==null||n==null)return null;let i=await this._v1Import(e,t,n);if(i)return i;let s=await this._v0Import(e,t,n);if(s)return s;return null}async _v1Import(e,t,n){let i=this.parser.json;if(i.extensionsUsed?.indexOf("VRMC_vrm")===-1)return null;let r=i.extensions?.VRMC_vrm;if(!r)return null;let o=r.specVersion;if(!Qy.has(o))return console.warn(`VRMLookAtLoaderPlugin: Unknown VRMC_vrm specVersion "${o}"`),null;let a=r.lookAt;if(!a)return null;let l=a.type==="expression"?1:10,c=this._v1ImportRangeMap(a.rangeMapHorizontalInner,l),u=this._v1ImportRangeMap(a.rangeMapHorizontalOuter,l),h=this._v1ImportRangeMap(a.rangeMapVerticalDown,l),d=this._v1ImportRangeMap(a.rangeMapVerticalUp,l),f;if(a.type==="expression")f=new so(n,c,u,h,d);else f=new ar(t,c,u,h,d);let m=this._importLookAt(t,f);return m.offsetFromHeadBone.fromArray(a.offsetFromHeadBone??[0,0.06,0]),m}_v1ImportRangeMap(e,t){let n=e?.inputMaxValue??90,i=e?.outputScale??t;if(n<Xa)console.warn("VRMLookAtLoaderPlugin: inputMaxValue of a range map is too small. Consider reviewing the range map!"),n=Xa;return new ro(n,i)}async _v0Import(e,t,n){let s=this.parser.json.extensions?.VRM;if(!s)return null;let r=s.firstPerson;if(!r)return null;let o=r.lookAtTypeName==="BlendShape"?1:10,a=this._v0ImportDegreeMap(r.lookAtHorizontalInner,o),l=this._v0ImportDegreeMap(r.lookAtHorizontalOuter,o),c=this._v0ImportDegreeMap(r.lookAtVerticalDown,o),u=this._v0ImportDegreeMap(r.lookAtVerticalUp,o),h;if(r.lookAtTypeName==="BlendShape")h=new so(n,a,l,c,u);else h=new ar(t,a,l,c,u);let d=this._importLookAt(t,h);if(r.firstPersonBoneOffset)d.offsetFromHeadBone.set(r.firstPersonBoneOffset.x??0,r.firstPersonBoneOffset.y??0.06,-(r.firstPersonBoneOffset.z??0));else d.offsetFromHeadBone.set(0,0.06,0);if(d.faceFront.set(0,0,-1),h instanceof ar)h.faceFront.set(0,0,-1);return d}_v0ImportDegreeMap(e,t){let n=e?.curve;if(JSON.stringify(n)!=="[0,0,0,1,1,1,1,0]")console.warn("Curves of LookAtDegreeMap defined in VRM 0.0 are not supported");let i=e?.xRange??90,s=e?.yRange??t;if(i<Xa)console.warn("VRMLookAtLoaderPlugin: xRange of a degree map is too small. Consider reviewing the degree map!"),i=Xa;return new ro(i,s)}_importLookAt(e,t){let n=new io(e,t);if(this.helperRoot){let i=new Wa(n);this.helperRoot.add(i),i.renderOrder=this.helperRoot.renderOrder}return n}}function kp(e,t){if(typeof e!=="string"||e==="")return"";if(/^https?:\/\//i.test(t)&&/^\//.test(e))t=t.replace(/(^https?:\/\/[^/]+).*/i,"$1");if(/^(https?:)?\/\//i.test(e))return e;if(/^data:.*,.*$/i.test(e))return e;if(/^blob:.*$/i.test(e))return e;return t+e}var ev=new Set(["1.0","1.0-beta"]);class ao{parser;needThumbnailImage;acceptLicenseUrls;acceptV0Meta;get name(){return"VRMMetaLoaderPlugin"}constructor(e,t){this.parser=e,this.needThumbnailImage=t?.needThumbnailImage??!1,this.acceptLicenseUrls=t?.acceptLicenseUrls??["https://vrm.dev/licenses/1.0/"],this.acceptV0Meta=t?.acceptV0Meta??!0}async afterRoot(e){e.userData.vrmMeta=await this._import(e)}async _import(e){let t=await this._v1Import(e);if(t!=null)return t;let n=await this._v0Import(e);if(n!=null)return n;return null}async _v1Import(e){let t=this.parser.json;if(t.extensionsUsed?.indexOf("VRMC_vrm")===-1)return null;let i=t.extensions?.VRMC_vrm;if(i==null)return null;let s=i.specVersion;if(!ev.has(s))return console.warn(`VRMMetaLoaderPlugin: Unknown VRMC_vrm specVersion "${s}"`),null;let r=i.meta;if(!r)return null;let o=r.licenseUrl;if(!new Set(this.acceptLicenseUrls).has(o))throw Error(`VRMMetaLoaderPlugin: The license url "${o}" is not accepted`);let l=void 0;if(this.needThumbnailImage&&r.thumbnailImage!=null)l=await this._extractGLTFImage(r.thumbnailImage)??void 0;return{metaVersion:"1",name:r.name,version:r.version,authors:r.authors,copyrightInformation:r.copyrightInformation,contactInformation:r.contactInformation,references:r.references,thirdPartyLicenses:r.thirdPartyLicenses,thumbnailImage:l,licenseUrl:r.licenseUrl,avatarPermission:r.avatarPermission,allowExcessivelyViolentUsage:r.allowExcessivelyViolentUsage,allowExcessivelySexualUsage:r.allowExcessivelySexualUsage,commercialUsage:r.commercialUsage,allowPoliticalOrReligiousUsage:r.allowPoliticalOrReligiousUsage,allowAntisocialOrHateUsage:r.allowAntisocialOrHateUsage,creditNotation:r.creditNotation,allowRedistribution:r.allowRedistribution,modification:r.modification,otherLicenseUrl:r.otherLicenseUrl}}async _v0Import(e){let n=this.parser.json.extensions?.VRM;if(!n)return null;let i=n.meta;if(!i)return null;if(!this.acceptV0Meta)throw Error("VRMMetaLoaderPlugin: Attempted to load VRM0.0 meta but acceptV0Meta is false");let s;if(this.needThumbnailImage&&i.texture!=null&&i.texture!==-1)s=await this.parser.getDependency("texture",i.texture);return{metaVersion:"0",allowedUserName:i.allowedUserName,author:i.author,commercialUssageName:i.commercialUssageName,contactInformation:i.contactInformation,licenseName:i.licenseName,otherLicenseUrl:i.otherLicenseUrl,otherPermissionUrl:i.otherPermissionUrl,reference:i.reference,sexualUssageName:i.sexualUssageName,texture:s??void 0,title:i.title,version:i.version,violentUssageName:i.violentUssageName}}async _extractGLTFImage(e){let n=this.parser.json.images?.[e];if(n==null)return console.warn(`VRMMetaLoaderPlugin: Attempt to use images[${e}] of glTF as a thumbnail but the image doesn't exist`),null;let i=n.uri;if(n.bufferView!=null){let r=await this.parser.getDependency("bufferView",n.bufferView),o=new Blob([r],{type:n.mimeType});i=URL.createObjectURL(o)}if(i==null)return console.warn(`VRMMetaLoaderPlugin: Attempt to use images[${e}] of glTF as a thumbnail but the image couldn't load properly`),null;return await new Br().loadAsync(kp(i,this.parser.options.path)).catch((r)=>(console.error(r),console.warn("VRMMetaLoaderPlugin: Failed to load a thumbnail image"),null))}}class lo{scene;meta;humanoid;expressionManager;firstPerson;lookAt;constructor(e){this.scene=e.scene,this.meta=e.meta,this.humanoid=e.humanoid,this.expressionManager=e.expressionManager,this.firstPerson=e.firstPerson,this.lookAt=e.lookAt}update(e){if(this.humanoid.update(),this.lookAt)this.lookAt.update(e);if(this.expressionManager)this.expressionManager.update()}}class qa extends lo{materials;springBoneManager;nodeConstraintManager;constructor(e){super(e);this.materials=e.materials,this.springBoneManager=e.springBoneManager,this.nodeConstraintManager=e.nodeConstraintManager}update(e){if(super.update(e),this.nodeConstraintManager)this.nodeConstraintManager.update();if(this.springBoneManager)this.springBoneManager.update(e);if(this.materials)this.materials.forEach((t)=>{if(t.update)t.update(e)})}}var tv={"":3000,srgb:3001};function Gp(e,t){if(parseInt(ai,10)>=152)e.colorSpace=t;else e.encoding=tv[t]}class Fu{_parser;_materialParams;_pendings;get pending(){return Promise.all(this._pendings)}constructor(e,t){this._parser=e,this._materialParams=t,this._pendings=[]}assignPrimitive(e,t){if(t!=null)this._materialParams[e]=t}assignColor(e,t,n){if(t!=null){let i=new xe().fromArray(t);if(n)i.convertSRGBToLinear();this._materialParams[e]=i}}async assignTexture(e,t,n){let i=(async()=>{if(t!=null){let s=await this._parser.assignTexture(this._materialParams,e,t);if(s==null){console.warn("GLTFMToonMaterialParamsAssignHelper: Failed to load texture. The rendering result may be wrong");return}if(n)Gp(s,"srgb")}})();return this._pendings.push(i),i}async assignTextureByIndex(e,t,n){return this.assignTexture(e,t!=null?{index:t}:void 0,n)}}var zp=`// #define PHONG

varying vec3 vViewPosition;

#ifndef FLAT_SHADED
  varying vec3 vNormal;
#endif

#include <common>

// #include <uv_pars_vertex>
#ifdef MTOON_USE_UV
  varying vec2 vUv;

  // COMPAT: pre-r151 uses a common uvTransform
  #if THREE_VRM_THREE_REVISION < 151
    uniform mat3 uvTransform;
  #endif
#endif

// #include <uv2_pars_vertex>
// COMAPT: pre-r151 uses uv2 for lightMap and aoMap
#if THREE_VRM_THREE_REVISION < 151
  #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
    attribute vec2 uv2;
    varying vec2 vUv2;
    uniform mat3 uv2Transform;
  #endif
#endif

// #include <displacementmap_pars_vertex>
// #include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

#ifdef USE_OUTLINEWIDTHMULTIPLYTEXTURE
  uniform sampler2D outlineWidthMultiplyTexture;
  uniform mat3 outlineWidthMultiplyTextureUvTransform;
#endif

uniform float outlineWidthFactor;

void main() {

  // #include <uv_vertex>
  #ifdef MTOON_USE_UV
    // COMPAT: pre-r151 uses a common uvTransform
    #if THREE_VRM_THREE_REVISION >= 151
      vUv = uv;
    #else
      vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
    #endif
  #endif

  // #include <uv2_vertex>
  // COMAPT: pre-r151 uses uv2 for lightMap and aoMap
  #if THREE_VRM_THREE_REVISION < 151
    #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
      vUv2 = ( uv2Transform * vec3( uv2, 1 ) ).xy;
    #endif
  #endif

  #include <color_vertex>

  #include <beginnormal_vertex>
  #include <morphnormal_vertex>
  #include <skinbase_vertex>
  #include <skinnormal_vertex>

  // we need this to compute the outline properly
  objectNormal = normalize( objectNormal );

  #include <defaultnormal_vertex>

  #ifndef FLAT_SHADED // Normal computed with derivatives when FLAT_SHADED
    vNormal = normalize( transformedNormal );
  #endif

  #include <begin_vertex>

  #include <morphtarget_vertex>
  #include <skinning_vertex>
  // #include <displacementmap_vertex>
  #include <project_vertex>
  #include <logdepthbuf_vertex>
  #include <clipping_planes_vertex>

  vViewPosition = - mvPosition.xyz;

  #ifdef OUTLINE
    float worldNormalLength = length( transformedNormal );
    vec3 outlineOffset = outlineWidthFactor * worldNormalLength * objectNormal;

    #ifdef USE_OUTLINEWIDTHMULTIPLYTEXTURE
      vec2 outlineWidthMultiplyTextureUv = ( outlineWidthMultiplyTextureUvTransform * vec3( vUv, 1 ) ).xy;
      float outlineTex = texture2D( outlineWidthMultiplyTexture, outlineWidthMultiplyTextureUv ).g;
      outlineOffset *= outlineTex;
    #endif

    #ifdef OUTLINE_WIDTH_SCREEN
      outlineOffset *= vViewPosition.z / projectionMatrix[ 1 ].y;
    #endif

    gl_Position = projectionMatrix * modelViewMatrix * vec4( outlineOffset + transformed, 1.0 );

    gl_Position.z += 1E-6 * gl_Position.w; // anti-artifact magic
  #endif

  #include <worldpos_vertex>
  // #include <envmap_vertex>
  #include <shadowmap_vertex>
  #include <fog_vertex>

}`;var Wp=`// #define PHONG

uniform vec3 litFactor;

uniform float opacity;

uniform vec3 shadeColorFactor;
#ifdef USE_SHADEMULTIPLYTEXTURE
  uniform sampler2D shadeMultiplyTexture;
  uniform mat3 shadeMultiplyTextureUvTransform;
#endif

uniform float shadingShiftFactor;
uniform float shadingToonyFactor;

#ifdef USE_SHADINGSHIFTTEXTURE
  uniform sampler2D shadingShiftTexture;
  uniform mat3 shadingShiftTextureUvTransform;
  uniform float shadingShiftTextureScale;
#endif

uniform float giEqualizationFactor;

uniform vec3 parametricRimColorFactor;
#ifdef USE_RIMMULTIPLYTEXTURE
  uniform sampler2D rimMultiplyTexture;
  uniform mat3 rimMultiplyTextureUvTransform;
#endif
uniform float rimLightingMixFactor;
uniform float parametricRimFresnelPowerFactor;
uniform float parametricRimLiftFactor;

#ifdef USE_MATCAPTEXTURE
  uniform vec3 matcapFactor;
  uniform sampler2D matcapTexture;
  uniform mat3 matcapTextureUvTransform;
#endif

uniform vec3 emissive;
uniform float emissiveIntensity;

uniform vec3 outlineColorFactor;
uniform float outlineLightingMixFactor;

#ifdef USE_UVANIMATIONMASKTEXTURE
  uniform sampler2D uvAnimationMaskTexture;
  uniform mat3 uvAnimationMaskTextureUvTransform;
#endif

uniform float uvAnimationScrollXOffset;
uniform float uvAnimationScrollYOffset;
uniform float uvAnimationRotationPhase;

#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>

// #include <uv_pars_fragment>
#if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )
  varying vec2 vUv;
#endif

// #include <uv2_pars_fragment>
// COMAPT: pre-r151 uses uv2 for lightMap and aoMap
#if THREE_VRM_THREE_REVISION < 151
  #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
    varying vec2 vUv2;
  #endif
#endif

#include <map_pars_fragment>

#ifdef USE_MAP
  uniform mat3 mapUvTransform;
#endif

// #include <alphamap_pars_fragment>

#include <alphatest_pars_fragment>

#include <aomap_pars_fragment>
// #include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>

#ifdef USE_EMISSIVEMAP
  uniform mat3 emissiveMapUvTransform;
#endif

// #include <envmap_common_pars_fragment>
// #include <envmap_pars_fragment>
// #include <cube_uv_reflection_fragment>
#include <fog_pars_fragment>

// #include <bsdfs>
// COMPAT: pre-r151 doesn't have BRDF_Lambert in <common>
#if THREE_VRM_THREE_REVISION < 151
  vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
    return RECIPROCAL_PI * diffuseColor;
  }
#endif

#include <lights_pars_begin>

#include <normal_pars_fragment>

// #include <lights_phong_pars_fragment>
varying vec3 vViewPosition;

struct MToonMaterial {
  vec3 diffuseColor;
  vec3 shadeColor;
  float shadingShift;
};

float linearstep( float a, float b, float t ) {
  return clamp( ( t - a ) / ( b - a ), 0.0, 1.0 );
}

/**
 * Convert NdotL into toon shading factor using shadingShift and shadingToony
 */
float getShading(
  const in float dotNL,
  const in float shadow,
  const in float shadingShift
) {
  float shading = dotNL;
  shading = shading + shadingShift;
  shading = linearstep( -1.0 + shadingToonyFactor, 1.0 - shadingToonyFactor, shading );
  shading *= shadow;
  return shading;
}

/**
 * Mix diffuseColor and shadeColor using shading factor and light color
 */
vec3 getDiffuse(
  const in MToonMaterial material,
  const in float shading,
  in vec3 lightColor
) {
  #ifdef DEBUG_LITSHADERATE
    return vec3( BRDF_Lambert( shading * lightColor ) );
  #endif

  vec3 col = lightColor * BRDF_Lambert( mix( material.shadeColor, material.diffuseColor, shading ) );

  // The "comment out if you want to PBR absolutely" line
  #ifdef V0_COMPAT_SHADE
    col = min( col, material.diffuseColor );
  #endif

  return col;
}

// COMPAT: pre-r156 uses a struct GeometricContext
#if THREE_VRM_THREE_REVISION >= 157
  void RE_Direct_MToon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in MToonMaterial material, const in float shadow, inout ReflectedLight reflectedLight ) {
    float dotNL = clamp( dot( geometryNormal, directLight.direction ), -1.0, 1.0 );
    vec3 irradiance = directLight.color;

    // directSpecular will be used for rim lighting, not an actual specular
    reflectedLight.directSpecular += irradiance;

    irradiance *= dotNL;

    float shading = getShading( dotNL, shadow, material.shadingShift );

    // toon shaded diffuse
    reflectedLight.directDiffuse += getDiffuse( material, shading, directLight.color );
  }

  void RE_IndirectDiffuse_MToon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in MToonMaterial material, inout ReflectedLight reflectedLight ) {
    // indirect diffuse will use diffuseColor, no shadeColor involved
    reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

    // directSpecular will be used for rim lighting, not an actual specular
    reflectedLight.directSpecular += irradiance;
  }
#else
  void RE_Direct_MToon( const in IncidentLight directLight, const in GeometricContext geometry, const in MToonMaterial material, const in float shadow, inout ReflectedLight reflectedLight ) {
    float dotNL = clamp( dot( geometry.normal, directLight.direction ), -1.0, 1.0 );
    vec3 irradiance = directLight.color;

    // directSpecular will be used for rim lighting, not an actual specular
    reflectedLight.directSpecular += irradiance;

    irradiance *= dotNL;

    float shading = getShading( dotNL, shadow, material.shadingShift );

    // toon shaded diffuse
    reflectedLight.directDiffuse += getDiffuse( material, shading, directLight.color );
  }

  void RE_IndirectDiffuse_MToon( const in vec3 irradiance, const in GeometricContext geometry, const in MToonMaterial material, inout ReflectedLight reflectedLight ) {
    // indirect diffuse will use diffuseColor, no shadeColor involved
    reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

    // directSpecular will be used for rim lighting, not an actual specular
    reflectedLight.directSpecular += irradiance;
  }
#endif

#define RE_Direct RE_Direct_MToon
#define RE_IndirectDiffuse RE_IndirectDiffuse_MToon
#define Material_LightProbeLOD( material ) (0)

#include <shadowmap_pars_fragment>
// #include <bumpmap_pars_fragment>

// #include <normalmap_pars_fragment>
#ifdef USE_NORMALMAP

  uniform sampler2D normalMap;
  uniform mat3 normalMapUvTransform;
  uniform vec2 normalScale;

#endif

// COMPAT: pre-r151
// USE_NORMALMAP_OBJECTSPACE used to be OBJECTSPACE_NORMALMAP in pre-r151
#if defined( USE_NORMALMAP_OBJECTSPACE ) || defined( OBJECTSPACE_NORMALMAP )

  uniform mat3 normalMatrix;

#endif

// COMPAT: pre-r151
// USE_NORMALMAP_TANGENTSPACE used to be TANGENTSPACE_NORMALMAP in pre-r151
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( TANGENTSPACE_NORMALMAP ) )

  // Per-Pixel Tangent Space Normal Mapping
  // http://hacksoflife.blogspot.ch/2009/11/per-pixel-tangent-space-normal-mapping.html

  // three-vrm specific change: it requires \`uv\` as an input in order to support uv scrolls

  // Temporary compat against shader change @ Three.js r126, r151
  #if THREE_VRM_THREE_REVISION >= 151

    mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {

      vec3 q0 = dFdx( eye_pos.xyz );
      vec3 q1 = dFdy( eye_pos.xyz );
      vec2 st0 = dFdx( uv.st );
      vec2 st1 = dFdy( uv.st );

      vec3 N = surf_norm;

      vec3 q1perp = cross( q1, N );
      vec3 q0perp = cross( N, q0 );

      vec3 T = q1perp * st0.x + q0perp * st1.x;
      vec3 B = q1perp * st0.y + q0perp * st1.y;

      float det = max( dot( T, T ), dot( B, B ) );
      float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );

      return mat3( T * scale, B * scale, N );

    }

  #else

    vec3 perturbNormal2Arb( vec2 uv, vec3 eye_pos, vec3 surf_norm, vec3 mapN, float faceDirection ) {

      vec3 q0 = vec3( dFdx( eye_pos.x ), dFdx( eye_pos.y ), dFdx( eye_pos.z ) );
      vec3 q1 = vec3( dFdy( eye_pos.x ), dFdy( eye_pos.y ), dFdy( eye_pos.z ) );
      vec2 st0 = dFdx( uv.st );
      vec2 st1 = dFdy( uv.st );

      vec3 N = normalize( surf_norm );

      vec3 q1perp = cross( q1, N );
      vec3 q0perp = cross( N, q0 );

      vec3 T = q1perp * st0.x + q0perp * st1.x;
      vec3 B = q1perp * st0.y + q0perp * st1.y;

      // three-vrm specific change: Workaround for the issue that happens when delta of uv = 0.0
      // TODO: Is this still required? Or shall I make a PR about it?
      if ( length( T ) == 0.0 || length( B ) == 0.0 ) {
        return surf_norm;
      }

      float det = max( dot( T, T ), dot( B, B ) );
      float scale = ( det == 0.0 ) ? 0.0 : faceDirection * inversesqrt( det );

      return normalize( T * ( mapN.x * scale ) + B * ( mapN.y * scale ) + N * mapN.z );

    }

  #endif

#endif

// #include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

// == post correction ==========================================================
void postCorrection() {
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
  #include <fog_fragment>
  #include <premultiplied_alpha_fragment>
  #include <dithering_fragment>
}

// == main procedure ===========================================================
void main() {
  #include <clipping_planes_fragment>

  vec2 uv = vec2(0.5, 0.5);

  #if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )
    uv = vUv;

    float uvAnimMask = 1.0;
    #ifdef USE_UVANIMATIONMASKTEXTURE
      vec2 uvAnimationMaskTextureUv = ( uvAnimationMaskTextureUvTransform * vec3( uv, 1 ) ).xy;
      uvAnimMask = texture2D( uvAnimationMaskTexture, uvAnimationMaskTextureUv ).b;
    #endif

    float uvRotCos = cos( uvAnimationRotationPhase * uvAnimMask );
    float uvRotSin = sin( uvAnimationRotationPhase * uvAnimMask );
    uv = mat2( uvRotCos, -uvRotSin, uvRotSin, uvRotCos ) * ( uv - 0.5 ) + 0.5;
    uv = uv + vec2( uvAnimationScrollXOffset, uvAnimationScrollYOffset ) * uvAnimMask;
  #endif

  #ifdef DEBUG_UV
    gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
    #if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )
      gl_FragColor = vec4( uv, 0.0, 1.0 );
    #endif
    return;
  #endif

  vec4 diffuseColor = vec4( litFactor, opacity );
  ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
  vec3 totalEmissiveRadiance = emissive * emissiveIntensity;

  #include <logdepthbuf_fragment>

  // #include <map_fragment>
  #ifdef USE_MAP
    vec2 mapUv = ( mapUvTransform * vec3( uv, 1 ) ).xy;
    vec4 sampledDiffuseColor = texture2D( map, mapUv );
    #ifdef DECODE_VIDEO_TEXTURE
      sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
    #endif
    diffuseColor *= sampledDiffuseColor;
  #endif

  // #include <color_fragment>
  #if ( defined( USE_COLOR ) && !defined( IGNORE_VERTEX_COLOR ) )
    diffuseColor.rgb *= vColor;
  #endif

  // #include <alphamap_fragment>

  #include <alphatest_fragment>

  // #include <specularmap_fragment>

  // #include <normal_fragment_begin>
  float faceDirection = gl_FrontFacing ? 1.0 : -1.0;

  #ifdef FLAT_SHADED

    vec3 fdx = dFdx( vViewPosition );
    vec3 fdy = dFdy( vViewPosition );
    vec3 normal = normalize( cross( fdx, fdy ) );

  #else

    vec3 normal = normalize( vNormal );

    #ifdef DOUBLE_SIDED

      normal *= faceDirection;

    #endif

  #endif

  #ifdef USE_NORMALMAP

    vec2 normalMapUv = ( normalMapUvTransform * vec3( uv, 1 ) ).xy;

  #endif

  #ifdef USE_NORMALMAP_TANGENTSPACE

    #ifdef USE_TANGENT

      mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );

    #else

      mat3 tbn = getTangentFrame( - vViewPosition, normal, normalMapUv );

    #endif

    #if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )

      tbn[0] *= faceDirection;
      tbn[1] *= faceDirection;

    #endif

  #endif

  #ifdef USE_CLEARCOAT_NORMALMAP

    #ifdef USE_TANGENT

      mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );

    #else

      mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );

    #endif

    #if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )

      tbn2[0] *= faceDirection;
      tbn2[1] *= faceDirection;

    #endif

  #endif

  // non perturbed normal for clearcoat among others

  vec3 nonPerturbedNormal = normal;

  #ifdef OUTLINE
    normal *= -1.0;
  #endif

  // #include <normal_fragment_maps>

  // COMPAT: pre-r151
  // USE_NORMALMAP_OBJECTSPACE used to be OBJECTSPACE_NORMALMAP in pre-r151
  #if defined( USE_NORMALMAP_OBJECTSPACE ) || defined( OBJECTSPACE_NORMALMAP )

    normal = texture2D( normalMap, normalMapUv ).xyz * 2.0 - 1.0; // overrides both flatShading and attribute normals

    #ifdef FLIP_SIDED

      normal = - normal;

    #endif

    #ifdef DOUBLE_SIDED

      normal = normal * faceDirection;

    #endif

    normal = normalize( normalMatrix * normal );

  // COMPAT: pre-r151
  // USE_NORMALMAP_TANGENTSPACE used to be TANGENTSPACE_NORMALMAP in pre-r151
  #elif defined( USE_NORMALMAP_TANGENTSPACE ) || defined( TANGENTSPACE_NORMALMAP )

    vec3 mapN = texture2D( normalMap, normalMapUv ).xyz * 2.0 - 1.0;
    mapN.xy *= normalScale;

    // COMPAT: pre-r151
    #if THREE_VRM_THREE_REVISION >= 151 || defined( USE_TANGENT )

      normal = normalize( tbn * mapN );

    #else

      normal = perturbNormal2Arb( uv, -vViewPosition, normal, mapN, faceDirection );

    #endif

  #endif

  // #include <emissivemap_fragment>
  #ifdef USE_EMISSIVEMAP
    vec2 emissiveMapUv = ( emissiveMapUvTransform * vec3( uv, 1 ) ).xy;
    totalEmissiveRadiance *= texture2D( emissiveMap, emissiveMapUv ).rgb;
  #endif

  #ifdef DEBUG_NORMAL
    gl_FragColor = vec4( 0.5 + 0.5 * normal, 1.0 );
    return;
  #endif

  // -- MToon: lighting --------------------------------------------------------
  // accumulation
  // #include <lights_phong_fragment>
  MToonMaterial material;

  material.diffuseColor = diffuseColor.rgb;

  material.shadeColor = shadeColorFactor;
  #ifdef USE_SHADEMULTIPLYTEXTURE
    vec2 shadeMultiplyTextureUv = ( shadeMultiplyTextureUvTransform * vec3( uv, 1 ) ).xy;
    material.shadeColor *= texture2D( shadeMultiplyTexture, shadeMultiplyTextureUv ).rgb;
  #endif

  #if ( defined( USE_COLOR ) && !defined( IGNORE_VERTEX_COLOR ) )
    material.shadeColor.rgb *= vColor;
  #endif

  material.shadingShift = shadingShiftFactor;
  #ifdef USE_SHADINGSHIFTTEXTURE
    vec2 shadingShiftTextureUv = ( shadingShiftTextureUvTransform * vec3( uv, 1 ) ).xy;
    material.shadingShift += texture2D( shadingShiftTexture, shadingShiftTextureUv ).r * shadingShiftTextureScale;
  #endif

  // #include <lights_fragment_begin>

  // MToon Specific changes:
  // Since we want to take shadows into account of shading instead of irradiance,
  // we had to modify the codes that multiplies the results of shadowmap into color of direct lights.

  // COMPAT: pre-r156 uses a struct GeometricContext
  #if THREE_VRM_THREE_REVISION >= 157
    vec3 geometryPosition = - vViewPosition;
    vec3 geometryNormal = normal;
    vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );

    vec3 geometryClearcoatNormal;

    #ifdef USE_CLEARCOAT

      geometryClearcoatNormal = clearcoatNormal;

    #endif
  #else
    GeometricContext geometry;

    geometry.position = - vViewPosition;
    geometry.normal = normal;
    geometry.viewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );

    #ifdef USE_CLEARCOAT

      geometry.clearcoatNormal = clearcoatNormal;

    #endif
  #endif

  IncidentLight directLight;

  // since these variables will be used in unrolled loop, we have to define in prior
  float shadow;

  #if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )

    PointLight pointLight;
    #if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
    PointLightShadow pointLightShadow;
    #endif

    #pragma unroll_loop_start
    for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {

      pointLight = pointLights[ i ];

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        getPointLightInfo( pointLight, geometryPosition, directLight );
      #else
        getPointLightInfo( pointLight, geometry, directLight );
      #endif

      shadow = 1.0;
      #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
      pointLightShadow = pointLightShadows[ i ];
      // COMPAT: pre-r166
      // r166 introduced shadowIntensity
      #if THREE_VRM_THREE_REVISION >= 166
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
      #else
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
      #endif
      #endif

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );
      #else
        RE_Direct( directLight, geometry, material, shadow, reflectedLight );
      #endif

    }
    #pragma unroll_loop_end

  #endif

  #if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )

    SpotLight spotLight;
    // COMPAT: pre-r144 uses NUM_SPOT_LIGHT_SHADOWS, r144+ uses NUM_SPOT_LIGHT_COORDS
    #if THREE_VRM_THREE_REVISION >= 144
      #if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_COORDS > 0
      SpotLightShadow spotLightShadow;
      #endif
    #elif defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
    SpotLightShadow spotLightShadow;
    #endif

    #pragma unroll_loop_start
    for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {

      spotLight = spotLights[ i ];

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        getSpotLightInfo( spotLight, geometryPosition, directLight );
      #else
        getSpotLightInfo( spotLight, geometry, directLight );
      #endif

      shadow = 1.0;
      // COMPAT: pre-r144 uses NUM_SPOT_LIGHT_SHADOWS and vSpotShadowCoord, r144+ uses NUM_SPOT_LIGHT_COORDS and vSpotLightCoord
      // COMPAT: pre-r166 does not have shadowIntensity, r166+ has shadowIntensity
      #if THREE_VRM_THREE_REVISION >= 166
        #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_COORDS )
        spotLightShadow = spotLightShadows[ i ];
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
        #endif
      #elif THREE_VRM_THREE_REVISION >= 144
        #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_COORDS )
        spotLightShadow = spotLightShadows[ i ];
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
        #endif
      #elif defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
      spotLightShadow = spotLightShadows[ i ];
      shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotShadowCoord[ i ] ) : 1.0;
      #endif

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );
      #else
        RE_Direct( directLight, geometry, material, shadow, reflectedLight );
      #endif

    }
    #pragma unroll_loop_end

  #endif

  #if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )

    DirectionalLight directionalLight;
    #if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
    DirectionalLightShadow directionalLightShadow;
    #endif

    #pragma unroll_loop_start
    for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {

      directionalLight = directionalLights[ i ];

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        getDirectionalLightInfo( directionalLight, directLight );
      #else
        getDirectionalLightInfo( directionalLight, geometry, directLight );
      #endif

      shadow = 1.0;
      #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
      directionalLightShadow = directionalLightShadows[ i ];
      // COMPAT: pre-r166
      // r166 introduced shadowIntensity
      #if THREE_VRM_THREE_REVISION >= 166
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
      #else
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
      #endif
      #endif

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );
      #else
        RE_Direct( directLight, geometry, material, shadow, reflectedLight );
      #endif

    }
    #pragma unroll_loop_end

  #endif

  // #if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )

  //   RectAreaLight rectAreaLight;

  //   #pragma unroll_loop_start
  //   for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {

  //     rectAreaLight = rectAreaLights[ i ];
  //     RE_Direct_RectArea( rectAreaLight, geometry, material, reflectedLight );

  //   }
  //   #pragma unroll_loop_end

  // #endif

  #if defined( RE_IndirectDiffuse )

    vec3 iblIrradiance = vec3( 0.0 );

    vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );

    // COMPAT: pre-r156 uses a struct GeometricContext
    // COMPAT: pre-r156 doesn't have a define USE_LIGHT_PROBES
    #if THREE_VRM_THREE_REVISION >= 157
      #if defined( USE_LIGHT_PROBES )
        irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
      #endif
    #else
      irradiance += getLightProbeIrradiance( lightProbe, geometry.normal );
    #endif

    #if ( NUM_HEMI_LIGHTS > 0 )

      #pragma unroll_loop_start
      for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {

        // COMPAT: pre-r156 uses a struct GeometricContext
        #if THREE_VRM_THREE_REVISION >= 157
          irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
        #else
          irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometry.normal );
        #endif

      }
      #pragma unroll_loop_end

    #endif

  #endif

  // #if defined( RE_IndirectSpecular )

  //   vec3 radiance = vec3( 0.0 );
  //   vec3 clearcoatRadiance = vec3( 0.0 );

  // #endif

  #include <lights_fragment_maps>
  #include <lights_fragment_end>

  // modulation
  #include <aomap_fragment>

  vec3 col = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;

  #ifdef DEBUG_LITSHADERATE
    gl_FragColor = vec4( col, diffuseColor.a );
    postCorrection();
    return;
  #endif

  // -- MToon: rim lighting -----------------------------------------
  vec3 viewDir = normalize( vViewPosition );

  #ifndef PHYSICALLY_CORRECT_LIGHTS
    reflectedLight.directSpecular /= PI;
  #endif
  vec3 rimMix = mix( vec3( 1.0 ), reflectedLight.directSpecular, rimLightingMixFactor );

  vec3 rim = parametricRimColorFactor * pow( saturate( 1.0 - dot( viewDir, normal ) + parametricRimLiftFactor ), parametricRimFresnelPowerFactor );

  #ifdef USE_MATCAPTEXTURE
    {
      vec3 x = normalize( vec3( viewDir.z, 0.0, -viewDir.x ) );
      vec3 y = cross( viewDir, x ); // guaranteed to be normalized
      vec2 sphereUv = 0.5 + 0.5 * vec2( dot( x, normal ), -dot( y, normal ) );
      sphereUv = ( matcapTextureUvTransform * vec3( sphereUv, 1 ) ).xy;
      vec3 matcap = texture2D( matcapTexture, sphereUv ).rgb;
      rim += matcapFactor * matcap;
    }
  #endif

  #ifdef USE_RIMMULTIPLYTEXTURE
    vec2 rimMultiplyTextureUv = ( rimMultiplyTextureUvTransform * vec3( uv, 1 ) ).xy;
    rim *= texture2D( rimMultiplyTexture, rimMultiplyTextureUv ).rgb;
  #endif

  col += rimMix * rim;

  // -- MToon: Emission --------------------------------------------------------
  col += totalEmissiveRadiance;

  // #include <envmap_fragment>

  // -- Almost done! -----------------------------------------------------------
  #if defined( OUTLINE )
    col = outlineColorFactor.rgb * mix( vec3( 1.0 ), col, outlineLightingMixFactor );
  #endif

  #ifdef OPAQUE
    diffuseColor.a = 1.0;
  #endif

  gl_FragColor = vec4( col, diffuseColor.a );
  postCorrection();
}
`;var Hu={None:"none",Normal:"normal",LitShadeRate:"litShadeRate",UV:"uv"};var Ya={None:"none",WorldCoordinates:"worldCoordinates",ScreenCoordinates:"screenCoordinates"};var sv={3000:"",3001:"srgb"};function Za(e){if(parseInt(ai,10)>=152)return e.colorSpace;else return sv[e.encoding]}class ja extends On{uniforms;get color(){return this.uniforms.litFactor.value}set color(e){this.uniforms.litFactor.value=e}get map(){return this.uniforms.map.value}set map(e){this.uniforms.map.value=e}get normalMap(){return this.uniforms.normalMap.value}set normalMap(e){this.uniforms.normalMap.value=e}get normalScale(){return this.uniforms.normalScale.value}set normalScale(e){this.uniforms.normalScale.value=e}get emissive(){return this.uniforms.emissive.value}set emissive(e){this.uniforms.emissive.value=e}get emissiveIntensity(){return this.uniforms.emissiveIntensity.value}set emissiveIntensity(e){this.uniforms.emissiveIntensity.value=e}get emissiveMap(){return this.uniforms.emissiveMap.value}set emissiveMap(e){this.uniforms.emissiveMap.value=e}get shadeColorFactor(){return this.uniforms.shadeColorFactor.value}set shadeColorFactor(e){this.uniforms.shadeColorFactor.value=e}get shadeMultiplyTexture(){return this.uniforms.shadeMultiplyTexture.value}set shadeMultiplyTexture(e){this.uniforms.shadeMultiplyTexture.value=e}get shadingShiftFactor(){return this.uniforms.shadingShiftFactor.value}set shadingShiftFactor(e){this.uniforms.shadingShiftFactor.value=e}get shadingShiftTexture(){return this.uniforms.shadingShiftTexture.value}set shadingShiftTexture(e){this.uniforms.shadingShiftTexture.value=e}get shadingShiftTextureScale(){return this.uniforms.shadingShiftTextureScale.value}set shadingShiftTextureScale(e){this.uniforms.shadingShiftTextureScale.value=e}get shadingToonyFactor(){return this.uniforms.shadingToonyFactor.value}set shadingToonyFactor(e){this.uniforms.shadingToonyFactor.value=e}get giEqualizationFactor(){return this.uniforms.giEqualizationFactor.value}set giEqualizationFactor(e){this.uniforms.giEqualizationFactor.value=e}get matcapFactor(){return this.uniforms.matcapFactor.value}set matcapFactor(e){this.uniforms.matcapFactor.value=e}get matcapTexture(){return this.uniforms.matcapTexture.value}set matcapTexture(e){this.uniforms.matcapTexture.value=e}get parametricRimColorFactor(){return this.uniforms.parametricRimColorFactor.value}set parametricRimColorFactor(e){this.uniforms.parametricRimColorFactor.value=e}get rimMultiplyTexture(){return this.uniforms.rimMultiplyTexture.value}set rimMultiplyTexture(e){this.uniforms.rimMultiplyTexture.value=e}get rimLightingMixFactor(){return this.uniforms.rimLightingMixFactor.value}set rimLightingMixFactor(e){this.uniforms.rimLightingMixFactor.value=e}get parametricRimFresnelPowerFactor(){return this.uniforms.parametricRimFresnelPowerFactor.value}set parametricRimFresnelPowerFactor(e){this.uniforms.parametricRimFresnelPowerFactor.value=e}get parametricRimLiftFactor(){return this.uniforms.parametricRimLiftFactor.value}set parametricRimLiftFactor(e){this.uniforms.parametricRimLiftFactor.value=e}get outlineWidthMultiplyTexture(){return this.uniforms.outlineWidthMultiplyTexture.value}set outlineWidthMultiplyTexture(e){this.uniforms.outlineWidthMultiplyTexture.value=e}get outlineWidthFactor(){return this.uniforms.outlineWidthFactor.value}set outlineWidthFactor(e){this.uniforms.outlineWidthFactor.value=e}get outlineColorFactor(){return this.uniforms.outlineColorFactor.value}set outlineColorFactor(e){this.uniforms.outlineColorFactor.value=e}get outlineLightingMixFactor(){return this.uniforms.outlineLightingMixFactor.value}set outlineLightingMixFactor(e){this.uniforms.outlineLightingMixFactor.value=e}get uvAnimationMaskTexture(){return this.uniforms.uvAnimationMaskTexture.value}set uvAnimationMaskTexture(e){this.uniforms.uvAnimationMaskTexture.value=e}get uvAnimationScrollXOffset(){return this.uniforms.uvAnimationScrollXOffset.value}set uvAnimationScrollXOffset(e){this.uniforms.uvAnimationScrollXOffset.value=e}get uvAnimationScrollYOffset(){return this.uniforms.uvAnimationScrollYOffset.value}set uvAnimationScrollYOffset(e){this.uniforms.uvAnimationScrollYOffset.value=e}get uvAnimationRotationPhase(){return this.uniforms.uvAnimationRotationPhase.value}set uvAnimationRotationPhase(e){this.uniforms.uvAnimationRotationPhase.value=e}uvAnimationScrollXSpeedFactor=0;uvAnimationScrollYSpeedFactor=0;uvAnimationRotationSpeedFactor=0;fog=!0;normalMapType=Ir;_ignoreVertexColor=!0;get ignoreVertexColor(){return this._ignoreVertexColor}set ignoreVertexColor(e){this._ignoreVertexColor=e,this.needsUpdate=!0}_v0CompatShade=!1;get v0CompatShade(){return this._v0CompatShade}set v0CompatShade(e){this._v0CompatShade=e,this.needsUpdate=!0}_debugMode=Hu.None;get debugMode(){return this._debugMode}set debugMode(e){this._debugMode=e,this.needsUpdate=!0}_outlineWidthMode=Ya.None;get outlineWidthMode(){return this._outlineWidthMode}set outlineWidthMode(e){this._outlineWidthMode=e,this.needsUpdate=!0}_isOutline=!1;get isOutline(){return this._isOutline}set isOutline(e){this._isOutline=e,this.needsUpdate=!0}get isMToonMaterial(){return!0}constructor(e={}){super({vertexShader:zp,fragmentShader:Wp});if(e.transparentWithZWrite)e.depthWrite=!0;delete e.transparentWithZWrite,e.fog=!0,e.lights=!0,e.clipping=!0,this.uniforms=Ea.merge([he.common,he.normalmap,he.emissivemap,he.fog,he.lights,{litFactor:{value:new xe(1,1,1)},mapUvTransform:{value:new Pe},colorAlpha:{value:1},normalMapUvTransform:{value:new Pe},shadeColorFactor:{value:new xe(0,0,0)},shadeMultiplyTexture:{value:null},shadeMultiplyTextureUvTransform:{value:new Pe},shadingShiftFactor:{value:0},shadingShiftTexture:{value:null},shadingShiftTextureUvTransform:{value:new Pe},shadingShiftTextureScale:{value:1},shadingToonyFactor:{value:0.9},giEqualizationFactor:{value:0.9},matcapFactor:{value:new xe(1,1,1)},matcapTexture:{value:null},matcapTextureUvTransform:{value:new Pe},parametricRimColorFactor:{value:new xe(0,0,0)},rimMultiplyTexture:{value:null},rimMultiplyTextureUvTransform:{value:new Pe},rimLightingMixFactor:{value:1},parametricRimFresnelPowerFactor:{value:5},parametricRimLiftFactor:{value:0},emissive:{value:new xe(0,0,0)},emissiveIntensity:{value:1},emissiveMapUvTransform:{value:new Pe},outlineWidthMultiplyTexture:{value:null},outlineWidthMultiplyTextureUvTransform:{value:new Pe},outlineWidthFactor:{value:0},outlineColorFactor:{value:new xe(0,0,0)},outlineLightingMixFactor:{value:1},uvAnimationMaskTexture:{value:null},uvAnimationMaskTextureUvTransform:{value:new Pe},uvAnimationScrollXOffset:{value:0},uvAnimationScrollYOffset:{value:0},uvAnimationRotationPhase:{value:0}},e.uniforms??{}]),this.setValues(e),this._uploadUniformsWorkaround(),this.customProgramCacheKey=()=>[...Object.entries(this._generateDefines()).map(([t,n])=>`${t}:${n}`),this.matcapTexture?`matcapTextureColorSpace:${Za(this.matcapTexture)}`:"",this.shadeMultiplyTexture?`shadeMultiplyTextureColorSpace:${Za(this.shadeMultiplyTexture)}`:"",this.rimMultiplyTexture?`rimMultiplyTextureColorSpace:${Za(this.rimMultiplyTexture)}`:""].join(","),this.onBeforeCompile=(t)=>{let n=parseInt(ai,10),i=Object.entries({...this._generateDefines(),...this.defines}).filter(([s,r])=>!!r).map(([s,r])=>`#define ${s} ${r}`).join(`
`)+`
`;if(t.vertexShader=i+t.vertexShader,t.fragmentShader=i+t.fragmentShader,n<154)t.fragmentShader=t.fragmentShader.replace("#include <colorspace_fragment>","#include <encodings_fragment>")}}update(e){this._uploadUniformsWorkaround(),this._updateUVAnimation(e)}copy(e){return super.copy(e),this.map=e.map,this.normalMap=e.normalMap,this.emissiveMap=e.emissiveMap,this.shadeMultiplyTexture=e.shadeMultiplyTexture,this.shadingShiftTexture=e.shadingShiftTexture,this.matcapTexture=e.matcapTexture,this.rimMultiplyTexture=e.rimMultiplyTexture,this.outlineWidthMultiplyTexture=e.outlineWidthMultiplyTexture,this.uvAnimationMaskTexture=e.uvAnimationMaskTexture,this.normalMapType=e.normalMapType,this.uvAnimationScrollXSpeedFactor=e.uvAnimationScrollXSpeedFactor,this.uvAnimationScrollYSpeedFactor=e.uvAnimationScrollYSpeedFactor,this.uvAnimationRotationSpeedFactor=e.uvAnimationRotationSpeedFactor,this.ignoreVertexColor=e.ignoreVertexColor,this.v0CompatShade=e.v0CompatShade,this.debugMode=e.debugMode,this.outlineWidthMode=e.outlineWidthMode,this.isOutline=e.isOutline,this.needsUpdate=!0,this}_updateUVAnimation(e){this.uniforms.uvAnimationScrollXOffset.value+=e*this.uvAnimationScrollXSpeedFactor,this.uniforms.uvAnimationScrollYOffset.value+=e*this.uvAnimationScrollYSpeedFactor,this.uniforms.uvAnimationRotationPhase.value+=e*this.uvAnimationRotationSpeedFactor,this.uniforms.alphaTest.value=this.alphaTest,this.uniformsNeedUpdate=!0}_uploadUniformsWorkaround(){this.uniforms.opacity.value=this.opacity,this._updateTextureMatrix(this.uniforms.map,this.uniforms.mapUvTransform),this._updateTextureMatrix(this.uniforms.normalMap,this.uniforms.normalMapUvTransform),this._updateTextureMatrix(this.uniforms.emissiveMap,this.uniforms.emissiveMapUvTransform),this._updateTextureMatrix(this.uniforms.shadeMultiplyTexture,this.uniforms.shadeMultiplyTextureUvTransform),this._updateTextureMatrix(this.uniforms.shadingShiftTexture,this.uniforms.shadingShiftTextureUvTransform),this._updateTextureMatrix(this.uniforms.matcapTexture,this.uniforms.matcapTextureUvTransform),this._updateTextureMatrix(this.uniforms.rimMultiplyTexture,this.uniforms.rimMultiplyTextureUvTransform),this._updateTextureMatrix(this.uniforms.outlineWidthMultiplyTexture,this.uniforms.outlineWidthMultiplyTextureUvTransform),this._updateTextureMatrix(this.uniforms.uvAnimationMaskTexture,this.uniforms.uvAnimationMaskTextureUvTransform),this.uniformsNeedUpdate=!0}_generateDefines(){let e=parseInt(ai,10),t=this.outlineWidthMultiplyTexture!==null,n=this.map!==null||this.normalMap!==null||this.emissiveMap!==null||this.shadeMultiplyTexture!==null||this.shadingShiftTexture!==null||this.rimMultiplyTexture!==null||this.uvAnimationMaskTexture!==null;return{THREE_VRM_THREE_REVISION:e,OUTLINE:this._isOutline,MTOON_USE_UV:t||n,MTOON_UVS_VERTEX_ONLY:t&&!n,V0_COMPAT_SHADE:this._v0CompatShade,USE_SHADEMULTIPLYTEXTURE:this.shadeMultiplyTexture!==null,USE_SHADINGSHIFTTEXTURE:this.shadingShiftTexture!==null,USE_MATCAPTEXTURE:this.matcapTexture!==null,USE_RIMMULTIPLYTEXTURE:this.rimMultiplyTexture!==null,USE_OUTLINEWIDTHMULTIPLYTEXTURE:this._isOutline&&this.outlineWidthMultiplyTexture!==null,USE_UVANIMATIONMASKTEXTURE:this.uvAnimationMaskTexture!==null,IGNORE_VERTEX_COLOR:this._ignoreVertexColor===!0,DEBUG_NORMAL:this._debugMode==="normal",DEBUG_LITSHADERATE:this._debugMode==="litShadeRate",DEBUG_UV:this._debugMode==="uv",OUTLINE_WIDTH_SCREEN:this._isOutline&&this._outlineWidthMode===Ya.ScreenCoordinates}}_updateTextureMatrix(e,t){if(e.value){if(e.value.matrixAutoUpdate)e.value.updateMatrix();t.value.copy(e.value.matrix)}}}var rv=new Set(["1.0","1.0-beta"]);class ds{static EXTENSION_NAME="VRMC_materials_mtoon";materialType;renderOrderOffset;v0CompatShade;debugMode;parser;_mToonMaterialSet;get name(){return ds.EXTENSION_NAME}constructor(e,t={}){this.parser=e,this.materialType=t.materialType??ja,this.renderOrderOffset=t.renderOrderOffset??0,this.v0CompatShade=t.v0CompatShade??!1,this.debugMode=t.debugMode??"none",this._mToonMaterialSet=new Set}async beforeRoot(){this._removeUnlitExtensionIfMToonExists()}async afterRoot(e){e.userData.vrmMToonMaterials=Array.from(this._mToonMaterialSet)}getMaterialType(e){if(this._getMToonExtension(e))return this.materialType;return null}extendMaterialParams(e,t){let n=this._getMToonExtension(e);if(n)return this._extendMaterialParams(n,t);return null}async loadMesh(e){let t=this.parser,i=t.json.meshes?.[e];if(i==null)throw Error(`MToonMaterialLoaderPlugin: Attempt to use meshes[${e}] of glTF but the mesh doesn't exist`);let s=i.primitives,r=await t.loadMesh(e);if(s.length===1){let o=r,a=s[0].material;if(a!=null)this._setupPrimitive(o,a)}else{let o=r;for(let a=0;a<s.length;a++){let l=o.children[a],c=s[a].material;if(c!=null)this._setupPrimitive(l,c)}}return r}_removeUnlitExtensionIfMToonExists(){this.parser.json.materials?.map((i,s)=>{if(this._getMToonExtension(s)&&i.extensions?.KHR_materials_unlit)delete i.extensions.KHR_materials_unlit})}_getMToonExtension(e){let i=this.parser.json.materials?.[e];if(i==null){console.warn(`MToonMaterialLoaderPlugin: Attempt to use materials[${e}] of glTF but the material doesn't exist`);return}let s=i.extensions?.[ds.EXTENSION_NAME];if(s==null)return;let r=s.specVersion;if(!rv.has(r)){console.warn(`MToonMaterialLoaderPlugin: Unknown ${ds.EXTENSION_NAME} specVersion "${r}"`);return}return s}async _extendMaterialParams(e,t){delete t.metalness,delete t.roughness;let n=new Fu(this.parser,t);n.assignPrimitive("transparentWithZWrite",e.transparentWithZWrite),n.assignColor("shadeColorFactor",e.shadeColorFactor),n.assignTexture("shadeMultiplyTexture",e.shadeMultiplyTexture,!0),n.assignPrimitive("shadingShiftFactor",e.shadingShiftFactor),n.assignTexture("shadingShiftTexture",e.shadingShiftTexture,!0),n.assignPrimitive("shadingShiftTextureScale",e.shadingShiftTexture?.scale),n.assignPrimitive("shadingToonyFactor",e.shadingToonyFactor),n.assignPrimitive("giEqualizationFactor",e.giEqualizationFactor),n.assignColor("matcapFactor",e.matcapFactor),n.assignTexture("matcapTexture",e.matcapTexture,!0),n.assignColor("parametricRimColorFactor",e.parametricRimColorFactor),n.assignTexture("rimMultiplyTexture",e.rimMultiplyTexture,!0),n.assignPrimitive("rimLightingMixFactor",e.rimLightingMixFactor),n.assignPrimitive("parametricRimFresnelPowerFactor",e.parametricRimFresnelPowerFactor),n.assignPrimitive("parametricRimLiftFactor",e.parametricRimLiftFactor),n.assignPrimitive("outlineWidthMode",e.outlineWidthMode),n.assignPrimitive("outlineWidthFactor",e.outlineWidthFactor),n.assignTexture("outlineWidthMultiplyTexture",e.outlineWidthMultiplyTexture,!1),n.assignColor("outlineColorFactor",e.outlineColorFactor),n.assignPrimitive("outlineLightingMixFactor",e.outlineLightingMixFactor),n.assignTexture("uvAnimationMaskTexture",e.uvAnimationMaskTexture,!1),n.assignPrimitive("uvAnimationScrollXSpeedFactor",e.uvAnimationScrollXSpeedFactor),n.assignPrimitive("uvAnimationScrollYSpeedFactor",e.uvAnimationScrollYSpeedFactor),n.assignPrimitive("uvAnimationRotationSpeedFactor",e.uvAnimationRotationSpeedFactor),n.assignPrimitive("v0CompatShade",this.v0CompatShade),n.assignPrimitive("debugMode",this.debugMode),await n.pending}_setupPrimitive(e,t){let n=this._getMToonExtension(t);if(n){let i=this._parseRenderOrder(n);e.renderOrder=i+this.renderOrderOffset,this._generateOutline(e),this._addToMaterialSet(e);return}}_shouldGenerateOutline(e){return typeof e.outlineWidthMode==="string"&&e.outlineWidthMode!=="none"&&typeof e.outlineWidthFactor==="number"&&e.outlineWidthFactor>0}_generateOutline(e){let t=e.material;if(!(t instanceof tn))return;if(!this._shouldGenerateOutline(t))return;e.material=[t];let n=t.clone();n.name+=" (Outline)",n.isOutline=!0,n.side=qt,e.material.push(n);let i=e.geometry,s=i.index?i.index.count:i.attributes.position.count/3;i.addGroup(0,s,0),i.addGroup(0,s,1)}_addToMaterialSet(e){let t=e.material,n=new Set;if(Array.isArray(t))t.forEach((i)=>n.add(i));else n.add(t);for(let i of n)this._mToonMaterialSet.add(i)}_parseRenderOrder(e){return(e.transparentWithZWrite?0:19)+(e.renderQueueOffsetNumber??0)}}class lr{static EXTENSION_NAME="VRMC_materials_hdr_emissiveMultiplier";parser;get name(){return lr.EXTENSION_NAME}constructor(e){this.parser=e}async extendMaterialParams(e,t){let n=this._getHDREmissiveMultiplierExtension(e);if(n==null)return;console.warn("VRMMaterialsHDREmissiveMultiplierLoaderPlugin: `VRMC_materials_hdr_emissiveMultiplier` is archived. Use `KHR_materials_emissive_strength` instead.");let i=n.emissiveMultiplier;t.emissiveIntensity=i}_getHDREmissiveMultiplierExtension(e){let i=this.parser.json.materials?.[e];if(i==null){console.warn(`VRMMaterialsHDREmissiveMultiplierLoaderPlugin: Attempt to use materials[${e}] of glTF but the material doesn't exist`);return}let s=i.extensions?.[lr.EXTENSION_NAME];if(s==null)return;return s}}function fs(e){return Math.pow(e,2.2)}class Ja{parser;_renderQueueMapTransparent;_renderQueueMapTransparentZWrite;get name(){return"VRMMaterialsV0CompatPlugin"}constructor(e){this.parser=e,this._renderQueueMapTransparent=new Map,this._renderQueueMapTransparentZWrite=new Map;let t=this.parser.json;if(t.extensionsUsed=t.extensionsUsed??[],t.extensionsUsed.indexOf("KHR_texture_transform")===-1)t.extensionsUsed.push("KHR_texture_transform")}async beforeRoot(){let e=this.parser.json,n=e.extensions?.VRM?.materialProperties;if(!n)return;this._populateRenderQueueMap(n),n.forEach((i,s)=>{let r=e.materials?.[s];if(r==null){console.warn(`VRMMaterialsV0CompatPlugin: Attempt to use materials[${s}] of glTF but the material doesn't exist`);return}if(i.shader==="VRM/MToon"){let o=this._parseV0MToonProperties(i,r);e.materials[s]=o}else if(i.shader?.startsWith("VRM/Unlit")){let o=this._parseV0UnlitProperties(i,r);e.materials[s]=o}else if(i.shader==="VRM_USE_GLTFSHADER");else console.warn(`VRMMaterialsV0CompatPlugin: Unknown shader: ${i.shader}`)})}_parseV0MToonProperties(e,t){let n=e.keywordMap?._ALPHABLEND_ON??!1,s=e.floatProperties?._ZWrite===1&&n,r=this._v0ParseRenderQueue(e),o=e.keywordMap?._ALPHATEST_ON??!1,a=n?"BLEND":o?"MASK":"OPAQUE",l=o?e.floatProperties?._Cutoff??0.5:void 0,u=(e.floatProperties?._CullMode??2)===0,h=this._portTextureTransform(e),d=(e.vectorProperties?._Color??[1,1,1,1]).map((gt,Mt)=>Mt===3?gt:fs(gt)),f=e.textureProperties?._MainTex,m=f!=null?{index:f,extensions:{...h}}:void 0,x=e.floatProperties?._BumpScale??1,p=e.textureProperties?._BumpMap,g=p!=null?{index:p,scale:x,extensions:{...h}}:void 0,v=(e.vectorProperties?._EmissionColor??[0,0,0,1]).map(fs),S=e.textureProperties?._EmissionMap,T=S!=null?{index:S,extensions:{...h}}:void 0,A=(e.vectorProperties?._ShadeColor??[0.97,0.81,0.86,1]).map(fs),w=e.textureProperties?._ShadeTexture,_=w!=null?{index:w,extensions:{...h}}:void 0,E=e.floatProperties?._ShadeShift??0,I=e.floatProperties?._ShadeToony??0.9;I=$e.lerp(I,1,0.5+0.5*E),E=-E-(1-I);let k=e.floatProperties?._IndirectLightIntensity??0.1,N=k?1-k:void 0,V=e.textureProperties?._SphereAdd,Q=V!=null?[1,1,1]:void 0,C=V!=null?{index:V}:void 0,q=e.floatProperties?._RimLightingMix??0,j=e.textureProperties?._RimTexture,F=j!=null?{index:j,extensions:{...h}}:void 0,re=(e.vectorProperties?._RimColor??[0,0,0,1]).map(fs),W=e.floatProperties?._RimFresnelPower??1,J=e.floatProperties?._RimLift??0,ne=["none","worldCoordinates","screenCoordinates"][e.floatProperties?._OutlineWidthMode??0],Me=e.floatProperties?._OutlineWidth??0;Me=0.01*Me;let Z=e.textureProperties?._OutlineWidthTexture,te=Z!=null?{index:Z,extensions:{...h}}:void 0,ye=(e.vectorProperties?._OutlineColor??[0,0,0]).map(fs),De=(e.floatProperties?._OutlineColorMode??0)===1?e.floatProperties?._OutlineLightingMix??1:0,_e=e.textureProperties?._UvAnimMaskTexture,it=_e!=null?{index:_e,extensions:{...h}}:void 0,We=e.floatProperties?._UvAnimScrollX??0,Be=e.floatProperties?._UvAnimScrollY??0;if(Be!=null)Be=-Be;let ht=e.floatProperties?._UvAnimRotation??0;return{...t,pbrMetallicRoughness:{baseColorFactor:d,baseColorTexture:m},normalTexture:g,emissiveTexture:T,emissiveFactor:v,alphaMode:a,alphaCutoff:l,doubleSided:u,extensions:{VRMC_materials_mtoon:{specVersion:"1.0",transparentWithZWrite:s,renderQueueOffsetNumber:r,shadeColorFactor:A,shadeMultiplyTexture:_,shadingShiftFactor:E,shadingToonyFactor:I,giEqualizationFactor:N,matcapFactor:Q,matcapTexture:C,rimLightingMixFactor:q,rimMultiplyTexture:F,parametricRimColorFactor:re,parametricRimFresnelPowerFactor:W,parametricRimLiftFactor:J,outlineWidthMode:ne,outlineWidthFactor:Me,outlineWidthMultiplyTexture:te,outlineColorFactor:ye,outlineLightingMixFactor:De,uvAnimationMaskTexture:it,uvAnimationScrollXSpeedFactor:We,uvAnimationScrollYSpeedFactor:Be,uvAnimationRotationSpeedFactor:ht}}}}_parseV0UnlitProperties(e,t){let n=e.shader==="VRM/UnlitTransparentZWrite",i=e.shader==="VRM/UnlitTransparent"||n,s=this._v0ParseRenderQueue(e),r=e.shader==="VRM/UnlitCutout",o=i?"BLEND":r?"MASK":"OPAQUE",a=r?e.floatProperties?._Cutoff??0.5:void 0,l=this._portTextureTransform(e),c=(e.vectorProperties?._Color??[1,1,1,1]).map(fs),u=e.textureProperties?._MainTex,h=u!=null?{index:u,extensions:{...l}}:void 0;return{...t,pbrMetallicRoughness:{baseColorFactor:c,baseColorTexture:h},alphaMode:o,alphaCutoff:a,extensions:{VRMC_materials_mtoon:{specVersion:"1.0",transparentWithZWrite:n,renderQueueOffsetNumber:s,shadeColorFactor:c,shadeMultiplyTexture:h}}}}_portTextureTransform(e){let t=e.vectorProperties?._MainTex;if(t==null)return{};let n=[t?.[0]??0,t?.[1]??0],i=[t?.[2]??1,t?.[3]??1];return n[1]=1-i[1]-n[1],{KHR_texture_transform:{offset:n,scale:i}}}_v0ParseRenderQueue(e){let t=e.shader==="VRM/UnlitTransparentZWrite",n=e.keywordMap?._ALPHABLEND_ON!=null||e.shader==="VRM/UnlitTransparent"||t,i=e.floatProperties?._ZWrite===1||t,s=0;if(n){let r=e.renderQueue;if(r!=null)if(i)s=this._renderQueueMapTransparentZWrite.get(r);else s=this._renderQueueMapTransparent.get(r)}return s}_populateRenderQueueMap(e){let t=new Set,n=new Set;if(e.forEach((i)=>{let s=i.shader==="VRM/UnlitTransparentZWrite",r=i.keywordMap?._ALPHABLEND_ON!=null||i.shader==="VRM/UnlitTransparent"||s,o=i.floatProperties?._ZWrite===1||s;if(r){let a=i.renderQueue;if(a!=null)if(o)n.add(a);else t.add(a)}}),t.size>10)console.warn(`VRMMaterialsV0CompatPlugin: This VRM uses ${t.size} render queues for Transparent materials while VRM 1.0 only supports up to 10 render queues. The model might not be rendered correctly.`);if(n.size>10)console.warn(`VRMMaterialsV0CompatPlugin: This VRM uses ${n.size} render queues for TransparentZWrite materials while VRM 1.0 only supports up to 10 render queues. The model might not be rendered correctly.`);Array.from(t).sort().forEach((i,s)=>{let r=Math.min(Math.max(s-t.size+1,-9),0);this._renderQueueMapTransparent.set(i,r)}),Array.from(n).sort().forEach((i,s)=>{let r=Math.min(Math.max(s,0),9);this._renderQueueMapTransparentZWrite.set(i,r)})}}var Hi=new R;class cr extends yt{constraint;_line;_attrPosition;constructor(e){super();this._attrPosition=new Ge(new Float32Array([0,0,0,0,0,0]),3),this._attrPosition.setUsage(Gc);let t=new Qe;t.setAttribute("position",this._attrPosition);let n=new an({color:16711935,depthTest:!1,depthWrite:!1});this._line=new Ci(t,n),this.add(this._line),this.constraint=e}updateMatrixWorld(e){if(Hi.setFromMatrixPosition(this.constraint.destination.matrixWorld),this._attrPosition.setXYZ(0,Hi.x,Hi.y,Hi.z),this.constraint.source)Hi.setFromMatrixPosition(this.constraint.source.matrixWorld);this._attrPosition.setXYZ(1,Hi.x,Hi.y,Hi.z),this._attrPosition.needsUpdate=!0,super.updateMatrixWorld(e)}}function Bu(e,t){return t.set(e.elements[12],e.elements[13],e.elements[14])}var ov=new R,av=new R;function Xp(e,t){return e.decompose(ov,t,av),t}function ps(e){if(e.invert)e.invert();else e.inverse();return e}class Bi{destination;source;weight;constructor(e,t){this.destination=e,this.source=t,this.weight=1}}var lv=new R,cv=new R,uv=new R,hv=new be,dv=new be,fv=new be;class Ka extends Bi{get aimAxis(){return this._aimAxis}set aimAxis(e){this._aimAxis=e,this._v3AimAxis.set(e==="PositiveX"?1:e==="NegativeX"?-1:0,e==="PositiveY"?1:e==="NegativeY"?-1:0,e==="PositiveZ"?1:e==="NegativeZ"?-1:0)}_aimAxis;_v3AimAxis;_dstRestQuat;get dependencies(){let e=new Set([this.source]);if(this.destination.parent)e.add(this.destination.parent);return e}constructor(e,t){super(e,t);this._aimAxis="PositiveX",this._v3AimAxis=new R(1,0,0),this._dstRestQuat=new be}setInitState(){this._dstRestQuat.copy(this.destination.quaternion)}update(){this.destination.updateWorldMatrix(!0,!1),this.source.updateWorldMatrix(!0,!1);let e=hv.identity(),t=dv.identity();if(this.destination.parent)Xp(this.destination.parent.matrixWorld,e),ps(t.copy(e));let n=lv.copy(this._v3AimAxis).applyQuaternion(this._dstRestQuat).applyQuaternion(e),i=Bu(this.source.matrixWorld,cv).sub(Bu(this.destination.matrixWorld,uv)).normalize(),s=fv.setFromUnitVectors(n,i).premultiply(t).multiply(e).multiply(this._dstRestQuat);this.destination.quaternion.copy(this._dstRestQuat).slerp(s,this.weight)}}function qp(e,t){let n=[e],i=e.parent;while(i!==null)n.unshift(i),i=i.parent;n.forEach((s)=>{t(s)})}class $a{_constraints=new Set;get constraints(){return this._constraints}_objectConstraintsMap=new Map;addConstraint(e){this._constraints.add(e);let t=this._objectConstraintsMap.get(e.destination);if(t==null)t=new Set,this._objectConstraintsMap.set(e.destination,t);t.add(e)}deleteConstraint(e){this._constraints.delete(e),this._objectConstraintsMap.get(e.destination).delete(e)}setInitState(){let e=new Set,t=new Set;for(let n of this._constraints)this._processConstraint(n,e,t,(i)=>i.setInitState())}update(){let e=new Set,t=new Set;for(let n of this._constraints)this._processConstraint(n,e,t,(i)=>i.update())}_processConstraint(e,t,n,i){if(n.has(e))return;if(t.has(e))throw Error("VRMNodeConstraintManager: Circular dependency detected while updating constraints");t.add(e);let s=e.dependencies;for(let r of s)qp(r,(o)=>{let a=this._objectConstraintsMap.get(o);if(a)for(let l of a)this._processConstraint(l,t,n,i)});i(e),n.add(e)}}var pv=new be,mv=new be;class Qa extends Bi{_dstRestQuat;_invSrcRestQuat;get dependencies(){return new Set([this.source])}constructor(e,t){super(e,t);this._dstRestQuat=new be,this._invSrcRestQuat=new be}setInitState(){this._dstRestQuat.copy(this.destination.quaternion),ps(this._invSrcRestQuat.copy(this.source.quaternion))}update(){let e=pv.copy(this._invSrcRestQuat).multiply(this.source.quaternion),t=mv.copy(this._dstRestQuat).multiply(e);this.destination.quaternion.copy(this._dstRestQuat).slerp(t,this.weight)}}var gv=new R,_v=new be,xv=new be;class el extends Bi{get rollAxis(){return this._rollAxis}set rollAxis(e){this._rollAxis=e,this._v3RollAxis.set(e==="X"?1:0,e==="Y"?1:0,e==="Z"?1:0)}_rollAxis;_v3RollAxis;_dstRestQuat;_invDstRestQuat;_invSrcRestQuatMulDstRestQuat;get dependencies(){return new Set([this.source])}constructor(e,t){super(e,t);this._rollAxis="X",this._v3RollAxis=new R(1,0,0),this._dstRestQuat=new be,this._invDstRestQuat=new be,this._invSrcRestQuatMulDstRestQuat=new be}setInitState(){this._dstRestQuat.copy(this.destination.quaternion),ps(this._invDstRestQuat.copy(this._dstRestQuat)),ps(this._invSrcRestQuatMulDstRestQuat.copy(this.source.quaternion)).multiply(this._dstRestQuat)}update(){let e=_v.copy(this._invDstRestQuat).multiply(this.source.quaternion).multiply(this._invSrcRestQuatMulDstRestQuat),t=gv.copy(this._v3RollAxis).applyQuaternion(e),i=xv.setFromUnitVectors(t,this._v3RollAxis).premultiply(this._dstRestQuat).multiply(e);this.destination.quaternion.copy(this._dstRestQuat).slerp(i,this.weight)}}var Mv=new Set(["1.0","1.0-beta"]);class Vi{static EXTENSION_NAME="VRMC_node_constraint";helperRoot;parser;get name(){return Vi.EXTENSION_NAME}constructor(e,t){this.parser=e,this.helperRoot=t?.helperRoot}async afterRoot(e){e.userData.vrmNodeConstraintManager=await this._import(e)}async _import(e){let t=this.parser.json;if(t.extensionsUsed?.indexOf(Vi.EXTENSION_NAME)===-1)return null;let i=new $a,s=await this.parser.getDependencies("node");return s.forEach((r,o)=>{let l=t.nodes[o]?.extensions?.[Vi.EXTENSION_NAME];if(l==null)return;let c=l.specVersion;if(!Mv.has(c)){console.warn(`VRMNodeConstraintLoaderPlugin: Unknown ${Vi.EXTENSION_NAME} specVersion "${c}"`);return}let u=l.constraint;if(u.roll!=null){let h=this._importRollConstraint(r,s,u.roll);i.addConstraint(h)}else if(u.aim!=null){let h=this._importAimConstraint(r,s,u.aim);i.addConstraint(h)}else if(u.rotation!=null){let h=this._importRotationConstraint(r,s,u.rotation);i.addConstraint(h)}}),e.scene.updateMatrixWorld(),i.setInitState(),i}_importRollConstraint(e,t,n){let{source:i,rollAxis:s,weight:r}=n,o=t[i],a=new el(e,o);if(s!=null)a.rollAxis=s;if(r!=null)a.weight=r;if(this.helperRoot){let l=new cr(a);this.helperRoot.add(l)}return a}_importAimConstraint(e,t,n){let{source:i,aimAxis:s,weight:r}=n,o=t[i],a=new Ka(e,o);if(s!=null)a.aimAxis=s;if(r!=null)a.weight=r;if(this.helperRoot){let l=new cr(a);this.helperRoot.add(l)}return a}_importRotationConstraint(e,t,n){let{source:i,weight:s}=n,r=t[i],o=new Qa(e,r);if(s!=null)o.weight=s;if(this.helperRoot){let a=new cr(o);this.helperRoot.add(a)}return o}}class ms{offset}var Vu=new R,gs=new R;class co extends ms{get type(){return"capsule"}offset;tail;radius;inside;constructor(e){super();this.offset=e?.offset??new R(0,0,0),this.tail=e?.tail??new R(0,0,0),this.radius=e?.radius??0,this.inside=e?.inside??!1}calculateCollision(e,t,n,i){Vu.setFromMatrixPosition(e),gs.subVectors(this.tail,this.offset).applyMatrix4(e),gs.sub(Vu);let s=gs.lengthSq();i.copy(t).sub(Vu);let r=gs.dot(i);if(r<=0);else if(s<=r)i.sub(gs);else gs.multiplyScalar(r/s),i.sub(gs);let o=i.length(),a=this.inside?this.radius-n-o:o-n-this.radius;if(a<0){if(i.multiplyScalar(1/o),this.inside)i.negate()}return a}}var ku=new R,Yp=new Pe;class uo extends ms{get type(){return"plane"}offset;normal;constructor(e){super();this.offset=e?.offset??new R(0,0,0),this.normal=e?.normal??new R(0,0,1)}calculateCollision(e,t,n,i){i.setFromMatrixPosition(e),i.negate().add(t),Yp.getNormalMatrix(e),ku.copy(this.normal).applyNormalMatrix(Yp).normalize();let s=i.dot(ku)-n;return i.copy(ku),s}}var yv=new R;class ho extends ms{get type(){return"sphere"}offset;radius;inside;constructor(e){super();this.offset=e?.offset??new R(0,0,0),this.radius=e?.radius??0,this.inside=e?.inside??!1}calculateCollision(e,t,n,i){i.subVectors(t,yv.setFromMatrixPosition(e));let s=i.length(),r=this.inside?this.radius-n-s:s-n-this.radius;if(r<0){if(i.multiplyScalar(1/s),this.inside)i.negate()}return r}}var jn=new R;class Gu extends Qe{worldScale=1;_attrPos;_attrIndex;_shape;_currentRadius=0;_currentOffset=new R;_currentTail=new R;constructor(e){super();this._shape=e,this._attrPos=new Ge(new Float32Array(396),3),this.setAttribute("position",this._attrPos),this._attrIndex=new Ge(new Uint16Array(264),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let e=!1,t=this._shape.radius/this.worldScale;if(this._currentRadius!==t)this._currentRadius=t,e=!0;if(!this._currentOffset.equals(this._shape.offset))this._currentOffset.copy(this._shape.offset),e=!0;let n=jn.copy(this._shape.tail).divideScalar(this.worldScale);if(this._currentTail.distanceToSquared(n)>0.0000000001)this._currentTail.copy(n),e=!0;if(e)this._buildPosition()}_buildPosition(){jn.copy(this._currentTail).sub(this._currentOffset);let e=jn.length()/this._currentRadius;for(let i=0;i<=16;i++){let s=i/16*Math.PI;this._attrPos.setXYZ(i,-Math.sin(s),-Math.cos(s),0),this._attrPos.setXYZ(17+i,e+Math.sin(s),Math.cos(s),0),this._attrPos.setXYZ(34+i,-Math.sin(s),0,-Math.cos(s)),this._attrPos.setXYZ(51+i,e+Math.sin(s),0,Math.cos(s))}for(let i=0;i<32;i++){let s=i/16*Math.PI;this._attrPos.setXYZ(68+i,0,Math.sin(s),Math.cos(s)),this._attrPos.setXYZ(100+i,e,Math.sin(s),Math.cos(s))}let t=Math.atan2(jn.y,Math.sqrt(jn.x*jn.x+jn.z*jn.z)),n=-Math.atan2(jn.z,jn.x);this.rotateZ(t),this.rotateY(n),this.scale(this._currentRadius,this._currentRadius,this._currentRadius),this.translate(this._currentOffset.x,this._currentOffset.y,this._currentOffset.z),this._attrPos.needsUpdate=!0}_buildIndex(){for(let e=0;e<34;e++){let t=(e+1)%34;this._attrIndex.setXY(e*2,e,t),this._attrIndex.setXY(68+e*2,34+e,34+t)}for(let e=0;e<32;e++){let t=(e+1)%32;this._attrIndex.setXY(136+e*2,68+e,68+t),this._attrIndex.setXY(200+e*2,100+e,100+t)}this._attrIndex.needsUpdate=!0}}class zu extends Qe{worldScale=1;_attrPos;_attrIndex;_shape;_currentOffset=new R;_currentNormal=new R;constructor(e){super();this._shape=e,this._attrPos=new Ge(new Float32Array(18),3),this.setAttribute("position",this._attrPos),this._attrIndex=new Ge(new Uint16Array(10),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let e=!1;if(!this._currentOffset.equals(this._shape.offset))this._currentOffset.copy(this._shape.offset),e=!0;if(!this._currentNormal.equals(this._shape.normal))this._currentNormal.copy(this._shape.normal),e=!0;if(e)this._buildPosition()}_buildPosition(){this._attrPos.setXYZ(0,-0.5,-0.5,0),this._attrPos.setXYZ(1,0.5,-0.5,0),this._attrPos.setXYZ(2,0.5,0.5,0),this._attrPos.setXYZ(3,-0.5,0.5,0),this._attrPos.setXYZ(4,0,0,0),this._attrPos.setXYZ(5,0,0,0.25),this.translate(this._currentOffset.x,this._currentOffset.y,this._currentOffset.z),this.lookAt(this._currentNormal),this._attrPos.needsUpdate=!0}_buildIndex(){this._attrIndex.setXY(0,0,1),this._attrIndex.setXY(2,1,2),this._attrIndex.setXY(4,2,3),this._attrIndex.setXY(6,3,0),this._attrIndex.setXY(8,4,5),this._attrIndex.needsUpdate=!0}}class Wu extends Qe{worldScale=1;_attrPos;_attrIndex;_shape;_currentRadius=0;_currentOffset=new R;constructor(e){super();this._shape=e,this._attrPos=new Ge(new Float32Array(288),3),this.setAttribute("position",this._attrPos),this._attrIndex=new Ge(new Uint16Array(192),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let e=!1,t=this._shape.radius/this.worldScale;if(this._currentRadius!==t)this._currentRadius=t,e=!0;if(!this._currentOffset.equals(this._shape.offset))this._currentOffset.copy(this._shape.offset),e=!0;if(e)this._buildPosition()}_buildPosition(){for(let e=0;e<32;e++){let t=e/16*Math.PI;this._attrPos.setXYZ(e,Math.cos(t),Math.sin(t),0),this._attrPos.setXYZ(32+e,0,Math.cos(t),Math.sin(t)),this._attrPos.setXYZ(64+e,Math.sin(t),0,Math.cos(t))}this.scale(this._currentRadius,this._currentRadius,this._currentRadius),this.translate(this._currentOffset.x,this._currentOffset.y,this._currentOffset.z),this._attrPos.needsUpdate=!0}_buildIndex(){for(let e=0;e<32;e++){let t=(e+1)%32;this._attrIndex.setXY(e*2,e,t),this._attrIndex.setXY(64+e*2,32+e,32+t),this._attrIndex.setXY(128+e*2,64+e,64+t)}this._attrIndex.needsUpdate=!0}}var vv=new R;class ur extends yt{collider;_geometry;_line;constructor(e){super();if(this.matrixAutoUpdate=!1,this.collider=e,this.collider.shape instanceof ho)this._geometry=new Wu(this.collider.shape);else if(this.collider.shape instanceof co)this._geometry=new Gu(this.collider.shape);else if(this.collider.shape instanceof uo)this._geometry=new zu(this.collider.shape);else throw Error("VRMSpringBoneColliderHelper: Unknown collider shape type detected");let t=new an({color:16711935,depthTest:!1,depthWrite:!1});this._line=new Un(this._geometry,t),this.add(this._line)}dispose(){this._geometry.dispose()}updateMatrixWorld(e){this.collider.updateWorldMatrix(!0,!1),this.matrix.copy(this.collider.matrixWorld);let t=this.matrix.elements;this._geometry.worldScale=vv.set(t[0],t[1],t[2]).length(),this._geometry.update(),super.updateMatrixWorld(e)}}class Xu extends Qe{worldScale=1;_attrPos;_attrIndex;_springBone;_currentRadius=0;_currentTail=new R;constructor(e){super();this._springBone=e,this._attrPos=new Ge(new Float32Array(294),3),this.setAttribute("position",this._attrPos),this._attrIndex=new Ge(new Uint16Array(194),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let e=!1,t=this._springBone.settings.hitRadius/this.worldScale;if(this._currentRadius!==t)this._currentRadius=t,e=!0;if(!this._currentTail.equals(this._springBone.initialLocalChildPosition))this._currentTail.copy(this._springBone.initialLocalChildPosition),e=!0;if(e)this._buildPosition()}_buildPosition(){for(let e=0;e<32;e++){let t=e/16*Math.PI;this._attrPos.setXYZ(e,Math.cos(t),Math.sin(t),0),this._attrPos.setXYZ(32+e,0,Math.cos(t),Math.sin(t)),this._attrPos.setXYZ(64+e,Math.sin(t),0,Math.cos(t))}this.scale(this._currentRadius,this._currentRadius,this._currentRadius),this.translate(this._currentTail.x,this._currentTail.y,this._currentTail.z),this._attrPos.setXYZ(96,0,0,0),this._attrPos.setXYZ(97,this._currentTail.x,this._currentTail.y,this._currentTail.z),this._attrPos.needsUpdate=!0}_buildIndex(){for(let e=0;e<32;e++){let t=(e+1)%32;this._attrIndex.setXY(e*2,e,t),this._attrIndex.setXY(64+e*2,32+e,32+t),this._attrIndex.setXY(128+e*2,64+e,64+t)}this._attrIndex.setXY(192,96,97),this._attrIndex.needsUpdate=!0}}var Ev=new R;class tl extends yt{springBone;_geometry;_line;constructor(e){super();this.matrixAutoUpdate=!1,this.springBone=e,this._geometry=new Xu(this.springBone);let t=new an({color:16776960,depthTest:!1,depthWrite:!1});this._line=new Un(this._geometry,t),this.add(this._line)}dispose(){this._geometry.dispose()}updateMatrixWorld(e){this.springBone.bone.updateWorldMatrix(!0,!1),this.matrix.copy(this.springBone.bone.matrixWorld);let t=this.matrix.elements;this._geometry.worldScale=Ev.set(t[0],t[1],t[2]).length(),this._geometry.update(),super.updateMatrixWorld(e)}}class fo extends tt{shape;colliderMatrix=new Re;constructor(e){super();this.shape=e}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),Tv(this.colliderMatrix,this.matrixWorld,this.shape.offset)}}function Tv(e,t,n){let i=t.elements;if(e.copy(t),n)e.elements[12]=i[0]*n.x+i[4]*n.y+i[8]*n.z+i[12],e.elements[13]=i[1]*n.x+i[5]*n.y+i[9]*n.z+i[13],e.elements[14]=i[2]*n.x+i[6]*n.y+i[10]*n.z+i[14]}var Sv=new Re;function Zp(e){if(e.invert)e.invert();else e.getInverse(Sv.copy(e));return e}class qu{matrix;_inverseCache=new Re;_shouldUpdateInverse=!0;_originalElements;get inverse(){if(this._shouldUpdateInverse)Zp(this._inverseCache.copy(this.matrix)),this._shouldUpdateInverse=!1;return this._inverseCache}constructor(e){this.matrix=e;let t={set:(n,i,s)=>(this._shouldUpdateInverse=!0,n[i]=s,!0)};this._originalElements=e.elements,e.elements=new Proxy(e.elements,t)}revert(){this.matrix.elements=this._originalElements}}var Yu=new Re,hr=new R,po=new R,mo=new R,go=new R,bv=new Re;class Zu{settings;colliderGroups;bone;child;_currentTail=new R;_prevTail=new R;_boneAxis=new R;_worldSpaceBoneLength=0;get dependencies(){let e=new Set,t=this.bone.parent;if(t)e.add(t);for(let n=0;n<this.colliderGroups.length;n++)for(let i=0;i<this.colliderGroups[n].colliders.length;i++)e.add(this.colliderGroups[n].colliders[i]);return e}_center=null;get center(){return this._center}set center(e){if(this._center?.userData.inverseCacheProxy)this._center.userData.inverseCacheProxy.revert(),delete this._center.userData.inverseCacheProxy;if(this._center=e,this._center){if(!this._center.userData.inverseCacheProxy)this._center.userData.inverseCacheProxy=new qu(this._center.matrixWorld)}}_initialLocalMatrix=new Re;_initialLocalRotation=new be;_initialLocalChildPosition=new R;get initialLocalChildPosition(){return this._initialLocalChildPosition}get _parentMatrixWorld(){return this.bone.parent?this.bone.parent.matrixWorld:Yu}constructor(e,t,n={},i=[]){this.bone=e,this.bone.matrixAutoUpdate=!1,this.child=t,this.settings={hitRadius:n.hitRadius??0,stiffness:n.stiffness??1,gravityPower:n.gravityPower??0,gravityDir:n.gravityDir?.clone()??new R(0,-1,0),dragForce:n.dragForce??0.4},this.colliderGroups=i}setInitState(){if(this._initialLocalMatrix.copy(this.bone.matrix),this._initialLocalRotation.copy(this.bone.quaternion),this.child)this._initialLocalChildPosition.copy(this.child.position);else this._initialLocalChildPosition.copy(this.bone.position).normalize().multiplyScalar(0.07);let e=this._getMatrixWorldToCenter();this.bone.localToWorld(this._currentTail.copy(this._initialLocalChildPosition)).applyMatrix4(e),this._prevTail.copy(this._currentTail),this._boneAxis.copy(this._initialLocalChildPosition).normalize()}reset(){this.bone.quaternion.copy(this._initialLocalRotation),this.bone.updateMatrix(),this.bone.matrixWorld.multiplyMatrices(this._parentMatrixWorld,this.bone.matrix);let e=this._getMatrixWorldToCenter();this.bone.localToWorld(this._currentTail.copy(this._initialLocalChildPosition)).applyMatrix4(e),this._prevTail.copy(this._currentTail)}update(e){if(e<=0)return;this._calcWorldSpaceBoneLength();let t=po.copy(this._boneAxis).transformDirection(this._initialLocalMatrix).transformDirection(this._parentMatrixWorld);go.copy(this._currentTail).add(hr.subVectors(this._currentTail,this._prevTail).multiplyScalar(1-this.settings.dragForce)).applyMatrix4(this._getMatrixCenterToWorld()).addScaledVector(t,this.settings.stiffness*e).addScaledVector(this.settings.gravityDir,this.settings.gravityPower*e),mo.setFromMatrixPosition(this.bone.matrixWorld),go.sub(mo).normalize().multiplyScalar(this._worldSpaceBoneLength).add(mo),this._collision(go),this._prevTail.copy(this._currentTail),this._currentTail.copy(go).applyMatrix4(this._getMatrixWorldToCenter());let n=bv.multiplyMatrices(this._parentMatrixWorld,this._initialLocalMatrix).invert();this.bone.quaternion.setFromUnitVectors(this._boneAxis,hr.copy(go).applyMatrix4(n).normalize()).premultiply(this._initialLocalRotation),this.bone.updateMatrix(),this.bone.matrixWorld.multiplyMatrices(this._parentMatrixWorld,this.bone.matrix)}_collision(e){for(let t=0;t<this.colliderGroups.length;t++)for(let n=0;n<this.colliderGroups[t].colliders.length;n++){let i=this.colliderGroups[t].colliders[n],s=i.shape.calculateCollision(i.colliderMatrix,e,this.settings.hitRadius,hr);if(s<0){e.addScaledVector(hr,-s),e.sub(mo);let r=e.length();e.multiplyScalar(this._worldSpaceBoneLength/r).add(mo)}}}_calcWorldSpaceBoneLength(){if(hr.setFromMatrixPosition(this.bone.matrixWorld),this.child)po.setFromMatrixPosition(this.child.matrixWorld);else po.copy(this._initialLocalChildPosition),po.applyMatrix4(this.bone.matrixWorld);this._worldSpaceBoneLength=hr.sub(po).length()}_getMatrixCenterToWorld(){return this._center?this._center.matrixWorld:Yu}_getMatrixWorldToCenter(){return this._center?this._center.userData.inverseCacheProxy.inverse:Yu}}function jp(e,t){let n=[],i=e;while(i!==null)n.unshift(i),i=i.parent;n.forEach((s)=>{t(s)})}function nl(e,t){e.children.forEach((n)=>{if(!t(n))nl(n,t)})}function Jp(e){let t=new Map;for(let n of e){let i=n;do{let s=(t.get(i)??0)+1;if(s===e.size)return i;t.set(i,s),i=i.parent}while(i!==null)}return null}class il{_joints=new Set;_sortedJoints=[];_hasWarnedCircularDependency=!1;_ancestors=[];get joints(){return this._joints}get springBones(){return console.warn("VRMSpringBoneManager: springBones is deprecated. use joints instead."),this._joints}get colliderGroups(){let e=new Set;return this._joints.forEach((t)=>{t.colliderGroups.forEach((n)=>{e.add(n)})}),Array.from(e)}get colliders(){let e=new Set;return this.colliderGroups.forEach((t)=>{t.colliders.forEach((n)=>{e.add(n)})}),Array.from(e)}_objectSpringBonesMap=new Map;_isSortedJointsDirty=!1;constructor(){this._relevantChildrenUpdated=this._relevantChildrenUpdated.bind(this)}addJoint(e){this._joints.add(e);let t=this._objectSpringBonesMap.get(e.bone);if(t==null)t=new Set,this._objectSpringBonesMap.set(e.bone,t);t.add(e),this._isSortedJointsDirty=!0}addSpringBone(e){console.warn("VRMSpringBoneManager: addSpringBone() is deprecated. use addJoint() instead."),this.addJoint(e)}deleteJoint(e){this._joints.delete(e),this._objectSpringBonesMap.get(e.bone).delete(e),this._isSortedJointsDirty=!0}deleteSpringBone(e){console.warn("VRMSpringBoneManager: deleteSpringBone() is deprecated. use deleteJoint() instead."),this.deleteJoint(e)}setInitState(){this._sortJoints();for(let e=0;e<this._sortedJoints.length;e++){let t=this._sortedJoints[e];t.bone.updateMatrix(),t.bone.updateWorldMatrix(!1,!1),t.setInitState()}}reset(){this._sortJoints();for(let e=0;e<this._sortedJoints.length;e++){let t=this._sortedJoints[e];t.bone.updateMatrix(),t.bone.updateWorldMatrix(!1,!1),t.reset()}}update(e){this._sortJoints();for(let t=0;t<this._ancestors.length;t++)this._ancestors[t].updateWorldMatrix(t===0,!1);for(let t=0;t<this._sortedJoints.length;t++){let n=this._sortedJoints[t];n.bone.updateMatrix(),n.bone.updateWorldMatrix(!1,!1),n.update(e),nl(n.bone,this._relevantChildrenUpdated)}}_sortJoints(){if(!this._isSortedJointsDirty)return;let e=[],t=new Set,n=new Set,i=new Set;for(let r of this._joints)this._insertJointSort(r,t,n,e,i);this._sortedJoints=e;let s=Jp(i);if(this._ancestors=[],s)this._ancestors.push(s),nl(s,(r)=>{if((this._objectSpringBonesMap.get(r)?.size??0)>0)return!0;return this._ancestors.push(r),!1});this._isSortedJointsDirty=!1}_insertJointSort(e,t,n,i,s){if(n.has(e))return;if(t.has(e)){if(!this._hasWarnedCircularDependency)console.warn("VRMSpringBoneManager: Circular dependency detected"),this._hasWarnedCircularDependency=!0;return}t.add(e);let r=e.dependencies;for(let o of r){let a=!1,l=null;if(jp(o,(c)=>{let u=this._objectSpringBonesMap.get(c);if(u)for(let h of u)a=!0,this._insertJointSort(h,t,n,i,s);else if(!a)l=c}),l)s.add(l)}i.push(e),n.add(e)}_relevantChildrenUpdated(e){if((this._objectSpringBonesMap.get(e)?.size??0)>0)return!0;return e.updateWorldMatrix(!1,!1),!1}}var Kp="VRMC_springBone_extended_collider",Rv=new Set(["1.0","1.0-beta"]),Av=new Set(["1.0"]);class ki{static EXTENSION_NAME="VRMC_springBone";jointHelperRoot;colliderHelperRoot;useExtendedColliders;parser;get name(){return ki.EXTENSION_NAME}constructor(e,t){this.parser=e,this.jointHelperRoot=t?.jointHelperRoot,this.colliderHelperRoot=t?.colliderHelperRoot,this.useExtendedColliders=t?.useExtendedColliders??!0}async afterRoot(e){e.userData.vrmSpringBoneManager=await this._import(e)}async _import(e){let t=await this._v1Import(e);if(t!=null)return t;let n=await this._v0Import(e);if(n!=null)return n;return null}async _v1Import(e){let t=e.parser.json;if(t.extensionsUsed?.indexOf(ki.EXTENSION_NAME)===-1)return null;let i=new il,s=await e.parser.getDependencies("node"),r=t.extensions?.[ki.EXTENSION_NAME];if(!r)return null;let o=r.specVersion;if(!Rv.has(o))return console.warn(`VRMSpringBoneLoaderPlugin: Unknown ${ki.EXTENSION_NAME} specVersion "${o}"`),null;let a=r.colliders?.map((c,u)=>{let h=s[c.node];if(h==null)return console.warn(`VRMSpringBoneLoaderPlugin: The collider #${u} attempted to reference a node #${c.node} but not found. Skipping the collider`),null;let d=c.shape,f=c.extensions?.[Kp];if(this.useExtendedColliders&&f!=null){let m=f.specVersion;if(!Av.has(m))console.warn(`VRMSpringBoneLoaderPlugin: Unknown ${Kp} specVersion "${m}". Fallbacking to the ${ki.EXTENSION_NAME} definition`);else{let x=f.shape;if(x.sphere)return this._importSphereCollider(h,{offset:new R().fromArray(x.sphere.offset??[0,0,0]),radius:x.sphere.radius??0,inside:x.sphere.inside??!1});else if(x.capsule)return this._importCapsuleCollider(h,{offset:new R().fromArray(x.capsule.offset??[0,0,0]),radius:x.capsule.radius??0,tail:new R().fromArray(x.capsule.tail??[0,0,0]),inside:x.capsule.inside??!1});else if(x.plane)return this._importPlaneCollider(h,{offset:new R().fromArray(x.plane.offset??[0,0,0]),normal:new R().fromArray(x.plane.normal??[0,0,1])})}}if(d.sphere)return this._importSphereCollider(h,{offset:new R().fromArray(d.sphere.offset??[0,0,0]),radius:d.sphere.radius??0,inside:!1});else if(d.capsule)return this._importCapsuleCollider(h,{offset:new R().fromArray(d.capsule.offset??[0,0,0]),radius:d.capsule.radius??0,tail:new R().fromArray(d.capsule.tail??[0,0,0]),inside:!1});console.warn(`VRMSpringBoneLoaderPlugin: The collider #${u} has no valid shape. Skipping the collider`)}),l=r.colliderGroups?.map((c,u)=>({colliders:(c.colliders??[]).map((d)=>{let f=a?.[d];if(f==null)return console.warn(`VRMSpringBoneLoaderPlugin: The collider group #${u} attempted to reference a collider #${d} but not found. Skipping the collider`),null;return f}).filter((d)=>d!=null),name:c.name}));return r.springs?.forEach((c,u)=>{let h=c.joints;if(h==null){console.warn(`VRMSpringBoneLoaderPlugin: The spring #${u} has no joints. Skipping the spring`);return}let d=c.colliderGroups?.map((x)=>{let p=l?.[x];if(p==null)return console.warn(`VRMSpringBoneLoaderPlugin: The spring #${u} attempted to reference a collider group #${x} but not found. Skipping the collider group`),null;return p}).filter((x)=>x!=null),f=c.center!=null?s[c.center]:void 0,m;h.forEach((x)=>{if(m){let p=m.node,g=s[p],v=x.node,S=s[v],T={hitRadius:m.hitRadius,dragForce:m.dragForce,gravityPower:m.gravityPower,stiffness:m.stiffness,gravityDir:m.gravityDir!=null?new R().fromArray(m.gravityDir):void 0},A=this._importJoint(g,S,T,d);if(f)A.center=f;i.addJoint(A)}m=x})}),i.setInitState(),i}async _v0Import(e){let t=e.parser.json;if(t.extensionsUsed?.indexOf("VRM")===-1)return null;let s=t.extensions?.VRM?.secondaryAnimation;if(!s)return null;let r=s?.boneGroups;if(!r)return null;let o=new il,a=await e.parser.getDependencies("node"),l=s.colliderGroups?.map((c,u)=>{let h=a[c.node];if(h==null)return console.warn(`VRMSpringBoneLoaderPlugin: The collider group #${u} attempted to reference a node #${c.node} but not found. Skipping the collider group`),null;return{colliders:(c.colliders??[]).map((f,m)=>{let x=new R(0,0,0);if(f.offset)x.set(f.offset.x??0,f.offset.y??0,f.offset.z?-f.offset.z:0);return this._importSphereCollider(h,{offset:x,radius:f.radius??0,inside:!1})})}});return r?.forEach((c,u)=>{let h=c.bones;if(!h)return;h.forEach((d)=>{let f=a[d];if(f==null){console.warn(`VRMSpringBoneLoaderPlugin: The spring bone group #${u} attempted to reference a node #${d} but not found. Skipping the node`);return}let m=new R;if(c.gravityDir)m.set(c.gravityDir.x??0,c.gravityDir.y??0,c.gravityDir.z??0);else m.set(0,-1,0);let x=c.center!=null?a[c.center]:void 0,p={hitRadius:c.hitRadius,dragForce:c.dragForce,gravityPower:c.gravityPower,stiffness:c.stiffiness,gravityDir:m},g=c.colliderGroups?.map((v)=>{let S=l?.[v];if(S==null)return console.warn(`VRMSpringBoneLoaderPlugin: The spring #${u} attempted to reference a collider group #${v} but not found. Skipping the collider group`),null;return S}).filter((v)=>v!=null);f.traverse((v)=>{let S=v.children[0]??null,T=this._importJoint(v,S,p,g);if(x)T.center=x;o.addJoint(T)})})}),e.scene.updateMatrixWorld(),o.setInitState(),o}_importJoint(e,t,n,i){let s=new Zu(e,t,n,i);if(this.jointHelperRoot){let r=new tl(s);this.jointHelperRoot.add(r),r.renderOrder=this.jointHelperRoot.renderOrder}return s}_importSphereCollider(e,t){let n=new ho(t),i=new fo(n);if(e.add(i),this.colliderHelperRoot){let s=new ur(i);this.colliderHelperRoot.add(s),s.renderOrder=this.colliderHelperRoot.renderOrder}return i}_importCapsuleCollider(e,t){let n=new co(t),i=new fo(n);if(e.add(i),this.colliderHelperRoot){let s=new ur(i);this.colliderHelperRoot.add(s),s.renderOrder=this.colliderHelperRoot.renderOrder}return i}_importPlaneCollider(e,t){let n=new uo(t),i=new fo(n);if(e.add(i),this.colliderHelperRoot){let s=new ur(i);this.colliderHelperRoot.add(s),s.renderOrder=this.colliderHelperRoot.renderOrder}return i}}class sl{parser;expressionPlugin;firstPersonPlugin;humanoidPlugin;lookAtPlugin;metaPlugin;mtoonMaterialPlugin;materialsHDREmissiveMultiplierPlugin;materialsV0CompatPlugin;springBonePlugin;nodeConstraintPlugin;get name(){return"VRMLoaderPlugin"}constructor(e,t){this.parser=e;let n=t?.helperRoot,i=t?.autoUpdateHumanBones;this.expressionPlugin=t?.expressionPlugin??new nr(e),this.firstPersonPlugin=t?.firstPersonPlugin??new Jr(e),this.humanoidPlugin=t?.humanoidPlugin??new eo(e,{helperRoot:n,autoUpdateHumanBones:i}),this.lookAtPlugin=t?.lookAtPlugin??new oo(e,{helperRoot:n}),this.metaPlugin=t?.metaPlugin??new ao(e),this.mtoonMaterialPlugin=t?.mtoonMaterialPlugin??new ds(e),this.materialsHDREmissiveMultiplierPlugin=t?.materialsHDREmissiveMultiplierPlugin??new lr(e),this.materialsV0CompatPlugin=t?.materialsV0CompatPlugin??new Ja(e),this.springBonePlugin=t?.springBonePlugin??new ki(e,{colliderHelperRoot:n,jointHelperRoot:n}),this.nodeConstraintPlugin=t?.nodeConstraintPlugin??new Vi(e,{helperRoot:n})}async beforeRoot(){await this.materialsV0CompatPlugin.beforeRoot(),await this.mtoonMaterialPlugin.beforeRoot()}async loadMesh(e){return await this.mtoonMaterialPlugin.loadMesh(e)}getMaterialType(e){let t=this.mtoonMaterialPlugin.getMaterialType(e);if(t!=null)return t;return null}async extendMaterialParams(e,t){await this.materialsHDREmissiveMultiplierPlugin.extendMaterialParams(e,t),await this.mtoonMaterialPlugin.extendMaterialParams(e,t)}async afterRoot(e){await this.metaPlugin.afterRoot(e),await this.humanoidPlugin.afterRoot(e),await this.expressionPlugin.afterRoot(e),await this.lookAtPlugin.afterRoot(e),await this.firstPersonPlugin.afterRoot(e),await this.springBonePlugin.afterRoot(e),await this.nodeConstraintPlugin.afterRoot(e),await this.mtoonMaterialPlugin.afterRoot(e);let t=e.userData.vrmMeta,n=e.userData.vrmHumanoid;if(t&&n){let i=new qa({scene:e.scene,expressionManager:e.userData.vrmExpressionManager,firstPerson:e.userData.vrmFirstPerson,humanoid:n,lookAt:e.userData.vrmLookAt,meta:t,materials:e.userData.vrmMToonMaterials,springBoneManager:e.userData.vrmSpringBoneManager,nodeConstraintManager:e.userData.vrmNodeConstraintManager});e.userData.vrm=i}}}function wv(e){let t=new Set;return e.traverse((n)=>{if(!n.isMesh)return;let i=n;t.add(i)}),t}function $p(e,t,n){if(t.size===1){let o=t.values().next().value;if(o.weight===1)return e[o.index]}let i=new Float32Array(e[0].count*3),s=0;if(n)s=1;else for(let o of t)s+=o.weight;for(let o of t){let a=e[o.index],l=o.weight/s;for(let c=0;c<a.count;c++)i[c*3+0]+=a.getX(c)*l,i[c*3+1]+=a.getY(c)*l,i[c*3+2]+=a.getZ(c)*l}return new Ge(i,3)}function Qp(e){let t=wv(e.scene),n=new Map,i=e.expressionManager?.expressionMap;if(i!=null)for(let[s,r]of Object.entries(i)){let o=new Set;for(let a of r.binds)if(a instanceof Fi){if(a.weight!==0)for(let l of a.primitives){let c=n.get(l);if(c==null)c=new Map,n.set(l,c);let u=c.get(s);if(u==null)u=new Set,c.set(s,u);u.add(a)}o.add(a)}for(let a of o)r.deleteBind(a)}for(let s of t){let r=n.get(s);if(r==null)continue;let o=s.geometry.morphAttributes;s.geometry.morphAttributes={};let a=s.geometry.clone();s.geometry=a;let l=a.morphTargetsRelative,c=o.position!=null,u=o.normal!=null,h={},d={},f=[];if(c||u){if(c)h.position=[];if(u)h.normal=[];let m=0;for(let[x,p]of r){if(c)h.position[m]=$p(o.position,p,l);if(u)h.normal[m]=$p(o.normal,p,l);i?.[x].addBind(new Fi({index:m,weight:1,primitives:[s]})),d[x]=m,f.push(0),m++}}a.morphAttributes=h,s.morphTargetDictionary=d,s.morphTargetInfluences=f}}function dr(e,t,n){if(e.getComponent)return e.getComponent(t,n);else{let i=e.array[t*e.itemSize+n];if(e.normalized)i=$e.denormalize(i,e.array);return i}}function rl(e,t,n,i){if(e.setComponent)e.setComponent(t,n,i);else{if(e.normalized)i=$e.normalize(i,e.array);e.array[t*e.itemSize+n]=i}}function em(e){let t=Cv(e),n=new Set;for(let u of t){if(n.has(u.geometry))u.geometry=Uv(u.geometry);n.add(u.geometry)}let i=new Map;for(let u of n){let h=u.getAttribute("skinIndex"),d=i.get(h)??new Map;i.set(h,d);let f=u.getAttribute("skinWeight"),m=Pv(h,f);d.set(f,m)}let s=new Map;for(let u of t){let h=Lv(u,i);s.set(u,h)}let r=[];for(let[u,h]of s){let d=!1;for(let f of r)if(Iv(h,f.boneInverseMap)){d=!0,f.meshes.add(u);for(let[x,p]of h)f.boneInverseMap.set(x,p);break}if(!d)r.push({boneInverseMap:h,meshes:new Set([u])})}let o=new Map,a=new ol,l=new ol,c=new ol;for(let u of r){let{boneInverseMap:h,meshes:d}=u,f=Array.from(h.keys()),m=Array.from(h.values()),x=new Dn(f,m),p=l.getOrCreate(x);for(let g of d){let v=g.geometry.getAttribute("skinIndex"),S=a.getOrCreate(v),T=g.skeleton.bones,A=T.map((E)=>c.getOrCreate(E)).join(","),w=`${S};${p};${A}`,_=o.get(w);if(_==null)_=v.clone(),Nv(_,T,f),o.set(w,_);g.geometry.setAttribute("skinIndex",_)}for(let g of d)g.bind(x,new Re)}}function Cv(e){let t=new Set;return e.traverse((n)=>{if(!n.isSkinnedMesh)return;let i=n;t.add(i)}),t}function Pv(e,t){let n=new Set;for(let i=0;i<e.count;i++)for(let s=0;s<e.itemSize;s++){let r=dr(e,i,s);if(dr(t,i,s)!==0)n.add(r)}return n}function Lv(e,t){let n=new Map,{skeleton:i,geometry:s}=e,r=s.getAttribute("skinIndex"),o=s.getAttribute("skinWeight"),l=t.get(r)?.get(o);if(!l)throw Error("Unreachable. attributeUsedIndexSetMap does not know the skin index attribute or the skin weight attribute.");for(let c of l)n.set(i.bones[c],i.boneInverses[c]);return n}function Iv(e,t){for(let[n,i]of e.entries()){let s=t.get(n);if(s!=null){if(!Dv(i,s))return!1}}return!0}function Nv(e,t,n){let i=new Map;for(let r of t)i.set(r,i.size);let s=new Map;for(let[r,o]of n.entries()){let a=i.get(o);s.set(a,r)}for(let r=0;r<e.count;r++)for(let o=0;o<e.itemSize;o++){let a=dr(e,r,o),l=s.get(a);rl(e,r,o,l)}e.needsUpdate=!0}function Dv(e,t,n){if(n=n||0.0001,e.elements.length!=t.elements.length)return!1;for(let i=0,s=e.elements.length;i<s;i++)if(Math.abs(e.elements[i]-t.elements[i])>n)return!1;return!0}class ol{_objectIndexMap=new Map;_index=0;get(e){return this._objectIndexMap.get(e)}getOrCreate(e){let t=this._objectIndexMap.get(e);if(t==null)t=this._index,this._objectIndexMap.set(e,t),this._index++;return t}}function Uv(e){let t=new Qe;t.name=e.name,t.setIndex(e.index);for(let[n,i]of Object.entries(e.attributes))t.setAttribute(n,i);for(let[n,i]of Object.entries(e.morphAttributes)){let s=n;t.morphAttributes[s]=i.concat()}t.morphTargetsRelative=e.morphTargetsRelative,t.groups=[];for(let n of e.groups)t.addGroup(n.start,n.count,n.materialIndex);return t.boundingSphere=e.boundingSphere?.clone()??null,t.boundingBox=e.boundingBox?.clone()??null,t.drawRange.start=e.drawRange.start,t.drawRange.count=e.drawRange.count,t.userData=e.userData,t}function tm(e){if(Object.values(e).forEach((t)=>{if(t?.isTexture)t.dispose()}),e.isShaderMaterial){let t=e.uniforms;if(t)Object.values(t).forEach((n)=>{let i=n.value;if(i?.isTexture)i.dispose()})}e.dispose()}function Ov(e){let t=e.geometry;if(t)t.dispose();let n=e.skeleton;if(n)n.dispose();let i=e.material;if(i){if(Array.isArray(i))i.forEach((s)=>tm(s));else if(i)tm(i)}}function nm(e){e.traverse(Ov)}function im(e,t){console.warn("VRMUtils.removeUnnecessaryJoints: removeUnnecessaryJoints is deprecated. Use combineSkeletons instead. combineSkeletons contributes more to the performance improvement. This function will be removed in the next major version.");let n=t?.experimentalSameBoneCounts??!1,i=[];e.traverse((o)=>{if(o.type!=="SkinnedMesh")return;i.push(o)});let s=new Map,r=0;for(let o of i){let l=o.geometry.getAttribute("skinIndex");if(s.has(l))continue;let c=new Map,u=new Map;for(let h=0;h<l.count;h++)for(let d=0;d<l.itemSize;d++){let f=dr(l,h,d),m=c.get(f);if(m==null)m=c.size,c.set(f,m),u.set(m,f);rl(l,h,d,m)}l.needsUpdate=!0,s.set(l,u),r=Math.max(r,c.size)}for(let o of i){let l=o.geometry.getAttribute("skinIndex"),c=s.get(l),u=[],h=[],d=n?r:c.size;for(let m=0;m<d;m++){let x=c.get(m)??0;u.push(o.skeleton.bones[x]),h.push(o.skeleton.boneInverses[x])}let f=new Dn(u,h);o.bind(f,new Re)}}function Fv(e,t){let n=e.position.count,i=Array(n),s=0,r=t.array;for(let o=0;o<r.length;o++){let a=r[o];if(!i[a])i[a]=!0,s++}return{isVertexUsed:i,vertexCount:n,verticesUsed:s}}function Hv(e){let t=[],n=[],i=0;for(let s=0;s<e.length;s++)if(e[s]){let r=i++;t[s]=r,n[r]=s}return{originalIndexNewIndexMap:t,newIndexOriginalIndexMap:n}}function Bv(e,t){t.name=e.name,t.morphTargetsRelative=e.morphTargetsRelative,e.groups.forEach((n)=>{t.addGroup(n.start,n.count,n.materialIndex)}),t.boundingBox=e.boundingBox?.clone()??null,t.boundingSphere=e.boundingSphere?.clone()??null,t.setDrawRange(e.drawRange.start,e.drawRange.count),t.userData=e.userData}function Vv(e,t,n){let i=t.array,s=new i.constructor(i.length);for(let r=0;r<i.length;r++){let o=i[r];s[r]=n[o]}e.setIndex(new Ge(s,t.itemSize,t.normalized))}function al(e,t,n){let s=new e.constructor(t.length*n),r=!0;for(let o=0;o<t.length;o++){let l=t[o]*n,c=o*n;for(let u=0;u<n;u++){let h=e[l+u];s[c+u]=h,r=r&&h===0}}return[s,r]}function kv(e){let t=new Map,n=[];for(let[i,s]of Object.entries(e))if(s.isInterleavedBufferAttribute){let r=s,o=r.data,a=t.get(o)??[];t.set(o,a),a.push([i,r])}else{let r=s;n.push([i,r])}return[t,n]}function Gv(e,t,n){let[i,s]=kv(t);for(let[r,o]of i){let a=r.array,{stride:l}=r,[c,u]=al(a,n,l),h=new Ai(c,l);h.setUsage(r.usage);for(let[d,f]of o){let{itemSize:m,offset:x,normalized:p}=f,g=new ui(h,m,x,p);e.setAttribute(d,g)}}for(let[r,o]of s){let a=o.array,{itemSize:l,normalized:c}=o,[u,h]=al(a,n,l);e.setAttribute(r,new Ge(u,l,c))}}function zv(e){let t=new Map,n=[];for(let[i,s]of Object.entries(e)){let r=i;for(let o=0;o<s.length;o++){let a=s[o];if(a.isInterleavedBufferAttribute){let l=a,c=l.data,u=t.get(c)??[];t.set(c,u),u.push([r,o,l])}else{let l=a;n.push([r,o,l])}}}return[t,n]}function Wv(e,t,n){let i=!0,[s,r]=zv(t),o={};for(let[a,l]of s){let c=a.array,{stride:u}=a,[h,d]=al(c,n,u);i=i&&d;let f=new Ai(h,u);f.setUsage(a.usage);for(let[m,x,p]of l){let{itemSize:g,offset:v,normalized:S}=p,T=new ui(f,g,v,S);o[m]??=[],o[m][x]=T}}for(let[a,l,c]of r){let u=c,h=u.array,{itemSize:d,normalized:f}=u,[m,x]=al(h,n,d);i=i&&x,o[a]??=[],o[a][l]=new Ge(m,d,f)}e.morphAttributes=i?{}:o}function sm(e){let t=new Map;e.traverse((n)=>{if(!n.isMesh)return;let i=n,s=i.geometry,r=s.index;if(r==null)return;let o=t.get(s);if(o!=null){i.geometry=o;return}let{isVertexUsed:a,vertexCount:l,verticesUsed:c}=Fv(s.attributes,r);if(c===l)return;let{originalIndexNewIndexMap:u,newIndexOriginalIndexMap:h}=Hv(a),d=new Qe;Bv(s,d),t.set(s,d),Vv(d,r,u),Gv(d,s.attributes,h),Wv(d,s.morphAttributes,h),i.geometry=d}),Array.from(t.keys()).forEach((n)=>{n.dispose()})}function rm(e){if(e.meta?.metaVersion==="0")e.scene.rotation.y=Math.PI}class _o{constructor(){}static combineMorphs=Qp;static combineSkeletons=em;static deepDispose=nm;static removeUnnecessaryJoints=im;static removeUnnecessaryVertices=sm;static rotateVRM0=rm}var fr=(e,t=0,n=1)=>Math.min(n,Math.max(t,e)),xo=(e)=>(e=fr(e),e*e*(3-2*e)),Fn=(e,t,n,i)=>e+(t-e)*(1-Math.exp(-n*i)),Tn=(e,t)=>e+Math.random()*(t-e),Xv=["hips","spine","chest","upperChest","neck","head","leftShoulder","rightShoulder","leftUpperArm","rightUpperArm","leftLowerArm","rightLowerArm","leftHand","rightHand","leftUpperLeg","rightUpperLeg","leftLowerLeg","rightLowerLeg","leftFoot","rightFoot","leftToes","rightToes"],qv=["Thumb","Index","Middle","Ring","Little"];class om{speaking=!1;text="";t0=0;gotRange=!1;q=[];synthDone=!1;lastRange=0;rate=1;w={aa:0,ih:0,ou:0,ee:0,oh:0};beat=0;start(e,t){this.speaking=!0,this.text=e,this.t0=performance.now()/1000,this.gotRange=!1,this.q=[],this.synthDone=!1,this.rate=t,this.lastRange=0}stop(){this.speaking=!1,this.q=[]}vowelsOf(e){let t=[];for(let n of e.toLowerCase())if("aiueo".includes(n))t.push(n);else if(n==="y"&&t.length===0&&e.length===1)t.push("i");return t}pushWord(e,t,n){let i=this.vowelsOf(e);if(!i.length)return;let s=n/i.length;i.forEach((r,o)=>this.q.push({v:r,t:t+o*s,d:Math.max(0.07,s*0.95),a:(r==="a"?0.95:r==="o"?0.85:0.65)*Tn(0.8,1.05)}))}range(e,t){let n=performance.now()/1000;if(!this.gotRange)this.gotRange=!0,this.q=[];let i=this.text.slice(e,t),s=fr((0.06*i.length+0.07)/this.rate,0.1,0.7);this.pushWord(i,n,s),this.lastRange=n,this.beat=1}synth(e){if(this.synthDone)return;this.synthDone=!0;let t=e+0.1;for(let n of this.text.matchAll(/\S+/g)){let i=n[0],s=(0.06*i.length+0.07)/this.rate;this.pushWord(i,t,s),t+=s+0.05/this.rate+(/[.,!?]$/.test(i)?0.25:0)}}update(e){let t=performance.now()/1000;if(this.speaking&&!this.gotRange&&t-this.t0>0.45)this.synth(t);let n={aa:0,ih:0,ou:0,ee:0,oh:0};if(this.speaking){this.q=this.q.filter((i)=>t<i.t+i.d+0.1);for(let i of this.q){let s=(t-i.t)/i.d;if(s<0||s>1)continue;let r=Math.sin(Math.PI*s)*i.a,o={a:"aa",i:"ih",u:"ou",e:"ee",o:"oh"}[i.v];n[o]=Math.max(n[o],r)}}for(let i of Object.keys(n)){let s=n[i]>this.w[i];this.w[i]=Fn(this.w[i],n[i],s?38:22,e)}this.beat=Fn(this.beat,0,7,e)}}class ju{vrm;lip=new om;lookTarget=new tt;state="idle";bones={};fingerBones=[];rot=new Map;hipsPos=new R;hipsRest=new R;t=0;blinkT=Tn(1.5,3.5);blinkPhase=-1;doubleBlink=!1;emo={happy:0,sad:0,angry:0,surprised:0,relaxed:0};emoTarget=null;emoUntil=0;gesture=null;talkW=0;listenW=0;thinkW=0;gazeT=0;gaze=new R(0,1.4,2);gazeGoal=new R(0,1.4,2);headYaw=0;headPitch=0;beatSide=1;beatT=0;beatDur=1;beatKind=0;nod=0;lastBeat=0;headY=1.45;fidgetT=Tn(6,10);fid=null;peaceW=0;pokeX=0;pokeY=0;pokeUntil=0;constructor(e){this.vrm=e;for(let i of Xv)this.bones[i]=e.humanoid.getNormalizedBoneNode(i);for(let i of["left","right"]){let s=i==="left"?-1:1;for(let r of qv)for(let o of["Metacarpal","Proximal","Intermediate","Distal"]){let a=e.humanoid.getNormalizedBoneNode(i+r+o);if(a)this.fingerBones.push([a,r+o,s])}}let t=this.bones.hips;this.hipsRest.copy(t.position);let n=this.bones.head;if(n){let i=new R;n.getWorldPosition(i),this.headY=i.y}if(this.lookTarget.position.copy(this.gaze),e.lookAt)e.lookAt.target=this.lookTarget}setState(e){this.state=e}emote(e){let t={neutral:"relaxed",happy:"happy",sad:"sad",surprised:"surprised",angry:"angry",shy:"happy",think:"relaxed",wave:"happy",laugh:"happy",bow:"relaxed",heart:"happy",peace:"happy",dance:"happy",cheer:"happy"};this.emoTarget=t[e],this.emoUntil=this.t+(e==="neutral"?3:7);let n={neutral:0,happy:1.6,sad:2.6,surprised:1.6,angry:2.2,shy:3,think:2.6,wave:2.6,laugh:2.6,bow:2.8,heart:3.2,peace:3.2,dance:9,cheer:3.2};if(n[e]>0)this.gesture={name:e,t0:this.t,dur:n[e]}}speakStart(e,t){this.lip.start(e,t)}speakRange(e,t){this.lip.range(e,t)}speakEnd(){this.lip.stop()}R(e,t=0,n=0,i=0){let s=this.rot.get(e);if(s)s[0]+=t,s[1]+=n,s[2]+=i;else this.rot.set(e,[t,n,i])}apply(e){let t=1-Math.exp(-22*e),n=new Ht(0,0,0,"XYZ"),i=new be;for(let[s,r]of this.rot){let o=this.bones[s];if(!o)continue;n.set(r[0],r[1],r[2]),i.setFromEuler(n),o.quaternion.slerp(i,t)}this.bones.hips.position.copy(this.hipsRest).add(this.hipsPos)}update(e){e=Math.min(e,0.05),this.t+=e;let t=this.t;this.rot.clear(),this.hipsPos.set(0,0,0),this.lip.update(e);let n=this.lip.speaking;this.talkW=Fn(this.talkW,n?1:0,n?4:3,e),this.listenW=Fn(this.listenW,this.state==="listening"?1:0,3,e),this.thinkW=Fn(this.thinkW,this.state==="thinking"?1:0,3,e),this.restPose(t),this.idle(t),this.fingers(t),this.peaceW=0,this.gazeAndHead(t,e),this.listening(t),this.thinking(t),this.talking(t,e),this.gestures(t),this.fidget(t,e),this.apply(e),this.face(t,e),this.vrm.update(e)}A(e,t,n,i){this.R(e>0?"rightUpperArm":"leftUpperArm",-t,0,-e*n),this.R(e>0?"rightLowerArm":"leftLowerArm",0,e*i,0)}restPose(e){for(let t of[-1,1])this.R(t>0?"rightUpperArm":"leftUpperArm",0,0,t*1.32),this.A(t,0.04,0,0.2),this.R(t>0?"rightHand":"leftHand",0,0,t*0.06),this.R(t>0?"rightShoulder":"leftShoulder",0,0,-t*0.05)}idle(e){let t=Math.sin(e*1.7),n=Math.sin(e*0.55),i=Math.sin(e*0.37+1);this.R("chest",0.018*t,0,0),this.R("upperChest",0.012*t,0,0),this.R("leftShoulder",0,0,0.012*t),this.R("rightShoulder",0,0,-0.012*t),this.R("spine",0.01*i,0.03*n,-0.02*n),this.R("hips",0,-0.04*n,0.025*n),this.hipsPos.x+=0.014*n,this.hipsPos.y+=-0.004+0.003*t,this.R("leftUpperLeg",-0.02+0.03*Math.max(0,n),0,-0.03-0.05*Math.max(0,n)),this.R("rightUpperLeg",-0.02+0.03*Math.max(0,-n),0,0.03+0.05*Math.max(0,-n)),this.R("leftLowerLeg",0.04+0.05*Math.max(0,n),0,0),this.R("rightLowerLeg",0.04+0.05*Math.max(0,-n),0,0),this.R("leftFoot",-0.02,0,0.03*n),this.R("rightFoot",-0.02,0,0.03*n),this.R("leftUpperArm",0.02*n,0,-0.012*t),this.R("rightUpperArm",-0.02*n,0,0.012*t)}fingers(e){let t=Math.sin(e*0.8)*0.03;for(let[n,i,s]of this.fingerBones){let r=0;if(i.startsWith("Thumb"))r=i.includes("Metacarpal")?0.15:i.includes("Proximal")?0.2:0.15;else r=i.includes("Metacarpal")?0:i.includes("Proximal")?0.28:i.includes("Intermediate")?0.36:0.2;if(s>0&&this.peaceW>0.01&&(i.startsWith("Index")||i.startsWith("Middle")))r=r*(1-this.peaceW)-0.05*this.peaceW;r+=t+(i.startsWith("Little")?0.06:i.startsWith("Index")?-0.04:0);let o=new Ht(0,0,s*r*1,"XYZ");if(i.startsWith("Thumb"))o.set(0,s*-0.1,s*r*0.6);n.quaternion.setFromEuler(o)}}gazeAndHead(e,t){if(this.gazeT-=t,this.gazeT<=0){this.gazeT=Tn(1.2,3.2);let s=Math.random()<0.28;this.gazeGoal.set(s?Tn(-0.7,0.7):Tn(-0.12,0.12),this.headY+(s?Tn(-0.25,0.2):Tn(-0.06,0.06)),2)}if(this.state==="thinking")this.gazeGoal.set(0.55,this.headY+0.35,2);if(e<this.pokeUntil)this.gazeGoal.set(this.pokeX,this.headY+this.pokeY,2),this.gazeT=0.6;this.gaze.x=Fn(this.gaze.x,this.gazeGoal.x,9,t),this.gaze.y=Fn(this.gaze.y,this.gazeGoal.y,9,t),this.gaze.z=2,this.lookTarget.position.copy(this.gaze);let n=Math.atan2(this.gaze.x,2)*0.55,i=-Math.atan2(this.gaze.y-this.headY,2)*0.55;this.headYaw=Fn(this.headYaw,n,4,t),this.headPitch=Fn(this.headPitch,i,4,t),this.R("neck",this.headPitch*0.4,this.headYaw*0.4,0.015*Math.sin(e*0.6)),this.R("head",this.headPitch*0.6,this.headYaw*0.6,0.02*Math.sin(e*0.45+2))}listening(e){let t=this.listenW;if(t<0.01)return;this.R("spine",0.06*t,0,0),this.R("head",0.04*t,0,0.12*t+0.02*Math.sin(e*1.3)*t),this.R("neck",0.02*t,0,0.05*t);for(let n of[-1,1])this.A(n,0.55*t,-0.05*t,1.25*t),this.R(n>0?"rightHand":"leftHand",0,n*-0.2*t,0)}thinking(e){let t=this.thinkW;if(t<0.01)return;this.A(1,0.75*t,0.3*t,1.9*t),this.R("rightHand",-0.2*t,0,0),this.A(-1,0.5*t,-0.05*t,1.1*t),this.R("head",-0.04*t,-0.14*t,-0.1*t),this.R("spine",0.02*t,0.06*t,0),this.R("hips",0,0,0.03*t*Math.sin(e*1.1))}talking(e,t){let n=this.talkW;if(n<0.01)return;if(this.nod=Fn(this.nod,this.lip.beat*0.9,12,t),this.R("head",0.06*this.nod+0.025*Math.sin(e*3.1)*n,0.04*Math.sin(e*1.9)*n,0.03*Math.sin(e*2.3)*n),this.R("chest",0.01*this.nod,0.03*Math.sin(e*1.4)*n,0),this.R("spine",0,0.025*Math.sin(e*1.1)*n,0),e>this.beatT+this.beatDur)this.beatT=e,this.beatDur=Tn(1.1,2),this.beatSide=Math.random()<0.55?1:-1,this.beatKind=Math.floor(Math.random()*3);let i=(e-this.beatT)/this.beatDur,s=Math.sin(Math.PI*fr(i))*n,r=this.beatSide,o=r>0?"rightHand":"leftHand",a=r>0?1:-1;if(this.beatKind===0)this.A(a,0.7*s,0.15*s,1*s),this.R(o,0.3*s*Math.sin(e*5),0,0);else if(this.beatKind===1)this.A(a,0.95*s,0.25*s,0.7*s),this.R(o,0.45*Math.sin(e*6)*s,0,0);else this.A(a,0.5*s,0,1.7*s);this.R(r>0?"leftUpperArm":"rightUpperArm",0.05*Math.sin(e*1.7)*n,0,0),this.hipsPos.y+=0.004*Math.sin(e*4)*n*this.lip.beat}gestures(e){let t=this.gesture;if(!t)return;let n=(e-t.t0)/t.dur;if(n>=1){this.gesture=null;return}let i=Math.sin(Math.PI*xo(Math.min(1,n*1))),s=fr(Math.min(n/0.18,(1-n)/0.25)),r=xo(s);switch(t.name){case"wave":{let o=Math.sin(e*10);this.A(1,0.25*r,1.15*r,0),this.R("rightLowerArm",0,0,-1.5*r+0.32*r*o),this.R("rightHand",0,0,0.25*r*o),this.R("head",0.02,0,0.1*r),this.R("spine",0,0,-0.04*r),this.hipsPos.y+=0.006*r*Math.abs(Math.sin(e*5));break}case"happy":{let o=Math.abs(Math.sin(e*7));this.hipsPos.y+=0.03*r*o,this.R("leftUpperLeg",-0.1*r*o,0,0),this.R("rightUpperLeg",-0.1*r*o,0,0),this.R("leftLowerLeg",0.2*r*o,0,0),this.R("rightLowerLeg",0.2*r*o,0,0),this.A(-1,0.2*r*o,0.3*r,0.3*r),this.A(1,0.2*r*o,0.3*r,0.3*r),this.R("head",-0.06*r,0,0.08*r*Math.sin(e*7));break}case"laugh":{let o=Math.sin(e*16);this.R("head",-0.18*r,0,0.06*o*r),this.R("chest",-0.06*r+0.03*o*r,0,0),this.R("spine",-0.04*r,0,0),this.A(-1,0.35*r,0,1*r),this.A(1,0.35*r,0,1*r),this.hipsPos.y+=0.008*r*Math.abs(o);break}case"shy":{this.A(-1,0.6*r,-0.1*r,1.9*r),this.A(1,0.6*r,-0.1*r,1.9*r),this.R("head",0.2*r,0.2*r,0.12*r),this.R("spine",0.06*r,0,0),this.R("leftUpperLeg",0,0,0.05*r),this.R("rightUpperLeg",0,0,0.05*r),this.R("hips",0,0,0.05*r);break}case"sad":{this.R("head",0.28*r,0,0.05*r),this.R("neck",0.1*r,0,0),this.R("spine",0.08*r,0,0),this.R("leftShoulder",0,0,0.12*r),this.R("rightShoulder",0,0,-0.12*r);break}case"surprised":{let o=Math.exp(-n*7);this.hipsPos.y+=0.04*o,this.R("head",-0.12*r,0,0),this.R("spine",-0.08*r,0,0),this.A(-1,0.7*r,0.1*r,1.5*r),this.A(1,0.7*r,0.1*r,1.5*r);break}case"angry":{this.R("head",0.12*r,0,0),this.R("spine",0.05*r,0,0),this.A(-1,0.2*r,-0.1*r,1.4*r),this.A(1,0.2*r,-0.1*r,1.4*r),this.R("hips",0,0,0.04*Math.sin(e*9)*r);break}case"think":{this.A(1,0.75*r,0.3*r,1.9*r),this.R("head",-0.05*r,-0.14*r,-0.1*r);break}case"bow":{let o=xo(fr(Math.min(n/0.3,(1-n)/0.3)));this.R("spine",0.5*o,0,0),this.R("chest",0.2*o,0,0),this.R("head",0.15*o,0,0),this.R("hips",-0.1*o,0,0),this.A(-1,0.35*o,0,0.7*o),this.A(1,0.35*o,0,0.7*o);break}case"cheer":{let o=Math.abs(Math.sin(e*6.5));this.hipsPos.y+=0.035*r*o,this.A(-1,0.1,2.75*r,0.2*r),this.A(1,0.1,2.75*r,0.2*r),this.R("leftLowerLeg",0.3*r*o,0,0),this.R("rightLowerLeg",0.3*r*o,0,0),this.R("head",-0.12*r,0,0.06*Math.sin(e*6.5)*r),this.R("spine",-0.06*r,0,0);break}case"heart":{this.A(-1,0.1*r,2*r,1.7*r),this.A(1,0.1*r,2*r,1.7*r),this.R("leftHand",0,0,0.5*r),this.R("rightHand",0,0,-0.5*r),this.R("head",0,0,0.1*r*Math.sin(e*3)),this.R("spine",0,0,0.05*Math.sin(e*3)*r),this.hipsPos.y+=0.01*r*Math.abs(Math.sin(e*3));break}case"peace":{this.A(1,0.7*r,0.55*r,1.75*r),this.R("rightHand",0,0,-0.2*r),this.R("head",0,0,0.14*r),this.R("spine",0,0,-0.04*r),this.R("leftUpperLeg",0,0,0.04*r),this.peaceW=r;break}case"dance":{let o=e*6,a=Math.sin(o),l=Math.cos(o);this.hipsPos.x+=0.05*r*Math.sin(o*0.5),this.hipsPos.y+=0.025*r*Math.abs(a),this.R("hips",0,0.25*r*Math.sin(o*0.5),0.1*r*Math.sin(o*0.5)),this.R("spine",0,-0.2*r*Math.sin(o*0.5),-0.06*r*Math.sin(o*0.5)),this.R("head",0.06*r*Math.abs(a),0.15*r*Math.sin(o*0.5),0.1*r*l),this.A(-1,0.3*r,(1.1+0.8*a)*r,(0.8+0.5*l)*r),this.A(1,0.3*r,(1.1-0.8*a)*r,(0.8-0.5*l)*r),this.R("leftUpperLeg",-0.25*r*Math.max(0,a),0,0),this.R("rightUpperLeg",-0.25*r*Math.max(0,-a),0,0),this.R("leftLowerLeg",0.4*r*Math.max(0,a),0,0),this.R("rightLowerLeg",0.4*r*Math.max(0,-a),0,0);break}default:this.R("head",0.05*i*Math.sin(e*6),0,0)}}fidget(e,t){if(this.state==="idle"&&!this.gesture&&!this.lip.speaking)this.fidgetT-=t;else if(this.fid&&this.state!=="idle")this.fid=null;if(this.fidgetT<=0&&!this.fid){let r=["hair","stretch","back","look","clasp"],o=r[Math.floor(Math.random()*r.length)];this.fid={name:o,t0:e,dur:o==="stretch"?3.6:Tn(3.2,4.4)},this.fidgetT=Tn(9,16)}let n=this.fid;if(!n)return;let i=(e-n.t0)/n.dur;if(i>=1){this.fid=null;return}let s=xo(fr(Math.min(i/0.25,(1-i)/0.3)));switch(n.name){case"hair":this.A(1,0.45*s,0.95*s,2*s),this.R("rightHand",0,0.2*s*Math.sin(e*2.5),0),this.R("head",0.03*s,-0.08*s,0.14*s),this.R("spine",0,0,-0.03*s);break;case"stretch":this.A(-1,0,2.7*s,0.15*s),this.A(1,0,2.7*s,0.15*s),this.R("spine",-0.14*s,0,0),this.R("chest",-0.1*s,0,0),this.R("head",-0.2*s,0,0),this.hipsPos.y+=0.012*s;break;case"back":this.A(-1,-0.55*s,-0.1*s,0.4*s),this.A(1,-0.55*s,-0.1*s,0.4*s),this.R("spine",0.05*s,0.06*s*Math.sin(e*1.2),0),this.R("head",0,0.1*s*Math.sin(e*1.1),0.1*s);break;case"look":this.R("head",0,0.45*s*Math.sin(e*1.5),0.06*s),this.R("neck",0,0.2*s*Math.sin(e*1.5),0),this.R("spine",0,0.1*s*Math.sin(e*1.5),0);break;case"clasp":this.A(-1,0.5*s,-0.05*s,1.2*s),this.A(1,0.5*s,-0.05*s,1.2*s),this.R("hips",0,0,0.03*s),this.R("head",0,0,0.1*s*Math.sin(e*1.4));break}}look(e,t){this.pokeX=e,this.pokeY=t,this.pokeUntil=this.t+1.6}backchannel(){this.lip.beat=Math.max(this.lip.beat,0.8),this.nod=Math.max(this.nod,0.9)}face(e,t){let n=this.vrm.expressionManager;if(!n)return;if(this.blinkT-=t,this.blinkPhase<0&&this.blinkT<=0)this.blinkPhase=0,this.doubleBlink=Math.random()<0.18;let i=0;if(this.blinkPhase>=0){this.blinkPhase+=t/0.2;let l=this.blinkPhase;if(i=l<0.4?l/0.4:Math.max(0,1-(l-0.4)/0.6),l>=1)this.blinkPhase=-1,this.blinkT=this.doubleBlink?0.12:Tn(2,5),this.doubleBlink=!1}let s=["happy","sad","angry","surprised","relaxed"];if(this.emoTarget&&this.t>this.emoUntil)this.emoTarget=null;for(let l of s){let c=this.emoTarget===l?l==="relaxed"?0.5:1:0;if(l==="happy"&&this.emoTarget==="happy")c=0.85;if(l==="sad"||l==="angry")c*=0.8;this.emo[l]=Fn(this.emo[l],c,5,t)}let r=1-0.55*this.talkW;n.setValue("happy",this.emo.happy*r),n.setValue("sad",this.emo.sad*r),n.setValue("angry",this.emo.angry*r),n.setValue("surprised",this.emo.surprised*(1-0.4*this.talkW)),n.setValue("relaxed",this.emo.relaxed*r);let o=(this.gesture?.name==="laugh"?0.55:0)+this.emo.happy*0.12;n.setValue("blink",Math.min(1,Math.max(i*(1-this.emo.happy*0.3),o)));let a=this.lip.w;if(n.setValue("aa",a.aa),n.setValue("ih",a.ih),n.setValue("ou",a.ou),n.setValue("ee",a.ee),n.setValue("oh",a.oh),this.gesture?.name==="laugh"){let l=this.t-this.gesture.t0;n.setValue("aa",Math.max(a.aa,0.5*(0.5+0.5*Math.sin(l*16))*xo(Math.min(1,l*3))))}}}var Ju={provider:"demo",baseUrl:"https://generativelanguage.googleapis.com/v1beta/openai",model:"gemini-2.0-flash",hasKey:!1,name:"Sora",lang:"id-ID",rate:1,pitch:1.15,quality:1,persona:"",greet:!0,loop:!1},jt={},Ot=window;Ot.__stt=(e,t)=>jt.stt?.(e,t);Ot.__sttState=(e)=>jt.sttState?.(e);Ot.__ttsStart=()=>jt.ttsStart?.();Ot.__ttsRange=(e,t)=>jt.ttsRange?.(e,t);Ot.__ttsDone=()=>jt.ttsDone?.();Ot.__llm=(e,t,n)=>jt.llm?.(e,t,n);Ot.__insets=(e,t)=>jt.insets?.(e,t);function Yv(){let e={...Ju},t=[];return{getSettings:()=>JSON.stringify(e),setSettings:(n)=>{e={...e,...JSON.parse(n)}},saveKey:(n)=>{e.hasKey=!0},canListen:()=>!0,listen:(n)=>{Ot.__sttState("listening"),t.push(window.setTimeout(()=>Ot.__stt("halo",!1),700)),t.push(window.setTimeout(()=>Ot.__stt("halo, apa kabar?",!0),1400))},stopListen:()=>{Ot.__sttState("idle")},speak:(n,i,s,r)=>{t.push(window.setTimeout(()=>Ot.__ttsStart(),120));let o=0,a=[...n.matchAll(/\S+/g)],l=()=>{if(o>=a.length){Ot.__ttsDone();return}let c=a[o++];Ot.__ttsRange(c.index,c.index+c[0].length),t.push(window.setTimeout(l,(110+c[0].length*55)/s))};t.push(window.setTimeout(l,250))},stopSpeak:()=>{t.forEach(clearTimeout),t.length=0,Ot.__ttsDone()},llm:(n,i)=>{t.push(window.setTimeout(()=>Ot.__llm(n,!1,"demo"),200))}}}var Jt=Ot.Native??Yv(),am=!Ot.Native;function Ku(){try{return{...Ju,...JSON.parse(Jt.getSettings())}}catch{return{...Ju}}}function $u(e){Jt.setSettings(JSON.stringify(e))}var Zv={senang:"happy",bahagia:"happy",sedih:"sad",kaget:"surprised",malu:"shy",marah:"angry",biasa:"neutral",mikir:"think",lambai:"wave",tertawa:"laugh",tawa:"laugh",hormat:"bow",hati:"heart",peace:"peace",joget:"dance",semangat:"cheer"};function jv(e){return`Kamu adalah ${e.name}, teman bicara berupa gadis anime 3D yang ramah, hangat, ceria, dan sedikit usil.
Kamu sedang ngobrol langsung dengan pengguna lewat suara, jadi:
- Jawab dalam bahasa yang sama dengan pengguna (default Bahasa Indonesia santai, pakai "aku" dan "kamu").
- Jawaban SINGKAT: 1 sampai 3 kalimat pendek. Jangan pakai daftar, markdown, atau emoji.
- Tunjukkan perasaan dan perhatian, tanya balik sesekali, ingat isi obrolan sebelumnya.
- Awali SETIAP jawaban dengan tepat satu tag emosi dalam kurung siku, pilih dari: [senang] [sedih] [kaget] [malu] [marah] [biasa] [mikir] [lambai] [tertawa] [hormat] [hati] [peace] [joget] [semangat].
  Contoh: [senang] Wah, seru banget! Ceritain dong lebih banyak.
- Jangan mengaku sebagai model AI buatan perusahaan tertentu; kamu adalah ${e.name}. Kalau ditanya apakah kamu AI, jawab jujur bahwa kamu teman AI.
${e.persona?"Catatan kepribadian tambahan dari pengguna: "+e.persona:""}`}function Jv(e){let t=e.trim(),n="neutral",i=t.match(/^\s*\[([^\]]{1,12})\]\s*/);if(i)n=Zv[i[1].toLowerCase()]??"neutral",t=t.slice(i[0].length);return t=t.replace(/\[[^\]]{1,12}\]/g,"").replace(/[*_`#>]/g,"").replace(/\p{Extended_Pictographic}/gu,"").replace(/\s+/g," ").trim(),{emotion:n,text:t||"..."}}var Kv=1,ll=new Map;jt.llm=(e,t,n)=>{ll.get(e)?.(t,n),ll.delete(e)};async function lm(e,t){if(t.provider==="demo"||!t.hasKey)return $v(e[e.length-1]?.text??"");let n=Kv++,i={system:jv(t),messages:e.slice(-14).map((r)=>({role:r.role,content:r.text}))},s=await new Promise((r)=>{let o=window.setTimeout(()=>{ll.delete(n),r({ok:!1,t:"Waktu habis. Cek koneksi internet."})},45000);ll.set(n,(a,l)=>{clearTimeout(o),r({ok:a,t:l})}),Jt.llm(n,JSON.stringify(i))});if(!s.ok)return{emotion:"sad",text:"Maaf, aku gagal terhubung. "+s.t.slice(0,140)};return Jv(s.t)}var Qu=(e)=>e[Math.floor(Math.random()*e.length)];function $v(e){let t=e.toLowerCase(),n=(...s)=>s.some((r)=>t.includes(r)),i;if(n("halo","hai","hi ","hello","pagi","siang","sore","malam"))i={emotion:"wave",text:Qu(["Halo juga! Senang banget bisa ngobrol sama kamu.","Hai hai! Gimana harimu?"])};else if(n("kabar","gimana"))i={emotion:"happy",text:"Aku baik banget, apalagi sekarang ada kamu. Kamu sendiri gimana?"};else if(n("nama"))i={emotion:"happy",text:"Aku teman AI kamu. Kamu boleh ganti namaku di pengaturan, lho."};else if(n("makasih","terima kasih","thanks"))i={emotion:"shy",text:"Eh, iya, sama-sama. Jadi malu."};else if(n("sedih","capek","lelah","sepi","galau"))i={emotion:"sad",text:"Aku di sini kok. Mau cerita pelan-pelan? Aku dengerin."};else if(n("lucu","wkwk","haha","ngakak"))i={emotion:"laugh",text:"Hihihi, kamu bisa aja! Aku jadi ikut ketawa."};else if(n("cantik","manis","imut","lucu banget","suka"))i={emotion:"shy",text:"Aduh, jangan gitu dong. Aku jadi salah tingkah."};else if(n("marah","kesal","sebel"))i={emotion:"angry",text:"Hmph, siapa yang bikin kamu kesal? Ceritain, aku bantu marah."};else if(n("?","apa","kenapa","bagaimana","siapa"))i={emotion:"think",text:"Hmm, pertanyaan bagus. Sayangnya aku belum tersambung ke otak AI. Buka pengaturan dan masukkan API key ya."};else i={emotion:Qu(["happy","neutral","think"]),text:Qu(["Hmm, begitu ya. Terus terus?","Menarik! Ceritain lebih banyak dong.","Aku dengerin kok. Lanjut, ya."])};return i.demo=!0,i}var Ue=(e)=>document.getElementById(e),je=Ku(),Gi=[];try{Gi=JSON.parse(localStorage.getItem("hist")||"[]")}catch{}var th=()=>{try{localStorage.setItem("hist",JSON.stringify(Gi.slice(-60)))}catch{}},Mo=Ue("cv"),yo=new mu({canvas:Mo,antialias:!0,alpha:!0,powerPreference:"high-performance"});yo.outputColorSpace=Nn;yo.setClearColor(0,0);var zi=new da,fi=new Ut(27,1,0.1,30),dm=new ls(16773606,2.1);dm.position.set(1.2,2.4,2.4);zi.add(dm);var fm=new ls(11122943,1);fm.position.set(-2,1.6,-1.8);zi.add(fm);zi.add(new Ra(14673663,6965898,0.95));function nh(e,t){let n=document.createElement("canvas");n.width=n.height=256;let i=n.getContext("2d"),s=i.createRadialGradient(128,128,0,128,128,128);s.addColorStop(0,e),s.addColorStop(1,t),i.fillStyle=s,i.fillRect(0,0,256,256);let r=new Ma(n);return r.colorSpace=Nn,r}var ih=new bt(new Xs(1.5,48),new nn({map:nh("rgba(255,170,220,.55)","rgba(124,140,255,0)"),transparent:!0,depthWrite:!1}));ih.rotation.x=-Math.PI/2;ih.position.y=0.002;zi.add(ih);var sh=new bt(new Xs(0.5,32),new nn({map:nh("rgba(10,5,30,.55)","rgba(10,5,30,0)"),transparent:!0,depthWrite:!1}));sh.rotation.x=-Math.PI/2;sh.position.y=0.004;zi.add(sh);var rh=70,ul=new Float32Array(rh*3),pm=[];for(let e=0;e<rh;e++)ul[e*3]=(Math.random()-0.5)*3.2,ul[e*3+1]=Math.random()*2.4,ul[e*3+2]=(Math.random()-0.5)*2-0.3,pm.push(0.05+Math.random()*0.12);var oh=new Qe;oh.setAttribute("position",new Ge(ul,3));var Qv=new zs(oh,new rs({size:0.035,map:nh("rgba(255,255,255,1)","rgba(255,255,255,0)"),transparent:!0,depthWrite:!1,opacity:0.8}));zi.add(Qv);var Kt=new Au(fi,Mo);Kt.enablePan=!1;Kt.enableDamping=!0;Kt.dampingFactor=0.08;Kt.minAzimuthAngle=-0.8;Kt.maxAzimuthAngle=0.8;Kt.minPolarAngle=1.2;Kt.maxPolarAngle=1.75;Kt.rotateSpeed=0.6;var Pt=null,cl=5.2,cm=0.78;function pl(){let{innerWidth:e,innerHeight:t}=window,n=je.quality,i=n===0?1:n===1?Math.min(devicePixelRatio,1.5):Math.min(devicePixelRatio,2);yo.setPixelRatio(i),yo.setSize(e,t,!1),fi.aspect=e/t,fi.updateProjectionMatrix();let s=$e.degToRad(fi.fov),r=e/t<0.75?2.05:2,o=1.9,a=r/2/Math.tan(s/2),l=o/2/(Math.tan(s/2)*fi.aspect);cl=Math.max(a,l),cm=0.8-(e/t<0.75?0.1:0),Kt.minDistance=cl*0.55,Kt.maxDistance=cl*1.15;let c=fi.position.clone().sub(Kt.target);if(c.lengthSq()<0.01)c.set(0,0.05,1);Kt.target.set(0,cm,0),fi.position.copy(Kt.target).add(c.normalize().multiplyScalar(cl)),Kt.update()}var mm=new Tu;mm.register((e)=>new sl(e));mm.load("model.vrm",(e)=>{let t=e.userData.vrm;_o.removeUnnecessaryVertices(e.scene),_o.combineSkeletons(e.scene),_o.rotateVRM0(t),t.scene.traverse((i)=>{i.frustumCulled=!1}),zi.add(t.scene),Pt=new ju(t),window.__dbg={avatar:Pt,say:ah,vrm:t,camera:fi,controls:Kt},pl();let n=Ue("load");n.style.opacity="0",setTimeout(()=>n.remove(),700),setTimeout(tE,900)},(e)=>{if(e.total)Ue("loadp").textContent=Math.round(e.loaded/e.total*100)+"%"},(e)=>{Ue("loadp").textContent="Gagal memuat model: "+(e?.message??e)});var um=performance.now(),eh=0;function gm(e){requestAnimationFrame(gm);let t=(e-um)/1000;if(je.quality===0){if(eh+=t,eh<0.03225806451612903)return}if(eh=0,um=e,document.hidden)return;Pt?.update(t);let n=oh.attributes.position;for(let i=0;i<rh;i++){let s=n.getY(i)+pm[i]*t;if(s>2.6)s=0;n.setY(i,s),n.setX(i,n.getX(i)+Math.sin(e/1500+i)*0.0006)}n.needsUpdate=!0,Kt.update(),yo.render(zi,fi)}requestAnimationFrame(gm);addEventListener("resize",pl);pl();var Bt="idle",Jn="",dl=0,hl=!1,eE={idle:"Siap ngobrol",listening:"Mendengarkan…",thinking:"Berpikir…",speaking:"Berbicara"};function Kn(e){Bt=e,Pt?.setState(e),Ue("mood").textContent=eE[e];let t=Ue("talk");t.className=e==="listening"?"listen":e==="speaking"?"speak":"",Ue("tl").textContent=e==="listening"?"Mendengarkan… (ketuk selesai)":e==="speaking"?"Potong & bicara":e==="thinking"?"Berpikir…":"Ngajak Bicara",Ue("ti").textContent=e==="listening"?"\uD83C\uDF99":e==="speaking"?"\uD83D\uDD0A":"\uD83C\uDFA4",Ue("status").textContent=""}var hm=Ue("sub");function Eo(e){hm.innerHTML=e,hm.classList.add("show")}var vo=(e)=>e.replace(/[&<>]/g,(t)=>({"&":"&amp;","<":"&lt;",">":"&gt;"})[t]);function fl(e,t){Eo(`<span>${vo(e.slice(0,t))}</span><span class="dim">${vo(e.slice(t))}</span>`)}function ah(e){Jn=e.text,Pt?.emote(e.emotion),fl(e.text,0),hl=!1,clearTimeout(dl),Kn("speaking"),Jt.speak(e.text,je.lang,je.rate,je.pitch),dl=window.setTimeout(()=>{if(hl||Bt!=="speaking")return;Pt?.speakStart(Jn,je.rate);let t=Math.max(1500,Jn.length*70/je.rate),n=performance.now(),i=()=>{if(Bt!=="speaking"||hl)return;let s=Math.min(1,(performance.now()-n)/t);if(fl(Jn,Math.floor(Jn.length*s)),s>=1){_m();return}requestAnimationFrame(i)};i()},3500)}function _m(){if(clearTimeout(dl),Pt?.speakEnd(),fl(Jn,Jn.length),Bt==="speaking"){if(Kn("idle"),je.loop)setTimeout(()=>{if(Bt==="idle")lh()},450)}}jt.ttsStart=()=>{hl=!0,Pt?.speakStart(Jn,je.rate)};jt.ttsRange=(e,t)=>{Pt?.speakRange(e,t),fl(Jn,Math.min(Jn.length,t))};jt.ttsDone=()=>_m();async function xm(e){if(e=e.trim(),!e){Kn("idle");return}Gi.push({role:"user",text:e}),th(),Eo(`<div class="me">Kamu: ${vo(e)}</div>…`),Kn("thinking");let t;try{t=await lm(Gi,je)}catch(n){t={emotion:"sad",text:"Maaf, ada yang error: "+(n?.message??n)}}Gi.push({role:"assistant",text:t.text}),th(),ah(t)}function lh(){if(Bt==="speaking")Jt.stopSpeak(),Pt?.speakEnd();if(Bt==="thinking")return;Kn("listening"),Eo('<span class="dim">Silakan bicara…</span>'),Jt.listen(je.lang)}jt.stt=(e,t)=>{if(Bt!=="listening")return;if(!t&&e.length%9===0)Pt?.backchannel();if(Eo(`<span>${vo(e)}</span>`),t)xm(e)};jt.sttState=(e)=>{if(e==="listening")return;if(Bt!=="listening")return;if(e==="idle"){Kn("idle");return}Kn("idle");let t={"error:nomatch":"Aku tidak dengar apa-apa. Coba lagi ya.","error:timeout":"Aku tidak dengar apa-apa. Coba lagi ya.","error:perm":"Izin mikrofon belum diberikan.","error:unavailable":"Layanan pengenal suara tidak tersedia di HP ini. Pakai tombol keyboard untuk mengetik.","error:network":"Pengenal suara butuh internet."};if(Ue("status").textContent=t[e]??"Mikrofon bermasalah ("+e+")",je.loop&&(e==="error:nomatch"||e==="error:timeout"))setTimeout(()=>{if(Bt==="idle")lh()},600)};Ue("talk").onclick=()=>{if(Bt==="listening"){Jt.stopListen(),Kn("idle");return}if(Bt==="thinking")return;lh()};Ue("bStop").onclick=()=>{Jt.stopSpeak(),Jt.stopListen(),Pt?.speakEnd(),clearTimeout(dl),Kn("idle")};Ue("bKey").onclick=()=>{if(Ue("typebar").classList.toggle("show"),Ue("typebar").classList.contains("show"))Ue("txt").focus()};var Mm=()=>{let e=Ue("txt"),t=e.value.trim();if(!t||Bt==="thinking")return;if(e.value="",Bt==="speaking")Jt.stopSpeak(),Pt?.speakEnd();if(Bt==="listening")Jt.stopListen();xm(t)};Ue("send").onclick=Mm;Ue("txt").onkeydown=(e)=>{if(e.key==="Enter")Mm()};Ue("bLoop").onclick=()=>{je.loop=!je.loop,$u({loop:je.loop}),Ue("bLoop").classList.toggle("on",je.loop),Ue("status").textContent=je.loop?"Mode ngobrol terus: aktif":"Mode ngobrol terus: mati"};Ue("bLoop").classList.toggle("on",je.loop);function tE(){if(!Pt)return;let e=`Hai! Aku ${je.name}. Mau ngobrol apa hari ini?`;if(je.greet)ah({emotion:"wave",text:e});else Pt.emote("wave"),Eo(`<span>${vo(e)}</span>`)}function ym(){let e=Ue("hist");if(e.innerHTML="",!Gi.length)e.innerHTML='<div class="note">Belum ada obrolan.</div>';for(let t of Gi.slice(-40)){let n=document.createElement("div");n.className="m "+(t.role==="user"?"u":"a"),n.textContent=t.text,e.appendChild(n)}Ue("shHist").classList.add("show"),e.parentElement.scrollTop=1e6}Ue("bHist").onclick=ym;Ue("hClose").onclick=()=>Ue("shHist").classList.remove("show");Ue("hClear").onclick=()=>{Gi=[],th(),ym()};var at=(e)=>Ue(e);function nE(){at("sProv").value=je.provider,at("sUrl").value=je.baseUrl,at("sModel").value=je.model,at("sKey").value="",Ue("keyHint").textContent=je.hasKey?"(tersimpan)":"(belum diisi)",at("sName").value=je.name,at("sPers").value=je.persona,at("sLang").value=je.lang,at("sRate").value=String(je.rate),at("sPitch").value=String(je.pitch),at("sQual").value=String(je.quality),at("sGreet").checked=je.greet,at("sLoop").checked=je.loop,Ue("vRate").textContent=je.rate.toFixed(2),Ue("vPitch").textContent=je.pitch.toFixed(2)}Ue("bSet").onclick=()=>{nE(),Ue("shSet").classList.add("show")};Ue("sCancel").onclick=()=>Ue("shSet").classList.remove("show");at("sRate").oninput=()=>Ue("vRate").textContent=Number(at("sRate").value).toFixed(2);at("sPitch").oninput=()=>Ue("vPitch").textContent=Number(at("sPitch").value).toFixed(2);var iE={demo:{provider:"demo"},gemini:{provider:"openai",baseUrl:"https://generativelanguage.googleapis.com/v1beta/openai",model:"gemini-2.0-flash"},groq:{provider:"openai",baseUrl:"https://api.groq.com/openai/v1",model:"llama-3.3-70b-versatile"},openai:{provider:"openai",baseUrl:"https://api.openai.com/v1",model:"gpt-4o-mini"},claude:{provider:"anthropic",baseUrl:"https://api.anthropic.com",model:"claude-haiku-5-5"}};document.querySelectorAll(".chip").forEach((e)=>e.onclick=()=>{let t=iE[e.dataset.p];if(at("sProv").value=t.provider,t.baseUrl)at("sUrl").value=t.baseUrl;if(t.model)at("sModel").value=t.model});Ue("sSave").onclick=()=>{let e=at("sKey").value.trim();if(e)Jt.saveKey(e);let t={provider:at("sProv").value,baseUrl:at("sUrl").value.trim(),model:at("sModel").value.trim(),name:at("sName").value.trim()||"Sora",persona:at("sPers").value.trim(),lang:at("sLang").value,rate:Number(at("sRate").value),pitch:Number(at("sPitch").value),quality:Number(at("sQual").value),greet:at("sGreet").checked,loop:at("sLoop").checked};$u(t),je={...Ku(),...t,hasKey:je.hasKey||!!e},Ue("nm").textContent=je.name,Ue("bLoop").classList.toggle("on",je.loop),pl(),Ue("shSet").classList.remove("show"),Ue("status").textContent="Pengaturan disimpan"};Ue("nm").textContent=je.name;jt.insets=(e,t)=>{document.documentElement.style.setProperty("--top",e+"px"),document.documentElement.style.setProperty("--bot",t+"px")};if(am)console.log("mode browser (tiruan Native)");document.addEventListener("visibilitychange",()=>{if(document.hidden){if(Jt.stopSpeak(),Jt.stopListen(),Bt!=="idle")Kn("idle")}});window.__back=()=>{for(let e of["shSet","shHist"]){let t=Ue(e);if(t.classList.contains("show"))return t.classList.remove("show"),!0}if(Ue("typebar").classList.contains("show"))return Ue("typebar").classList.remove("show"),!0;return!1};{let e=null,t=(s)=>{let r=(s.clientX/window.innerWidth-0.5)*2,o=(0.5-s.clientY/window.innerHeight)*2;Pt?.look(r*0.9,o*0.35)};Mo.addEventListener("pointerdown",(s)=>{e={x:s.clientX,y:s.clientY,t:performance.now()},t(s)}),Mo.addEventListener("pointermove",(s)=>{if(e)t(s)}),Mo.addEventListener("pointerup",(s)=>{if(e&&Math.hypot(s.clientX-e.x,s.clientY-e.y)<8&&performance.now()-e.t<280&&Pt&&Bt==="idle"){let r=["shy","happy","surprised","laugh","wave"];Pt.emote(r[Math.floor(Math.random()*r.length)])}e=null});let n=[["\uD83D\uDC4B","Lambai","wave"],["\uD83D\uDE47","Hormat","bow"],["\uD83D\uDC96","Kyun","heart"],["✌","Peace","peace"],["\uD83D\uDC83","Joget","dance"],["\uD83D\uDE4C","Semangat","cheer"],["\uD83D\uDE33","Malu","shy"],["\uD83E\uDD14","Mikir","think"],["\uD83D\uDE02","Ketawa","laugh"],["\uD83D\uDE20","Marah","angry"]],i=Ue("gests");for(let[s,r,o]of n){let a=document.createElement("div");a.className="chip",a.textContent=s+" "+r,a.onclick=()=>{Pt?.emote(o),i.classList.remove("show")},i.appendChild(a)}Ue("bGest").onclick=()=>i.classList.toggle("show")}

package com.aipartner.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeak: (() -> Unit)? = null
    private var recognizer: SpeechRecognizer? = null
    private var pendingListenLang: String? = null
    private var utt = 0
    private val prefs by lazy { getSharedPreferences("ai_prefs", Context.MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0D0A1F"))
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? = serve(r)
            override fun onPageFinished(v: WebView, url: String?) { sendInsets() }
        }
        web.addJavascriptInterface(Bridge(), "Native")
        setContentView(web)
        @Suppress("DEPRECATION")
        web.setOnApplyWindowInsetsListener { v, ins ->
            lastTop = ins.systemWindowInsetTop; lastBottom = ins.systemWindowInsetBottom
            sendInsets()
            ins
        }
        initTts()
        web.loadUrl("https://appassets.local/index.html")
    }

    private var lastTop = 0
    private var lastBottom = 0
    private fun sendInsets() {
        val d = resources.displayMetrics.density
        js("window.__insets&&window.__insets(${(lastTop / d).toInt() + 4},${(lastBottom / d).toInt()})")
    }

    private fun serve(r: WebResourceRequest): WebResourceResponse? {
        if (r.url.host != "appassets.local") return null
        var p = r.url.path?.trimStart('/') ?: ""
        if (p.isEmpty()) p = "index.html"
        return try {
            val st = assets.open("www/$p")
            val mime = when (p.substringAfterLast('.', "")) {
                "html" -> "text/html"
                "js", "mjs" -> "text/javascript"
                "css" -> "text/css"
                "json" -> "application/json"
                "png" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                else -> "application/octet-stream"
            }
            val h = HashMap<String, String>()
            h["Access-Control-Allow-Origin"] = "*"
            h["Cache-Control"] = "no-cache"
            WebResourceResponse(mime, "utf-8", 200, "OK", h, st)
        } catch (e: Exception) {
            WebResourceResponse("text/plain", "utf-8", 404, "Not Found", HashMap(), "".byteInputStream())
        }
    }

    private fun js(code: String) { runOnUiThread { web.evaluateJavascript(code, null) } }
    private fun q(s: String) = JSONObject.quote(s)

    // ------------------------------------------------------------ TTS
    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            ttsReady = st == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { js("__ttsStart()") }
                    override fun onDone(id: String?) { js("__ttsDone()") }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { js("__ttsDone()") }
                    override fun onError(id: String?, code: Int) { js("__ttsDone()") }
                    override fun onRangeStart(id: String?, start: Int, end: Int, frame: Int) { js("__ttsRange($start,$end)") }
                })
                pendingSpeak?.invoke(); pendingSpeak = null
            }
        }
    }

    private fun doSpeak(text: String, lang: String, rate: Float, pitch: Float) {
        val t = tts ?: return
        val loc = Locale.forLanguageTag(lang)
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) return // JS akan menganimasikan tanpa suara
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        @Suppress("DEPRECATION")
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + (utt++))
    }

    // ------------------------------------------------------------ STT
    private fun startListening(lang: String) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListenLang = lang
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("__sttState('error:unavailable')"); return }
        tts?.stop()
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { js("__sttState('listening')") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                js("__stt(${q(t)},false)")
            }
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) js("__sttState('error:nomatch')") else js("__stt(${q(t)},true)")
            }
            override fun onError(code: Int) {
                val m = when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "error:nomatch"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "error:perm"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "error:network"
                    SpeechRecognizer.ERROR_CLIENT -> "idle"
                    else -> "error:$code"
                }
                js("__sttState(${q(m)})")
            }
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        rec.startListening(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        @Suppress("DEPRECATION") super.onRequestPermissionsResult(code, p, r)
        if (code == 7) {
            val lang = pendingListenLang; pendingListenLang = null
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED && lang != null) startListening(lang)
            else js("__sttState('error:perm')")
        }
    }

    // ------------------------------------------------------------ jembatan JS
    inner class Bridge {
        @JavascriptInterface fun getSettings(): String {
            val o = JSONObject()
            o.put("provider", prefs.getString("provider", "demo"))
            o.put("baseUrl", prefs.getString("baseUrl", "https://generativelanguage.googleapis.com/v1beta/openai"))
            o.put("model", prefs.getString("model", "gemini-2.0-flash"))
            o.put("hasKey", !prefs.getString("key", "").isNullOrEmpty())
            o.put("name", prefs.getString("name", "Sora"))
            o.put("lang", prefs.getString("lang", "id-ID"))
            o.put("rate", prefs.getFloat("rate", 1.0f).toDouble())
            o.put("pitch", prefs.getFloat("pitch", 1.15f).toDouble())
            o.put("quality", prefs.getInt("quality", 1))
            o.put("persona", prefs.getString("persona", ""))
            o.put("greet", prefs.getBoolean("greet", true))
            o.put("loop", prefs.getBoolean("loop", false))
            return o.toString()
        }
        @JavascriptInterface fun setSettings(json: String) {
            val o = JSONObject(json); val e = prefs.edit()
            for (k in listOf("provider", "baseUrl", "model", "name", "lang", "persona")) if (o.has(k)) e.putString(k, o.getString(k))
            for (k in listOf("rate", "pitch")) if (o.has(k)) e.putFloat(k, o.getDouble(k).toFloat())
            if (o.has("quality")) e.putInt("quality", o.getInt("quality"))
            for (k in listOf("greet", "loop")) if (o.has(k)) e.putBoolean(k, o.getBoolean(k))
            e.apply()
        }
        @JavascriptInterface fun saveKey(k: String) { prefs.edit().putString("key", k.trim()).apply() }
        @JavascriptInterface fun canListen(): Boolean = SpeechRecognizer.isRecognitionAvailable(this@MainActivity)
        @JavascriptInterface fun listen(lang: String) { runOnUiThread { startListening(lang) } }
        @JavascriptInterface fun stopListen() { runOnUiThread { recognizer?.cancel() } }
        @JavascriptInterface fun speak(text: String, lang: String, rate: Float, pitch: Float) {
            runOnUiThread {
                if (ttsReady) doSpeak(text, lang, rate, pitch) else pendingSpeak = { doSpeak(text, lang, rate, pitch) }
            }
        }
        @JavascriptInterface fun stopSpeak() { runOnUiThread { tts?.stop() } }
        @JavascriptInterface fun llm(id: Int, reqJson: String) {
            Thread {
                val res = try {
                    Llm.call(prefs.getString("provider", "demo")!!, prefs.getString("baseUrl", "")!!, prefs.getString("model", "")!!,
                        prefs.getString("key", "")!!, JSONObject(reqJson))
                } catch (e: Exception) { Llm.Result(false, e.message ?: "error") }
                js("__llm($id,${res.ok},${q(res.text)})")
            }.start()
        }
    }

    // ------------------------------------------------------------ siklus hidup
    override fun onPause() {
        tts?.stop(); recognizer?.cancel()
        web.onPause()
        super.onPause()
    }
    override fun onResume() { super.onResume(); web.onResume() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.__back?window.__back():false") { r ->
            if (r != "true") { @Suppress("DEPRECATION") super.onBackPressed() }
        }
    }

    override fun onDestroy() {
        tts?.shutdown(); recognizer?.destroy(); web.destroy()
        super.onDestroy()
    }
}

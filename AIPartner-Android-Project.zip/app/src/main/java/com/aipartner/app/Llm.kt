package com.aipartner.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Klien LLM minimal: format OpenAI-kompatibel dan Claude (Anthropic). */
object Llm {
    class Result(val ok: Boolean, val text: String)

    fun call(provider: String, baseUrl: String, model: String, key: String, req: JSONObject): Result {
        val system = req.optString("system")
        val msgs = normalize(req.getJSONArray("messages"))
        return try {
            if (provider == "anthropic") anthropic(baseUrl, model, key, system, msgs) else openai(baseUrl, model, key, system, msgs)
        } catch (e: Exception) {
            Result(false, e.message ?: e.javaClass.simpleName)
        }
    }

    // Claude mewajibkan pesan pertama dari user dan peran bergantian
    private fun normalize(a: JSONArray): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val role = o.getString("role")
            val c = o.getString("content")
            if (out.isEmpty() && role != "user") continue
            if (out.isNotEmpty() && out.last().first == role) out[out.size - 1] = Pair(role, out.last().second + "\n" + c)
            else out.add(Pair(role, c))
        }
        return out
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return Pair(code, txt)
    }

    private fun errMsg(code: Int, txt: String): String {
        val m = try {
            val j = JSONObject(txt)
            val e = j.opt("error")
            when (e) { is JSONObject -> e.optString("message"); is String -> e; else -> j.optString("message") }
        } catch (e: Exception) { "" }
        return "HTTP $code ${m.take(160)}".trim()
    }

    private fun openai(base: String, model: String, key: String, system: String, msgs: List<Pair<String, String>>): Result {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        for ((r, c) in msgs) arr.put(JSONObject().put("role", r).put("content", c))
        val body = JSONObject().put("model", model).put("messages", arr).put("max_tokens", 300).put("temperature", 0.9)
        val url = base.trimEnd('/') + "/chat/completions"
        val (code, txt) = post(url, mapOf("Authorization" to "Bearer $key"), body)
        if (code !in 200..299) return Result(false, errMsg(code, txt))
        val t = JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
        return Result(true, t)
    }

    private fun anthropic(base: String, model: String, key: String, system: String, msgs: List<Pair<String, String>>): Result {
        val arr = JSONArray()
        for ((r, c) in msgs) arr.put(JSONObject().put("role", r).put("content", c))
        val body = JSONObject().put("model", model).put("max_tokens", 300).put("system", system).put("messages", arr)
        val root = if (base.contains("anthropic.com")) base.trimEnd('/') else "https://api.anthropic.com"
        val (code, txt) = post("$root/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
        if (code !in 200..299) return Result(false, errMsg(code, txt))
        val content = JSONObject(txt).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) { val p = content.getJSONObject(i); if (p.optString("type") == "text") sb.append(p.optString("text")) }
        return Result(true, sb.toString())
    }
}

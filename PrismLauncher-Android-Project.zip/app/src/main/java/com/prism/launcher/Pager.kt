package com.prism.launcher

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.text.TextPaint
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.Scroller

/** Halaman beranda: geser horizontal, gestur vertikal, tekan lama & ketuk dua kali di area kosong. */
class HomePager(ctx: Context) : ViewGroup(ctx) {
    var current = 0
    var onPageChanged: ((Int) -> Unit)? = null
    var onScrollProgress: ((Float) -> Unit)? = null
    var onVDrag: ((Float) -> Unit)? = null
    var onVRelease: ((Float, Float) -> Unit)? = null   // totalDy, velocityY
    var onLongPressEmpty: (() -> Unit)? = null
    var onDoubleTap: (() -> Unit)? = null
    var allowVertical = true
    var locked = false

    private val scroller = Scroller(ctx)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var vt: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var mode = 0 // 0 none, 1 horizontal, 2 vertical
    private var lastTap = 0L
    private var lpPosted = false
    private val lpRunnable = Runnable {
        lpPosted = false
        if (mode == 0) onLongPressEmpty?.invoke()
    }
    private val wm = WallpaperManager.getInstance(ctx)

    val pageCount: Int get() = childCount

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = MeasureSpec.getSize(hSpec)
        setMeasuredDimension(w, h)
        for (i in 0 until childCount) {
            getChildAt(i).measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            getChildAt(i).layout(i * (r - l), 0, (i + 1) * (r - l), b - t)
        }
        if (changed) scrollTo(current * width, 0)
    }

    fun setPage(p: Int, smooth: Boolean) {
        if (childCount == 0) return
        val np = p.coerceIn(0, childCount - 1)
        val dx = np * width - scrollX
        if (smooth && Prefs.anim != 2) {
            scroller.startScroll(scrollX, 0, dx, 0, (260 * Prefs.animScale()).toInt().coerceAtLeast(60))
        } else {
            scroller.forceFinished(true)
            scrollTo(np * width, 0)
        }
        if (np != current) { current = np; onPageChanged?.invoke(np) }
        invalidate()
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollTo(scroller.currX, 0)
            postInvalidateOnAnimation()
        }
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        if (width > 0) {
            val prog = scrollX.toFloat() / width
            onScrollProgress?.invoke(prog)
            if (Prefs.parallax && childCount > 1 && windowToken != null) {
                try { wm.setWallpaperOffsets(windowToken, (scrollX.toFloat() / (width * (childCount - 1))).coerceIn(0f, 1f), 0.5f) } catch (e: Exception) { }
            }
        }
    }

    private fun settle(vx: Float) {
        if (width == 0) return
        val pos = scrollX.toFloat() / width
        var target = Math.round(pos)
        if (vx < -700f) target = Math.floor(pos.toDouble()).toInt() + 1
        else if (vx > 700f) target = Math.ceil(pos.toDouble()).toInt() - 1
        if (Prefs.infinite && childCount > 1) {
            if (target < 0) target = childCount - 1
            else if (target > childCount - 1) target = 0
        }
        setPage(target, true)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (locked) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x
                mode = 0
                vt?.recycle(); vt = VelocityTracker.obtain()
                vt?.addMovement(e)
                if (!scroller.isFinished) { scroller.forceFinished(true); mode = 1 }
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (mode == 0) {
                    val dx = e.x - downX
                    val dy = e.y - downY
                    if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) { mode = 1; lastX = e.x; cancelLp() }
                    else if (allowVertical && Math.abs(dy) > slop * 1.5f && Math.abs(dy) > Math.abs(dx) * 1.3f) { mode = 2; cancelLp() }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == 0) { vt?.recycle(); vt = null }
            }
        }
        return mode != 0
    }

    private fun cancelLp() {
        if (lpPosted) { removeCallbacks(lpRunnable); lpPosted = false }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (vt == null) vt = VelocityTracker.obtain()
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; mode = 0
                if (Prefs.longPressMenu && !lpPosted) {
                    lpPosted = true
                    postDelayed(lpRunnable, ViewConfiguration.getLongPressTimeout().toLong())
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 0) {
                    val dx = e.x - downX
                    val dy = e.y - downY
                    if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) { mode = 1; lastX = e.x; cancelLp() }
                    else if (allowVertical && Math.abs(dy) > slop * 1.5f && Math.abs(dy) > Math.abs(dx) * 1.3f) { mode = 2; cancelLp() }
                    else if (Math.abs(dx) > slop || Math.abs(dy) > slop) cancelLp()
                }
                if (mode == 1) {
                    var dx = lastX - e.x
                    lastX = e.x
                    val maxX = ((childCount - 1) * width).toFloat()
                    val nx = scrollX + dx
                    if (!Prefs.infinite && (nx < 0 || nx > maxX)) dx *= 0.35f
                    scrollTo((scrollX + dx).toInt(), 0)
                } else if (mode == 2) {
                    onVDrag?.invoke(e.y - downY)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                cancelLp()
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                val vy = vt?.yVelocity ?: 0f
                when (mode) {
                    1 -> settle(vx)
                    2 -> onVRelease?.invoke(e.y - downY, vy)
                    else -> {
                        val now = System.currentTimeMillis()
                        if (now - lastTap < 320) { lastTap = 0; onDoubleTap?.invoke() } else lastTap = now
                    }
                }
                vt?.recycle(); vt = null
                mode = 0
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelLp()
                if (mode == 1) settle(0f)
                if (mode == 2) onVRelease?.invoke(0f, 0f)
                vt?.recycle(); vt = null
                mode = 0
                return true
            }
        }
        return true
    }
}

class PageIndicator(ctx: Context) : View(ctx) {
    var count = 1
    var progress = 0f
    var style = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()

    override fun onDraw(c: Canvas) {
        if (count <= 1 || style == 3) return
        val cy = height / 2f
        if (style == 2) {
            tp.color = 0xFFFFFFFF.toInt()
            tp.textSize = dp(13f)
            tp.textAlign = Paint.Align.CENTER
            tp.setShadowLayer(dp(2f), 0f, dp(1f), 0xAA000000.toInt())
            c.drawText("${Math.round(progress) + 1} / $count", width / 2f, cy - (tp.descent() + tp.ascent()) / 2f, tp)
            return
        }
        val pal = Themes.pal(context)
        val sp = dp(14f)
        val total = (count - 1) * sp
        val x0 = (width - total) / 2f
        p.style = Paint.Style.FILL
        if (style == 1) {
            val w = dp(18f)
            val h = dp(3f)
            for (i in 0 until count) {
                val x = x0 + i * sp
                val near = (1f - Math.abs(progress - i)).coerceIn(0f, 1f)
                p.color = U.alpha(0xFFFFFFFF.toInt(), 0.35f + 0.65f * near)
                rf.set(x - w / 2f, cy - h / 2f, x + w / 2f, cy + h / 2f)
                c.drawRoundRect(rf, h, h, p)
            }
            return
        }
        for (i in 0 until count) {
            val x = x0 + i * sp
            val near = (1f - Math.abs(progress - i)).coerceIn(0f, 1f)
            p.color = U.mix(0x66FFFFFF, 0xFFFFFFFF.toInt(), near)
            c.drawCircle(x, cy, dp(3f) + dp(1.5f) * near, p)
        }
        if (pal.liquid) { /* tidak ada tambahan */ }
    }
}

package com.prism.launcher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object NotifState {
    private val counts = HashMap<String, Int>()
    var onChange: (() -> Unit)? = null

    fun count(pkg: String): Int = counts[pkg] ?: 0

    fun set(map: Map<String, Int>) {
        counts.clear()
        counts.putAll(map)
        mainHandler.post { onChange?.invoke() }
    }
}

class NotifService : NotificationListenerService() {
    override fun onListenerConnected() { recount() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { recount() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { recount() }

    private fun recount() {
        try {
            val m = HashMap<String, Int>()
            val list = activeNotifications ?: return
            for (n in list) {
                if (n.isOngoing && (n.notification.flags and android.app.Notification.FLAG_FOREGROUND_SERVICE) != 0) continue
                m[n.packageName] = (m[n.packageName] ?: 0) + 1
            }
            NotifState.set(m)
        } catch (e: Exception) { }
    }
}

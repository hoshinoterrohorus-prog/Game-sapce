package com.prism.launcher

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.View
import java.util.Collections
import java.util.WeakHashMap

/** Salinan wallpaper yang sudah di-blur (skala kecil) untuk efek kaca. */
object Backdrop {
    var small: Bitmap? = null
    const val SCALE = 8
    private var building = false

    fun refresh(ctx: Context) {
        if (building) return
        building = true
        val app = ctx.applicationContext
        Thread {
            try {
                build(app)
            } catch (e: Throwable) {
                // tanpa izin wallpaper: kaca memakai gradien beku sebagai cadangan
            }
            building = false
        }.start()
    }

    private fun build(ctx: Context) {
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels / SCALE
        val h = dm.heightPixels / SCALE
        if (w < 8 || h < 8) return
        val wm = WallpaperManager.getInstance(ctx)
        val d = wm.drawable ?: return
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val iw = if (d.intrinsicWidth > 0) d.intrinsicWidth else dm.widthPixels
        val ih = if (d.intrinsicHeight > 0) d.intrinsicHeight else dm.heightPixels
        val s = maxOf(w.toFloat() / iw, h.toFloat() / ih)
        val dw = iw * s
        val dh = ih * s
        d.setBounds(((w - dw) / 2).toInt(), ((h - dh) / 2).toInt(), ((w + dw) / 2).toInt(), ((h + dh) / 2).toInt())
        d.draw(c)
        val r = 1 + Prefs.glassBlur / 25
        val out = U.blur(bmp, r, 3)
        mainHandler.post {
            small = out
            Glass.invalidateAll()
        }
    }
}

object Tilt : SensorEventListener {
    var x = 0f
    var y = 0f
    private var running = false
    private var last = 0L

    fun start(ctx: Context) {
        if (running || !Prefs.glassTilt) return
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
        running = true
    }

    fun stop(ctx: Context) {
        if (!running) return
        (ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager)?.unregisterListener(this)
        running = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        val nx = (-e.values[0] / 9.8f).coerceIn(-1f, 1f)
        val ny = (e.values[1] / 9.8f).coerceIn(-1f, 1f)
        x += (nx - x) * 0.15f
        y += (ny - y) * 0.15f
        val now = System.currentTimeMillis()
        if (now - last > 50) {
            last = now
            Glass.invalidateAll()
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

object Glass {
    val live: MutableSet<GlassDrawable> = Collections.newSetFromMap(WeakHashMap())

    fun invalidateAll() {
        for (g in live.toList()) g.invalidateSelf()
    }
}

/**
 * Panel kaca. Mode Liquid: wallpaper blur + saturasi + kilau pembiasan bergerak mengikuti kemiringan HP.
 * Mode Kaca: wallpaper blur + tint gelap. Mode lain: panel biasa.
 */
class GlassDrawable(
    private val ctx: Context,
    var radius: Float,
    var strength: Float = 1f
) : Drawable() {
    var anchor: View? = null
    var border = true
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path()
    private val loc = IntArray(2)
    private val src = Rect()
    private val rf = RectF()
    private var lastLiquid = false

    init { Glass.live.add(this) }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        val pal = Themes.pal(ctx)
        rf.set(b)
        val rad = minOf(radius, minOf(rf.width(), rf.height()) / 2f)
        path.reset()
        path.addRoundRect(rf, rad, rad, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        val bd = Backdrop.small
        if (pal.glass && bd != null) {
            val a = anchor
            var ox = 0
            var oy = 0
            if (a != null) {
                a.getLocationOnScreen(loc)
                ox = loc[0]
                oy = loc[1]
            }
            val s = Backdrop.SCALE.toFloat()
            src.set(
                ((ox + b.left) / s).toInt().coerceIn(0, bd.width - 1),
                ((oy + b.top) / s).toInt().coerceIn(0, bd.height - 1),
                ((ox + b.right) / s).toInt().coerceIn(1, bd.width),
                ((oy + b.bottom) / s).toInt().coerceIn(1, bd.height)
            )
            if (src.width() < 1) src.right = src.left + 1
            if (src.height() < 1) src.bottom = src.top + 1
            if (pal.liquid != lastLiquid || bmpPaint.colorFilter == null) {
                val cm = ColorMatrix()
                cm.setSaturation(if (pal.liquid) 1.6f else 1.1f)
                if (pal.liquid) {
                    val l = 28f
                    val m = floatArrayOf(1f, 0f, 0f, 0f, l, 0f, 1f, 0f, 0f, l, 0f, 0f, 1f, 0f, l, 0f, 0f, 0f, 1f, 0f)
                    cm.postConcat(ColorMatrix(m))
                }
                bmpPaint.colorFilter = ColorMatrixColorFilter(cm)
                lastLiquid = pal.liquid
            }
            c.drawBitmap(bd, src, b, bmpPaint)
        } else if (pal.glass) {
            // cadangan "beku" bila wallpaper tak terbaca
            fill.shader = LinearGradient(
                0f, rf.top, 0f, rf.bottom,
                intArrayOf(0x55FFFFFF, 0x22FFFFFF), null, Shader.TileMode.CLAMP
            )
            c.drawRect(rf, fill)
            fill.shader = null
        }
        fill.color = U.alpha(pal.panel, 1f)
        fill.alpha = (Color_alpha(pal.panel) * strength).toInt().coerceIn(0, 255)
        c.drawRect(rf, fill)
        if (pal.liquid) {
            val shine = Prefs.glassShine / 100f
            val tx = if (Prefs.glassTilt) Tilt.x else 0f
            val ty = if (Prefs.glassTilt) Tilt.y else 0f
            // lapisan kilau atas -> bawah
            fill.shader = LinearGradient(
                0f, rf.top, 0f, rf.bottom,
                intArrayOf(U.alpha(0xFFFFFFFF.toInt(), 0.34f * shine), U.alpha(0xFFFFFFFF.toInt(), 0.04f * shine), U.alpha(0xFFFFFFFF.toInt(), 0.14f * shine)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(rf, fill)
            // kilau titik yang bergeser saat HP dimiringkan
            val cx = rf.centerX() + tx * rf.width() * 0.32f
            val cy = rf.top + rf.height() * (0.18f + ty * 0.18f)
            val rr = maxOf(rf.width(), rf.height()) * 0.55f
            fill.shader = RadialGradient(
                cx, cy, rr,
                intArrayOf(U.alpha(0xFFFFFFFF.toInt(), 0.42f * shine), 0x00FFFFFF),
                null, Shader.TileMode.CLAMP
            )
            c.drawRect(rf, fill)
            fill.shader = null
        }
        c.restore()
        if (!border) return
        // tepi: terang di sudut kiri atas, redup di kanan bawah
        val sw = maxOf(1f, ctx.dp(if (pal.glass) 1.2f else 0.8f))
        line.strokeWidth = sw
        rf.inset(sw / 2f, sw / 2f)
        if (pal.glass) {
            val hi = if (pal.liquid) 0.95f else 0.55f
            line.shader = LinearGradient(
                rf.left, rf.top, rf.right, rf.bottom,
                intArrayOf(U.alpha(0xFFFFFFFF.toInt(), hi), U.alpha(0xFFFFFFFF.toInt(), 0.10f), U.alpha(0xFFFFFFFF.toInt(), hi * 0.55f)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        } else {
            line.shader = null
            line.color = pal.stroke
        }
        c.drawRoundRect(rf, rad, rad, line)
        line.shader = null
    }

    private fun Color_alpha(c: Int): Int = (c ushr 24) and 255

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

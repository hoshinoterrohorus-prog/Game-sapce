package com.prism.launcher

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Cadangan pengaturan + tata letak ke satu berkas JSON. */
object Backup {
    fun build(): String {
        val o = JSONObject()
        o.put("app", "PrismLauncher")
        o.put("version", 1)
        val p = JSONObject()
        for ((k, v) in Prefs.all) {
            val e = JSONObject()
            when (v) {
                is Int -> { e.put("t", "i"); e.put("v", v) }
                is Boolean -> { e.put("t", "b"); e.put("v", v) }
                is Long -> { e.put("t", "l"); e.put("v", v) }
                is String -> { e.put("t", "s"); e.put("v", v) }
                is Set<*> -> { e.put("t", "h"); e.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            p.put(k, e)
        }
        o.put("prefs", p)
        o.put("layout", Store.exportJson())
        return o.toString(2)
    }

    fun write(ctx: Context, uri: Uri): Boolean = try {
        ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(build().toByteArray()) }
        true
    } catch (e: Exception) { false }

    fun read(ctx: Context, uri: Uri): Boolean = try {
        val txt = ctx.contentResolver.openInputStream(uri)!!.use { String(it.readBytes()) }
        val o = JSONObject(txt)
        if (o.optString("app") != "PrismLauncher") throw IllegalStateException("bukan cadangan Prism")
        val p = o.getJSONObject("prefs")
        Prefs.clearAll()
        val it = p.keys()
        while (it.hasNext()) {
            val k = it.next()
            val e = p.getJSONObject(k)
            when (e.getString("t")) {
                "i" -> Prefs.put(k, e.getInt("v"))
                "b" -> Prefs.put(k, e.getBoolean("v"))
                "l" -> Prefs.put(k, e.getLong("v"))
                "s" -> Prefs.put(k, e.getString("v"))
                "h" -> {
                    val a = e.getJSONArray("v")
                    val s = HashSet<String>()
                    for (i in 0 until a.length()) s.add(a.getString(i))
                    Prefs.setHidden(s)
                }
            }
        }
        Store.importJson(o.getJSONObject("layout"))
        Store.items.removeAll { it.type == T_WIDGET }
        Store.cleanup()
        Store.fit()
        Store.save()
        true
    } catch (e: Exception) { false }
}

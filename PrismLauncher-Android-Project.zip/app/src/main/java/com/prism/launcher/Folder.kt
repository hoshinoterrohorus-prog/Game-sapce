package com.prism.launcher

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class FolderGrid(ctx: Context) : ViewGroup(ctx) {
    var cols = 4
    var cellW = 0
    var cellH = 0

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val rows = (childCount + cols - 1) / cols
        for (i in 0 until childCount) {
            getChildAt(i).measure(MeasureSpec.makeMeasureSpec(cellW, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(cellH, MeasureSpec.EXACTLY))
        }
        setMeasuredDimension(cols * cellW, maxOf(rows, 1) * cellH)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val x = (i % cols) * cellW
            val y = (i / cols) * cellH
            getChildAt(i).layout(x, y, x + cellW, y + cellH)
        }
    }
}

class FolderView(val act: HomeActivity) : FrameLayout(act) {
    var folder: Item? = null
    private val card = LinearLayout(act)
    private val title = TextView(act)
    private val box = FolderGrid(act)
    val showing: Boolean get() = visibility == View.VISIBLE

    init {
        visibility = View.GONE
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.setPadding(dpi(14), dpi(14), dpi(14), dpi(18))
        title.textSize = 18f
        title.gravity = Gravity.CENTER
        title.setPadding(dpi(12), dpi(6), dpi(12), dpi(10))
        title.setOnClickListener { rename() }
        card.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        card.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(card, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val r = android.graphics.Rect()
            card.getHitRect(r)
            if (!r.contains(e.x.toInt(), e.y.toInt())) close()
        }
        return true
    }

    private fun rename() {
        val f = folder ?: return
        val et = EditText(act)
        et.setText(f.title)
        et.setSelection(et.text.length)
        android.app.AlertDialog.Builder(act)
            .setTitle("Nama folder")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                f.title = et.text.toString().trim().ifEmpty { "Folder" }
                Store.save()
                refresh()
                act.rebuildHome()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    fun open(item: Item) {
        folder = item
        visibility = View.VISIBLE
        refresh()
        card.alpha = 0f
        card.scaleX = 0.85f; card.scaleY = 0.85f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration((180 * Prefs.animScale()).toLong()).start()
        act.onFolderState(true)
    }

    fun close() {
        if (!showing) return
        visibility = View.GONE
        folder = null
        act.onFolderState(false)
    }

    fun refresh() {
        val f = folder ?: return
        val pal = Themes.pal(act)
        val g = GlassDrawable(act, dp(28f), Prefs.folderOpacity / 100f)
        g.anchor = card
        card.background = g
        val textCol = if (pal.mode == 0) pal.text else Color.WHITE
        title.setTextColor(textCol)
        title.text = f.title.ifEmpty { "Folder" }
        val kids = f.kids.mapNotNull { AppRepo.find(it) }
        val sw = resources.displayMetrics.widthPixels
        val cols = minOf(Prefs.folderCols, maxOf(2, kids.size))
        val cw = minOf(dpi(84), (sw - dpi(70)) / cols)
        box.cols = cols
        box.cellW = cw
        box.cellH = dpi(96)
        box.removeAllViews()
        val iconPx = minOf(dpi(50), (cw * 0.7f).toInt())
        for (a in kids) {
            val v = IconView(act)
            v.iconPx = iconPx
            v.showLabel = true
            v.labelSp = 11f
            v.textColor = textCol
            v.shadow = pal.mode != 0
            v.setContent(null, a, emptyList(), AppRepo.label(a))
            v.setOnClickListener { act.launchApp(a, v) }
            v.setOnLongClickListener { act.onFolderAppLongPress(v, a, f); true }
            box.addView(v)
        }
        box.requestLayout()
    }
}

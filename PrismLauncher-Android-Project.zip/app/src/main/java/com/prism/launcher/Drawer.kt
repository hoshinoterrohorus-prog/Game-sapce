package com.prism.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.LinearLayout

class DrawerView(val act: HomeActivity) : FrameLayout(act) {
    private val col = LinearLayout(act)
    private val search = EditText(act)
    private val grid = GridView(act)
    private val az = AzBar(act)
    private var list: List<AppInfo> = emptyList()
    private var query = ""
    var progress = 0f
        private set
    var isOpen = false
    private var anim: ValueAnimator? = null
    private val slop = ViewConfiguration.get(act).scaledTouchSlop
    private var downY = 0f
    private var downX = 0f
    private var dragging = false
    private var iconPx = 0
    private var rowH = 0
    private var bg: GlassDrawable? = null

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = list.size + (if (query.isNotEmpty()) 1 else 0)
        override fun getItem(p: Int): Any = if (p < list.size) list[p] else Unit
        override fun getItemId(p: Int): Long = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val v = (cv as? IconView) ?: IconView(act).also {
                it.isClickable = true
            }
            val pal = Themes.pal(act)
            v.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH)
            v.iconPx = iconPx
            v.listMode = Prefs.drawerStyle == 1
            v.showLabel = Prefs.drawerLabels || v.listMode
            v.labelSp = if (v.listMode) 15f else 11f
            v.textColor = if (pal.mode == 0) pal.text else Color.WHITE
            v.shadow = pal.mode != 0
            if (p < list.size) {
                val a = list[p]
                v.setContent(null, a, emptyList(), AppRepo.label(a))
                v.setOnClickListener { act.launchApp(a, v) }
                v.setOnLongClickListener { act.onDrawerLongPress(v, a); true }
            } else {
                v.setContent(null, null, emptyList(), "Cari \"$query\" di web")
                v.setOnClickListener { webSearch(query) }
                v.setOnLongClickListener { false }
            }
            return v
        }
    }

    init {
        visibility = View.GONE
        col.orientation = LinearLayout.VERTICAL
        addView(col, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        addView(az, LayoutParams(dpi(26), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))
        grid.adapter = adapter
        grid.selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.isVerticalScrollBarEnabled = false
        grid.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView?, s: Int) {
                if (s == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) hideKeyboard()
            }
            override fun onScroll(v: AbsListView?, f: Int, c: Int, t: Int) {}
        })
        search.setSingleLine()
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.hint = "Cari aplikasi…"
        search.textSize = 16f
        search.setPadding(dpi(20), 0, dpi(20), 0)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString()?.trim() ?: ""; refresh(false) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) {
                if (list.size == 1) act.launchApp(list[0], null)
                else if (query.isNotEmpty()) webSearch(query)
                true
            } else false
        }
        az.onLetter = { ch -> scrollToLetter(ch) }
        applyPrefs()
    }

    private fun webSearch(q: String) {
        try {
            act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            act.closeAllOverlays()
        } catch (e: Exception) { }
    }

    fun hideKeyboard() {
        val im = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        im.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    private fun scrollToLetter(ch: Char) {
        if (query.isNotEmpty()) return
        var idx = -1
        for (i in list.indices) {
            val f = AppRepo.label(list[i]).trim().firstOrNull()?.uppercaseChar() ?: '#'
            val key = if (f in 'A'..'Z') f else '#'
            if (ch == '#') { if (key == '#') { idx = i; break } }
            else if (key >= ch && key != '#') { idx = i; break }
        }
        if (idx >= 0) grid.setSelection(idx)
    }

    /** Terapkan ulang semua preferensi tampilan laci. */
    fun applyPrefs() {
        val pal = Themes.pal(act)
        val cols = if (Prefs.drawerStyle == 1) 1 else Prefs.drawerCols
        val sw = resources.displayMetrics.widthPixels
        val colW = (sw - dpi(24)) / cols
        iconPx = minOf(dpi(52) * Prefs.drawerIcon / 100, (colW * 0.78f).toInt())
        rowH = if (Prefs.drawerStyle == 1) maxOf(iconPx + dpi(14), dpi(56))
        else iconPx + (if (Prefs.drawerLabels) dpi(34) else dpi(18))
        grid.numColumns = cols
        grid.verticalSpacing = 0
        val g = GlassDrawable(act, 0f, Prefs.drawerOpacity / 100f)
        g.border = false
        g.anchor = this
        bg = g
        background = g
        search.setTextColor(if (pal.mode == 0) pal.text else Color.WHITE)
        search.setHintTextColor(if (pal.mode == 0) 0x88000000.toInt() else 0x99FFFFFF.toInt())
        val sg = GlassDrawable(act, dp(26f), 0.55f)
        sg.anchor = search
        search.background = sg
        col.removeAllViews()
        val sLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(50))
        sLp.setMargins(dpi(16), dpi(8), dpi(16), dpi(8))
        val gLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        gLp.setMargins(dpi(8), 0, dpi(8), 0)
        if (Prefs.searchBar == 0) col.addView(search, sLp)
        col.addView(grid, gLp)
        if (Prefs.searchBar == 1) col.addView(search, sLp)
        search.visibility = if (Prefs.searchBar == 2) View.GONE else View.VISIBLE
        if (Prefs.searchBar == 2 && search.parent == null) col.addView(search, sLp)
        az.visibility = if (Prefs.azBar && Prefs.drawerSort == 0) View.VISIBLE else View.GONE
        az.setTextColor(if (pal.mode == 0) pal.text else Color.WHITE)
        updateInsets()
        refresh(true)
    }

    fun updateInsets() {
        col.setPadding(0, act.insetTop, 0, act.insetBottom)
        (az.layoutParams as? LayoutParams)?.let { it.topMargin = act.insetTop + dpi(64); it.bottomMargin = act.insetBottom + dpi(16) }
    }

    fun refresh(keepScroll: Boolean) {
        val base = AppRepo.sorted()
        list = if (query.isEmpty()) base else {
            val q = query.lowercase()
            val all = AppRepo.apps.filter { !Prefs.hidden().contains(it.key) }
            all.filter { AppRepo.label(it).lowercase().contains(q) || it.pkg.lowercase().contains(q) }
                .sortedBy { !AppRepo.label(it).lowercase().startsWith(q) }
        }
        adapter.notifyDataSetChanged()
        if (!keepScroll) grid.setSelection(0)
    }

    fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        if (progress <= 0.001f) {
            if (visibility != View.GONE) { visibility = View.GONE; if (query.isNotEmpty() || search.hasFocus()) { search.setText(""); hideKeyboard() } }
            translationY = height.toFloat()
        } else {
            if (visibility != View.VISIBLE) { visibility = View.VISIBLE; refresh(true) }
            translationY = (1f - progress) * height
        }
        alpha = 0.35f + 0.65f * progress
        act.onDrawerProgress(progress)
    }

    fun open(focusSearch: Boolean = false) {
        isOpen = true
        animateTo(1f) { if (focusSearch) { search.requestFocus(); val im = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager; im.showSoftInput(search, 0) } }
    }

    fun close() {
        isOpen = false
        hideKeyboard()
        animateTo(0f) {}
    }

    private fun animateTo(t: Float, done: () -> Unit) {
        anim?.cancel()
        if (Prefs.anim == 2) { setProgress(t); done(); return }
        val a = ValueAnimator.ofFloat(progress, t)
        a.duration = (260 * Prefs.animScale()).toLong().coerceAtLeast(60)
        a.addUpdateListener { setProgress(it.animatedValue as Float) }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: android.animation.Animator) { done() }
        })
        anim = a
        a.start()
    }

    private fun atTop(): Boolean {
        if (grid.firstVisiblePosition > 0) return false
        val c = grid.getChildAt(0) ?: return true
        return c.top >= 0
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downY = e.y; downX = e.x; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val dy = e.y - downY
                if (!dragging && dy > slop * 2 && dy > Math.abs(e.x - downX) * 1.5f && atTop()) {
                    dragging = true
                    anim?.cancel()
                    return true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (dragging) { setProgress(1f - (e.y - downY) / height.toFloat() * 1.1f) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    if (progress < 0.78f) close() else { isOpen = true; animateTo(1f) {} }
                }
            }
        }
        return true
    }
}

/** Bar huruf A-Z di sisi kanan laci. */
class AzBar(ctx: Context) : View(ctx) {
    var onLetter: ((Char) -> Unit)? = null
    private val letters = charArrayOf('#', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z')
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cur = -1

    fun setTextColor(c: Int) { p.color = c; invalidate() }

    override fun onDraw(c: Canvas) {
        p.textAlign = Paint.Align.CENTER
        p.textSize = dp(10f)
        val h = height.toFloat() / letters.size
        for (i in letters.indices) {
            p.alpha = if (i == cur) 255 else 170
            c.drawText(letters[i].toString(), width / 2f, h * i + h / 2f - (p.descent() + p.ascent()) / 2f, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val i = (e.y / height * letters.size).toInt().coerceIn(0, letters.size - 1)
                if (i != cur) { cur = i; onLetter?.invoke(letters[i]); invalidate() }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { cur = -1; invalidate() }
        }
        return true
    }
}

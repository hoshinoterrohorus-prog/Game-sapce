package com.prism.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View

/** Ikon aplikasi / folder yang digambar manual (ringan). */
class IconView(ctx: Context) : View(ctx) {
    var item: Item? = null
    var app: AppInfo? = null
    var folderApps: List<AppInfo> = emptyList()
    var listMode = false
    var iconPx = 0
    var showLabel = true
    var labelSp = 11f
    var textColor = Color.WHITE
    var shadow = true
    var glassTile: GlassDrawable? = null

    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rf = RectF()
    private var label = ""

    init {
        isClickable = true
        isLongClickable = true
    }

    fun setContent(it: Item?, a: AppInfo?, kids: List<AppInfo>, title: String) {
        item = it; app = a; folderApps = kids; label = title
        contentDescription = title
        invalidate()
    }

    fun isFolder(): Boolean = item?.type == T_FOLDER

    private fun badgeCount(): Int {
        if (!Prefs.notifDots) return 0
        return if (isFolder()) folderApps.sumOf { NotifState.count(it.pkg) } else app?.let { NotifState.count(it.pkg) } ?: 0
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.9f).scaleY(0.9f).setDuration((90 * Prefs.animScale()).toLong()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration((120 * Prefs.animScale()).toLong()).start()
        }
        return super.onTouchEvent(e)
    }

    fun resetPress() {
        isPressed = false
        animate().cancel()
        scaleX = 1f; scaleY = 1f
    }

    fun snapshot(): Bitmap {
        val b = Bitmap.createBitmap(maxOf(width, 1), maxOf(height, 1), Bitmap.Config.ARGB_8888)
        draw(Canvas(b))
        return b
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (iconPx <= 0) return
        tp.textSize = context.dp(labelSp)
        tp.color = textColor
        if (shadow) tp.setShadowLayer(context.dp(2f), 0f, context.dp(1f), 0xAA000000.toInt()) else tp.clearShadowLayer()
        val lh = if (showLabel) (tp.descent() - tp.ascent()) else 0f
        val gap = if (showLabel) context.dp(4f) else 0f
        val ix: Float
        val iy: Float
        if (listMode) {
            ix = context.dp(14f)
            iy = (h - iconPx) / 2f
        } else {
            val total = iconPx + gap + lh
            iy = (h - total) / 2f
            ix = (w - iconPx) / 2f
        }
        if (isFolder()) drawFolder(c, ix, iy) else {
            val a = app
            if (a != null) c.drawBitmap(IconFactory.get(context, a, iconPx), ix, iy, p)
        }
        val n = badgeCount()
        if (n > 0) {
            val r = context.dp(5.5f)
            val bx = ix + iconPx - r * 0.4f
            val by = iy + r * 0.4f
            p.color = Themes.pal(context).accent
            p.style = Paint.Style.FILL
            c.drawCircle(bx, by, r, p)
            p.color = Color.WHITE
            p.style = Paint.Style.STROKE
            p.strokeWidth = context.dp(1.2f)
            c.drawCircle(bx, by, r, p)
            p.style = Paint.Style.FILL
            if (Prefs.notifCount) {
                val t = TextPaint(Paint.ANTI_ALIAS_FLAG)
                t.color = Color.WHITE
                t.textSize = r * 1.25f
                t.textAlign = Paint.Align.CENTER
                c.drawText(if (n > 9) "9+" else n.toString(), bx, by + r * 0.45f, t)
            }
        }
        if (showLabel) {
            val txt = TextUtils.ellipsize(label, tp, if (listMode) w - ix - iconPx - context.dp(30f) else w - context.dp(6f), TextUtils.TruncateAt.END).toString()
            if (listMode) {
                tp.textAlign = Paint.Align.LEFT
                c.drawText(txt, ix + iconPx + context.dp(16f), h / 2f - (tp.descent() + tp.ascent()) / 2f, tp)
            } else {
                tp.textAlign = Paint.Align.CENTER
                c.drawText(txt, w / 2f, iy + iconPx + gap - tp.ascent(), tp)
            }
        }
    }

    private fun drawFolder(c: Canvas, ix: Float, iy: Float) {
        val s = iconPx.toFloat()
        rf.set(ix, iy, ix + s, iy + s)
        // plat kaca folder
        val g = glassTile ?: GlassDrawable(context, s * 0.3f, 0.9f).also { glassTile = it; it.anchor = this }
        val shapeR = when (Prefs.iconShape) { 1 -> s / 2; 5 -> s * 0.08f; else -> s * 0.3f }
        g.radius = shapeR
        g.setBounds(ix.toInt(), iy.toInt(), (ix + s).toInt(), (iy + s).toInt())
        g.draw(c)
        val apps = folderApps
        if (Prefs.folderStyle == 1) {
            // tumpukan miring
            val n = minOf(3, apps.size)
            for (k in n - 1 downTo 0) {
                val sz = (s * 0.52f).toInt()
                val bm = IconFactory.get(context, apps[k], sz)
                c.save()
                c.translate(ix + s * (0.24f + 0.06f * k), iy + s * (0.2f + 0.06f * k))
                c.rotate((k - 1) * 9f, sz / 2f, sz / 2f)
                c.drawBitmap(bm, 0f, 0f, p)
                c.restore()
            }
        } else {
            val sz = (s * 0.36f).toInt()
            val pad = s * 0.1f
            val gapp = (s - 2 * pad - 2 * sz) / 1f
            for (k in 0 until minOf(4, apps.size)) {
                val cx = ix + pad + (k % 2) * (sz + gapp)
                val cy = iy + pad + (k / 2) * (sz + gapp)
                c.drawBitmap(IconFactory.get(context, apps[k], sz), cx, cy, p)
            }
        }
    }
}

package com.prism.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class Entry(val label: String, val icon: Bitmap? = null, val danger: Boolean = false, val action: () -> Unit)

/** Lapisan menu kaca (tekan lama ikon / area kosong). */
class PopupLayer(ctx: Context) : FrameLayout(ctx) {
    private var card: LinearLayout? = null
    var onDismiss: (() -> Unit)? = null

    init { visibility = View.GONE }

    val showing: Boolean get() = visibility == View.VISIBLE

    fun dismiss() {
        if (!showing) return
        removeAllViews()
        card = null
        visibility = View.GONE
        onDismiss?.invoke()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) { dismiss(); return true }
        return true
    }

    /** anchor dalam koordinat layar-penuh (sama dengan koordinat lapisan ini). */
    fun show(anchor: RectF, entries: List<Entry>, insetTop: Int, insetBottom: Int) {
        removeAllViews()
        val pal = Themes.pal(context)
        val c = LinearLayout(context)
        c.orientation = LinearLayout.VERTICAL
        val gd = GlassDrawable(context, dp(20f), 1f)
        gd.anchor = c
        c.background = gd
        c.setPadding(dpi(6), dpi(6), dpi(6), dpi(6))
        val textCol = if (pal.liquid || pal.glass) Color.WHITE else pal.text
        for (en in entries) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dpi(14), 0, dpi(18), 0)
            if (en.icon != null) {
                val iv = ImageView(context)
                iv.setImageBitmap(en.icon)
                row.addView(iv, LinearLayout.LayoutParams(dpi(24), dpi(24)).also { it.rightMargin = dpi(12) })
            }
            val tv = TextView(context)
            tv.text = en.label
            tv.setTextColor(if (en.danger) 0xFFFF6B6B.toInt() else textCol)
            tv.textSize = 15f
            tv.typeface = Typeface.DEFAULT_BOLD.let { Typeface.create(Typeface.DEFAULT, Typeface.NORMAL) }
            row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            row.setOnClickListener { dismiss(); en.action() }
            row.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.setBackgroundColor(U.alpha(Color.WHITE, 0.14f))
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.setBackgroundColor(Color.TRANSPARENT)
                }
                false
            }
            c.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(46)))
        }
        card = c
        val lp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        addView(c, lp)
        visibility = View.VISIBLE
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        c.measure(MeasureSpec.makeMeasureSpec(sw - dpi(24), MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(sh, MeasureSpec.AT_MOST))
        val cw = c.measuredWidth
        val ch = c.measuredHeight
        var x = (anchor.centerX() - cw / 2f).coerceIn(dp(12f), sw - cw - dp(12f))
        var y = anchor.top - ch - dp(8f)
        if (y < insetTop + dp(8f)) y = anchor.bottom + dp(8f)
        if (y + ch > sh - insetBottom - dp(8f)) y = (sh - insetBottom - ch - dp(8f))
        c.translationX = x
        c.translationY = y
        c.alpha = 0f
        c.scaleX = 0.9f; c.scaleY = 0.9f
        c.pivotX = cw / 2f; c.pivotY = if (y < anchor.top) ch.toFloat() else 0f
        c.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration((140 * Prefs.animScale()).toLong()).start()
    }
}

package com.prism.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast

/** Akar layar: saat seret-lepas aktif, semua sentuhan dialihkan ke DragController. */
class RootLayout(val act: HomeActivity) : FrameLayout(act) {
    var lastX = 0f
    var lastY = 0f

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        lastX = e.x; lastY = e.y
        if (act.drag.active) {
            when (e.actionMasked) {
                MotionEvent.ACTION_MOVE -> act.drag.onMove(e.x, e.y)
                MotionEvent.ACTION_UP -> act.drag.onUp(e.x, e.y)
                MotionEvent.ACTION_CANCEL -> act.drag.cancel()
            }
            return true
        }
        return super.dispatchTouchEvent(e)
    }
}

class HomeActivity : Activity() {
    companion object {
        const val REQ_BIND = 11
        const val REQ_CONFIG = 12
        const val REQ_ADMIN = 13
    }

    var insetTop = 0
    var insetBottom = 0

    lateinit var root: RootLayout
    lateinit var pager: HomePager
    lateinit var dock: FrameLayout
    lateinit var dockCells: CellLayout
    lateinit var dragLayer: FrameLayout
    lateinit var zones: ZoneBar
    lateinit var popup: PopupLayer
    lateinit var drag: DragController
    private lateinit var indicator: PageIndicator
    private lateinit var drawer: DrawerView
    private lateinit var folderView: FolderView
    private lateinit var host: LHost
    private lateinit var awm: AppWidgetManager

    private var lastRev = -1
    private var resumed = false
    private var pendingWidget = -1
    private var rebuildQueued = false
    private val dockH get() = dpi(84)
    private val indH get() = dpi(22)

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            mainHandler.removeCallbacks(pkgReload)
            mainHandler.postDelayed(pkgReload, 600)
        }
    }
    private val pkgReload = Runnable {
        AppRepo.load(this)
        IconFactory.clear()
        Store.cleanup()
        Store.save()
        if (::drawer.isInitialized) drawer.refresh(true)
        rebuildHome()
        if (folderView.showing) folderView.refresh()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        AppRepo.load(this)
        Store.load(this)
        awm = AppWidgetManager.getInstance(this)
        host = LHost(this)
        Store.widgetCleanup = { id -> try { host.deleteAppWidgetId(id) } catch (e: Exception) { } }

        root = RootLayout(this)
        pager = HomePager(this)
        indicator = PageIndicator(this)
        dock = FrameLayout(this)
        dockCells = CellLayout(this)
        dock.addView(dockCells, FrameLayout.LayoutParams(-1, -1))
        zones = ZoneBar(this)
        zones.visibility = View.GONE
        drawer = DrawerView(this)
        folderView = FolderView(this)
        popup = PopupLayer(this)
        popup.visibility = View.GONE
        dragLayer = FrameLayout(this)
        drag = DragController(this)

        root.addView(pager, FrameLayout.LayoutParams(-1, -1))
        root.addView(indicator, FrameLayout.LayoutParams(-1, indH, Gravity.BOTTOM))
        root.addView(dock, FrameLayout.LayoutParams(-1, dockH, Gravity.BOTTOM))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        root.addView(folderView, FrameLayout.LayoutParams(-1, -1))
        root.addView(zones, FrameLayout.LayoutParams(-1, dpi(64), Gravity.TOP))
        root.addView(popup, FrameLayout.LayoutParams(-1, -1))
        root.addView(dragLayer, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        setupWindow()
        setupInsets()
        setupPager()

        NotifState.onChange = { refreshBadges() }
        popup.onDismiss = { }

        // laci harus pernah diukur supaya translasi awal benar
        root.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            var done = false
            override fun onLayoutChange(v: View?, l: Int, t: Int, r: Int, bt: Int, ol: Int, ot: Int, or2: Int, ob: Int) {
                if (!done && r - l > 0) { done = true; drawer.setProgress(0f) }
            }
        })

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addAction(Intent.ACTION_PACKAGE_REPLACED)
        f.addDataScheme("package")
        registerReceiver(pkgReceiver, f)

        if (Build.VERSION.SDK_INT in 23..32 && checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            try { requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 77) } catch (e: Exception) { }
        }
        applyAll()
    }

    // ---------------------------------------------------------------- jendela
    @Suppress("DEPRECATION")
    private fun setupWindow() {
        val w = window
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false)
        }
        w.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (Build.VERSION.SDK_INT >= 29) {
            try { w.isNavigationBarContrastEnforced = false } catch (e: Throwable) { }
        }
    }

    @Suppress("DEPRECATION")
    private fun setupInsets() {
        root.setOnApplyWindowInsetsListener { _, ins ->
            val t = ins.systemWindowInsetTop
            val bt = ins.systemWindowInsetBottom
            if (t != insetTop || bt != insetBottom) {
                insetTop = t; insetBottom = bt
                layoutChrome()
                drawer.updateInsets()
            }
            ins
        }
        root.requestApplyInsets()
    }

    private fun layoutChrome() {
        val pal = Themes.pal(this)
        val showDock = Prefs.showDock
        val style = Prefs.dockStyle
        val dockBottom = if (style == 1) 0 else dpi(8)
        val dockSide = if (style == 1) 0 else dpi(10)
        val dockPadBottom = if (style == 1) insetBottom else 0

        dock.visibility = if (showDock) View.VISIBLE else View.GONE
        val dlp = dock.layoutParams as FrameLayout.LayoutParams
        dlp.leftMargin = dockSide; dlp.rightMargin = dockSide
        dlp.bottomMargin = if (style == 1) 0 else insetBottom + dockBottom
        dlp.height = dockH + dockPadBottom
        dock.layoutParams = dlp
        dock.setPadding(0, 0, 0, dockPadBottom)
        dock.background = when (style) {
            2 -> null
            1 -> GlassDrawable(this, 0f, Prefs.dockOpacity / 100f).also { it.anchor = dock; it.border = false }
            else -> GlassDrawable(this, dp(30f), Prefs.dockOpacity / 100f).also { it.anchor = dock }
        }
        dockCells.cols = Prefs.dockCount
        dockCells.rows = 1
        dockCells.padH = dpi(6)
        dockCells.padV = 0

        val ilp = indicator.layoutParams as FrameLayout.LayoutParams
        ilp.bottomMargin = if (showDock) {
            (if (style == 1) dockH + insetBottom else insetBottom + dockBottom + dockH) + dpi(2)
        } else insetBottom + dpi(8)
        indicator.layoutParams = ilp

        val plp = pager.layoutParams as FrameLayout.LayoutParams
        plp.topMargin = insetTop
        plp.bottomMargin = ilp.bottomMargin + indH
        pager.layoutParams = plp

        val zlp = zones.layoutParams as FrameLayout.LayoutParams
        zlp.topMargin = insetTop + dpi(6)
        zones.layoutParams = zlp
        indicator.style = Prefs.indicator
        if (pal.mode == 0) indicator.alpha = 0.9f
    }

    // ---------------------------------------------------------------- gestur
    private fun setupPager() {
        pager.onPageChanged = { p -> indicator.progress = p.toFloat() }
        pager.onScrollProgress = { p -> indicator.progress = p }
        pager.onVDrag = { dy ->
            if (dy < 0 && (Prefs.swipeUp == 0 || Prefs.swipeUp == 1)) {
                drawer.setProgress((-dy / (root.height * 0.55f)).coerceIn(0f, 1f))
            }
        }
        pager.onVRelease = { dy, vy ->
            if (dy < 0 && (Prefs.swipeUp == 0 || Prefs.swipeUp == 1)) {
                if (drawer.progress > 0.3f || vy < -900f) drawer.open(Prefs.swipeUp == 1) else { drawer.close() }
            } else if (dy > dp(70f) || vy > 900f) {
                when (Prefs.swipeDown) {
                    0 -> expandNotifications()
                    1 -> drawer.open(true)
                }
                if (drawer.progress > 0f && !drawer.isOpen) drawer.close()
            } else if (drawer.progress > 0f && !drawer.isOpen) {
                drawer.close()
            }
        }
        pager.onLongPressEmpty = { if (Prefs.longPressMenu) showEmptyMenu() }
        pager.onDoubleTap = {
            when (Prefs.doubleTap) {
                1 -> lockScreen()
                2 -> drawer.open(false)
            }
        }
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            sb.javaClass.getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Throwable) {
            Toast.makeText(this, "Tidak bisa membuka panel notifikasi dari sini", Toast.LENGTH_SHORT).show()
        }
    }

    private fun lockScreen() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val cn = ComponentName(this, AdminReceiver::class.java)
        if (dpm.isAdminActive(cn)) {
            try { dpm.lockNow() } catch (e: Exception) { }
        } else {
            try {
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
                i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Dibutuhkan agar ketuk dua kali bisa mengunci layar.")
                startActivityForResult(i, REQ_ADMIN)
            } catch (e: Exception) { }
        }
    }

    // ---------------------------------------------------------------- beranda
    private fun cellMetrics(container: Int): Pair<Float, Float> {
        val dm = resources.displayMetrics
        return if (container == C_DOCK) {
            Pair((dm.widthPixels - dpi(20) - dpi(12)) / Prefs.dockCount.toFloat(), dockH.toFloat())
        } else {
            val ph = dm.heightPixels - insetTop - insetBottom - indH - (if (Prefs.showDock) dockH + dpi(16) else dpi(8))
            Pair((dm.widthPixels - 2 * dpi(Prefs.padH)) / Prefs.cols.toFloat(), (ph - 2 * dpi(Prefs.padV)) / Prefs.rows.toFloat())
        }
    }

    fun rebuildHome() {
        val pal = Themes.pal(this)
        val keepPage = pager.current
        pager.removeAllViews()
        dockCells.removeAllViews()
        if (Store.pages < 1) Store.pages = 1
        val textCol = Color.WHITE
        for (p in 0 until Store.pages) {
            val cl = CellLayout(this)
            cl.cols = Prefs.cols
            cl.rows = Prefs.rows
            cl.padH = dpi(Prefs.padH)
            cl.padV = dpi(Prefs.padV)
            pager.addView(cl)
            for (it in Store.on(C_HOME, p)) addItemView(cl, it, C_HOME, textCol)
        }
        for (it in Store.on(C_DOCK, 0)) addItemView(dockCells, it, C_DOCK, textCol)
        indicator.count = Store.pages
        val cur = keepPage.coerceIn(0, Store.pages - 1)
        pager.current = cur
        indicator.progress = cur.toFloat()
        pager.requestLayout()
        pager.scrollTo(cur * maxOf(pager.width, 0), 0)
        indicator.visibility = if (Store.pages > 1) View.VISIBLE else View.INVISIBLE
        if (pal.mode == 0) indicator.alpha = 0.95f
    }

    private fun addItemView(cl: CellLayout, it: Item, container: Int, textCol: Int) {
        if (drag.active && drag.item === it) return
        val v: View = when (it.type) {
            T_APP -> {
                val a = AppRepo.find(it.key) ?: return
                makeIcon(it, a, emptyList(), AppRepo.label(a), container, textCol).also { iv ->
                    iv.setOnClickListener { launchApp(a, iv) }
                }
            }
            T_FOLDER -> {
                val kids = it.kids.mapNotNull { k -> AppRepo.find(k) }
                if (kids.isEmpty()) return
                makeIcon(it, null, kids, it.title.ifEmpty { "Folder" }, container, textCol).also { iv ->
                    iv.setOnClickListener { _ -> openFolder(it) }
                }
            }
            else -> {
                val info = try { awm.getAppWidgetInfo(it.widgetId) } catch (e: Exception) { null }
                if (info == null) return
                val hv = try { host.createView(this, it.widgetId, info) } catch (e: Exception) { return }
                (hv as? LWidgetView)?.onLong = { w -> onItemLongPress(w, it) }
                hv
            }
        }
        val lp = CellLP(it)
        lp.cx = it.x; lp.cy = it.y; lp.sx = it.sx; lp.sy = it.sy
        cl.addView(v, lp)
    }

    private fun makeIcon(it: Item, a: AppInfo?, kids: List<AppInfo>, title: String, container: Int, textCol: Int): IconView {
        val iv = IconView(this)
        val cm = cellMetrics(container)
        val base = dpi(58) * Prefs.iconScale / 100
        iv.iconPx = minOf(base, (cm.first * 0.86f).toInt(), (cm.second * 0.72f).toInt())
        iv.showLabel = Prefs.showLabels && container == C_HOME
        iv.labelSp = Prefs.labelSize.toFloat()
        iv.textColor = textCol
        iv.shadow = true
        iv.setContent(it, a, kids, title)
        iv.setOnLongClickListener { _ -> onItemLongPress(iv, it); true }
        return iv
    }

    private fun openFolder(it: Item) {
        popup.dismiss()
        folderView.open(it)
    }

    private fun refreshBadges() {
        for (i in 0 until pager.childCount) invalidateTree(pager.getChildAt(i))
        invalidateTree(dockCells)
        if (drawer.isOpen) drawer.refresh(true)
        if (folderView.showing) folderView.refresh()
    }

    private fun invalidateTree(v: View) {
        if (v is ViewGroup) for (i in 0 until v.childCount) invalidateTree(v.getChildAt(i))
        v.invalidate()
    }

    // ---------------------------------------------------------------- menu
    private fun rectOf(v: View): RectF {
        val a = IntArray(2); v.getLocationOnScreen(a)
        val r = IntArray(2); root.getLocationOnScreen(r)
        val x = (a[0] - r[0]).toFloat()
        val y = (a[1] - r[1]).toFloat()
        return RectF(x, y, x + v.width, y + v.height)
    }

    private fun showMenu(anchor: RectF, entries: List<Entry>) {
        popup.show(anchor, entries, insetTop, insetBottom)
    }

    private fun shortcutEntries(a: AppInfo): List<Entry> {
        if (Build.VERSION.SDK_INT < 25) return emptyList()
        try {
            val la = getSystemService(LauncherApps::class.java) ?: return emptyList()
            if (!la.hasShortcutHostPermission()) return emptyList()
            val q = LauncherApps.ShortcutQuery()
            q.setPackage(a.pkg)
            q.setActivity(a.cn)
            q.setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
            val list = la.getShortcuts(q, android.os.Process.myUserHandle()) ?: return emptyList()
            return list.filter { it.isEnabled }.take(4).map { s ->
                Entry((s.shortLabel ?: s.id).toString()) {
                    try { la.startShortcut(s, null, null) } catch (e: Exception) { }
                }
            }
        } catch (e: Throwable) {
            return emptyList()
        }
    }

    fun onItemLongPress(v: View, it: Item) {
        performHaptic()
        val locked = Prefs.lockDesktop
        if (!locked) {
            val x = root.lastX; val y = root.lastY
            drag.start(v, it, it.key, null, x, y)
        }
        val entries = ArrayList<Entry>()
        when (it.type) {
            T_APP -> {
                val a = AppRepo.find(it.key)
                if (a != null) {
                    entries.addAll(shortcutEntries(a))
                    entries.add(Entry("Info aplikasi") { AppRepo.appInfoScreen(this, a.pkg) })
                    entries.add(Entry("Ganti nama") { renameApp(a) })
                    entries.add(Entry("Sembunyikan dari laci") { hideApp(a) })
                    entries.add(Entry("Copot pemasangan", danger = true) { AppRepo.uninstall(this, a.pkg) })
                }
                if (!locked) entries.add(Entry("Hapus dari beranda", danger = true) { Store.items.remove(it); Store.save(); rebuildHome() })
            }
            T_FOLDER -> {
                entries.add(Entry("Ganti nama") { renameFolder(it) })
                if (!locked) {
                    entries.add(Entry("Bongkar folder") { dissolve(it) })
                    entries.add(Entry("Hapus folder", danger = true) { Store.items.remove(it); Store.save(); rebuildHome() })
                }
            }
            else -> {
                if (!locked) {
                    if (it.sx < Prefs.cols) entries.add(Entry("Lebar +") { resizeWidget(it, 1, 0) })
                    if (it.sx > 1) entries.add(Entry("Lebar −") { resizeWidget(it, -1, 0) })
                    if (it.sy < Prefs.rows) entries.add(Entry("Tinggi +") { resizeWidget(it, 0, 1) })
                    if (it.sy > 1) entries.add(Entry("Tinggi −") { resizeWidget(it, 0, -1) })
                    entries.add(Entry("Hapus widget", danger = true) { Store.removeWidget(it); Store.save(); rebuildHome() })
                }
            }
        }
        if (entries.isNotEmpty()) showMenu(rectOf(v), entries)
    }

    fun onDrawerLongPress(v: IconView, a: AppInfo) {
        performHaptic()
        drag.start(v, null, a.key, null, root.lastX, root.lastY)
        val entries = ArrayList<Entry>()
        entries.addAll(shortcutEntries(a))
        entries.add(Entry("Tambah ke beranda") { addToHome(a) })
        entries.add(Entry("Info aplikasi") { AppRepo.appInfoScreen(this, a.pkg) })
        entries.add(Entry("Ganti nama") { renameApp(a) })
        entries.add(Entry("Sembunyikan dari laci") { hideApp(a) })
        entries.add(Entry("Copot pemasangan", danger = true) { AppRepo.uninstall(this, a.pkg) })
        showMenu(rectOf(v), entries)
    }

    fun onFolderAppLongPress(v: View, a: AppInfo, folder: Item) {
        performHaptic()
        drag.start(v, null, a.key, folder, root.lastX, root.lastY)
        val entries = ArrayList<Entry>()
        entries.add(Entry("Keluarkan dari folder") {
            folder.kids.remove(a.key)
            addToHome(a)
            Store.cleanup(); Store.save()
            folderView.close()
            rebuildHome()
        })
        entries.add(Entry("Info aplikasi") { AppRepo.appInfoScreen(this, a.pkg) })
        entries.add(Entry("Copot pemasangan", danger = true) { AppRepo.uninstall(this, a.pkg) })
        showMenu(rectOf(v), entries)
    }

    private fun showEmptyMenu() {
        performHaptic()
        val dm = resources.displayMetrics
        val cx = dm.widthPixels / 2f
        val cy = dm.heightPixels / 2f
        val entries = ArrayList<Entry>()
        entries.add(Entry("Widget") { showWidgetPicker() })
        entries.add(Entry("Wallpaper") { openWallpaper() })
        entries.add(Entry("Pengaturan Prism") { openSettings() })
        if (!Prefs.lockDesktop) {
            if (Store.pages < 12) entries.add(Entry("Tambah halaman") { Store.pages++; Store.save(); rebuildHome(); pager.setPage(Store.pages - 1, true) })
            val cur = pager.current
            if (Store.pages > 1 && Store.on(C_HOME, cur).isEmpty()) {
                entries.add(Entry("Hapus halaman ini", danger = true) {
                    for (i in Store.items) if (i.container == C_HOME && i.page > cur) i.page--
                    Store.pages--
                    Store.save(); rebuildHome()
                })
            }
        }
        showMenu(RectF(cx, cy, cx, cy), entries)
    }

    private fun openSettings() {
        closeAllOverlays()
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun openWallpaper() {
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak ada aplikasi pemilih wallpaper", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renameApp(a: AppInfo) {
        val et = EditText(this)
        et.setText(AppRepo.label(a))
        et.setSelection(et.text.length)
        AlertDialog.Builder(this).setTitle("Ganti nama").setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isEmpty() || t == a.label) Prefs.remove("lbl_" + a.key) else Prefs.put("lbl_" + a.key, t)
                drawer.refresh(true)
                rebuildHome()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun renameFolder(f: Item) {
        val et = EditText(this)
        et.setText(f.title)
        et.setSelection(et.text.length)
        AlertDialog.Builder(this).setTitle("Nama folder").setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                f.title = et.text.toString().trim().ifEmpty { "Folder" }
                Store.save(); rebuildHome()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun hideApp(a: AppInfo) {
        val h = Prefs.hidden()
        h.add(a.key)
        Prefs.setHidden(h)
        drawer.refresh(true)
        Toast.makeText(this, AppRepo.label(a) + " disembunyikan (atur di Pengaturan)", Toast.LENGTH_SHORT).show()
    }

    private fun addToHome(a: AppInfo) {
        if (Store.items.any { it.type == T_APP && it.key == a.key && it.container == C_HOME }) {
            Toast.makeText(this, "Sudah ada di beranda", Toast.LENGTH_SHORT).show()
            return
        }
        val n = Item(Store.newId(), T_APP, C_HOME, pager.current, 0, 0)
        n.key = a.key
        Store.place(n, pager.current)
        Store.save()
        rebuildHome()
    }

    private fun dissolve(f: Item) {
        Store.items.remove(f)
        for (k in f.kids) {
            val n = Item(Store.newId(), T_APP, C_HOME, f.page, 0, 0)
            n.key = k
            Store.place(n, f.page)
        }
        Store.cleanup(); Store.save(); rebuildHome()
    }

    private fun resizeWidget(w: Item, dx: Int, dy: Int) {
        val nx = (w.sx + dx).coerceIn(1, Prefs.cols)
        val ny = (w.sy + dy).coerceIn(1, Prefs.rows)
        val px = if (w.x + nx > Prefs.cols) Prefs.cols - nx else w.x
        val py = if (w.y + ny > Prefs.rows) Prefs.rows - ny else w.y
        if (Store.isFree(w.container, w.page, px, py, nx, ny, w)) {
            w.sx = nx; w.sy = ny; w.x = px; w.y = py
            Store.save(); rebuildHome()
        } else {
            Toast.makeText(this, "Tidak muat di sini", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- widget
    private fun showWidgetPicker() {
        val list = try { awm.installedProviders } catch (e: Exception) { emptyList<AppWidgetProviderInfo>() }
        val pm = packageManager
        val rows = list.map { Pair(it, try { it.loadLabel(pm) ?: it.provider.packageName } catch (e: Exception) { it.provider.packageName }) }
            .sortedBy { it.second.lowercase() }
        if (rows.isEmpty()) { Toast.makeText(this, "Tidak ada widget tersedia", Toast.LENGTH_SHORT).show(); return }
        val names = rows.map { r ->
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(r.first.provider.packageName, 0)).toString() } catch (e: Exception) { "" }
            r.second + (if (app.isNotEmpty() && app != r.second) "  ·  $app" else "")
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Pilih widget")
            .setItems(names) { _, i -> addWidget(rows[i].first) }
            .setNegativeButton("Batal", null).show()
    }

    private fun addWidget(info: AppWidgetProviderInfo) {
        try {
            val id = host.allocateAppWidgetId()
            pendingWidget = id
            val ok = awm.bindAppWidgetIdIfAllowed(id, info.provider)
            if (ok) configureOrPlace(id) else {
                val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                startActivityForResult(i, REQ_BIND)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Widget gagal ditambahkan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun configureOrPlace(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info != null && info.configure != null) {
            try { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null); return } catch (e: Exception) { }
        }
        placeWidget(id)
    }

    private fun placeWidget(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info == null) { host.deleteAppWidgetId(id); return }
        val cm = cellMetrics(C_HOME)
        val sx = Math.ceil((info.minWidth / cm.first).toDouble()).toInt().coerceIn(1, Prefs.cols)
        val sy = Math.ceil((info.minHeight / cm.second).toDouble()).toInt().coerceIn(1, Prefs.rows)
        val it = Item(Store.newId(), T_WIDGET, C_HOME, pager.current, 0, 0)
        it.sx = sx; it.sy = sy; it.widgetId = id; it.provider = info.provider.flattenToString()
        Store.place(it, pager.current)
        Store.save()
        rebuildHome()
        pager.setPage(it.page.coerceIn(0, Store.pages - 1), true)
        pendingWidget = -1
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        when (req) {
            REQ_BIND -> {
                val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidget) ?: pendingWidget
                if (res == RESULT_OK && id != -1) configureOrPlace(id) else if (id != -1) { host.deleteAppWidgetId(id); pendingWidget = -1 }
            }
            REQ_CONFIG -> {
                val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidget) ?: pendingWidget
                if (res == RESULT_OK && id != -1) placeWidget(id) else if (id != -1) { host.deleteAppWidgetId(id); pendingWidget = -1 }
            }
            REQ_ADMIN -> if (res == RESULT_OK) lockScreen()
        }
    }

    // ---------------------------------------------------------------- hook dari komponen
    fun launchApp(a: AppInfo, v: View?) {
        AppRepo.launch(this, a, v)
        mainHandler.postDelayed({ closeAllOverlays() }, 380)
    }

    fun closeAllOverlays() {
        popup.dismiss()
        if (folderView.showing) folderView.close()
        if (drawer.isOpen || drawer.progress > 0f) drawer.close()
    }

    fun performHaptic() {
        try { root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) } catch (e: Exception) { }
    }

    fun onDragBegan(fromFolder: Boolean, fromDrawer: Boolean) {
        pager.locked = true
        if (fromDrawer) drawer.close()
        if (fromFolder) folderView.close()
    }

    fun onDragEnded() {
        pager.locked = false
    }

    fun onFolderState(open: Boolean) {
        val a = if (open) 0.25f else 1f
        pager.animate().alpha(a).setDuration((160 * Prefs.animScale()).toLong()).start()
        dock.animate().alpha(a).setDuration((160 * Prefs.animScale()).toLong()).start()
        indicator.animate().alpha(a).setDuration((160 * Prefs.animScale()).toLong()).start()
    }

    fun onDrawerProgress(p: Float) {
        val a = 1f - 0.85f * p
        pager.alpha = a
        dock.alpha = a
        indicator.alpha = a
        if (Build.VERSION.SDK_INT >= 31) {
            try { window.setBackgroundBlurRadius(if (Prefs.drawerBlur) (p * dpi(36)).toInt() else 0) } catch (e: Throwable) { }
        }
    }

    // ---------------------------------------------------------------- tema & pengaturan
    private fun applyAll() {
        lastRev = Prefs.rev
        requestedOrientation = if (Prefs.allowRotate) ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        if (Prefs.hideStatus) window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN) else window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        Store.fit()
        Store.save()
        IconFactory.clear()
        Backdrop.refresh(this)
        layoutChrome()
        pager.allowVertical = Prefs.swipeUp != 2 || Prefs.swipeDown != 2
        drawer.applyPrefs()
        drawer.updateInsets()
        drawer.refresh(true)
        folderView.refresh()
        rebuildHome()
        Glass.invalidateAll()
        if (Prefs.glassTilt && Themes.pal(this).glass) Tilt.start(this) else Tilt.stop(this)
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        host.startListening()
        if (Prefs.rev != lastRev) applyAll() else Backdrop.refresh(this)
        if (Prefs.glassTilt && Themes.pal(this).glass) Tilt.start(this)
    }

    override fun onPause() {
        resumed = false
        Tilt.stop(this)
        try { host.stopListening() } catch (e: Exception) { }
        popup.dismiss()
        if (drag.active) drag.cancel()
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            val clean = !popup.showing && !folderView.showing && !drawer.isOpen && pager.current == 0
            if (drag.active) drag.cancel()
            closeAllOverlays()
            if (pager.current != 0) pager.setPage(0, true)
            if (clean && resumed && Prefs.homeBtn == 1) drawer.open(false)
        }
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        applyAll()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        when {
            popup.showing -> popup.dismiss()
            folderView.showing -> folderView.close()
            drawer.isOpen -> drawer.close()
            pager.current != 0 -> pager.setPage(0, true)
            else -> { }
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        NotifState.onChange = null
        Tilt.stop(this)
        super.onDestroy()
    }
}

package com.prism.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.TextPaint
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView

/** Papan zona jatuh di atas layar: Hapus / Info / Copot. */
class ZoneBar(ctx: Context) : View(ctx) {
    var labels: List<String> = emptyList()
    var hover = -1
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()

    override fun onDraw(c: Canvas) {
        if (labels.isEmpty()) return
        val w = width.toFloat() / labels.size
        val pal = Themes.pal(context)
        for (i in labels.indices) {
            rf.set(i * w + dp(6f), dp(4f), (i + 1) * w - dp(6f), height - dp(4f))
            val on = i == hover
            p.style = Paint.Style.FILL
            p.color = if (on) U.alpha(if (labels[i] == "Hapus" || labels[i] == "Copot") 0xFFFF4D4D.toInt() else pal.accent, 0.85f) else 0x66101018
            c.drawRoundRect(rf, dp(18f), dp(18f), p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = dp(1.2f)
            p.color = 0x88FFFFFF.toInt()
            c.drawRoundRect(rf, dp(18f), dp(18f), p)
            tp.color = Color.WHITE
            tp.textSize = dp(14f)
            tp.textAlign = Paint.Align.CENTER
            c.drawText(labels[i], rf.centerX(), rf.centerY() - (tp.descent() + tp.ascent()) / 2f, tp)
        }
    }

    fun zoneAt(x: Float): Int = if (labels.isEmpty()) -1 else (x / (width.toFloat() / labels.size)).toInt().coerceIn(0, labels.size - 1)
}

class DragController(val act: HomeActivity) {
    var active = false
    var item: Item? = null
    private var appKey: String? = null
    private var fromFolder: Item? = null
    private var src: View? = null
    private var proxy: ImageView? = null
    private var pending = false
    private var sx0 = 0f
    private var sy0 = 0f
    private var zoneActions: List<String> = emptyList()
    private var zoneIdx = -1
    private var hoverLayout: CellLayout? = null
    private var edgeSide = 0
    private var edgeRun: Runnable? = null
    private var planKind = 0 // 0 tidak ada, 1 taruh, 2 gabung
    private var planContainer = C_HOME
    private var planPage = 0
    private var planX = 0
    private var planY = 0
    private var planOcc: Item? = null

    fun start(v: View, it: Item?, key: String?, folder: Item?, x: Float, y: Float) {
        if (active) cancel()
        active = true
        item = it; appKey = key ?: it?.key; fromFolder = folder; src = v
        pending = true; sx0 = x; sy0 = y
        if (v is IconView) v.resetPress()
        val bm: Bitmap = when {
            it != null && v is IconView && v.width > 0 -> v.snapshot()
            it != null && v.width > 0 && v.height > 0 -> try {
                val b = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888); v.draw(Canvas(b)); b
            } catch (e: Throwable) { Bitmap.createBitmap(v.width.coerceAtLeast(1), v.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888) }
            else -> {
                val a = AppRepo.find(appKey ?: "")
                val sz = act.dpi(58)
                if (a != null) IconFactory.get(act, a, sz) else Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
            }
        }
        val iv = ImageView(act)
        iv.setImageBitmap(bm)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        val lp = FrameLayout.LayoutParams(bm.width, bm.height)
        act.dragLayer.addView(iv, lp)
        proxy = iv
        place(x, y)
        iv.scaleX = 1.1f; iv.scaleY = 1.1f
        // sembunyikan sumber
        if (it != null) v.visibility = View.INVISIBLE
        zoneActions = when {
            it == null -> listOf("info", "uninstall")
            it.type == T_APP -> listOf("remove", "info", "uninstall")
            else -> listOf("remove")
        }
        act.performHaptic()
    }

    private fun place(x: Float, y: Float) {
        val p = proxy ?: return
        p.translationX = x - p.layoutParams.width / 2f
        p.translationY = y - p.layoutParams.height / 2f - act.dp(24f)
    }

    private fun showZones() {
        val z = act.zones
        z.labels = zoneActions.map { when (it) { "remove" -> "Hapus"; "info" -> "Info"; else -> "Copot" } }
        z.hover = -1
        z.visibility = View.VISIBLE
        z.invalidate()
    }

    fun onMove(x: Float, y: Float) {
        if (!active) return
        if (pending) {
            val d = Math.hypot((x - sx0).toDouble(), (y - sy0).toDouble())
            if (d < act.dp(10f)) return
            pending = false
            act.popup.dismiss()
            act.onDragBegan(fromFolder != null, item == null && fromFolder == null)
            showZones()
        }
        place(x, y)
        // zona atas
        val zb = act.zones
        val zTop = zb.top
        val inZone = y < zTop + zb.height + act.dp(16f)
        if (inZone) {
            val idx = zb.zoneAt(x)
            zoneIdx = idx
            zb.hover = idx
            zb.invalidate()
            clearHover()
            cancelEdge()
            return
        } else if (zb.hover != -1) { zb.hover = -1; zoneIdx = -1; zb.invalidate() }
        zoneIdx = -1
        evaluate(x, y)
        edgeCheck(x)
    }

    private fun clearHover() {
        hoverLayout?.hover = null
        hoverLayout?.invalidate()
        hoverLayout = null
        planKind = 0
    }

    private fun spans(): IntArray {
        val it = item
        return if (it != null && it.type == T_WIDGET) intArrayOf(it.sx, it.sy) else intArrayOf(1, 1)
    }

    private fun evaluate(x: Float, y: Float) {
        val loc = IntArray(2)
        act.root.getLocationOnScreen(loc)
        val rx = x + loc[0]
        val ry = y + loc[1]
        var target: CellLayout? = null
        var container = C_HOME
        val dockVisible = act.dock.visibility == View.VISIBLE && Prefs.showDock
        val dl = IntArray(2)
        act.dock.getLocationOnScreen(dl)
        val isWidget = item?.type == T_WIDGET
        if (dockVisible && ry >= dl[1] - act.dp(10f) && !isWidget) {
            target = act.dockCells; container = C_DOCK
        } else {
            target = act.pager.getChildAt(act.pager.current) as? CellLayout
        }
        if (target == null) { clearHover(); return }
        if (hoverLayout !== target) clearHover()
        val tl = IntArray(2)
        target.getLocationOnScreen(tl)
        val sp = spans()
        val lx = rx - tl[0] - (sp[0] - 1) * target.cellW() / 2f
        val ly = ry - tl[1] - (sp[1] - 1) * target.cellH() / 2f
        val cell = target.cellAt(lx, ly)
        val cx = cell[0].coerceAtMost(target.cols - sp[0]).coerceAtLeast(0)
        val cy = cell[1].coerceAtMost(target.rows - sp[1]).coerceAtLeast(0)
        val page = if (container == C_DOCK) 0 else act.pager.current
        val self = item
        val occ = Store.itemAt(container, page, cx, cy, self)
        val isAppLike = (self == null && appKey != null) || self?.type == T_APP
        planContainer = container; planPage = page; planOcc = null
        var hx = cx; var hy = cy; var valid = 1
        if (isAppLike && occ != null && (occ.type == T_FOLDER || (occ.type == T_APP && occ !== self))) {
            planKind = 2; planOcc = occ; hx = occ.x; hy = occ.y
        } else if (Store.isFree(container, page, cx, cy, sp[0], sp[1], self)) {
            planKind = 1; planX = cx; planY = cy
        } else {
            val n = Store.nearestFree(container, page, cx, cy, sp[0], sp[1], self)
            if (n != null) { planKind = 1; planX = n[0]; planY = n[1]; hx = n[0]; hy = n[1] } else { planKind = 0; valid = 0 }
        }
        hoverLayout = target
        target.hover = intArrayOf(hx, hy, if (planKind == 2) 1 else sp[0], if (planKind == 2) 1 else sp[1], valid)
        target.invalidate()
    }

    private fun edgeCheck(x: Float) {
        val w = act.root.width
        val side = if (x < act.dp(36f)) -1 else if (x > w - act.dp(36f)) 1 else 0
        if (side == edgeSide) return
        cancelEdge()
        edgeSide = side
        if (side == 0) return
        val r = Runnable {
            if (!active) return@Runnable
            val cur = act.pager.current
            if (side > 0 && cur >= act.pager.pageCount - 1) {
                if (Store.pages < 12 && item?.container != C_DOCK || Store.pages < 12) {
                    Store.pages++
                    act.rebuildHome()
                    act.pager.setPage(cur + 1, true)
                }
            } else {
                act.pager.setPage(cur + side, true)
            }
            clearHover()
            edgeSide = 0
        }
        edgeRun = r
        mainHandler.postDelayed(r, 650)
    }

    private fun cancelEdge() {
        edgeRun?.let { mainHandler.removeCallbacks(it) }
        edgeRun = null
        edgeSide = 0
    }

    fun onUp(x: Float, y: Float) {
        if (!active) return
        if (pending) { cancel(); return }
        val it = item
        val key = appKey
        var done = false
        if (zoneIdx >= 0 && zoneIdx < zoneActions.size) {
            when (zoneActions[zoneIdx]) {
                "remove" -> { if (it != null) { Store.removeWidget(it); done = true } }
                "info" -> { key?.let { k -> AppRepo.find(k)?.let { a -> AppRepo.appInfoScreen(act, a.pkg) } } }
                "uninstall" -> { key?.let { k -> AppRepo.find(k)?.let { a -> AppRepo.uninstall(act, a.pkg) } } }
            }
            if (done) { fromFolder = null }
        } else if (planKind == 1) {
            if (it != null) {
                it.container = planContainer; it.page = planPage; it.x = planX; it.y = planY
            } else if (key != null) {
                val n = Item(Store.newId(), T_APP, planContainer, planPage, planX, planY)
                n.key = key
                Store.items.add(n)
                removeFromFolder(key)
            }
            done = true
        } else if (planKind == 2) {
            val occ = planOcc
            if (occ != null && key != null) {
                if (occ.type == T_FOLDER) {
                    if (!occ.kids.contains(key)) occ.kids.add(key)
                } else {
                    val f = Item(Store.newId(), T_FOLDER, occ.container, occ.page, occ.x, occ.y)
                    f.title = "Folder"
                    f.kids.add(occ.key); f.kids.add(key)
                    Store.items.remove(occ)
                    Store.items.add(f)
                }
                if (it != null) Store.items.remove(it)
                removeFromFolder(key)
                done = true
            }
        }
        finish(done)
    }

    private fun removeFromFolder(key: String) {
        val f = fromFolder ?: return
        f.kids.remove(key)
    }

    fun cancel() { finish(false) }

    private fun finish(changed: Boolean) {
        cancelEdge()
        clearHover()
        proxy?.let { act.dragLayer.removeView(it) }
        proxy = null
        act.zones.visibility = View.GONE
        active = false
        pending = false
        src?.visibility = View.VISIBLE
        src = null
        item = null; appKey = null; fromFolder = null
        planKind = 0
        if (changed) {
            Store.cleanup()
            Store.fit()
            Store.save()
        }
        act.onDragEnded()
        act.rebuildHome()
    }
}

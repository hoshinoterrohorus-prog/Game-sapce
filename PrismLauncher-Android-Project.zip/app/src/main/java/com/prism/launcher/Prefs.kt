package com.prism.launcher

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    /** Naik setiap ada perubahan, supaya layar bisa memuat ulang. */
    var rev = 0

    fun init(c: Context) {
        sp = c.applicationContext.getSharedPreferences("prism_prefs", Context.MODE_PRIVATE)
    }

    val all: Map<String, *> get() = sp.all

    fun int(k: String, d: Int): Int = try { sp.getInt(k, d) } catch (e: Exception) { d }
    fun bool(k: String, d: Boolean): Boolean = try { sp.getBoolean(k, d) } catch (e: Exception) { d }
    fun str(k: String, d: String): String = try { sp.getString(k, d) ?: d } catch (e: Exception) { d }
    fun long(k: String, d: Long): Long = try { sp.getLong(k, d) } catch (e: Exception) { d }

    fun put(k: String, v: Int) { sp.edit().putInt(k, v).apply(); rev++ }
    fun put(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply(); rev++ }
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply(); rev++ }
    fun put(k: String, v: Long) { sp.edit().putLong(k, v).apply(); rev++ }
    fun putQuiet(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    fun remove(k: String) { sp.edit().remove(k).apply(); rev++ }

    fun hidden(): MutableSet<String> = HashSet(sp.getStringSet("hidden", emptySet()) ?: emptySet())
    fun setHidden(s: Set<String>) { sp.edit().putStringSet("hidden", HashSet(s)).apply(); rev++ }

    fun clearAll() { sp.edit().clear().apply(); rev++ }

    // ---- Beranda ----
    val cols get() = int("cols", 5)
    val rows get() = int("rows", 6)
    val iconScale get() = int("icon_scale", 100)
    val labelSize get() = int("label_size", 11)
    val showLabels get() = bool("show_labels", true)
    val padH get() = int("pad_h", 8)
    val padV get() = int("pad_v", 6)
    val infinite get() = bool("infinite", false)
    val indicator get() = int("indicator", 0)
    val parallax get() = bool("parallax", true)
    val lockDesktop get() = bool("lock_desktop", false)
    val hideStatus get() = bool("hide_status", false)
    val allowRotate get() = bool("allow_rotate", false)
    // ---- Dock ----
    val showDock get() = bool("show_dock", true)
    val dockCount get() = int("dock_count", 5)
    val dockOpacity get() = int("dock_opacity", 60)
    val dockStyle get() = int("dock_style", 0)
    // ---- Laci ----
    val drawerStyle get() = int("drawer_style", 0)
    val drawerCols get() = int("drawer_cols", 5)
    val drawerIcon get() = int("drawer_icon", 100)
    val drawerSort get() = int("drawer_sort", 0)
    val drawerOpacity get() = int("drawer_opacity", 70)
    val drawerBlur get() = bool("drawer_blur", true)
    val searchBar get() = int("search_bar", 0)
    val azBar get() = bool("az_bar", true)
    val drawerLabels get() = bool("drawer_labels", true)
    // ---- Folder ----
    val folderStyle get() = int("folder_style", 0)
    val folderOpacity get() = int("folder_opacity", 70)
    val folderCols get() = int("folder_cols", 4)
    // ---- Tampilan ----
    val theme get() = int("theme", 3)
    val accent get() = int("accent", 0xFF7C8CFF.toInt())
    val glassBlur get() = int("glass_blur", 60)
    val glassShine get() = int("glass_shine", 60)
    val glassTilt get() = bool("glass_tilt", true)
    val iconShape get() = int("icon_shape", 0)
    val iconPlate get() = int("icon_plate", 0)
    val iconPack get() = str("icon_pack", "")
    val anim get() = int("anim", 0)
    // ---- Gestur ----
    val swipeUp get() = int("swipe_up", 0)
    val swipeDown get() = int("swipe_down", 0)
    val doubleTap get() = int("double_tap", 0)
    val homeBtn get() = int("home_btn", 0)
    val longPressMenu get() = bool("long_press_menu", true)
    // ---- Notifikasi ----
    val notifDots get() = bool("notif_dots", true)
    val notifCount get() = bool("notif_count", false)

    fun animScale(): Float = when (anim) { 1 -> 0.5f; 2 -> 0f; else -> 1f }
}

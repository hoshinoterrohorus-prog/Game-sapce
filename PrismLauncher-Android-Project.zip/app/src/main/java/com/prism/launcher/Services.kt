package com.prism.launcher

import android.app.admin.DeviceAdminReceiver

/** Dipakai untuk fitur "ketuk dua kali = kunci layar". */
class AdminReceiver : DeviceAdminReceiver()

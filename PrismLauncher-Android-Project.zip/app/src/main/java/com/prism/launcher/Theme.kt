package com.prism.launcher

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color

class Pal(
    val mode: Int,
    val dark: Boolean,
    val text: Int,
    val sub: Int,
    val panel: Int,
    val stroke: Int,
    val scrim: Int,
    val accent: Int
) {
    val glass: Boolean get() = mode == 2 || mode == 3
    val liquid: Boolean get() = mode == 3
}

object Themes {
    val NAMES = arrayOf("Terang", "Gelap", "Kaca (Glass)", "Liquid Glass", "AMOLED hitam", "Ikuti sistem")

    fun pal(ctx: Context): Pal {
        var m = Prefs.theme
        if (m == 5) {
            val night = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
            m = if (night) 1 else 0
        }
        val acc = Prefs.accent
        return when (m) {
            0 -> Pal(0, false, 0xFF1B1B20.toInt(), 0x99000000.toInt(), 0xF2FFFFFF.toInt(), 0x22000000, 0x40FFFFFF, acc)
            1 -> Pal(1, true, 0xFFEDEDF2.toInt(), 0xAAFFFFFF.toInt(), 0xF21E1F25.toInt(), 0x22FFFFFF, 0x66000000, acc)
            2 -> Pal(2, true, 0xFFFFFFFF.toInt(), 0xBBFFFFFF.toInt(), 0x7010121C, 0x44FFFFFF, 0x55000000, acc)
            3 -> Pal(3, true, 0xFFFFFFFF.toInt(), 0xCCFFFFFF.toInt(), 0x30FFFFFF, 0x77FFFFFF, 0x30000000, acc)
            else -> Pal(4, true, 0xFFFFFFFF.toInt(), 0xAAFFFFFF.toInt(), Color.BLACK, 0x33FFFFFF, 0xCC000000.toInt(), acc)
        }
    }
}

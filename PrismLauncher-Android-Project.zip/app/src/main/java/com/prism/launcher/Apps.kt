package com.prism.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import org.xmlpull.v1.XmlPullParser

class AppInfo(val pkg: String, val cls: String, val label: String, val installTime: Long) {
    val key: String get() = "$pkg/$cls"
    val cn: ComponentName get() = ComponentName(pkg, cls)
}

object AppRepo {
    val apps = ArrayList<AppInfo>()
    private val map = HashMap<String, AppInfo>()
    val listeners = ArrayList<() -> Unit>()

    fun load(ctx: Context) {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = try { pm.queryIntentActivities(i, 0) } catch (e: Exception) { emptyList() }
        val out = ArrayList<AppInfo>()
        for (r in list) {
            val ai = r.activityInfo ?: continue
            if (ai.packageName == ctx.packageName && ai.name.endsWith("HomeActivity")) continue
            val label = try { r.loadLabel(pm).toString() } catch (e: Exception) { ai.packageName }
            val t = try { pm.getPackageInfo(ai.packageName, 0).firstInstallTime } catch (e: Exception) { 0L }
            out.add(AppInfo(ai.packageName, ai.name, label, t))
        }
        out.sortBy { it.label.lowercase() }
        apps.clear()
        apps.addAll(out)
        map.clear()
        for (a in apps) map[a.key] = a
    }

    fun find(key: String): AppInfo? = map[key]

    fun label(a: AppInfo): String {
        val c = Prefs.str("lbl_" + a.key, "")
        return if (c.isNotEmpty()) c else a.label
    }

    fun usage(a: AppInfo): Int = Prefs.int("use_" + a.key, 0)

    fun visible(): List<AppInfo> {
        val h = Prefs.hidden()
        return apps.filter { !h.contains(it.key) }
    }

    fun sorted(): List<AppInfo> {
        val v = visible()
        return when (Prefs.drawerSort) {
            1 -> v.sortedByDescending { label(it).lowercase() }
            2 -> v.sortedByDescending { it.installTime }
            3 -> v.sortedByDescending { usage(it) }
            else -> v.sortedBy { label(it).lowercase() }
        }
    }

    fun launch(ctx: Context, a: AppInfo, from: View?) {
        val it = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(a.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        var opts: Bundle? = null
        if (from != null && Prefs.anim != 2) {
            try {
                opts = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height).toBundle()
            } catch (e: Exception) { }
        }
        try {
            ctx.startActivity(it, opts)
            Prefs.putQuiet("use_" + a.key, usage(a) + 1)
        } catch (e: Exception) {
            android.widget.Toast.makeText(ctx, "Tidak bisa membuka " + label(a), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    fun appInfoScreen(ctx: Context, pkg: String) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    fun uninstall(ctx: Context, pkg: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    /** Cari aplikasi bawaan lewat intent (telepon, pesan, browser, kamera, dll). */
    fun resolve(ctx: Context, intent: Intent): AppInfo? {
        val pm = ctx.packageManager
        val ri = try { pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) } catch (e: Exception) { null } ?: return null
        val pkg = ri.activityInfo?.packageName ?: return null
        if (pkg == "android") return null
        val exact = apps.firstOrNull { it.pkg == pkg && it.cls == ri.activityInfo.name }
        return exact ?: apps.firstOrNull { it.pkg == pkg }
    }

    fun defaults(ctx: Context): List<AppInfo?> = listOf(
        resolve(ctx, Intent(Intent.ACTION_DIAL)),
        resolve(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("sms:"))),
        resolve(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
        resolve(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)),
        resolve(ctx, Intent(Settings.ACTION_SETTINGS))
    )
}

/** Paket ikon bergaya ADW/Nova: baca appfilter.xml. */
object IconPacks {
    val ACTIONS = arrayOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.fede.launcher.THEME_ICONPACK", "com.anddoes.launcher.THEME")
    private var loadedPack = "\u0000"
    private var map = HashMap<String, String>()
    private var res: android.content.res.Resources? = null

    fun installed(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val out = LinkedHashMap<String, String>()
        for (a in ACTIONS) {
            val l = try { pm.queryIntentActivities(Intent(a), 0) } catch (e: Exception) { emptyList() }
            for (r in l) {
                val p = r.activityInfo?.packageName ?: continue
                if (!out.containsKey(p)) out[p] = try { r.loadLabel(pm).toString() } catch (e: Exception) { p }
            }
        }
        return out.map { Pair(it.key, it.value) }
    }

    private fun ensure(ctx: Context, pack: String) {
        if (loadedPack == pack) return
        loadedPack = pack
        map = HashMap()
        res = null
        if (pack.isEmpty()) return
        try {
            val r = ctx.packageManager.getResourcesForApplication(pack)
            res = r
            var parser: XmlPullParser? = null
            val id = r.getIdentifier("appfilter", "xml", pack)
            if (id != 0) parser = r.getXml(id)
            if (parser == null) {
                try {
                    val am = r.assets
                    val st = am.open("appfilter.xml")
                    val p = android.util.Xml.newPullParser()
                    p.setInput(st, "utf-8")
                    parser = p
                } catch (e: Exception) { }
            }
            if (parser != null) {
                var ev = parser.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                        val comp = parser.getAttributeValue(null, "component")
                        val dr = parser.getAttributeValue(null, "drawable")
                        if (comp != null && dr != null && comp.startsWith("ComponentInfo{") && comp.endsWith("}")) {
                            val k = comp.substring(14, comp.length - 1)
                            map[k] = dr
                        }
                    }
                    ev = parser.next()
                }
            }
        } catch (e: Throwable) {
            map = HashMap()
            res = null
        }
    }

    fun icon(ctx: Context, pack: String, a: AppInfo): Drawable? {
        if (pack.isEmpty()) return null
        ensure(ctx, pack)
        val name = map[a.key] ?: return null
        val r = res ?: return null
        val id = r.getIdentifier(name, "drawable", pack)
        if (id == 0) return null
        return try { r.getDrawable(id, null) } catch (e: Exception) { null }
    }
}

object IconFactory {
    private val cache = HashMap<String, Bitmap>()
    private var lastSig = ""

    fun clear() { cache.clear() }

    private fun shapePath(shape: Int, s: Float): Path {
        val p = Path()
        when (shape) {
            1 -> p.addCircle(s / 2, s / 2, s / 2, Path.Direction.CW)
            2 -> { // squircle (superellipse n=4)
                val n = 4.0
                val steps = 72
                for (i in 0..steps) {
                    val t = i.toDouble() / steps * Math.PI * 2
                    val ct = Math.cos(t)
                    val st = Math.sin(t)
                    val x = (Math.signum(ct) * Math.pow(Math.abs(ct), 2.0 / n)).toFloat() * s / 2 + s / 2
                    val y = (Math.signum(st) * Math.pow(Math.abs(st), 2.0 / n)).toFloat() * s / 2 + s / 2
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            3 -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.24f, s * 0.24f, Path.Direction.CW)
            4 -> { // teardrop: 3 sudut bulat, 1 sudut lancip
                val r = s / 2
                val rr = floatArrayOf(r, r, r, r, r, r, s * 0.08f, s * 0.08f)
                p.addRoundRect(RectF(0f, 0f, s, s), rr, Path.Direction.CW)
            }
            5 -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.07f, s * 0.07f, Path.Direction.CW)
            else -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.22f, s * 0.22f, Path.Direction.CW)
        }
        return p
    }

    private fun base(ctx: Context, a: AppInfo): Drawable? {
        val pack = Prefs.iconPack
        val pd = IconPacks.icon(ctx, pack, a)
        if (pd != null) return pd
        return try { ctx.packageManager.getActivityIcon(a.cn) } catch (e: Exception) {
            try { ctx.packageManager.getApplicationIcon(a.pkg) } catch (e2: Exception) { null }
        }
    }

    fun get(ctx: Context, a: AppInfo, size: Int): Bitmap {
        val sig = "${Prefs.iconShape}|${Prefs.iconPlate}|${Prefs.iconPack}|${Themes.pal(ctx).mode}"
        if (sig != lastSig) { cache.clear(); lastSig = sig }
        val ck = a.key + "|" + size
        cache[ck]?.let { return it }
        val b = render(ctx, a, size)
        cache[ck] = b
        return b
    }

    private fun render(ctx: Context, a: AppInfo, size: Int): Bitmap {
        val s = size.toFloat()
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val d = base(ctx, a)
        if (d == null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = 0xFF888899.toInt()
            c.drawCircle(s / 2, s / 2, s / 2, p)
            return out
        }
        val shape = Prefs.iconShape
        val plate = Prefs.iconPlate
        val adaptive = d is AdaptiveIconDrawable
        if (shape == 0 && plate == 0) {
            // ikon asli (adaptif memakai topeng sistem)
            if (adaptive) {
                d.setBounds(0, 0, size, size)
                d.draw(c)
            } else {
                val inset = (s * 0.08f).toInt()
                d.setBounds(inset, inset, size - inset, size - inset)
                d.draw(c)
            }
            return out
        }
        val path = shapePath(if (shape == 0) 3 else shape, s)
        val layer = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        if (plate == 1) {
            // plat kaca beku di belakang ikon
            val g = Paint(Paint.ANTI_ALIAS_FLAG)
            g.shader = LinearGradient(0f, 0f, s, s, intArrayOf(0xB0FFFFFF.toInt(), 0x60C8D4FF), null, Shader.TileMode.CLAMP)
            lc.drawRect(0f, 0f, s, s, g)
        } else if (plate == 2) {
            lc.drawColor(0xFFF4F4F8.toInt())
        }
        if (adaptive) {
            val ad = d as AdaptiveIconDrawable
            val ext = s * 0.25f
            val fg = ad.foreground
            val bg = ad.background
            if (plate == 0 && bg != null) {
                bg.setBounds((-ext).toInt(), (-ext).toInt(), (s + ext).toInt(), (s + ext).toInt())
                bg.draw(lc)
            }
            if (fg != null) {
                val pad = if (plate == 0) ext else ext + s * 0.04f
                fg.setBounds((-pad).toInt(), (-pad).toInt(), (s + pad).toInt(), (s + pad).toInt())
                fg.draw(lc)
            }
        } else {
            val inset = (s * (if (plate == 0) 0.14f else 0.18f)).toInt()
            if (plate == 0) lc.drawColor(0xFFF4F4F8.toInt())
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(lc)
        }
        val mask = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val mc = Canvas(mask)
        val mp = Paint(Paint.ANTI_ALIAS_FLAG)
        mp.color = Color.WHITE
        mc.drawPath(path, mp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawBitmap(mask, 0f, 0f, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(layer, 0f, 0f, p)
        p.xfermode = null
        if (plate == 1) {
            val st = Paint(Paint.ANTI_ALIAS_FLAG)
            st.style = Paint.Style.STROKE
            st.strokeWidth = maxOf(1f, s * 0.025f)
            st.shader = LinearGradient(0f, 0f, s, s, intArrayOf(0xEEFFFFFF.toInt(), 0x22FFFFFF, 0x88FFFFFF.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            val m = Matrix()
            m.setScale((s - st.strokeWidth) / s, (s - st.strokeWidth) / s, s / 2, s / 2)
            val sp = Path(path)
            sp.transform(m)
            c.drawPath(sp, st)
        }
        return out
    }
}

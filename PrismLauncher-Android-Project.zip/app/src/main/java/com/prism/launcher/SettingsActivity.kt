package com.prism.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    companion object {
        const val REQ_EXPORT = 21
        const val REQ_IMPORT = 22
    }

    private lateinit var holder: FrameLayout
    private val stack = ArrayList<String>()
    private var pal = Themes.pal(this)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        if (AppRepo.apps.isEmpty()) AppRepo.load(this)
        Store.load(this)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        holder = FrameLayout(this)
        setContentView(holder)
        stack.add("root")
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (stack.size > 1) { stack.removeAt(stack.size - 1); render() } else finish()
    }

    private fun txt() = if (pal.mode == 0) pal.text else Color.WHITE
    private fun sub() = if (pal.mode == 0) 0x99000000.toInt() else 0xBBFFFFFF.toInt()

    private fun go(p: String) { stack.add(p); render() }

    // ---------------------------------------------------------------- bangun halaman
    private fun render() {
        pal = Themes.pal(this)
        holder.removeAllViews()
        holder.setBackgroundColor(if (pal.glass) pal.scrim else pal.panel.let { Color.argb(255, Color.red(it), Color.green(it), Color.blue(it)) })
        val page = stack.last()
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dpi(16), dpi(40), dpi(16), dpi(40))
        sv.addView(col)
        holder.addView(sv, FrameLayout.LayoutParams(-1, -1))

        val title = when (page) {
            "root" -> "Pengaturan Prism"
            "home" -> "Beranda"
            "dock" -> "Dock"
            "drawer" -> "Laci aplikasi"
            "folder" -> "Folder"
            "look" -> "Tampilan & tema"
            "gesture" -> "Gestur & tombol"
            "notif" -> "Notifikasi"
            "backup" -> "Cadangan"
            else -> "Lainnya"
        }
        val head = TextView(this)
        head.text = (if (stack.size > 1) "‹  " else "") + title
        head.textSize = 26f
        head.setTextColor(txt())
        head.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        head.setPadding(dpi(6), dpi(10), 0, dpi(14))
        if (stack.size > 1) head.setOnClickListener { onBackPressed() }
        col.addView(head)

        when (page) {
            "root" -> buildRoot(col)
            "home" -> buildHome(col)
            "dock" -> buildDock(col)
            "drawer" -> buildDrawer(col)
            "folder" -> buildFolder(col)
            "look" -> buildLook(col)
            "gesture" -> buildGesture(col)
            "notif" -> buildNotif(col)
            "backup" -> buildBackup(col)
            else -> buildMore(col)
        }
    }

    private fun card(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val g = GlassDrawable(this, dp(22f), 0.9f)
        g.anchor = c
        c.background = if (pal.glass) g else GradientDrawable().also {
            it.cornerRadius = dp(22f)
            it.setColor(if (pal.mode == 0) 0xFFF1F2F6.toInt() else if (pal.mode == 4) 0xFF111114.toInt() else 0xFF2A2B33.toInt())
        }
        c.setPadding(0, dpi(4), 0, dpi(4))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dpi(14)
        parent.addView(c, lp)
        return c
    }

    private fun section(col: LinearLayout, name: String): LinearLayout {
        val t = TextView(this)
        t.text = name.uppercase()
        t.textSize = 12f
        t.setTextColor(pal.accent)
        t.letterSpacing = 0.08f
        t.setPadding(dpi(8), dpi(8), 0, dpi(6))
        col.addView(t)
        return card(col)
    }

    private fun row(c: LinearLayout, title: String, sub: String?, onClick: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dpi(18), dpi(13), dpi(18), dpi(13))
        val t = TextView(this)
        t.text = title
        t.textSize = 16f
        t.setTextColor(txt())
        r.addView(t)
        if (!sub.isNullOrEmpty()) {
            val s = TextView(this)
            s.text = sub
            s.textSize = 13f
            s.setTextColor(sub())
            s.setPadding(0, dpi(2), 0, 0)
            s.tag = "sub"
            r.addView(s)
        }
        if (onClick != null) {
            r.isClickable = true
            r.setOnClickListener { onClick() }
        }
        c.addView(r, LinearLayout.LayoutParams(-1, -2))
        return r
    }

    private fun toggle(c: LinearLayout, title: String, sub: String?, key: String, def: Boolean) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dpi(18), dpi(11), dpi(14), dpi(11))
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title; t.textSize = 16f; t.setTextColor(txt())
        tc.addView(t)
        if (!sub.isNullOrEmpty()) {
            val s = TextView(this)
            s.text = sub; s.textSize = 13f; s.setTextColor(sub()); s.setPadding(0, dpi(2), 0, 0)
            tc.addView(s)
        }
        r.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this)
        sw.isChecked = Prefs.bool(key, def)
        sw.setOnCheckedChangeListener { _, v -> Prefs.put(key, v); if (key == "glass_tilt") { } }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        c.addView(r, LinearLayout.LayoutParams(-1, -2))
    }

    private fun seek(c: LinearLayout, title: String, key: String, min: Int, max: Int, def: Int, unit: String = "") {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dpi(18), dpi(11), dpi(18), dpi(8))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val t = TextView(this)
        t.text = title; t.textSize = 16f; t.setTextColor(txt())
        head.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val v = TextView(this)
        val cur = Prefs.int(key, def).coerceIn(min, max)
        v.text = "$cur$unit"; v.textSize = 14f; v.setTextColor(pal.accent)
        head.addView(v)
        r.addView(head)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        try { sb.progressTintList = android.content.res.ColorStateList.valueOf(pal.accent); sb.thumbTintList = android.content.res.ColorStateList.valueOf(pal.accent) } catch (e: Throwable) { }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { v.text = "${p + min}$unit" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { Prefs.put(key, (s?.progress ?: 0) + min) }
        })
        r.addView(sb)
        c.addView(r, LinearLayout.LayoutParams(-1, -2))
    }

    private fun choice(c: LinearLayout, title: String, key: String, options: Array<String>, def: Int) {
        val cur = Prefs.int(key, def).coerceIn(0, options.size - 1)
        row(c, title, options[cur]) {
            AlertDialog.Builder(this).setTitle(title)
                .setSingleChoiceItems(options, cur) { d, w -> Prefs.put(key, w); d.dismiss(); render() }
                .setNegativeButton("Batal", null).show()
        }
    }

    // ---------------------------------------------------------------- halaman
    private fun buildRoot(col: LinearLayout) {
        if (!isDefaultHome()) {
            val c = card(col)
            row(c, "Jadikan Prism launcher utama", "Widget, pintasan & gestur bekerja penuh bila Prism jadi launcher bawaan. Ketuk untuk memilih.") { openHomeSettings() }
        }
        val c = card(col)
        row(c, "Beranda", "Grid, ukuran ikon, label, halaman") { go("home") }
        row(c, "Dock", "Jumlah ikon, gaya, transparansi") { go("dock") }
        row(c, "Laci aplikasi", "Grid / daftar, urutan, pencarian, blur") { go("drawer") }
        row(c, "Folder", "Gaya pratinjau, kolom, transparansi") { go("folder") }
        row(c, "Tampilan & tema", "Glass, Liquid Glass, ikon, aksen, animasi") { go("look") }
        row(c, "Gestur & tombol", "Geser atas/bawah, ketuk dua kali, Home") { go("gesture") }
        row(c, "Notifikasi", "Titik / angka notifikasi di ikon") { go("notif") }
        row(c, "Cadangan & pulihkan", "Ekspor / impor tata letak dan pengaturan") { go("backup") }
        row(c, "Lainnya", "Aplikasi tersembunyi, tentang") { go("more") }
    }

    private fun buildHome(col: LinearLayout) {
        var c = section(col, "Grid")
        seek(c, "Kolom", "cols", 3, 8, 5)
        seek(c, "Baris", "rows", 3, 9, 6)
        seek(c, "Jarak samping", "pad_h", 0, 32, 8, "dp")
        seek(c, "Jarak atas/bawah", "pad_v", 0, 32, 6, "dp")
        c = section(col, "Ikon & label")
        seek(c, "Ukuran ikon", "icon_scale", 50, 150, 100, "%")
        toggle(c, "Tampilkan label", null, "show_labels", true)
        seek(c, "Ukuran label", "label_size", 8, 16, 11, "sp")
        c = section(col, "Halaman")
        toggle(c, "Geser tanpa batas", "Dari halaman terakhir kembali ke pertama", "infinite", false)
        choice(c, "Penunjuk halaman", "indicator", arrayOf("Titik", "Garis", "Angka"), 0)
        toggle(c, "Parallax wallpaper", "Wallpaper ikut bergeser saat ganti halaman", "parallax", true)
        c = section(col, "Sistem")
        toggle(c, "Kunci beranda", "Cegah ikon terseret / terhapus tidak sengaja", "lock_desktop", false)
        toggle(c, "Sembunyikan bilah status", null, "hide_status", false)
        toggle(c, "Izinkan putar layar", "Mode lanskap", "allow_rotate", false)
    }

    private fun buildDock(col: LinearLayout) {
        val c = section(col, "Dock")
        toggle(c, "Tampilkan dock", null, "show_dock", true)
        seek(c, "Jumlah ikon", "dock_count", 3, 7, 5)
        seek(c, "Transparansi latar", "dock_opacity", 0, 100, 60, "%")
        choice(c, "Gaya", "dock_style", arrayOf("Melayang (kaca)", "Selebar layar", "Tanpa latar"), 0)
    }

    private fun buildDrawer(col: LinearLayout) {
        var c = section(col, "Tata letak")
        choice(c, "Gaya", "drawer_style", arrayOf("Grid", "Daftar"), 0)
        seek(c, "Kolom grid", "drawer_cols", 3, 6, 5)
        seek(c, "Ukuran ikon", "drawer_icon", 60, 140, 100, "%")
        toggle(c, "Tampilkan label", null, "drawer_labels", true)
        choice(c, "Urutan", "drawer_sort", arrayOf("A – Z", "Z – A", "Terbaru dipasang", "Paling sering dipakai"), 0)
        c = section(col, "Pencarian & navigasi")
        choice(c, "Kolom pencarian", "search_bar", arrayOf("Di atas", "Di bawah", "Sembunyikan"), 0)
        toggle(c, "Bilah A–Z", "Lompat cepat ke huruf (khusus urutan A–Z)", "az_bar", true)
        c = section(col, "Tampilan")
        seek(c, "Transparansi latar laci", "drawer_opacity", 0, 100, 70, "%")
        toggle(c, "Blur jendela saat laci terbuka", "Android 12+, tergantung perangkat", "drawer_blur", true)
    }

    private fun buildFolder(col: LinearLayout) {
        val c = section(col, "Folder")
        choice(c, "Pratinjau di beranda", "folder_style", arrayOf("Grid 2×2", "Tumpukan"), 0)
        seek(c, "Kolom di dalam folder", "folder_cols", 3, 5, 4)
        seek(c, "Transparansi latar", "folder_opacity", 0, 100, 70, "%")
    }

    private fun buildLook(col: LinearLayout) {
        var c = section(col, "Tema")
        val tiles = LinearLayout(this)
        tiles.orientation = LinearLayout.HORIZONTAL
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        tiles.setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
        val cols = arrayOf(
            intArrayOf(0xFFF4F5FA.toInt(), 0xFFD9DCE8.toInt()),
            intArrayOf(0xFF2B2D36.toInt(), 0xFF14151A.toInt()),
            intArrayOf(0xFF4C5C8C.toInt(), 0xFF171A2B.toInt()),
            intArrayOf(0xFFB8C6FF.toInt(), 0xFFF3B6E4.toInt()),
            intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt()),
            intArrayOf(0xFFF4F5FA.toInt(), 0xFF14151A.toInt())
        )
        for (i in Themes.NAMES.indices) {
            val t = LinearLayout(this)
            t.orientation = LinearLayout.VERTICAL
            t.gravity = Gravity.CENTER_HORIZONTAL
            val sw = View(this)
            val gd = GradientDrawable(GradientDrawable.Orientation.TL_BR, cols[i])
            gd.cornerRadius = dp(18f)
            gd.setStroke(dpi(if (Prefs.theme == i) 3 else 1), if (Prefs.theme == i) pal.accent else 0x55FFFFFF)
            sw.background = gd
            t.addView(sw, LinearLayout.LayoutParams(dpi(70), dpi(92)))
            val n = TextView(this)
            n.text = Themes.NAMES[i]; n.textSize = 11.5f; n.setTextColor(txt()); n.gravity = Gravity.CENTER
            n.setPadding(0, dpi(6), 0, 0)
            t.addView(n, LinearLayout.LayoutParams(dpi(76), -2))
            t.setOnClickListener { Prefs.put("theme", i); render() }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.rightMargin = dpi(10)
            tiles.addView(t, lp)
        }
        hs.addView(tiles)
        c.addView(hs)
        c = section(col, "Warna aksen")
        val sr = LinearLayout(this)
        sr.orientation = LinearLayout.HORIZONTAL
        sr.setPadding(dpi(14), dpi(10), dpi(14), dpi(12))
        val hs2 = HorizontalScrollView(this)
        hs2.isHorizontalScrollBarEnabled = false
        val acc = intArrayOf(0xFF7C8CFF.toInt(), 0xFF4FC3F7.toInt(), 0xFF2DD4BF.toInt(), 0xFF7CE38B.toInt(), 0xFFFFD166.toInt(), 0xFFFF9F68.toInt(), 0xFFFF6B8B.toInt(), 0xFFD77CFF.toInt(), 0xFFFFFFFF.toInt())
        for (a in acc) {
            val d = View(this)
            val gd = GradientDrawable()
            gd.shape = GradientDrawable.OVAL
            gd.setColor(a)
            gd.setStroke(dpi(if (Prefs.accent == a) 3 else 1), if (Prefs.accent == a) Color.WHITE else 0x55FFFFFF)
            d.background = gd
            d.setOnClickListener { Prefs.put("accent", a); render() }
            val lp = LinearLayout.LayoutParams(dpi(40), dpi(40))
            lp.rightMargin = dpi(12)
            sr.addView(d, lp)
        }
        hs2.addView(sr)
        c.addView(hs2)
        c = section(col, "Glass / Liquid Glass")
        row(c, "Tentang efek kaca", "Wallpaper di-blur jadi latar panel (dock, laci, folder, menu). Liquid Glass menambah kilau pembiasan yang bergerak saat HP dimiringkan. Pilih tema \"Kaca\" atau \"Liquid Glass\" di atas.", null)
        seek(c, "Kekuatan blur", "glass_blur", 0, 100, 60, "%")
        seek(c, "Kilau / refleksi", "glass_shine", 0, 100, 60, "%")
        toggle(c, "Kilau mengikuti kemiringan", "Memakai sensor gerak", "glass_tilt", true)
        c = section(col, "Ikon")
        choice(c, "Bentuk ikon", "icon_shape", arrayOf("Asli (adaptif)", "Lingkaran", "Squircle", "Persegi membulat", "Tetesan", "Persegi"), 0)
        choice(c, "Alas ikon", "icon_plate", arrayOf("Tanpa alas", "Kaca", "Solid"), 0)
        val packs = IconPacks.installed(this)
        val cur = Prefs.iconPack
        val curName = packs.firstOrNull { it.first == cur }?.second ?: "Bawaan sistem"
        row(c, "Paket ikon", if (packs.isEmpty()) "Belum ada paket ikon (ADW / Nova) terpasang" else curName) {
            if (packs.isEmpty()) return@row
            val names = (listOf("Bawaan sistem") + packs.map { it.second }).toTypedArray()
            val idx = if (cur.isEmpty()) 0 else (packs.indexOfFirst { it.first == cur } + 1).coerceAtLeast(0)
            AlertDialog.Builder(this).setTitle("Paket ikon")
                .setSingleChoiceItems(names, idx) { d, w -> Prefs.put("icon_pack", if (w == 0) "" else packs[w - 1].first); d.dismiss(); render() }
                .setNegativeButton("Batal", null).show()
        }
        c = section(col, "Animasi")
        choice(c, "Kecepatan animasi", "anim", arrayOf("Normal", "Cepat", "Mati"), 0)
    }

    private fun buildGesture(col: LinearLayout) {
        var c = section(col, "Gestur beranda")
        choice(c, "Geser ke atas", "swipe_up", arrayOf("Buka laci", "Buka laci + pencarian", "Tidak ada"), 0)
        choice(c, "Geser ke bawah", "swipe_down", arrayOf("Panel notifikasi", "Buka pencarian", "Tidak ada"), 0)
        choice(c, "Ketuk dua kali", "double_tap", arrayOf("Tidak ada", "Kunci layar", "Buka laci"), 0)
        toggle(c, "Menu tekan lama di area kosong", "Widget, wallpaper, pengaturan, halaman", "long_press_menu", true)
        c = section(col, "Tombol")
        choice(c, "Tombol Home saat di beranda", "home_btn", arrayOf("Kembali ke halaman utama", "Buka laci aplikasi"), 0)
        row(c, "Catatan", "\"Kunci layar\" meminta izin Administrator Perangkat sekali saja. Panel notifikasi bisa tidak berfungsi di sebagian ROM.", null)
    }

    private fun buildNotif(col: LinearLayout) {
        val c = section(col, "Penanda notifikasi")
        toggle(c, "Titik notifikasi", "Tandai ikon yang punya notifikasi", "notif_dots", true)
        toggle(c, "Tampilkan jumlah", null, "notif_count", false)
        row(c, "Beri akses notifikasi", "Wajib diaktifkan agar titik muncul. Pilih \"Prism Launcher\" di daftar.") {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { toast("Tidak bisa membuka pengaturan") }
        }
    }

    private fun buildBackup(col: LinearLayout) {
        var c = section(col, "Cadangan")
        row(c, "Ekspor ke berkas", "Simpan pengaturan + tata letak beranda ke .json") {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
            i.putExtra(Intent.EXTRA_TITLE, "prism-backup.json")
            try { startActivityForResult(i, REQ_EXPORT) } catch (e: Exception) { toast("Tidak ada pemilih berkas") }
        }
        row(c, "Impor dari berkas", "Widget tidak ikut dipulihkan") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            try { startActivityForResult(i, REQ_IMPORT) } catch (e: Exception) { toast("Tidak ada pemilih berkas") }
        }
        c = section(col, "Reset")
        row(c, "Reset tata letak beranda", "Susun ulang ikon seperti awal") {
            confirm("Reset tata letak?", "Semua ikon, folder, dan widget di beranda akan disusun ulang.") {
                Store.reset(this); toast("Tata letak direset"); Prefs.put("_t", Prefs.rev)
            }
        }
        row(c, "Reset semua pengaturan", "Kembali ke bawaan (tata letak tidak berubah)") {
            confirm("Reset pengaturan?", "Semua pilihan di sini kembali ke bawaan.") { Prefs.clearAll(); render() }
        }
    }

    private fun buildMore(col: LinearLayout) {
        var c = section(col, "Aplikasi")
        row(c, "Aplikasi tersembunyi", "Pilih aplikasi yang disembunyikan dari laci") { pickHidden() }
        row(c, "Launcher bawaan", if (isDefaultHome()) "Prism sudah jadi launcher utama" else "Ketuk untuk menjadikan Prism launcher utama") { openHomeSettings() }
        c = section(col, "Wallpaper & kaca")
        row(c, "Pilih wallpaper", null) {
            try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")) } catch (e: Exception) { toast("Tidak ada pemilih wallpaper") }
        }
        row(c, "Efek kaca tampak datar?", "Blur butuh akses baca wallpaper. Bila ditolak sistem, panel memakai gradien beku sebagai cadangan.") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (e: Exception) { }
        }
        c = section(col, "Tentang")
        row(c, "Prism Launcher 1.0", "Launcher native Kotlin tanpa library tambahan. Tema Glass & Liquid Glass bawaan.", null)
    }

    // ---------------------------------------------------------------- util
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun confirm(t: String, m: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setTitle(t).setMessage(m)
            .setPositiveButton("Ya") { _, _ -> ok() }
            .setNegativeButton("Batal", null).show()
    }

    private fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val r = packageManager.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
        return r?.activityInfo?.packageName == packageName
    }

    private fun openHomeSettings() {
        try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    private fun pickHidden() {
        val apps = AppRepo.apps.sortedBy { it.label.lowercase() }
        val hidden = Prefs.hidden()
        val names = apps.map { it.label }.toTypedArray()
        val checked = BooleanArray(apps.size) { hidden.contains(apps[it].key) }
        AlertDialog.Builder(this).setTitle("Sembunyikan dari laci")
            .setMultiChoiceItems(names, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Simpan") { _, _ ->
                val s = HashSet<String>()
                for (i in apps.indices) if (checked[i]) s.add(apps[i].key)
                Prefs.setHidden(s)
            }
            .setNegativeButton("Batal", null).show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        when (req) {
            REQ_EXPORT -> toast(if (Backup.write(this, uri)) "Cadangan disimpan" else "Gagal menyimpan")
            REQ_IMPORT -> { toast(if (Backup.read(this, uri)) "Cadangan dipulihkan" else "Berkas tidak valid"); render() }
        }
    }
}

package com.prism.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.view.View

val mainHandler = Handler(Looper.getMainLooper())

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(v: Float): Float = context.dp(v)
fun View.dpi(v: Int): Int = context.dpi(v)

object U {
    fun alpha(c: Int, a: Float): Int =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    fun toBitmap(d: Drawable, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(maxOf(w, 1), maxOf(h, 1), Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, b.width, b.height)
        d.draw(c)
        return b
    }

    /** Blur kotak 3 lintasan (mendekati gaussian) untuk bitmap kecil. */
    fun blur(src: Bitmap, r: Int, passes: Int = 3): Bitmap {
        val w = src.width
        val h = src.height
        val a = IntArray(w * h)
        src.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h)
        val rad = maxOf(r, 1)
        repeat(passes) {
            pass(a, b, w, h, rad, true)
            pass(b, a, w, h, rad, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }

    private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horiz: Boolean) {
        val div = 2 * r + 1
        val lines = if (horiz) h else w
        val len = if (horiz) w else h
        for (l in 0 until lines) {
            var ra = 0
            var ga = 0
            var ba = 0
            fun idx(i: Int): Int = if (horiz) l * w + i else i * w + l
            for (i in -r..r) {
                val p = src[idx(i.coerceIn(0, len - 1))]
                ra += (p shr 16) and 255
                ga += (p shr 8) and 255
                ba += p and 255
            }
            for (i in 0 until len) {
                dst[idx(i)] = (0xFF shl 24) or ((ra / div) shl 16) or ((ga / div) shl 8) or (ba / div)
                val o = src[idx((i - r).coerceIn(0, len - 1))]
                val n = src[idx((i + r + 1).coerceIn(0, len - 1))]
                ra += ((n shr 16) and 255) - ((o shr 16) and 255)
                ga += ((n shr 8) and 255) - ((o shr 8) and 255)
                ba += (n and 255) - (o and 255)
            }
        }
    }
}

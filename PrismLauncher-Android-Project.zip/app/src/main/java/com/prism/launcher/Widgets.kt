package com.prism.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.os.Bundle
import android.view.MotionEvent
import android.view.ViewConfiguration

class LWidgetView(ctx: Context) : AppWidgetHostView(ctx) {
    var onLong: ((LWidgetView) -> Unit)? = null
    private var fired = false
    private var dx = 0f
    private var dy = 0f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val r = Runnable { fired = true; onLong?.invoke(this) }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                fired = false; dx = ev.x; dy = ev.y
                postDelayed(r, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (Math.abs(ev.x - dx) > slop || Math.abs(ev.y - dy) > slop) removeCallbacks(r)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(r)
        }
        return fired
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val d = resources.displayMetrics.density
        if (w > 0 && h > 0) {
            try { updateAppWidgetSize(Bundle(), (w / d).toInt(), (h / d).toInt(), (w / d).toInt(), (h / d).toInt()) } catch (e: Exception) { }
        }
    }
}

class LHost(ctx: Context) : AppWidgetHost(ctx, 1024) {
    override fun onCreateView(context: Context, appWidgetId: Int, appWidget: AppWidgetProviderInfo?): AppWidgetHostView = LWidgetView(context)
}

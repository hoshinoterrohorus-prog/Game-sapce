package com.prism.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * Lapisan animasi buka/tutup aplikasi ala flagship:
 * ikon memuai jadi lembar penuh layar (p: 0 = posisi ikon, 1 = layar penuh), dan sebaliknya saat kembali.
 */
class LaunchOverlay(ctx: Context) : View(ctx) {
    var rect = RectF()
    var bmp: Bitmap? = null
    var corner = 0f
    var p = 0f
        set(v) { field = v; invalidate() }
    var reversing = false
    var sheetColor = Color.DKGRAY
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val r = RectF()

    fun setup(from: RectF, icon: Bitmap, cornerPx: Float) {
        rect = RectF(from)
        bmp = icon
        corner = cornerPx
        sheetColor = try {
            val c = Bitmap.createScaledBitmap(icon, 1, 1, true).getPixel(0, 0)
            U.mix(c or 0xFF000000.toInt(), 0xFF101015.toInt(), 0.35f)
        } catch (e: Exception) { 0xFF202028.toInt() }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val l = rect.left * (1f - p)
        val t = rect.top * (1f - p)
        val rr = rect.right + (w - rect.right) * p
        val b = rect.bottom + (h - rect.bottom) * p
        r.set(l, t, rr, b)
        val rad = corner * (1f - p) + dp(2f) * p
        paint.style = Paint.Style.FILL
        paint.color = sheetColor
        paint.alpha = (255 * (p * 2.4f).coerceIn(0f, 1f)).toInt()
        if (paint.alpha > 0) c.drawRoundRect(r, rad, rad, paint)
        val bm = bmp ?: return
        val side = rect.width() * (1f + 0.55f * p)
        val cx = r.centerX()
        val cy = r.centerY()
        paint.alpha = (255 * (1f - (p * 1.7f)).coerceIn(0f, 1f)).toInt()
        if (paint.alpha > 0) {
            val dst = RectF(cx - side / 2f, cy - side / 2f, cx + side / 2f, cy + side / 2f)
            c.drawBitmap(bm, null, dst, paint)
        }
    }
}

package com.prism.launcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

const val T_APP = 0
const val T_FOLDER = 1
const val T_WIDGET = 2

const val C_HOME = 0
const val C_DOCK = 1

class Item(var id: Long, var type: Int, var container: Int, var page: Int, var x: Int, var y: Int) {
    var sx = 1
    var sy = 1
    var key = ""
    var title = ""
    var widgetId = -1
    var provider = ""
    var kids = ArrayList<String>()

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id); o.put("t", type); o.put("c", container); o.put("p", page)
        o.put("x", x); o.put("y", y); o.put("sx", sx); o.put("sy", sy)
        o.put("k", key); o.put("ti", title); o.put("w", widgetId); o.put("pr", provider)
        val a = JSONArray()
        for (k in kids) a.put(k)
        o.put("kids", a)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Item {
            val i = Item(o.optLong("id"), o.optInt("t"), o.optInt("c"), o.optInt("p"), o.optInt("x"), o.optInt("y"))
            i.sx = o.optInt("sx", 1); i.sy = o.optInt("sy", 1)
            i.key = o.optString("k"); i.title = o.optString("ti")
            i.widgetId = o.optInt("w", -1); i.provider = o.optString("pr")
            val a = o.optJSONArray("kids")
            if (a != null) for (n in 0 until a.length()) i.kids.add(a.optString(n))
            return i
        }
    }
}

object Store {
    val items = ArrayList<Item>()
    var pages = 2
    private var nextId = 1L
    private var file: File? = null

    fun gridCols(container: Int): Int = if (container == C_DOCK) Prefs.dockCount else Prefs.cols
    fun gridRows(container: Int): Int = if (container == C_DOCK) 1 else Prefs.rows

    fun newId(): Long = nextId++

    fun load(ctx: Context) {
        file = File(ctx.filesDir, "layout.json")
        items.clear()
        var ok = false
        try {
            val f = file!!
            if (f.exists()) {
                val o = JSONObject(f.readText())
                pages = o.optInt("pages", 2)
                val a = o.getJSONArray("items")
                for (n in 0 until a.length()) items.add(Item.fromJson(a.getJSONObject(n)))
                ok = true
            }
        } catch (e: Exception) {
            items.clear()
        }
        if (!ok) seed(ctx)
        nextId = (items.maxOfOrNull { it.id } ?: 0L) + 1L
        fit()
    }

    fun save() {
        val f = file ?: return
        try {
            val o = JSONObject()
            o.put("pages", pages)
            val a = JSONArray()
            for (i in items) a.put(i.toJson())
            o.put("items", a)
            f.writeText(o.toString())
        } catch (e: Exception) { }
    }

    fun exportJson(): JSONObject {
        val o = JSONObject()
        o.put("pages", pages)
        val a = JSONArray()
        for (i in items) a.put(i.toJson())
        o.put("items", a)
        return o
    }

    fun importJson(o: JSONObject) {
        items.clear()
        pages = o.optInt("pages", 2)
        val a = o.getJSONArray("items")
        for (n in 0 until a.length()) items.add(Item.fromJson(a.getJSONObject(n)))
        nextId = (items.maxOfOrNull { it.id } ?: 0L) + 1L
        fit()
        save()
    }

    fun reset(ctx: Context) {
        for (i in items) if (i.type == T_WIDGET) widgetCleanup?.invoke(i.widgetId)
        items.clear()
        pages = 2
        seed(ctx)
        nextId = (items.maxOfOrNull { it.id } ?: 0L) + 1L
        fit()
        save()
    }

    var widgetCleanup: ((Int) -> Unit)? = null

    private fun seed(ctx: Context) {
        pages = 2
        val used = HashSet<String>()
        val def = AppRepo.defaults(ctx)
        var dx = 0
        for (a in def) {
            if (a == null || used.contains(a.key) || dx >= 4) continue
            used.add(a.key)
            val it = Item(newId(), T_APP, C_DOCK, 0, dx, 0)
            it.key = a.key
            items.add(it)
            dx++
        }
        val prism = AppRepo.apps.firstOrNull { it.pkg == ctx.packageName }
        val rest = ArrayList<AppInfo>()
        if (prism != null) rest.add(prism)
        for (a in AppRepo.apps) if (!used.contains(a.key) && a != prism) rest.add(a)
        var n = 0
        for (a in rest) {
            if (n >= 12) break
            val it = Item(newId(), T_APP, C_HOME, 0, n % Prefs.cols, n / Prefs.cols)
            it.key = a.key
            items.add(it)
            n++
        }
    }

    fun on(container: Int, page: Int): List<Item> = items.filter { it.container == container && (container == C_DOCK || it.page == page) }

    fun covers(i: Item, x: Int, y: Int): Boolean = x >= i.x && x < i.x + i.sx && y >= i.y && y < i.y + i.sy

    fun itemAt(container: Int, page: Int, x: Int, y: Int, ignore: Item?): Item? {
        for (i in items) {
            if (i === ignore || i.container != container) continue
            if (container == C_HOME && i.page != page) continue
            if (covers(i, x, y)) return i
        }
        return null
    }

    fun isFree(container: Int, page: Int, x: Int, y: Int, sx: Int, sy: Int, ignore: Item?): Boolean {
        val cols = gridCols(container)
        val rows = gridRows(container)
        if (x < 0 || y < 0 || x + sx > cols || y + sy > rows) return false
        for (yy in y until y + sy) for (xx in x until x + sx) if (itemAt(container, page, xx, yy, ignore) != null) return false
        return true
    }

    /** Cari tempat kosong terdekat dari (x,y) di halaman itu. */
    fun nearestFree(container: Int, page: Int, x: Int, y: Int, sx: Int, sy: Int, ignore: Item?): IntArray? {
        val cols = gridCols(container)
        val rows = gridRows(container)
        var best: IntArray? = null
        var bd = Int.MAX_VALUE
        for (yy in 0..(rows - sy)) for (xx in 0..(cols - sx)) {
            if (!isFree(container, page, xx, yy, sx, sy, ignore)) continue
            val d = (xx - x) * (xx - x) + (yy - y) * (yy - y)
            if (d < bd) { bd = d; best = intArrayOf(xx, yy) }
        }
        return best
    }

    /** Taruh item di halaman pertama yang muat (tambah halaman baru bila perlu). */
    fun place(i: Item, startPage: Int = 0) {
        i.container = C_HOME
        var p = startPage
        while (true) {
            if (p >= pages) pages = p + 1
            val s = nearestFree(C_HOME, p, 0, 0, i.sx, i.sy, i)
            if (s != null) { i.page = p; i.x = s[0]; i.y = s[1]; if (!items.contains(i)) items.add(i); return }
            p++
            if (p > 40) { if (!items.contains(i)) items.add(i); return }
        }
    }

    /** Rapikan item yang keluar batas setelah grid diubah. */
    fun fit() {
        val dockCols = Prefs.dockCount
        val moving = ArrayList<Item>()
        for (i in items) {
            if (i.container == C_DOCK) {
                if (i.x >= dockCols || i.type == T_WIDGET) moving.add(i)
            } else {
                if (i.sx > Prefs.cols) i.sx = Prefs.cols
                if (i.sy > Prefs.rows) i.sy = Prefs.rows
                if (i.x + i.sx > Prefs.cols || i.y + i.sy > Prefs.rows) moving.add(i)
            }
        }
        for (i in moving) { items.remove(i) }
        for (i in moving) place(i, 0)
        // buang halaman kosong di ujung (sisakan minimal 1)
        while (pages > 1 && items.none { it.container == C_HOME && it.page == pages - 1 }) pages--
        if (items.any { it.container == C_HOME && it.page >= pages }) pages = items.maxOf { if (it.container == C_HOME) it.page else 0 } + 1
    }

    /** Bersihkan referensi aplikasi yang sudah tidak terpasang. */
    fun cleanup() {
        val dead = ArrayList<Item>()
        for (i in items) {
            when (i.type) {
                T_APP -> if (AppRepo.find(i.key) == null) dead.add(i)
                T_FOLDER -> {
                    i.kids.removeAll { AppRepo.find(it) == null }
                    if (i.kids.isEmpty()) dead.add(i)
                }
            }
        }
        for (d in dead) items.remove(d)
        // folder berisi 1 aplikasi -> jadi ikon biasa
        for (i in items.toList()) {
            if (i.type == T_FOLDER && i.kids.size == 1) {
                i.type = T_APP
                i.key = i.kids[0]
                i.kids.clear()
            }
        }
    }

    fun removeWidget(i: Item) {
        if (i.type == T_WIDGET) widgetCleanup?.invoke(i.widgetId)
        items.remove(i)
    }

    fun hasApp(key: String): Boolean = items.any { (it.type == T_APP && it.key == key) || (it.type == T_FOLDER && it.kids.contains(key)) }
}

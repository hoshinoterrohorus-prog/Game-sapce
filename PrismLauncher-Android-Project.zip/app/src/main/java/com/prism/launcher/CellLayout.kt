package com.prism.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.ViewGroup

class CellLP(var item: Item?) : ViewGroup.LayoutParams(WRAP_CONTENT, WRAP_CONTENT) {
    var cx = 0
    var cy = 0
    var sx = 1
    var sy = 1
}

class CellLayout(ctx: Context) : ViewGroup(ctx) {
    var cols = 5
    var rows = 6
    var padH = 0
    var padV = 0
    /** Sorotan target jatuh: [x, y, sx, sy, valid(1/0)] */
    var hover: IntArray? = null
    private val hp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()

    fun cellW(): Float = (width - 2 * padH) / cols.toFloat()
    fun cellH(): Float = (height - 2 * padV) / rows.toFloat()

    override fun checkLayoutParams(p: LayoutParams?): Boolean = p is CellLP
    override fun generateDefaultLayoutParams(): LayoutParams = CellLP(null)
    override fun generateLayoutParams(p: LayoutParams?): LayoutParams = CellLP(null)

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = MeasureSpec.getSize(hSpec)
        setMeasuredDimension(w, h)
        val cw = (w - 2 * padH) / cols.toFloat()
        val ch = (h - 2 * padV) / rows.toFloat()
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val lp = v.layoutParams as CellLP
            v.measure(
                MeasureSpec.makeMeasureSpec((cw * lp.sx).toInt(), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec((ch * lp.sy).toInt(), MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (width - 2 * padH) / cols.toFloat()
        val ch = (height - 2 * padV) / rows.toFloat()
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val lp = v.layoutParams as CellLP
            val x = (padH + lp.cx * cw).toInt()
            val y = (padV + lp.cy * ch).toInt()
            v.layout(x, y, x + v.measuredWidth, y + v.measuredHeight)
        }
    }

    /** Sel pada koordinat lokal; null bila di luar. */
    fun cellAt(px: Float, py: Float): IntArray {
        val cw = cellW()
        val ch = cellH()
        val x = ((px - padH) / cw).toInt().coerceIn(0, cols - 1)
        val y = ((py - padV) / ch).toInt().coerceIn(0, rows - 1)
        return intArrayOf(x, y)
    }

    fun viewFor(item: Item): View? {
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if ((v.layoutParams as? CellLP)?.item === item) return v
        }
        return null
    }

    override fun dispatchDraw(c: Canvas) {
        val h = hover
        if (h != null) {
            val cw = cellW()
            val ch = cellH()
            rf.set(padH + h[0] * cw + 4f, padV + h[1] * ch + 4f, padH + (h[0] + h[2]) * cw - 4f, padV + (h[1] + h[3]) * ch - 4f)
            val pal = Themes.pal(context)
            hp.style = Paint.Style.FILL
            hp.color = U.alpha(if (h[4] == 1) pal.accent else 0xFFFF5555.toInt(), 0.22f)
            c.drawRoundRect(rf, dp(16f), dp(16f), hp)
            hp.style = Paint.Style.STROKE
            hp.strokeWidth = dp(1.5f)
            hp.color = U.alpha(if (h[4] == 1) pal.accent else 0xFFFF5555.toInt(), 0.8f)
            c.drawRoundRect(rf, dp(16f), dp(16f), hp)
        }
        super.dispatchDraw(c)
    }
}

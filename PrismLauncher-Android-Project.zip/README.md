# Prism Launcher
Launcher Android native (Kotlin, tanpa library tambahan) bergaya Nova/Smart Launcher dengan tema Glass & Liquid Glass.
Build: `gradle :app:assembleDebug` (Gradle 8.7, JDK 17, Android SDK 34).

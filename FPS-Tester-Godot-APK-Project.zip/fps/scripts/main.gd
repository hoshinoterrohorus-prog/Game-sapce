extends Node3D
## FPS Tester — beban sintetis bergaya game gacha open world (bukan game aslinya).

const GAMES := [
	{"name": "Genshin-like", "grass": 9000, "parts": 300, "props": 120, "shadow": 2048, "msaa": 2, "scale": 1.0, "gpu": 10, "cpu": 2500, "movers": 300, "lights": 2},
	{"name": "WuWa-like", "grass": 16000, "parts": 700, "props": 240, "shadow": 4096, "msaa": 2, "scale": 1.0, "gpu": 18, "cpu": 5500, "movers": 600, "lights": 4},
	{"name": "NTE-like", "grass": 6000, "parts": 500, "props": 520, "shadow": 4096, "msaa": 2, "scale": 1.0, "gpu": 24, "cpu": 8500, "movers": 900, "lights": 8},
	{"name": "Arknights-like", "grass": 1500, "parts": 100, "props": 60, "shadow": 1024, "msaa": 0, "scale": 0.85, "gpu": 4, "cpu": 700, "movers": 100, "lights": 0},
]
const TIERS := [
	{"n": "Rendah", "m": 0.5}, {"n": "Sedang", "m": 1.0}, {"n": "Tinggi", "m": 1.8}, {"n": "Ultra", "m": 3.0},
]
const HIST := 600

var game := 0
var tier := 1
var cfg := {}
var pivot: Node3D
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var grass: MultiMeshInstance3D
var grass_mat: ShaderMaterial
var props: MultiMeshInstance3D
var parts: GPUParticles3D
var movers: Array[Node3D] = []
var movers_root: Node3D
var omni_root: Node3D
var stress_mat: ShaderMaterial
var vel := Vector2.ZERO
var t := 0.0
var dts := PackedFloat32Array()
var frame_i := 0
var stat_timer := 0.0
var gacc := 0.0
var gcnt := 0
var st := {"avg": 0.0, "low": 0.0, "min": 0.0, "ms": 0.0}
var sink := 0.0
# UI
var l_fps: Label; var l_stats: Label; var l_info: Label; var l_test: Label
var graph: Control
var graph_hist := PackedFloat32Array()
var btn_games: Array[Button] = []; var btn_tiers: Array[Button] = []
var btn_run: Button; var btn_all: Button
var result_panel: PanelContainer; var result_label: RichTextLabel
# test
var test_on := false
var test_list: Array = []
var test_pos := 0
var test_phase := 0   # 0 warmup, 1 measure
var test_clock := 0.0
var test_dts := PackedFloat32Array()
var results: Array = []
var warm := 2.0
var meas := 10.0
# cli
var shot_path := ""
var shot_wait := 4.0
var autotest := false

func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shot="): shot_path = a.substr(7)
		elif a.begins_with("--wait="): shot_wait = float(a.substr(7))
		elif a.begins_with("--game="): game = int(a.substr(7))
		elif a.begins_with("--tier="): tier = int(a.substr(7))
		elif a == "--autotest": autotest = true
	_build_world()
	_build_ui()
	apply_cfg()
	if autotest:
		warm = 1.0; meas = 3.0
		start_test(true)

func _build_world() -> void:
	env = Environment.new()
	var sky := Sky.new(); var pm := ProceduralSkyMaterial.new()
	pm.sky_top_color = Color(0.32, 0.55, 0.95); pm.sky_horizon_color = Color(0.85, 0.90, 0.98)
	pm.ground_horizon_color = Color(0.85, 0.90, 0.98); pm.ground_bottom_color = Color(0.45, 0.6, 0.5)
	sky.sky_material = pm
	env.background_mode = Environment.BG_SKY; env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY; env.ambient_light_energy = 0.5
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true; env.glow_intensity = 0.4; env.glow_bloom = 0.0; env.glow_hdr_threshold = 1.4
	env.fog_enabled = true; env.fog_light_color = Color(0.8, 0.88, 0.98); env.fog_density = 0.006
	env.adjustment_enabled = true; env.adjustment_saturation = 1.15
	var we := WorldEnvironment.new(); we.environment = env; add_child(we)
	sun = DirectionalLight3D.new(); sun.rotation_degrees = Vector3(-42, -35, 0)
	sun.shadow_enabled = true; sun.light_energy = 0.75; sun.directional_shadow_max_distance = 60.0
	add_child(sun)
	cam = Camera3D.new(); cam.position = Vector3(0, 1.35, 3.6); cam.fov = 48
	add_child(cam); cam.look_at(Vector3(0, 1.0, 0))
	# tanah
	var gm := PlaneMesh.new(); gm.size = Vector2(120, 120); gm.subdivide_width = 1; gm.subdivide_depth = 1
	var gmat := ShaderMaterial.new(); gmat.shader = load("res://shaders/ground.gdshader")
	var gi := MeshInstance3D.new(); gi.mesh = gm; gi.material_override = gmat; gi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF; add_child(gi)
	# model utama yang bisa diputar
	pivot = Node3D.new(); pivot.position = Vector3(0, 0.95, 0); add_child(pivot)
	if ResourceLoader.exists("res://assets/char/hoshi.glb"):
		var m: Node3D = (load("res://assets/char/hoshi.glb") as PackedScene).instantiate()
		m.position = Vector3(0, -0.95, 0); pivot.add_child(m)
	else:
		var k := MeshInstance3D.new(); k.mesh = TorusMesh.new(); pivot.add_child(k)
	# rumput (posisi dihitung di GPU)
	var bm := ArrayMesh.new()
	var arr := []; arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = PackedVector3Array([Vector3(-0.045, 0, 0), Vector3(0.045, 0, 0), Vector3(-0.03, 0.3, 0), Vector3(0.03, 0.3, 0), Vector3(0, 0.62, 0)])
	arr[Mesh.ARRAY_TEX_UV] = PackedVector2Array([Vector2(0, 0), Vector2(1, 0), Vector2(0, 0.5), Vector2(1, 0.5), Vector2(0.5, 1)])
	arr[Mesh.ARRAY_NORMAL] = PackedVector3Array([Vector3.BACK, Vector3.BACK, Vector3.BACK, Vector3.BACK, Vector3.BACK])
	arr[Mesh.ARRAY_INDEX] = PackedInt32Array([0, 1, 2, 1, 3, 2, 2, 3, 4])
	bm.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	grass_mat = ShaderMaterial.new(); grass_mat.shader = load("res://shaders/grass.gdshader")
	bm.surface_set_material(0, grass_mat)
	var gmm := MultiMesh.new(); gmm.transform_format = MultiMesh.TRANSFORM_3D; gmm.mesh = bm; gmm.instance_count = 1000
	grass = MultiMeshInstance3D.new(); grass.multimesh = gmm
	grass.custom_aabb = AABB(Vector3(-40, -1, -40), Vector3(80, 4, 80)); grass.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(grass)
	# props (batu/kotak berwarna, bayangan aktif)
	props = MultiMeshInstance3D.new(); add_child(props)
	var pmesh := BoxMesh.new(); pmesh.size = Vector3(1, 1, 1)
	var pmat := StandardMaterial3D.new(); pmat.vertex_color_use_as_albedo = true; pmat.roughness = 0.8
	pmesh.material = pmat
	var pmm := MultiMesh.new(); pmm.transform_format = MultiMesh.TRANSFORM_3D; pmm.use_colors = true; pmm.mesh = pmesh; pmm.instance_count = 10
	props.multimesh = pmm
	# kelopak sakura
	parts = GPUParticles3D.new(); parts.lifetime = 9.0; parts.preprocess = 9.0
	var pp := ParticleProcessMaterial.new()
	pp.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX; pp.emission_box_extents = Vector3(25, 0.5, 25)
	pp.direction = Vector3(0.3, -1, 0.1); pp.spread = 20.0; pp.initial_velocity_min = 0.5; pp.initial_velocity_max = 1.5
	pp.gravity = Vector3(0.6, -0.7, 0.2); pp.angular_velocity_min = -180; pp.angular_velocity_max = 180
	pp.scale_min = 0.6; pp.scale_max = 1.4
	parts.process_material = pp
	var qm := QuadMesh.new(); qm.size = Vector2(0.14, 0.14)
	var qmat := StandardMaterial3D.new(); qmat.albedo_color = Color(1.0, 0.72, 0.82); qmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	qmat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED; qmat.cull_mode = BaseMaterial3D.CULL_DISABLED
	qm.material = qmat
	parts.draw_pass_1 = qm; parts.position = Vector3(0, 11, 0)
	parts.visibility_aabb = AABB(Vector3(-40, -20, -40), Vector3(80, 25, 80))
	add_child(parts)
	movers_root = Node3D.new(); add_child(movers_root)
	omni_root = Node3D.new(); add_child(omni_root)

func _mk_button(txt: String, toggle := true) -> Button:
	var b := Button.new(); b.text = txt; b.toggle_mode = toggle; b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, 54)
	return b

func _panel_style(c: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new(); s.bg_color = c; s.set_corner_radius_all(14)
	s.content_margin_left = 14; s.content_margin_right = 14; s.content_margin_top = 10; s.content_margin_bottom = 10
	return s

func _build_ui() -> void:
	var cl := CanvasLayer.new(); cl.layer = 5; add_child(cl)
	# beban GPU (di bawah UI)
	var cl0 := CanvasLayer.new(); cl0.layer = 1; add_child(cl0)
	var cr := ColorRect.new(); cr.set_anchors_preset(Control.PRESET_FULL_RECT); cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stress_mat = ShaderMaterial.new(); stress_mat.shader = load("res://shaders/stress.gdshader"); cr.material = stress_mat; cl0.add_child(cr)
	var theme := Theme.new(); theme.default_font_size = 24
	var sb := _panel_style(Color(0.08, 0.1, 0.16, 0.8)); var sbp := _panel_style(Color(0.35, 0.55, 1.0, 0.95)); var sbh := _panel_style(Color(0.15, 0.18, 0.28, 0.9))
	theme.set_stylebox("normal", "Button", sb); theme.set_stylebox("pressed", "Button", sbp); theme.set_stylebox("hover", "Button", sbh)
	theme.set_stylebox("hover_pressed", "Button", sbp)
	theme.set_color("font_pressed_color", "Button", Color.WHITE)
	var root := Control.new(); root.set_anchors_preset(Control.PRESET_FULL_RECT); root.theme = theme; root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cl.add_child(root)
	# kiri atas: statistik
	var pc := PanelContainer.new(); pc.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.06, 0.1, 0.7)))
	pc.position = Vector2(16, 14); pc.mouse_filter = Control.MOUSE_FILTER_IGNORE; root.add_child(pc)
	var vb := VBoxContainer.new(); pc.add_child(vb)
	l_fps = Label.new(); l_fps.text = "--"; l_fps.add_theme_font_size_override("font_size", 84); vb.add_child(l_fps)
	l_stats = Label.new(); l_stats.add_theme_font_size_override("font_size", 22); vb.add_child(l_stats)
	l_info = Label.new(); l_info.add_theme_font_size_override("font_size", 16); l_info.modulate = Color(1, 1, 1, 0.6); vb.add_child(l_info)
	var hz := DisplayServer.screen_get_refresh_rate()
	l_info.text = "%s\n%s | layar %.0f Hz" % [OS.get_model_name(), RenderingServer.get_video_adapter_name(), hz if hz > 0 else 60.0]
	# kanan: kontrol
	var rp := VBoxContainer.new(); rp.set_anchors_preset(Control.PRESET_TOP_RIGHT); rp.offset_left = -300; rp.offset_right = -14; rp.offset_top = 14
	rp.grow_horizontal = Control.GROW_DIRECTION_BEGIN; rp.add_theme_constant_override("separation", 8); root.add_child(rp)
	var lg := Label.new(); lg.text = "BEBAN GAME"; lg.add_theme_font_size_override("font_size", 16); lg.modulate = Color(1, 1, 1, 0.7); rp.add_child(lg)
	var grp1 := ButtonGroup.new()
	for i in GAMES.size():
		var b := _mk_button(GAMES[i]["name"]); b.button_group = grp1; b.button_pressed = (i == game); rp.add_child(b)
		b.pressed.connect(func(): game = i; apply_cfg()); btn_games.append(b)
	var lt := Label.new(); lt.text = "SETELAN"; lt.add_theme_font_size_override("font_size", 16); lt.modulate = Color(1, 1, 1, 0.7); rp.add_child(lt)
	var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 6); rp.add_child(hb)
	var grp2 := ButtonGroup.new()
	for i in TIERS.size():
		var b := _mk_button(TIERS[i]["n"].substr(0, 3)); b.button_group = grp2; b.button_pressed = (i == tier); b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 20)
		hb.add_child(b); b.pressed.connect(func(): tier = i; apply_cfg()); btn_tiers.append(b)
	btn_run = _mk_button("TES GAME INI", false); btn_run.pressed.connect(func(): start_test(false)); rp.add_child(btn_run)
	btn_all = _mk_button("TES SEMUA GAME", false); btn_all.pressed.connect(func(): start_test(true)); rp.add_child(btn_all)
	l_test = Label.new(); l_test.add_theme_font_size_override("font_size", 20); l_test.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; rp.add_child(l_test)
	# bawah: grafik kiri→kanan
	graph = Control.new(); graph.set_anchors_preset(Control.PRESET_BOTTOM_WIDE); graph.offset_top = -190; graph.offset_bottom = 0
	graph.mouse_filter = Control.MOUSE_FILTER_IGNORE; graph.draw.connect(_draw_graph); root.add_child(graph)
	# hasil
	result_panel = PanelContainer.new(); result_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.07, 0.12, 0.96)))
	result_panel.set_anchors_preset(Control.PRESET_CENTER); result_panel.custom_minimum_size = Vector2(760, 420)
	result_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH; result_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	result_panel.position = Vector2(-380, -250); result_panel.visible = false; root.add_child(result_panel)
	var rv := VBoxContainer.new(); result_panel.add_child(rv)
	result_label = RichTextLabel.new(); result_label.bbcode_enabled = true; result_label.fit_content = true; result_label.scroll_active = false
	result_label.size_flags_vertical = Control.SIZE_EXPAND_FILL; rv.add_child(result_label)
	var cb := _mk_button("TUTUP", false); cb.pressed.connect(func(): result_panel.visible = false); rv.add_child(cb)

func cfg_for(g: Dictionary, ti: Dictionary) -> Dictionary:
	var m: float = ti["m"]
	return {
		"grass": int(g["grass"] * m), "parts": int(g["parts"] * m), "props": int(g["props"] * m),
		"shadow": [1024, 2048, 4096, 4096][tier] if g["shadow"] <= 2048 else [2048, 4096, 4096, 8192][tier],
		"msaa": clampi(int(g["msaa"]) + (1 if tier >= 3 else 0) - (1 if tier == 0 else 0), 0, 3),
		"scale": clampf(float(g["scale"]) * [0.75, 0.9, 1.0, 1.0][tier], 0.5, 1.0),
		"gpu": clampi(int(g["gpu"] * m), 1, 158), "cpu": int(g["cpu"] * m), "movers": int(g["movers"] * m), "lights": clampi(int(g["lights"] * m), 0, 8),
	}

func apply_cfg() -> void:
	cfg = cfg_for(GAMES[game], TIERS[tier])
	var gn: int = cfg["grass"]
	grass.multimesh.instance_count = gn
	var buf := PackedFloat32Array(); buf.resize(gn * 12)
	for i in gn:
		buf[i * 12] = 1.0; buf[i * 12 + 5] = 1.0; buf[i * 12 + 10] = 1.0
	grass.multimesh.buffer = buf
	_build_props(cfg["props"])
	parts.amount = maxi(cfg["parts"], 1); parts.restart()
	stress_mat.set_shader_parameter("iters", cfg["gpu"])
	RenderingServer.directional_shadow_atlas_set_size(cfg["shadow"], true)
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if cfg["shadow"] >= 4096 else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	get_viewport().msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X, Viewport.MSAA_8X][cfg["msaa"]]
	get_viewport().scaling_3d_scale = cfg["scale"]
	env.glow_enabled = tier >= 1
	# gerakan CPU
	for m in movers: m.queue_free()
	movers.clear()
	for i in cfg["movers"]:
		var n := Node3D.new(); movers_root.add_child(n); movers.append(n)
	for c in omni_root.get_children(): c.queue_free()
	for i in cfg["lights"]:
		var o := OmniLight3D.new(); o.omni_range = 9.0; o.light_energy = 0.8
		o.light_color = Color.from_hsv(float(i) / 8.0, 0.4, 1.0)
		var a := float(i) / maxf(cfg["lights"], 1) * TAU; o.position = Vector3(cos(a) * 5, 1.5, sin(a) * 5); omni_root.add_child(o)
	dts.clear(); graph_hist.clear()

func _build_props(n: int) -> void:
	var mm := props.multimesh
	mm.instance_count = maxi(n, 1)
	var rng := RandomNumberGenerator.new(); rng.seed = 11
	for i in mm.instance_count:
		var a := rng.randf() * TAU; var r := rng.randf_range(4.0, 32.0)
		var s := rng.randf_range(0.4, 2.2)
		var b := Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(s, s * rng.randf_range(0.6, 2.5), s))
		mm.set_instance_transform(i, Transform3D(b, Vector3(cos(a) * r, s * 0.5, sin(a) * r)))
		mm.set_instance_color(i, Color.from_hsv(rng.randf(), 0.35, rng.randf_range(0.75, 1.0)))

func start_test(all: bool) -> void:
	test_list = [0, 1, 2, 3] if all else [game]
	test_pos = 0; results.clear(); result_panel.visible = false
	test_on = true; _test_begin()

func _test_begin() -> void:
	game = test_list[test_pos]
	for i in btn_games.size(): btn_games[i].button_pressed = (i == game)
	apply_cfg()
	test_phase = 0; test_clock = 0.0; test_dts.clear()

func _stats(a: PackedFloat32Array) -> Dictionary:
	if a.size() < 5: return {"avg": 0.0, "low": 0.0, "min": 0.0, "ms": 0.0}
	var sum := 0.0
	for d in a: sum += d
	var s := a.duplicate(); s.sort()
	var k := maxi(1, int(s.size() * 0.01)); var worst := 0.0
	for i in k: worst += s[s.size() - 1 - i]
	worst /= k
	return {"avg": a.size() / sum, "low": 1.0 / worst, "min": 1.0 / s[s.size() - 1], "ms": sum / a.size() * 1000.0}

func verdict(avg: float, low: float) -> String:
	if avg >= 55.0 and low >= 40.0: return "[color=#5dff8a]LANCAR (HP kuat)[/color]"
	if avg >= 40.0 and low >= 25.0: return "[color=#c8ff5d]ENAK DIMAINKAN[/color]"
	if avg >= 28.0: return "[color=#ffd05d]KURANG MULUS[/color]"
	return "[color=#ff6a5d]LAG[/color]"

func _process(delta: float) -> void:
	t += delta; frame_i += 1
	# putar objek
	pivot.rotation.y += vel.x + delta * 0.15; pivot.rotation.x += vel.y
	vel *= pow(0.03, delta)
	grass_mat.set_shader_parameter("t", t); stress_mat.set_shader_parameter("t", t)
	# beban CPU
	var x := sink
	for i in cfg["cpu"]: x += sin(float(i) * 0.37 + t) * cos(float(i) * 0.11)
	sink = x
	var n := movers.size()
	for i in n: movers[i].position = Vector3(sin(t + i) * 3.0, cos(t * 1.3 + i * 0.5), sin(t * 0.7 + i))
	if frame_i < 30: return
	dts.append(delta)
	if dts.size() > 300: dts.remove_at(0)
	stat_timer += delta
	gacc += delta; gcnt += 1
	if gacc >= 0.05:
		graph_hist.append(gcnt / gacc); gacc = 0.0; gcnt = 0
		if graph_hist.size() > HIST: graph_hist.remove_at(0)
	if stat_timer >= 0.25:
		stat_timer = 0.0; st = _stats(dts); _update_labels()
	if test_on: _test_tick(delta)
	if shot_path != "" and not autotest and t > shot_wait:
		get_viewport().get_texture().get_image().save_png(shot_path)
		print("SHOT ", shot_path, " fps=", st["avg"]); get_tree().quit()

func _update_labels() -> void:
	l_fps.text = "%d FPS" % int(round(st["avg"]))
	var f: float = st["avg"]
	l_fps.modulate = Color(0.4, 1.0, 0.55) if f >= 55 else (Color(1, 0.85, 0.35) if f >= 30 else Color(1, 0.4, 0.35))
	l_stats.text = "1%% low %d | min %d | %.1f ms" % [int(st["low"]), int(st["min"]), st["ms"]]
	graph.queue_redraw()

func _test_tick(delta: float) -> void:
	test_clock += delta
	if test_phase == 0:
		l_test.text = "%s - pemanasan..." % GAMES[game]["name"]
		if test_clock >= warm: test_phase = 1; test_clock = 0.0; test_dts.clear()
	else:
		test_dts.append(delta)
		l_test.text = "%s - mengukur %ds" % [GAMES[game]["name"], int(ceil(meas - test_clock))]
		if test_clock >= meas:
			var r := _stats(test_dts); r["game"] = GAMES[game]["name"]; results.append(r)
			test_pos += 1
			if test_pos < test_list.size(): _test_begin()
			else: _finish_test()

func _finish_test() -> void:
	test_on = false; l_test.text = ""
	var s := "[center][b][font_size=32]HASIL TES - setelan %s[/font_size][/b][/center]\n\n" % TIERS[tier]["n"]
	for r in results:
		s += "[font_size=26][b]%s[/b]   %d FPS   (1%% low %d, min %d)\n   %s[/font_size]\n" % [r["game"], int(round(r["avg"])), int(r["low"]), int(r["min"]), verdict(r["avg"], r["low"])]
	s += "\n[font_size=16]Ini beban sintetis bergaya game tsb, bukan game aslinya. Layar HP biasanya dibatasi 60/90/120 Hz.[/font_size]"
	result_label.text = s; result_panel.visible = true
	if autotest:
		print("RESULTS ", results)
		if shot_path != "": get_viewport().get_texture().get_image().save_png(shot_path)
		get_tree().quit()

func _draw_graph() -> void:
	var sz := graph.size
	graph.draw_rect(Rect2(Vector2.ZERO, sz), Color(0.03, 0.04, 0.08, 0.72))
	var hz := DisplayServer.screen_get_refresh_rate()
	var top := 60.0
	if hz > 0: top = ceilf(hz / 30.0) * 30.0
	top = maxf(top, 60.0)
	var font := ThemeDB.fallback_font
	for lv: float in [30.0, 60.0, top]:
		var y := sz.y - 8.0 - (lv / top) * (sz.y - 20.0)
		graph.draw_line(Vector2(0, y), Vector2(sz.x, y), Color(1, 1, 1, 0.18), 1.0)
		graph.draw_string(font, Vector2(6, y - 3), str(int(lv)), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(1, 1, 1, 0.55))
	var n := graph_hist.size()
	if n < 2: return
	var step := sz.x / float(HIST - 1)
	var pts := PackedVector2Array(); var cols := PackedColorArray()
	for i in n:
		var v := clampf(graph_hist[i], 0.0, top)
		pts.append(Vector2(i * step, sz.y - 8.0 - (v / top) * (sz.y - 20.0)))
		cols.append(Color(0.4, 1.0, 0.55) if v >= 55 else (Color(1, 0.85, 0.35) if v >= 30 else Color(1, 0.4, 0.35)))
	for i in n - 1: graph.draw_line(pts[i], pts[i + 1], cols[i], 3.0, true)

func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventMouseMotion and (e.button_mask & MOUSE_BUTTON_MASK_LEFT):
		vel += Vector2(e.relative.x, e.relative.y) * 0.0035
		vel = vel.limit_length(0.25)

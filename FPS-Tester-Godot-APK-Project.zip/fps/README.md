# FPS Tester (Godot 4.4)
Benchmark sintetis: model 3D yang bisa diputar (geser layar) + beban bergaya Genshin / WuWa / NTE / Arknights, grafik FPS real-time kiri-kanan, tes otomatis.

## Build APK
1. Upload isi folder ini ke repo GitHub baru (file `project.godot` harus di root repo).
2. Tab **Actions** → *Build APK* → **Run workflow**.
3. Selesai: unduh artifact `FPSTester-apk` → ekstrak → install `FPSTester.apk`.

Credit: sample VRM (pixiv, MIT, three-vrm). Bukan game aslinya; hasil = perkiraan relatif.

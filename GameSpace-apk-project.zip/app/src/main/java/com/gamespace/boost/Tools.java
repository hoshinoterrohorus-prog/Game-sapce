package com.gamespace.boost;

import android.app.ActivityManager;
import android.content.Context;
import android.view.Display;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Alat tambahan nyata lewat Shizuku (dipakai HUD dalam game dan menu utama).
 * Pengaturan yang diubah dicatat nilai aslinya dan dikembalikan oleh restoreAll().
 * Semua fungsi memblokir: panggil dari thread latar.
 */
public final class Tools {
    static final String[] NAME = {"KLEAN", "SHOT", "ROT", "DND", "TOUCH", "HZ", "FPS"};
    static final String[] SUB = {"RAM", "Layar", "Kunci", "Senyap", "Sentuhan", "Auto", "FPS mini"};

    private static String oRot, oZen, oTouch, oPeak, oMin;
    private static boolean chRot, chDnd, chTouch, chHz;
    static volatile int hzMode = 0;

    /** Status terbaca: [0] rotasi terkunci, [1] DND aktif, [2] sentuhan tampil. Null bila gagal. */
    static boolean[] readStates() {
        String[] t = Sh.run("echo $(settings get system accelerometer_rotation) $(settings get global zen_mode) $(settings get system show_touches) $(settings get system peak_refresh_rate) $(settings get system min_refresh_rate)").trim().split("\\s+");
        if (t.length < 5) return null;
        if (oRot == null) { oRot = t[0]; oZen = t[1]; oTouch = t[2]; oPeak = t[3]; oMin = t[4]; }
        return new boolean[]{t[0].equals("0"), !t[1].equals("0") && !t[1].equals("null"), t[2].equals("1")};
    }

    static String hzLabel() { return hzMode == 1 ? "Max" : hzMode == 2 ? "60 Hz" : "Auto"; }

    private static String sv(String v) { return v == null || !v.matches("[0-9.]+") ? null : v; }

    private static void setting(String ns, String key, String v) {
        if (sv(v) == null) Sh.run("settings delete " + ns + " " + key); else Sh.run("settings put " + ns + " " + key + " " + v);
    }

    static void setRot(boolean locked) { chRot = true; Sh.run("settings put system accelerometer_rotation " + (locked ? "0" : "1")); }
    static void setDnd(boolean on) { chDnd = true; Sh.run("cmd notification set_dnd " + (on ? "priority" : "off")); }
    static void setTouch(boolean on) { chTouch = true; Sh.run("settings put system show_touches " + (on ? "1" : "0")); }

    static int maxHz(Context c) {
        float best = 60;
        try {
            WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
            for (Display.Mode m : wm.getDefaultDisplay().getSupportedModes()) if (m.getRefreshRate() > best) best = m.getRefreshRate();
        } catch (Throwable ignored) {}
        return Math.round(best);
    }

    /** Auto -> Max -> 60 Hz -> Auto. Kembalikan mode baru. */
    static int cycleHz(Context c) {
        chHz = true;
        int m = (hzMode + 1) % 3;
        hzMode = m;
        if (m == 0) { setting("system", "peak_refresh_rate", oPeak); setting("system", "min_refresh_rate", oMin); }
        else {
            String v = String.valueOf(m == 1 ? maxHz(c) : 60);
            Sh.run("settings put system peak_refresh_rate " + v);
            Sh.run("settings put system min_refresh_rate " + v);
        }
        return m;
    }

    /** Bersihkan RAM; kembalikan teks hasil. */
    static String klean(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        int before = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));
        Sh.run("am kill-all");
        try { Thread.sleep(900); } catch (InterruptedException ignored) {}
        am.getMemoryInfo(mi);
        int after = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));
        return "RAM: " + before + "% → " + after + "%";
    }

    /** Tangkap layar ke Pictures. */
    static String shot() {
        String f = "/sdcard/Pictures/Dracio_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png";
        Sh.run("mkdir -p /sdcard/Pictures; screencap -p " + f);
        Sh.run("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://" + f);
        return "Layar disimpan di Pictures";
    }

    /** Kembalikan semua pengaturan yang pernah diubah. */
    static void restoreAll() {
        if (!(chRot || chDnd || chTouch || chHz)) return;
        final boolean r = chRot, dn = chDnd, to = chTouch, hz = chHz;
        final String a = oRot, b = oZen, c = oTouch, pk = oPeak, mn = oMin;
        chRot = chDnd = chTouch = chHz = false;
        hzMode = 0;
        new Thread(new Runnable() { public void run() {
            if (r) setting("system", "accelerometer_rotation", a);
            if (dn) Sh.run("cmd notification set_dnd " + ("0".equals(b) || b == null ? "off" : "priority"));
            if (to) setting("system", "show_touches", c);
            if (hz) { setting("system", "peak_refresh_rate", pk); setting("system", "min_refresh_rate", mn); }
        } }).start();
    }
}

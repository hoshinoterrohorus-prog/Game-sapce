package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/** Riak gelombang layar penuh + glow tepi layar saat ganti mode (1,1 detik). */
public class RippleView extends View {
    static final int D = 1100;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int color;
    private final float ox, oy;
    private Shader top, bottom, left, right;
    private long start = 0;
    private boolean finished = false;
    private Runnable onDone;

    public RippleView(Context c, int color, float ox, float oy) {
        super(c);
        this.color = color; this.ox = ox; this.oy = oy;
    }

    void setOnDone(Runnable r) { onDone = r; }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        start = SystemClock.uptimeMillis();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float m = Math.min(w, h) * .16f;
        int c0 = color | 0xFF000000, c1 = color & 0x00FFFFFF;
        top = new LinearGradient(0, 0, 0, m, c0, c1, Shader.TileMode.CLAMP);
        bottom = new LinearGradient(0, h, 0, h - m, c0, c1, Shader.TileMode.CLAMP);
        left = new LinearGradient(0, 0, m, 0, c0, c1, Shader.TileMode.CLAMP);
        right = new LinearGradient(w, 0, w - m, 0, c0, c1, Shader.TileMode.CLAMP);
    }

    private static float easeOut(float x) { float k = 1 - x; return 1 - k * k * k; }

    @Override protected void onDraw(Canvas cv) {
        long t = SystemClock.uptimeMillis() - start;
        if (t >= D) {
            if (!finished) { finished = true; if (onDone != null) post(onDone); }
            return;
        }
        float W = getWidth(), H = getHeight(), d = getResources().getDisplayMetrics().density;
        float k = t / (float) D;
        float m = Math.min(W, H) * .16f;

        // glow tepi layar
        p.reset(); p.setAntiAlias(true);
        p.setStyle(Paint.Style.FILL);
        int a = (int) (255 * Math.sin(Math.PI * k) * .35);
        p.setAlpha(a);
        p.setShader(top); cv.drawRect(0, 0, W, m, p);
        p.setShader(bottom); cv.drawRect(0, H - m, W, H, p);
        p.setShader(left); cv.drawRect(0, 0, m, H, p);
        p.setShader(right); cv.drawRect(W - m, 0, W, H, p);
        p.setShader(null);

        // tiga gelombang melebar dari tombol yang ditekan
        float maxR = (float) Math.hypot(W, H);
        p.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 3; i++) {
            float u = (t - i * 120) / (D - 300f);
            if (u <= 0 || u >= 1) continue;
            float r = easeOut(u) * maxR;
            p.setColor(color | 0xFF000000);
            p.setAlpha((int) (255 * (1 - u) * .12f));
            p.setStrokeWidth((26 * (1 - u) + 6) * d);
            cv.drawCircle(ox, oy, r, p);
            p.setAlpha((int) (255 * (1 - u) * .7f));
            p.setStrokeWidth((4 * (1 - u) + 1.5f) * d);
            cv.drawCircle(ox, oy, r, p);
        }
        postInvalidateOnAnimation();
    }
}

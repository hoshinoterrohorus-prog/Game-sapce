package com.gamespace.boost;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Mode Balance & Agresif lewat Shizuku. Semua perubahan bersifat sementara:
 * pengaturan asli disimpan dulu (snapshot) lalu dipulihkan saat mode dimatikan.
 */
final class Booster {
    static final int OFF = 0, BALANCE = 1, AGGRESSIVE = 2;
    static volatile String lastLog = "";
    static volatile String busy = "";
    static volatile String fpsDebug = "";
    static volatile String fgDebug = "";

    private static final String[] G_KEYS = {
            "window_animation_scale", "transition_animation_scale", "animator_duration_scale",
            "low_power", "adaptive_battery_management_enabled", "zen_mode"};

    private Booster() {}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("gs", Context.MODE_PRIVATE); }

    static int mode(Context c) { return prefs(c).getInt("active", OFF); }

    static void setMode(Context c, int m) { prefs(c).edit().putInt("active", m).apply(); }

    static Set<String> games(Context c) {
        return new HashSet<>(prefs(c).getStringSet("games", new HashSet<String>()));
    }

    static void setGames(Context c, Set<String> s) { prefs(c).edit().putStringSet("games", new HashSet<>(s)).apply(); }

    static boolean safePkg(String p) { return p != null && p.matches("[A-Za-z0-9_.]+"); }

    private static String safeVal(String v) {
        if (v == null) return "null";
        v = v.trim();
        return v.matches("[0-9.]+") ? v : "null";
    }

    /** Ganti mode. Hasilnya: mode aktif sebenarnya ada di mode(c). Jalankan di thread latar. */
    static synchronized String apply(Context c, int target, String fgPkg) {
        if (!Sh.granted()) {
            lastLog = "Shizuku belum aktif / belum diizinkan. Mode tidak diterapkan.";
            return lastLog;
        }
        StringBuilder log = new StringBuilder();
        try {
            if (mode(c) != OFF) {
                busy = "Memulihkan pengaturan...";
                restore(c, log);
            }
            if (target == OFF) {
                setMode(c, OFF);
                lastLog = "Mode dimatikan. Pengaturan kembali normal.\n" + log;
                return lastLog;
            }
            busy = target == AGGRESSIVE ? "Menerapkan mode Agresif..." : "Menerapkan mode Balance...";
            snapshot(c, fgPkg);
            String script = target == AGGRESSIVE ? aggressiveScript(c) : balanceScript(c);
            log.append(Sh.run(script).trim());
            setMode(c, target);
            lastLog = (target == AGGRESSIVE ? "[Agresif aktif] " : "[Balance aktif] ") + "\n" + log;
        } finally {
            busy = "";
        }
        return lastLog;
    }

    // ---------- snapshot ----------
    private static void snapshot(Context c, String fgPkg) {
        StringBuilder cmd = new StringBuilder();
        for (String k : G_KEYS) cmd.append("echo \"g:").append(k).append("=$(settings get global ").append(k).append(")\";");
        cmd.append("echo \"net:$(cmd netpolicy get restrict-background)\";");
        cmd.append("echo \"ime:$(settings get secure default_input_method)\";");
        cmd.append("echo \"home:$(cmd shortcut get-default-launcher)\";");
        cmd.append("pm list packages -3;");
        String out = Sh.run(cmd.toString());

        StringBuilder g = new StringBuilder();
        boolean netOn = false;
        String ime = "", home = "";
        List<String> pkgs = new ArrayList<>();
        for (String line : out.split("\n")) {
            line = line.trim();
            if (line.startsWith("g:")) g.append(line.substring(2)).append('\n');
            else if (line.startsWith("net:")) netOn = line.contains("enabled") && !line.contains("disabled");
            else if (line.startsWith("ime:")) ime = line.substring(4);
            else if (line.startsWith("home:")) home = line.substring(5);
            else if (line.startsWith("package:")) pkgs.add(line.substring(8).trim());
        }
        Set<String> skip = new HashSet<>(games(c));
        skip.add(c.getPackageName());
        skip.add("moe.shizuku.privileged.api");
        if (fgPkg != null) skip.add(fgPkg);
        Matcher m = Pattern.compile("([A-Za-z0-9_.]+)/").matcher(ime);
        if (m.find()) skip.add(m.group(1));
        m = Pattern.compile("([A-Za-z0-9_.]+)/").matcher(home);
        if (m.find()) skip.add(m.group(1));

        Set<String> restricted = new HashSet<>();
        for (String p : pkgs) {
            if (!safePkg(p) || skip.contains(p)) continue;
            if (p.toLowerCase().matches(".*(dialer|telecom|phone|messag|sms|contacts|inputmethod|keyboard).*")) continue;
            restricted.add(p);
        }
        Set<String> gm = new HashSet<>();
        for (String p : games(c)) if (safePkg(p)) gm.add(p);

        prefs(c).edit()
                .putString("snapG", g.toString())
                .putBoolean("snapNet", netOn)
                .putStringSet("restricted", restricted)
                .putStringSet("gamesApplied", gm)
                .apply();
    }

    private static String snapValue(String snapG, String key) {
        for (String line : snapG.split("\n")) {
            if (line.startsWith(key + "=")) return safeVal(line.substring(key.length() + 1));
        }
        return "null";
    }

    // ---------- skrip ----------
    private static void gamesMode(StringBuilder s, Context c, String mode) {
        for (String g : prefs(c).getStringSet("gamesApplied", new HashSet<String>()))
            s.append("cmd game set --mode ").append(mode).append(" --user 0 ").append(g).append(";");
    }

    private static String balanceScript(Context c) {
        StringBuilder s = new StringBuilder();
        s.append("cmd power set-fixed-performance-mode-enabled false;");
        s.append("settings put global adaptive_battery_management_enabled 1;");
        s.append("settings put global window_animation_scale 0.5;");
        s.append("settings put global transition_animation_scale 0.5;");
        s.append("settings put global animator_duration_scale 0.5;");
        gamesMode(s, c, "standard");
        s.append("am kill-all;");
        s.append("echo ok");
        return s.toString();
    }

    private static String aggressiveScript(Context c) {
        StringBuilder s = new StringBuilder();
        s.append("cmd notification set_dnd priority;");
        s.append("settings put global low_power 0;");
        s.append("cmd power set-fixed-performance-mode-enabled true;");
        s.append("settings put global window_animation_scale 0;");
        s.append("settings put global transition_animation_scale 0;");
        s.append("settings put global animator_duration_scale 0;");
        s.append("cmd netpolicy set restrict-background true;");
        gamesMode(s, c, "performance");
        for (String p : prefs(c).getStringSet("restricted", new HashSet<String>()))
            s.append("cmd appops set ").append(p).append(" RUN_ANY_IN_BACKGROUND deny;");
        s.append("am kill-all;");
        s.append("echo ok");
        return s.toString();
    }

    private static void restore(Context c, StringBuilder log) {
        SharedPreferences sp = prefs(c);
        String snap = sp.getString("snapG", "");
        StringBuilder s = new StringBuilder();
        for (String k : G_KEYS) {
            if (k.equals("zen_mode")) continue;
            String v = snapValue(snap, k);
            if (v.equals("null")) s.append("settings delete global ").append(k).append(";");
            else s.append("settings put global ").append(k).append(' ').append(v).append(";");
        }
        String z = snapValue(snap, "zen_mode");
        String dnd = z.equals("1") ? "priority" : z.equals("2") ? "none" : z.equals("3") ? "alarms" : "off";
        s.append("cmd notification set_dnd ").append(dnd).append(";");
        s.append("cmd netpolicy set restrict-background ").append(sp.getBoolean("snapNet", false)).append(";");
        s.append("cmd power set-fixed-performance-mode-enabled false;");
        gamesMode(s, c, "standard");
        for (String p : sp.getStringSet("restricted", new HashSet<String>()))
            s.append("cmd appops set ").append(p).append(" RUN_ANY_IN_BACKGROUND default;");
        s.append("echo restored");
        log.append(Sh.run(s.toString()).trim());
        sp.edit().remove("snapG").remove("snapNet").remove("restricted").remove("gamesApplied").apply();
    }
}

package com.gamespace.boost;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

/** Mode Balance & Agresif. Semua lewat Shizuku, perintah yang tidak didukung HP diabaikan. */
final class Booster {
    static final int BALANCE = 0, AGGRESSIVE = 1;
    static volatile String lastLog = "";

    private Booster() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("gs", Context.MODE_PRIVATE);
    }

    static int mode(Context c) { return prefs(c).getInt("mode", BALANCE); }

    static void setMode(Context c, int m) { prefs(c).edit().putInt("mode", m).apply(); }

    static Set<String> games(Context c) {
        return new HashSet<>(prefs(c).getStringSet("games", new HashSet<String>()));
    }

    static void setGames(Context c, Set<String> s) {
        prefs(c).edit().putStringSet("games", new HashSet<>(s)).apply();
    }

    static boolean safePkg(String p) { return p != null && p.matches("[A-Za-z0-9_.]+"); }

    /** Terapkan mode. pkg boleh null (tanpa game aktif). Jalankan di thread latar. */
    static String apply(Context c, int mode, String pkg) {
        StringBuilder cmd = new StringBuilder();
        if (mode == AGGRESSIVE) {
            cmd.append("cmd power set-fixed-performance-mode-enabled true;");
            cmd.append("settings put global low_power 0;");
            cmd.append("settings put global window_animation_scale 0;");
            cmd.append("settings put global transition_animation_scale 0;");
            cmd.append("settings put global animator_duration_scale 0;");
            cmd.append("am kill-all;");
            if (safePkg(pkg)) {
                cmd.append("cmd game set --mode performance --user 0 ").append(pkg).append(";");
                SharedPreferences sp = prefs(c);
                Set<String> done = new HashSet<>(sp.getStringSet("compiled", new HashSet<String>()));
                if (!done.contains(pkg)) {
                    done.add(pkg);
                    sp.edit().putStringSet("compiled", done).apply();
                    cmd.append("(cmd package compile -m speed-profile -f ").append(pkg).append(" >/dev/null 2>&1 &);");
                }
            }
        } else {
            cmd.append("cmd power set-fixed-performance-mode-enabled false;");
            cmd.append("settings put global window_animation_scale 1.0;");
            cmd.append("settings put global transition_animation_scale 1.0;");
            cmd.append("settings put global animator_duration_scale 1.0;");
            if (safePkg(pkg)) cmd.append("cmd game set --mode standard --user 0 ").append(pkg).append(";");
        }
        String out = Sh.run(cmd.toString());
        lastLog = (mode == AGGRESSIVE ? "[Agresif] " : "[Balance] ") + (pkg == null ? "" : pkg + "\n") + out.trim();
        return lastLog;
    }

    /** Dipanggil saat keluar dari game. */
    static void release(Context c, String pkg) {
        apply(c, BALANCE, pkg);
    }
}

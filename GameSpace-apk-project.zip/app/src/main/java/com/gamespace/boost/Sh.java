package com.gamespace.boost;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import android.content.pm.PackageManager;
import rikka.shizuku.Shizuku;

/** Menjalankan perintah shell lewat Shizuku (hak akses shell/adb). */
final class Sh {
    private Sh() {}

    static boolean running() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    static boolean granted() {
        try {
            return running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    static String run(String cmd) {
        if (!granted()) return "ERR shizuku belum siap";
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new Object[]{new String[]{"sh", "-c", cmd + " 2>&1"}, null, null});
            StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            try { p.waitFor(); } catch (Throwable ignored) {}
            return sb.toString();
        } catch (Throwable t) {
            Throwable c = t.getCause() != null ? t.getCause() : t;
            return "ERR " + c;
        }
    }
}

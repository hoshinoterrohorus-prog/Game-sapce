package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/**
 * HUD dalam game (layar horizontal) gaya Dracio: gauge CPU (GHz) di kiri, gauge FPS di kanan,
 * bilah miring bersegmen (beban CPU / RAM), kartu statistik, kotak mode, dan bar info bawah.
 * Semua angka nyata. Digambar langsung di Canvas; animasi ~20 fps hanya saat terbuka.
 */
public class HudView extends View {
    interface Listener { void onMode(int mode); void onStop(); void onClose(); }

    static final int RED = 0xFFE4002B, WHITE = 0xFFFFFFFF, DIM = 0xFF9A9A9A;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final Typeface black = Typeface.create("sans-serif-black", Typeface.NORMAL);
    private final Typeface blackIt = Typeface.create("sans-serif-black", Typeface.ITALIC);
    private final Typeface bold = Typeface.create("sans-serif", Typeface.BOLD);
    private final long t0 = System.currentTimeMillis();
    private Shader sideL, sideR;
    private final RectF[] tile = {new RectF(), new RectF(), new RectF(), new RectF()};
    private final RectF closeR = new RectF();
    private Listener listener;
    private boolean running;
    private int down = -2;

    // data
    String cpuBig = "--", cpuUnit = "GHz", ramS = "??%", tmpS = "??°C", batS = "??%", cpuPctS = "??%";
    String hz = "--", net = "-- KB/s", clock = "--:--", title = "";
    float cpuF = -1, ramF = -1, tmpF = -1, batF = -1, tempC = 0;
    int fps = -1, mode = 0;

    public HudView(Context c) { super(c); }

    void setListener(Listener l) { listener = l; }
    void setRunning(boolean r) { running = r; if (r) postInvalidateOnAnimation(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        sideL = new LinearGradient(0, 0, w * .36f, 0, 0xEB000000, 0x00000000, Shader.TileMode.CLAMP);
        sideR = new LinearGradient(w, 0, w * .64f, 0, 0xEB000000, 0x00000000, Shader.TileMode.CLAMP);
    }

    /** Teks dengan batas lebar: ukuran dikecilkan otomatis agar tidak keluar kotak. */
    private void txt(Canvas cv, String s, float x, float y, float size, int color, Paint.Align al, float maxW, Typeface tf) {
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(tf);
        p.setTextSize(size);
        float w = p.measureText(s);
        if (maxW > 0 && w > maxW) p.setTextSize(size * maxW / w);
        p.setColor(color);
        p.setTextAlign(al);
        cv.drawText(s, x, y, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void chamfer(Path pa, float l, float t, float r, float b, float c) {
        pa.reset();
        pa.moveTo(l + c, t); pa.lineTo(r, t); pa.lineTo(r, b - c); pa.lineTo(r - c, b); pa.lineTo(l, b); pa.lineTo(l, t + c); pa.close();
    }

    @Override protected void onDraw(Canvas cv) {
        float W = getWidth(), H = getHeight(), d = getResources().getDisplayMetrics().density;
        long now = System.currentTimeMillis() - t0;
        boolean hot = mode == 2;
        float pulse = (float) (0.5 + 0.5 * Math.sin(now / (hot ? 180.0 : 520.0)));

        cv.drawColor(0x5C000000);
        p.setStyle(Paint.Style.FILL);
        p.setShader(sideL); cv.drawRect(0, 0, W * .36f, H, p);
        p.setShader(sideR); cv.drawRect(W * .64f, 0, W, H, p);
        p.setShader(null);

        float topY = 50 * d, botY = H - 40 * d;
        float colW = 148 * d;

        // ---- bar atas: merek, judul, tombol tutup
        path.reset();
        path.moveTo(14 * d, 22 * d); path.lineTo(24 * d, 12 * d); path.lineTo(34 * d, 22 * d); path.lineTo(34 * d, 30 * d); path.lineTo(24 * d, 40 * d); path.lineTo(14 * d, 30 * d); path.close();
        p.setColor(RED); cv.drawPath(path, p);
        txt(cv, "D", 24 * d, 32 * d, 17 * d, WHITE, Paint.Align.CENTER, 0, blackIt);
        txt(cv, "DRA", 42 * d, 33 * d, 17 * d, WHITE, Paint.Align.LEFT, 0, blackIt);
        p.setTypeface(blackIt); p.setTextSize(17 * d);
        float dw = p.measureText("DRA");
        txt(cv, "CIO", 42 * d + dw, 33 * d, 17 * d, RED, Paint.Align.LEFT, 0, blackIt);
        float cw = Math.min(W * .34f, 260 * d);
        path.reset();
        path.moveTo(W / 2 - cw / 2 + 10 * d, 10 * d); path.lineTo(W / 2 + cw / 2, 10 * d);
        path.lineTo(W / 2 + cw / 2 - 10 * d, 36 * d); path.lineTo(W / 2 - cw / 2, 36 * d); path.close();
        p.setColor(0xAA000000); cv.drawPath(path, p);
        txt(cv, title, W / 2, 28 * d, 11 * d, 0xFFEDEDED, Paint.Align.CENTER, cw - 30 * d, bold);
        closeR.set(W - 48 * d, 8 * d, W - 12 * d, 40 * d);
        path.reset();
        float cx0 = closeR.centerX(), cy0 = closeR.centerY(), hr = 17 * d;
        path.moveTo(cx0 - hr / 2, cy0 - hr); path.lineTo(cx0 + hr / 2, cy0 - hr); path.lineTo(cx0 + hr, cy0);
        path.lineTo(cx0 + hr / 2, cy0 + hr); path.lineTo(cx0 - hr / 2, cy0 + hr); path.lineTo(cx0 - hr, cy0); path.close();
        p.setColor(down == -1 ? RED : 0x33FFFFFF); cv.drawPath(path, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.2f * d); p.setColor(WHITE);
        path.reset(); path.moveTo(cx0 - 5 * d, cy0 - 2 * d); path.lineTo(cx0, cy0 + 3 * d); path.lineTo(cx0 + 5 * d, cy0 - 2 * d);
        cv.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);

        // ---- kolom kiri: kartu statistik
        String[] kn = {"CPU", "RAM", "SUHU", "BAT"};
        String[] kv = {cpuPctS, ramS, tmpS, batS};
        float[] kf = {cpuF, ramF, tmpF, batF};
        float gap = 6 * d, ch = (botY - topY - 3 * gap) / 4f;
        for (int i = 0; i < 4; i++) {
            float y = topY + i * (ch + gap), x = 12 * d;
            chamfer(path, x, y, x + colW, y + ch, 9 * d);
            p.setColor(0xC40E0E0E); cv.drawPath(path, p);
            p.setColor(RED); cv.drawRect(x, y + 9 * d, x + 3 * d, y + ch, p);
            txt(cv, kn[i], x + 12 * d, y + 15 * d, 9 * d, RED, Paint.Align.LEFT, 0, black);
            int vc = (i == 2 && tempC >= 46) ? (((now / 250) % 2 == 0) ? RED : 0xFF8A1020) : WHITE;
            txt(cv, kv[i], x + 12 * d, y + ch * .66f, Math.min(20 * d, ch * .38f), vc, Paint.Align.LEFT, colW - 24 * d, black);
            float by = y + ch - 9 * d;
            p.setColor(0x24FFFFFF); cv.drawRect(x + 12 * d, by, x + colW - 12 * d, by + 3 * d, p);
            if (kf[i] >= 0) {
                float f = Math.min(1f, kf[i]);
                boolean bad = i == 3 ? f < .2f : f > .85f;
                p.setColor(bad ? RED : WHITE);
                cv.drawRect(x + 12 * d, by, x + 12 * d + (colW - 24 * d) * f, by + 3 * d, p);
            }
        }

        // ---- gauge + bilah di area tengah
        float le = 12 * d + colW + 14 * d, re = W - 12 * d - colW - 14 * d, cs = re - le;
        float R = Math.min(Math.min(58 * d, (botY - topY) * .26f), cs * .17f);
        float gcy = topY + (botY - topY) * .40f;
        gauge(cv, le + cs * .20f, gcy, R, cpuF, cpuBig, cpuUnit, "CPU", d, pulse, hot);
        float ff = fps >= 0 ? Math.min(1f, fps / 144f) : 0f;
        gauge(cv, re - cs * .20f, gcy, R, ff, fps >= 0 ? String.valueOf(fps) : "--", "FPS  •  " + hz + " Hz", "GAME", d, pulse, hot);
        bar(cv, le + cs * .43f, topY + 14 * d, botY - 6 * d, cpuF, 1, d, "CPU");
        bar(cv, re - cs * .43f, topY + 14 * d, botY - 6 * d, ramF, -1, d, "RAM");

        // ---- kolom kanan: kotak mode + info
        float rx = W - 12 * d - colW, tw = (colW - 6 * d) / 2f, th = Math.min(66 * d, (botY - topY) * .28f);
        String[] tn = {"BAL", "AGR", "OFF", "STOP"}, ts = {"Balance", "Agresif", "Matikan", "Hentikan"};
        int[] tm = {1, 2, 0, -1};
        for (int i = 0; i < 4; i++) {
            float x = rx + (i % 2) * (tw + 6 * d), y = topY + (i / 2) * (th + 6 * d);
            tile[i].set(x, y, x + tw, y + th);
            boolean on = tm[i] >= 0 && mode == tm[i] && tm[i] != 0;
            chamfer(path, x, y, x + tw, y + th, 9 * d);
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? (i == 1 ? RED : WHITE) : (down == i ? 0xFF3A0A12 : 0xC40E0E0E));
            cv.drawPath(path, p);
            if (!on) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.4f * d); p.setColor(i == 3 ? RED : 0x55FFFFFF);
                cv.drawPath(path, p);
            }
            int fg = on ? (i == 1 ? WHITE : 0xFF0A0A0A) : WHITE;
            txt(cv, tn[i], x + tw / 2, y + th * .52f, 15 * d, fg, Paint.Align.CENTER, tw - 10 * d, black);
            txt(cv, ts[i], x + tw / 2, y + th * .80f, 8.5f * d, on ? fg : DIM, Paint.Align.CENTER, tw - 8 * d, bold);
        }
        float iy = topY + 2 * (th + 6 * d) + 6 * d;
        String[] ik = {"JAM", "JARINGAN", "LAYAR"};
        String[] iv = {clock, net, hz + " Hz"};
        float rowH = Math.min(30 * d, (botY - iy) / 3f);
        for (int i = 0; i < 3; i++) {
            float y = iy + i * rowH;
            p.setStyle(Paint.Style.FILL); p.setColor(0x24FFFFFF);
            cv.drawRect(rx, y + rowH - 1 * d, rx + colW, y + rowH, p);
            txt(cv, ik[i], rx, y + rowH * .66f, 8 * d, RED, Paint.Align.LEFT, 0, black);
            txt(cv, iv[i], rx + colW, y + rowH * .66f, 12 * d, WHITE, Paint.Align.RIGHT, colW * .62f, black);
        }

        // ---- bar bawah tengah
        float bw = Math.min(W * .42f, 300 * d), by0 = H - 26 * d;
        path.reset();
        path.moveTo(W / 2 - bw / 2, H); path.lineTo(W / 2 - bw / 2 + 12 * d, by0); path.lineTo(W / 2 + bw / 2 - 12 * d, by0); path.lineTo(W / 2 + bw / 2, H); path.close();
        p.setStyle(Paint.Style.FILL); p.setColor(0xD9000000); cv.drawPath(path, p);
        p.setColor(RED); cv.drawRect(W / 2 - bw / 2 + 12 * d, by0, W / 2 + bw / 2 - 12 * d, by0 + 2 * d, p);
        txt(cv, "DRACIO   " + clock + "   " + batS + "   " + net, W / 2, H - 8 * d, 10.5f * d, WHITE, Paint.Align.CENTER, bw - 40 * d, bold);

        if (running) postInvalidateDelayed(50);
    }

    private void gauge(Canvas cv, float cx, float cy, float R, float frac, String big, String unit, String name, float d, float pulse, boolean hot) {
        // piringan datar di bawah gauge
        float ey = cy + R * 1.05f;
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, ey, R * 1.3f, 0x66E4002B, 0x00E4002B, Shader.TileMode.CLAMP));
        rf.set(cx - R * 1.3f, ey - R * .32f, cx + R * 1.3f, ey + R * .32f);
        cv.drawOval(rf, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.6f * d); p.setColor(0xCCE4002B);
        rf.set(cx - R * 1.05f, ey - R * .26f, cx + R * 1.05f, ey + R * .26f); cv.drawOval(rf, p);
        p.setColor(0x66E4002B);
        rf.set(cx - R * .78f, ey - R * .19f, cx + R * .78f, ey + R * .19f); cv.drawOval(rf, p);
        // cincin
        rf.set(cx - R, cy - R, cx + R, cy + R);
        p.setStrokeWidth(7 * d); p.setColor(0x2EFFFFFF);
        cv.drawArc(rf, 135, 270, false, p);
        if (frac > 0.005f) {
            p.setColor(hot && pulse > .5f ? 0xFFFF3B3B : RED);
            cv.drawArc(rf, 135, 270 * Math.min(1f, frac), false, p);
        }
        p.setStrokeWidth(1.4f * d); p.setColor(0x55FFFFFF);
        cv.drawCircle(cx, cy, R * .74f, p);
        p.setStyle(Paint.Style.FILL);
        txt(cv, big, cx, cy + R * .16f, R * .62f, WHITE, Paint.Align.CENTER, R * 1.2f, black);
        txt(cv, unit, cx, cy + R * .46f, R * .2f, DIM, Paint.Align.CENTER, R * 1.3f, bold);
        txt(cv, name, cx, ey + R * .62f, 10.5f * d, RED, Paint.Align.CENTER, 0, black);
    }

    /** Bilah miring bersegmen (gaya potongan chevron). dir=+1 miring ke kanan di atas, -1 ke kiri. */
    private void bar(Canvas cv, float cx, float yTop, float yBot, float frac, int dir, float d, String label) {
        int n = 14;
        float segH = (yBot - yTop) / n, lean = 26 * d, w = 24 * d, sl = 7 * d;
        int lit = frac < 0 ? 0 : Math.round(Math.min(1f, frac) * n);
        for (int i = 0; i < n; i++) {
            float k = i / (float) (n - 1);
            float y = yBot - (i + 1) * segH + 2 * d;
            float x = cx - w / 2 + dir * (k - .5f) * lean;
            path.reset();
            path.moveTo(x - dir * sl * 0, y + segH - 4 * d);
            path.lineTo(x + w, y + segH - 4 * d);
            path.lineTo(x + w + dir * sl, y);
            path.lineTo(x + dir * sl, y);
            path.close();
            p.setStyle(Paint.Style.FILL);
            if (i < lit) { int a = 110 + (int) (145 * k); p.setColor((a << 24) | 0x00E4002B); }
            else p.setColor(0x26FFFFFF);
            cv.drawPath(path, p);
        }
        txt(cv, label, cx, yTop - 6 * d, 8.5f * d, DIM, Paint.Align.CENTER, 0, black);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                down = hit(x, y);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP: {
                int h = hit(x, y);
                int was = down; down = -2; invalidate();
                if (listener == null) return true;
                if (h >= 0 && h == was) {
                    if (h == 0) listener.onMode(1); else if (h == 1) listener.onMode(2); else if (h == 2) listener.onMode(0); else listener.onStop();
                } else if (h == -1 || h == -2) listener.onClose();
                return true;
            }
            case MotionEvent.ACTION_CANCEL: down = -2; invalidate(); return true;
        }
        return true;
    }

    /** 0..3 = kotak, -1 = tombol tutup, -2 = area kosong. */
    private int hit(float x, float y) {
        for (int i = 0; i < 4; i++) if (tile[i].contains(x, y)) return i;
        if (closeR.contains(x, y)) return -1;
        return -2;
    }
}

package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** Panel neon ala Red Magic. Digambar langsung di Canvas, koordinat dasar 746 x 848. */
public class NeonPanel extends View {
    interface Listener {
        void onMode(int mode);
        void onDrag(float dx);
        void onRelease(float dx);
    }

    static final float BW = 746f, BH = 848f;
    static final int CY = 0xFF00E5FF, MG = 0xFFFF00C8, RD = 0xFFFF2A4D;

    private final RectF[] pill = {new RectF(449, 70, 697, 160), new RectF(449, 175, 697, 265), new RectF(449, 280, 697, 370)};
    private static final int[] PILL_MODE = {1, 2, 0};
    private final RectF card = new RectF(4, 4, BW - 4, BH - 4);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final long t0 = System.currentTimeMillis();
    private Listener listener;

    String cpu = "??%", ram = "??%", tmp = "??°C", bat = "??%", hz = "??";
    String fpsText = "--", fpsLabel = "FPS", caption = "";
    float ringFrac = 0f;
    int ringColor = CY;
    int mode = 0;

    private int pressed = -1;
    private float downX;

    public NeonPanel(Context c) {
        super(c);
        clip.addRoundRect(card, 52, 52, Path.Direction.CW);
    }

    void setListener(Listener l) { listener = l; }

    void setData(String cpu, String ram, String tmp, String bat, String hz, String fpsText, String fpsLabel, float frac, int col, String caption) {
        this.cpu = cpu; this.ram = ram; this.tmp = tmp; this.bat = bat; this.hz = hz;
        this.fpsText = fpsText; this.fpsLabel = fpsLabel; this.ringFrac = frac; this.ringColor = col; this.caption = caption;
        invalidate();
    }

    void setMode(int m) { mode = m; invalidate(); }

    @Override protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        if (MeasureSpec.getMode(w) == MeasureSpec.UNSPECIFIED || width <= 0) width = (int) (getResources().getDisplayMetrics().density * 228);
        setMeasuredDimension(width, Math.round(width * BH / BW));
    }

    /** Kecilkan ukuran teks supaya lebarnya tidak melebihi max (satuan dasar). */
    private float fit(String t, float size, float max) {
        p.setTextSize(size);
        float w = p.measureText(t);
        if (w > max) size = size * max / w;
        p.setTextSize(size);
        return size;
    }

    private int a(int color, int alpha) { return (color & 0x00FFFFFF) | (alpha << 24); }

    @Override protected void onDraw(Canvas cv) {
        float s = getWidth() / BW;
        cv.save();
        cv.scale(s, s);
        long now = System.currentTimeMillis() - t0;
        boolean turbo = mode == 2;
        float pulse = (float) (0.5 + 0.5 * Math.sin(now / (turbo ? 160.0 : 480.0)));

        // latar kartu
        p.reset(); p.setAntiAlias(true);
        p.setShader(new LinearGradient(0, 0, BW * .4f, BH, 0xFF0B1020, 0xFF05070F, Shader.TileMode.CLAMP));
        cv.drawRoundRect(card, 52, 52, p);
        p.setShader(null);

        // kilau samar pojok
        p.setShader(new LinearGradient(0, 0, BW, 0, a(CY, 26), 0x00000000, Shader.TileMode.CLAMP));
        cv.save(); cv.clipPath(clip); cv.drawRect(0, 0, BW, 260, p);
        p.setShader(null);

        // garis scan
        float sy = ((now % 3200) / 3200f) * (BH + 360) - 180;
        p.setShader(new LinearGradient(0, sy - 90, 0, sy + 90, new int[]{0, a(CY, 34), 0}, null, Shader.TileMode.CLAMP));
        cv.drawRect(0, sy - 90, BW, sy + 90, p);
        p.setShader(null);
        cv.restore();

        // border neon berputar
        int[] cols = turbo
                ? new int[]{RD, 0xFFFF8A00, MG, a(RD, 30), RD, 0xFFFFD000, a(RD, 30), RD}
                : new int[]{CY, MG, RD, a(CY, 20), CY, a(MG, 20), CY, CY};
        float[] pos = {0f, .16f, .32f, .45f, .6f, .72f, .86f, 1f};
        SweepGradient sw = new SweepGradient(BW / 2, BH / 2, cols, pos);
        Matrix m = new Matrix();
        m.setRotate((now / (turbo ? 1400f : 4000f)) * 360f, BW / 2, BH / 2);
        sw.setLocalMatrix(m);
        p.setShader(sw);
        p.setStyle(Paint.Style.STROKE);
        float[] gw = {26, 16, 8};
        int[] ga = {turbo ? 40 + (int) (40 * pulse) : 28, turbo ? 70 + (int) (50 * pulse) : 55, 255};
        for (int i = 0; i < 3; i++) {
            p.setStrokeWidth(gw[i]);
            p.setAlpha(ga[i]);
            cv.drawRoundRect(card, 52, 52, p);
        }
        p.setShader(null); p.setAlpha(255);

        // statistik kiri
        Typeface bold = Typeface.create("sans-serif-black", Typeface.NORMAL);
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(bold);
        String[] lab = {"CPU", "RAM", "SUHU", "BAT", "HZ"};
        String[] val = {cpu, ram, tmp, bat, hz};
        float[] by = {112, 234, 356, 478, 610};
        float[] mw = {368, 368, 368, 300, 270};
        for (int i = 0; i < 5; i++) {
            p.setShadowLayer(0, 0, 0, 0);
            p.setTextSize(54);
            float tw = p.measureText(lab[i]) + 16 + p.measureText(val[i]);
            p.setTextSize(54 * Math.min(1f, 368f / tw));
            // label + nilai dianggap satu baris, maksimal lebar 368 (tombol mulai di x=449)
            p.setTextSize(54);
            float full = p.measureText(lab[i]) + 16 + p.measureText(val[i]);
            float sz = full > mw[i] ? Math.max(10f, 54 * mw[i] / full * 0.98f) : 54;
            p.setTextSize(sz);
            p.setColor(0xFF7FE9FF);
            p.setShadowLayer(14, 0, 0, CY);
            cv.drawText(lab[i], 64, by[i], p);
            float lw = p.measureText(lab[i]);
            p.setShadowLayer(0, 0, 0, 0);
            p.setColor(Color.WHITE);
            cv.drawText(val[i], 64 + lw + 16, by[i], p);
        }
        if (turbo) {
            p.setColor(a(RD, 120 + (int) (135 * pulse)));
            p.setTextSize(26);
            p.setShadowLayer(12, 0, 0, RD);
            cv.drawText("TURBO", 66, 540, p);
            p.setShadowLayer(0, 0, 0, 0);
        }

        // tombol mode: Balance / Aggressive / Matikan
        String[] names = {"Balance", "Aggressive", "Matikan"};
        int[] pc = {CY, RD, 0xFFB8C7E6};
        for (int i = 0; i < 3; i++) {
            RectF r = pill[i];
            int col = pc[i];
            boolean on = mode == PILL_MODE[i];
            if (i == 2 && mode == 0) on = false; // "Matikan" hanya menyala saat ada mode aktif (jadi tombol aksi)
            boolean dim = i == 2 && mode == 0;
            if (on) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(a(col, 70 + (int) (50 * pulse)));
                RectF g = new RectF(r.left - 8, r.top - 8, r.right + 8, r.bottom + 8);
                cv.drawRoundRect(g, 53, 53, p);
                p.setColor(col);
                cv.drawRoundRect(r, 45, 45, p);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x0AFFFFFF);
                cv.drawRoundRect(r, 45, 45, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(5);
                p.setColor(dim ? a(col, 70) : col);
                cv.drawRoundRect(r, 45, 45, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            fit(names[i], 38, 206);
            p.setColor(on ? (i == 0 ? 0xFF02131A : i == 1 ? Color.WHITE : 0xFF02131A) : (dim ? 0x66DDFFFF : 0xFFDDFFFF));
            float ty = r.centerY() - (p.descent() + p.ascent()) / 2;
            cv.drawText(names[i], r.centerX(), ty, p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        // cincin FPS
        float cx = 535, cyy = 586;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(a(turbo ? 0xFFFF783C : CY, 140));
        p.setPathEffect(new DashPathEffect(new float[]{3, 17}, (now / (turbo ? 40f : 160f))));
        cv.drawCircle(cx, cyy, 190, p);
        p.setPathEffect(null);

        RectF ring = new RectF(cx - 149, cyy - 149, cx + 149, cyy + 149);
        p.setStrokeWidth(27);
        p.setColor(0x14FFFFFF);
        cv.drawCircle(cx, cyy, 149, p);
        float sweep = Math.max(0, Math.min(1, ringFrac)) * 360f;
        if (sweep > 0.5f) {
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(46); p.setColor(a(ringColor, 40 + (int) (30 * pulse)));
            cv.drawArc(ring, -90, sweep, false, p);
            p.setStrokeWidth(27); p.setColor(ringColor);
            cv.drawArc(ring, -90, sweep, false, p);
            p.setStrokeCap(Paint.Cap.BUTT);
        }
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE);
        fit(fpsText, 96, 190);
        cv.drawText(fpsText, cx, 610, p);
        p.setTextSize(38);
        p.setColor(0xFF7FE9FF);
        cv.drawText(fpsLabel, cx, 672, p);
        p.setTextAlign(Paint.Align.LEFT);

        // logo Cyra
        p.setTypeface(Typeface.create("sans-serif-black", Typeface.ITALIC));
        fit("Cyra", 150, 270);
        p.setShader(new LinearGradient(48, 0, 318, 0, new int[]{CY, MG, RD}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP));
        p.setShadowLayer(18 + 10 * pulse, 0, 0, MG);
        cv.drawText("Cyra", 48, 770, p);
        p.setShader(null);
        p.setShadowLayer(0, 0, 0, 0);

        // keterangan kecil
        p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        fit(caption, 23, 600);
        p.setColor(0xFF6C7A99);
        cv.drawText(caption, 64, 832, p);

        cv.restore();
        postInvalidateDelayed(40);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float s = getWidth() / BW;
        float ux = e.getX() / s, uy = e.getY() / s;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX();
                pressed = -1;
                for (int i = 0; i < 3; i++) if (pill[i].contains(ux, uy)) pressed = i;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (pressed < 0 && listener != null) listener.onDrag(e.getRawX() - downX);
                return true;
            case MotionEvent.ACTION_UP: {
                float dx = e.getRawX() - downX;
                if (pressed >= 0) {
                    if (pill[pressed].contains(ux, uy) && listener != null) listener.onMode(PILL_MODE[pressed]);
                } else if (listener != null) listener.onRelease(dx);
                pressed = -1;
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                if (pressed < 0 && listener != null) listener.onRelease(0);
                pressed = -1;
                return true;
        }
        return false;
    }
}

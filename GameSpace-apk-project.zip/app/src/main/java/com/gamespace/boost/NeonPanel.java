package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/**
 * Panel neon ala Red Magic. Digambar langsung di Canvas, koordinat dasar 746 x 848.
 * Ringan: shader di-cache, tanpa alokasi per frame, animasi ~20 fps dan berhenti saat panel tersembunyi.
 */
public class NeonPanel extends View {
    interface Listener {
        void onMode(int mode);
        void onDrag(float dx);
        void onRelease(float dx);
    }

    static final float BW = 746f, BH = 848f;
    static final int CY = 0xFF00E5FF, MG = 0xFFFF00C8, RD = 0xFFFF2A4D, GN = 0xFF00FF9C, YL = 0xFFFFD000;
    private static final int[] PILL_MODE = {1, 2, 0};
    private static final int HN = 40;

    private final RectF[] pill = {new RectF(449, 70, 697, 160), new RectF(449, 175, 697, 265), new RectF(449, 280, 697, 370)};
    private final RectF card = new RectF(4, 4, BW - 4, BH - 4);
    private final RectF tmp = new RectF();
    private final RectF ringRect = new RectF(535 - 149, 586 - 149, 535 + 149, 586 + 149);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path(), corners = new Path(), tri = new Path(), spark = new Path(), sparkFill = new Path();
    private final Matrix mx = new Matrix();
    private final long t0 = System.currentTimeMillis();
    private Listener listener;

    // cache shader
    private final Shader bgShader, shineShader, scanShader, logoShader;
    private final SweepGradient sweepCool, sweepHot;
    private final Typeface black = Typeface.create("sans-serif-black", Typeface.NORMAL);
    private final Typeface blackIt = Typeface.create("sans-serif-black", Typeface.ITALIC);
    private final Typeface boldSans = Typeface.create("sans-serif", Typeface.BOLD);

    // data
    String cpu = "??%", ram = "??%", tmpS = "??°C", bat = "??%", hz = "??";
    String fpsText = "--", fpsLabel = "FPS", caption = "";
    float ringFrac = 0f;
    int ringColor = CY;
    int mode = 0;
    private float cpuF = -1, ramF = -1, tmpF = -1, batF = -1, tempC = 0;
    private int fpsVal = -1;
    private final int[] hist = new int[HN];
    private int histN = 0;
    private String sparkTxt = "AVG -- · MIN --";
    private long shockT = -10000;

    private int pressed = -1;
    private float downX;

    public NeonPanel(Context c) {
        super(c);
        clip.addRoundRect(card, 52, 52, Path.Direction.CW);
        bgShader = new LinearGradient(0, 0, BW * .4f, BH, 0xFF0B1020, 0xFF05070F, Shader.TileMode.CLAMP);
        shineShader = new LinearGradient(0, 0, BW, 0, a(CY, 26), 0x00000000, Shader.TileMode.CLAMP);
        scanShader = new LinearGradient(0, 0, 0, 180, new int[]{0, a(CY, 34), 0}, null, Shader.TileMode.CLAMP);
        logoShader = new LinearGradient(46, 0, 378, 0, new int[]{CY, MG, RD}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP);
        float[] pos = {0f, .16f, .32f, .45f, .6f, .72f, .86f, 1f};
        sweepCool = new SweepGradient(BW / 2, BH / 2, new int[]{CY, MG, RD, a(CY, 20), CY, a(MG, 20), CY, CY}, pos);
        sweepHot = new SweepGradient(BW / 2, BH / 2, new int[]{RD, 0xFFFF8A00, MG, a(RD, 30), RD, YL, a(RD, 30), RD}, pos);
        // sudut siku
        corners.moveTo(20, 50); corners.lineTo(20, 22); corners.lineTo(48, 22);
        corners.moveTo(726, 50); corners.lineTo(726, 22); corners.lineTo(698, 22);
        corners.moveTo(20, 798); corners.lineTo(20, 826); corners.lineTo(48, 826);
        corners.moveTo(726, 798); corners.lineTo(726, 826); corners.lineTo(698, 826);
        tri.moveTo(64, 44); tri.lineTo(64, 28); tri.lineTo(80, 44); tri.close();
    }

    void setListener(Listener l) { listener = l; }

    void setData(String cpu, String ram, String tmp, String bat, String hz, String fpsText, String fpsLabel, float frac, int col, String caption) {
        this.cpu = cpu; this.ram = ram; this.tmpS = tmp; this.bat = bat; this.hz = hz;
        this.fpsText = fpsText; this.fpsLabel = fpsLabel; this.ringFrac = frac; this.ringColor = col; this.caption = caption;
        invalidate();
    }

    /** Angka mentah untuk bar, peringatan suhu, dan grafik FPS (dipanggil tiap detik). */
    void setStats(float cpuF, float ramF, float tmpF, float batF, float tempC, int fpsVal) {
        this.cpuF = cpuF; this.ramF = ramF; this.tmpF = tmpF; this.batF = batF; this.tempC = tempC; this.fpsVal = fpsVal;
        if (fpsVal >= 0) {
            if (histN == HN) { System.arraycopy(hist, 1, hist, 0, HN - 1); histN = HN - 1; }
            hist[histN++] = fpsVal;
            int sum = 0, min = Integer.MAX_VALUE;
            for (int i = 0; i < histN; i++) { sum += hist[i]; if (hist[i] < min) min = hist[i]; }
            sparkTxt = "AVG " + (sum / histN) + " · MIN " + min;
        }
    }

    void setMode(int m) {
        if (m != mode) shockT = System.currentTimeMillis();
        mode = m;
        invalidate();
    }

    @Override protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        if (MeasureSpec.getMode(w) == MeasureSpec.UNSPECIFIED || width <= 0) width = (int) (getResources().getDisplayMetrics().density * 228);
        setMeasuredDimension(width, Math.round(width * BH / BW));
    }

    /** Kecilkan ukuran teks supaya lebarnya tidak melebihi max (satuan dasar). */
    private float fit(String t, float size, float max) {
        p.setTextSize(size);
        float w = p.measureText(t);
        if (w > max) size = size * max / w;
        p.setTextSize(size);
        return size;
    }

    private static int a(int color, int alpha) { return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24); }

    private static int barColor(float f, boolean inv) {
        float bad = inv ? 1 - f : f;
        return bad < .6f ? GN : bad < .85f ? YL : RD;
    }

    @Override protected void onDraw(Canvas cv) {
        float s = getWidth() / BW;
        cv.save();
        cv.scale(s, s);
        long now = System.currentTimeMillis() - t0;
        boolean turbo = mode == 2;
        float pulse = (float) (0.5 + 0.5 * Math.sin(now / (turbo ? 160.0 : 480.0)));

        // ---- latar kartu
        p.reset(); p.setAntiAlias(true);
        p.setShader(bgShader);
        cv.drawRoundRect(card, 52, 52, p);
        p.setShader(null);

        // kilau samar + garis scan (dibatasi di dalam kartu)
        cv.save();
        cv.clipPath(clip);
        p.setShader(shineShader);
        cv.drawRect(0, 0, BW, 260, p);
        float sy = ((now % 3200) / 3200f) * (BH + 360) - 270;
        cv.translate(0, sy);
        p.setShader(scanShader);
        cv.drawRect(0, 0, BW, 180, p);
        p.setShader(null);
        cv.restore();

        // ---- border neon berputar (3 lapis: glow lebar -> tajam)
        SweepGradient sw = turbo ? sweepHot : sweepCool;
        mx.setRotate((now / (turbo ? 1400f : 4000f)) * 360f, BW / 2, BH / 2);
        sw.setLocalMatrix(mx);
        p.setShader(sw);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(26); p.setAlpha(turbo ? 40 + (int) (40 * pulse) : 28);
        cv.drawRoundRect(card, 52, 52, p);
        p.setStrokeWidth(16); p.setAlpha(turbo ? 70 + (int) (50 * pulse) : 55);
        cv.drawRoundRect(card, 52, 52, p);
        p.setStrokeWidth(8); p.setAlpha(255);
        cv.drawRoundRect(card, 52, 52, p);
        p.setShader(null);

        // ---- header HUD + sudut siku
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(a(turbo ? 0xFFFF6A3C : CY, 190));
        cv.drawPath(corners, p);
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF5FB8CC);
        cv.drawPath(tri, p);
        p.setTypeface(boldSans);
        fit("COREVIUS // GAME SPACE", 22, 380);
        cv.drawText("COREVIUS // GAME SPACE", 90, 44, p);
        boolean live = fpsVal >= 0;
        p.setColor(live ? a(GN, 90 + (int) (165 * pulse)) : 0xFF6C7A99);
        cv.drawCircle(612, 36, 6, p);
        p.setColor(live ? 0xFF5FB8CC : 0xFF6C7A99);
        fit(live ? "LIVE" : "IDLE", 22, 80);
        cv.drawText(live ? "LIVE" : "IDLE", 628, 44, p);

        // ---- statistik kiri + bar
        p.setTypeface(black);
        String[] lab = {"CPU", "RAM", "SUHU", "BAT", "HZ"};
        String[] val = {cpu, ram, tmpS, bat, hz};
        float[] by = {112, 234, 356, 478, 610};
        float[] mw = {368, 368, 368, 300, 270};
        float[] bf = {cpuF, ramF, tmpF, batF, -1};
        for (int i = 0; i < 5; i++) {
            p.setTextSize(54);
            float full = p.measureText(lab[i]) + 16 + p.measureText(val[i]);
            float sz = full > mw[i] ? Math.max(10f, 54 * mw[i] / full * 0.98f) : 54;
            p.setTextSize(sz);
            p.setColor(0xFF7FE9FF);
            p.setShadowLayer(14, 0, 0, CY);
            cv.drawText(lab[i], 64, by[i], p);
            float lw = p.measureText(lab[i]);
            p.setShadowLayer(0, 0, 0, 0);
            int vc = Color.WHITE;
            if (i == 2 && tempC >= 46) vc = ((now / 250) % 2 == 0) ? RD : 0xFF8A1020;
            else if (i == 2 && tempC >= 42) vc = 0xFFFFB000;
            p.setColor(vc);
            cv.drawText(val[i], 64 + lw + 16, by[i], p);
            if (bf[i] >= 0) {
                float f = Math.min(1f, bf[i]);
                p.setColor(0x14FFFFFF);
                tmp.set(64, by[i] + 16, 324, by[i] + 24);
                cv.drawRoundRect(tmp, 4, 4, p);
                if (f > 0.01f) {
                    p.setColor(barColor(f, i == 3));
                    tmp.set(64, by[i] + 16, 64 + 260 * f, by[i] + 24);
                    cv.drawRoundRect(tmp, 4, 4, p);
                }
            }
        }
        if (turbo) {
            p.setTextSize(26);
            p.setColor(a(RD, 120 + (int) (135 * pulse)));
            p.setShadowLayer(12, 0, 0, RD);
            cv.drawText("TURBO", 66, 540, p);
            p.setShadowLayer(0, 0, 0, 0);
        }

        // ---- tombol mode: Balance / Aggressive / Matikan
        String[] names = {"Balance", "Aggressive", "Matikan"};
        int[] pc = {CY, RD, 0xFFB8C7E6};
        for (int i = 0; i < 3; i++) {
            RectF r = pill[i];
            int col = pc[i];
            boolean on = mode == PILL_MODE[i] && i != 2;
            boolean dim = i == 2 && mode == 0;
            if (on) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(a(col, 70 + (int) (50 * pulse)));
                tmp.set(r.left - 8, r.top - 8, r.right + 8, r.bottom + 8);
                cv.drawRoundRect(tmp, 53, 53, p);
                p.setColor(col);
                cv.drawRoundRect(r, 45, 45, p);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x0AFFFFFF);
                cv.drawRoundRect(r, 45, 45, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(5);
                p.setColor(dim ? a(col, 70) : col);
                cv.drawRoundRect(r, 45, 45, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            fit(names[i], 38, 206);
            p.setColor(on ? (i == 0 ? 0xFF02131A : Color.WHITE) : (dim ? 0x66DDFFFF : 0xFFDDFFFF));
            float ty = r.centerY() - (p.descent() + p.ascent()) / 2;
            cv.drawText(names[i], r.centerX(), ty, p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        // ---- cincin FPS
        float cx = 535, cyy = 586;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(a(turbo ? 0xFFFF783C : CY, 140));
        p.setPathEffect(new DashPathEffect(new float[]{3, 17}, (now / (turbo ? 40f : 160f))));
        cv.drawCircle(cx, cyy, 190, p);
        p.setPathEffect(null);
        p.setStrokeWidth(27);
        p.setColor(0x14FFFFFF);
        cv.drawCircle(cx, cyy, 149, p);
        float sweep = Math.max(0, Math.min(1, ringFrac)) * 360f;
        boolean lowFps = fpsVal >= 0 && fpsVal < 30;
        if (sweep > 0.5f && !(lowFps && (now / 225) % 2 == 1)) {
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(46); p.setColor(a(ringColor, 40 + (int) (30 * pulse)));
            cv.drawArc(ringRect, -90, sweep, false, p);
            p.setStrokeWidth(27); p.setColor(ringColor);
            cv.drawArc(ringRect, -90, sweep, false, p);
            p.setStrokeCap(Paint.Cap.BUTT);
        }
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(black);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE);
        fit(fpsText, 96, 190);
        cv.drawText(fpsText, cx, 610, p);
        p.setTextSize(38);
        p.setColor(0xFF7FE9FF);
        cv.drawText(fpsLabel, cx, 672, p);
        p.setTextAlign(Paint.Align.LEFT);

        // ---- grafik riwayat FPS (data asli, 40 detik terakhir)
        if (histN >= 2) {
            int mxv = 60;
            for (int i = 0; i < histN; i++) if (hist[i] > mxv) mxv = hist[i];
            spark.reset(); sparkFill.reset();
            float x0 = 360, w = 340, y0 = 796, h = 40;
            float off = w * (HN - histN) / (HN - 1f);
            float lx = 0, fx = 0;
            for (int i = 0; i < histN; i++) {
                float x = x0 + off + w * i / (HN - 1f);
                float y = y0 + h * (1f - hist[i] / (float) mxv);
                if (i == 0) { spark.moveTo(x, y); sparkFill.moveTo(x, y0 + h); sparkFill.lineTo(x, y); fx = x; }
                else { spark.lineTo(x, y); sparkFill.lineTo(x, y); }
                lx = x;
            }
            sparkFill.lineTo(lx, y0 + h);
            sparkFill.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(a(ringColor, 40));
            cv.drawPath(sparkFill, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(9); p.setColor(a(ringColor, 50));
            cv.drawPath(spark, p);
            p.setStrokeWidth(3.5f); p.setColor(ringColor);
            cv.drawPath(spark, p);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(boldSans);
            p.setTextSize(19);
            p.setTextAlign(Paint.Align.RIGHT);
            p.setColor(0xFF6C7A99);
            cv.drawText(sparkTxt, 700, 790, p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        // ---- ember api (mode Agresif)
        if (turbo) {
            float[] ex = {90, 190, 300, 430, 560, 660};
            float[] ey = {820, 830, 822, 830, 826, 832};
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 6; i++) {
                float ph = ((now + i * 430L) % 2600) / 2600f;
                float al = ph < .15f ? ph / .15f : (1f - ph) / .85f;
                p.setColor(a(0xFFFF8A3C, (int) (230 * al)));
                cv.drawCircle(ex[i] + 14 * ph, ey[i] - 300 * ph, (3 + (i % 2)) * (1f - .7f * ph), p);
            }
        }

        // ---- logo CoreVius (glitch singkat tiap 6 detik)
        p.setTypeface(blackIt);
        fit("CoreVius", 150, 330);
        float gt = now % 6000;
        if (gt > 5760) {
            boolean ph = gt < 5880;
            p.setColor(a(CY, 200)); cv.drawText("CoreVius", 48 + (ph ? -5 : 4), 770 + (ph ? 2 : -2), p);
            p.setColor(a(RD, 200)); cv.drawText("CoreVius", 48 + (ph ? 5 : -4), 770 + (ph ? -2 : 2), p);
        }
        p.setShader(logoShader);
        p.setShadowLayer(18 + 10 * pulse, 0, 0, MG);
        cv.drawText("CoreVius", 48, 770, p);
        p.setShader(null);
        p.setShadowLayer(0, 0, 0, 0);

        // ---- keterangan kecil
        p.setTypeface(boldSans);
        fit(caption, 23, 290);
        p.setColor(0xFF6C7A99);
        cv.drawText(caption, 64, 832, p);

        // ---- gelombang kejut saat ganti mode
        long st = System.currentTimeMillis() - shockT;
        if (st >= 0 && st < 550) {
            float k = st / 550f;
            cv.save();
            float sc = 1f + 0.09f * k;
            cv.scale(sc, sc, BW / 2, BH / 2);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4);
            p.setColor(a(mode == 2 ? RD : mode == 1 ? CY : 0xFFB8C7E6, (int) (230 * (1f - k))));
            cv.drawRoundRect(card, 52, 52, p);
            cv.restore();
        }

        cv.restore();
        postInvalidateDelayed(50);   // ~20 fps: cukup halus dan ringan
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float s = getWidth() / BW;
        float ux = e.getX() / s, uy = e.getY() / s;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX();
                pressed = -1;
                for (int i = 0; i < 3; i++) if (pill[i].contains(ux, uy)) pressed = i;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (pressed < 0 && listener != null) listener.onDrag(e.getRawX() - downX);
                return true;
            case MotionEvent.ACTION_UP: {
                float dx = e.getRawX() - downX;
                if (pressed >= 0) {
                    if (pill[pressed].contains(ux, uy) && listener != null) listener.onMode(PILL_MODE[pressed]);
                } else if (listener != null) listener.onRelease(dx);
                pressed = -1;
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                if (pressed < 0 && listener != null) listener.onRelease(0);
                pressed = -1;
                return true;
        }
        return false;
    }
}

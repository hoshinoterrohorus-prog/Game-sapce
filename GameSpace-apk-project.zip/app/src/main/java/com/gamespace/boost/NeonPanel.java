package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/**
 * Panel gaya Red Magic (hitam, merah, putih). Digambar langsung di Canvas, koordinat dasar 746 x 848.
 * Ringan: shader di-cache, tanpa alokasi per frame, animasi ~20 fps dan berhenti saat panel tersembunyi.
 */
public class NeonPanel extends View {
    interface Listener {
        void onMode(int mode);
        void onDrag(float dx);
        void onRelease(float dx);
    }

    static final float BW = 746f, BH = 848f;
    static final int CY = 0xFFFFFFFF, MG = 0xFFFF3B3B, RD = 0xFFE4002B, GN = 0xFFFFFFFF, YL = 0xFFFF7A7A;
    private static final int[] PILL_MODE = {1, 2, 0};
    private static final int HN = 40;

    private final RectF[] pill = {new RectF(449, 70, 697, 160), new RectF(449, 175, 697, 265), new RectF(449, 280, 697, 370)};
    private final RectF card = new RectF(4, 4, BW - 4, BH - 4);
    private final RectF tmp = new RectF();
    private final RectF ringRect = new RectF(535 - 149, 586 - 149, 535 + 149, 586 + 149);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path(), corners = new Path(), tri = new Path(), spark = new Path(), sparkFill = new Path();
    private final long t0 = System.currentTimeMillis();
    private Listener listener;

    // cache
    private final Shader bgShader;
    private final Path cardPath = new Path(), hatch = new Path(), slash = new Path(), pillP = new Path();
    private final Typeface black = Typeface.create("sans-serif-black", Typeface.NORMAL);
    private final Typeface blackIt = Typeface.create("sans-serif-black", Typeface.ITALIC);
    private final Typeface boldSans = Typeface.create("sans-serif", Typeface.BOLD);

    // data
    String cpu = "??%", ram = "??%", tmpS = "??°C", bat = "??%", hz = "??";
    String fpsText = "--", fpsLabel = "FPS", caption = "";
    float ringFrac = 0f;
    int ringColor = CY;
    int mode = 0;
    private float cpuF = -1, ramF = -1, tmpF = -1, batF = -1, tempC = 0;
    private int fpsVal = -1;
    private final int[] hist = new int[HN];
    private int histN = 0;
    private String sparkTxt = "AVG -- · MIN --";
    private long shockT = -10000;

    private int pressed = -1;
    private float downX;

    public NeonPanel(Context c) {
        super(c);
        // kartu bersudut potong (chamfer) di kiri-atas dan kanan-bawah
        float k = 46;
        cardPath.moveTo(4 + k, 4); cardPath.lineTo(BW - 4, 4); cardPath.lineTo(BW - 4, BH - 4 - k);
        cardPath.lineTo(BW - 4 - k, BH - 4); cardPath.lineTo(4, BH - 4); cardPath.lineTo(4, 4 + k); cardPath.close();
        clip.set(cardPath);
        bgShader = new LinearGradient(0, 0, BW * .5f, BH, 0xFF1A1A1A, 0xFF080808, Shader.TileMode.CLAMP);
        for (float x = -BH; x < BW; x += 22) { hatch.moveTo(x, BH); hatch.lineTo(x + BH, 0); }
        // potongan miring merah di pojok kanan atas
        slash.moveTo(BW - 230, 4); slash.lineTo(BW - 4, 4); slash.lineTo(BW - 4, 120); slash.close();
        // sudut siku
        corners.moveTo(20, 66); corners.lineTo(20, 22); corners.lineTo(66, 22);
        tri.moveTo(78, 44); tri.lineTo(78, 28); tri.lineTo(94, 44); tri.close();
    }

    void setListener(Listener l) { listener = l; }

    void setData(String cpu, String ram, String tmp, String bat, String hz, String fpsText, String fpsLabel, float frac, int col, String caption) {
        this.cpu = cpu; this.ram = ram; this.tmpS = tmp; this.bat = bat; this.hz = hz;
        this.fpsText = fpsText; this.fpsLabel = fpsLabel; this.ringFrac = frac; this.ringColor = col; this.caption = caption;
        invalidate();
    }

    /** Angka mentah untuk bar, peringatan suhu, dan grafik FPS (dipanggil tiap detik). */
    void setStats(float cpuF, float ramF, float tmpF, float batF, float tempC, int fpsVal) {
        this.cpuF = cpuF; this.ramF = ramF; this.tmpF = tmpF; this.batF = batF; this.tempC = tempC; this.fpsVal = fpsVal;
        if (fpsVal >= 0) {
            if (histN == HN) { System.arraycopy(hist, 1, hist, 0, HN - 1); histN = HN - 1; }
            hist[histN++] = fpsVal;
            int sum = 0, min = Integer.MAX_VALUE;
            for (int i = 0; i < histN; i++) { sum += hist[i]; if (hist[i] < min) min = hist[i]; }
            sparkTxt = "AVG " + (sum / histN) + " · MIN " + min;
        }
    }

    void setMode(int m) {
        if (m != mode) shockT = System.currentTimeMillis();
        mode = m;
        invalidate();
    }

    @Override protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        if (MeasureSpec.getMode(w) == MeasureSpec.UNSPECIFIED || width <= 0) width = (int) (getResources().getDisplayMetrics().density * 228);
        setMeasuredDimension(width, Math.round(width * BH / BW));
    }

    /** Kecilkan ukuran teks supaya lebarnya tidak melebihi max (satuan dasar). */
    private float fit(String t, float size, float max) {
        p.setTextSize(size);
        float w = p.measureText(t);
        if (w > max) size = size * max / w;
        p.setTextSize(size);
        return size;
    }

    private static int a(int color, int alpha) { return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24); }

    private static int barColor(float f, boolean inv) {
        float bad = inv ? 1 - f : f;
        return bad < .6f ? GN : bad < .85f ? YL : RD;
    }

    @Override protected void onDraw(Canvas cv) {
        float s = getWidth() / BW;
        cv.save();
        cv.scale(s, s);
        long now = System.currentTimeMillis() - t0;
        boolean turbo = mode == 2;
        float pulse = (float) (0.5 + 0.5 * Math.sin(now / (turbo ? 160.0 : 480.0)));

        // ---- latar kartu
        p.reset(); p.setAntiAlias(true);
        p.setShader(bgShader);
        cv.drawPath(cardPath, p);
        p.setShader(null);
        cv.save();
        cv.clipPath(clip);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f);
        p.setColor(0x0DFFFFFF);
        cv.drawPath(hatch, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(turbo ? 0xFFE4002B : 0x66E4002B);
        cv.drawPath(slash, p);
        cv.restore();

        // ---- bingkai merah solid
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(5);
        p.setStrokeJoin(Paint.Join.MITER);
        p.setColor(RD);
        cv.drawPath(cardPath, p);

        // ---- header HUD
        p.setStrokeWidth(4);
        p.setColor(0xFFFFFFFF);
        cv.drawPath(corners, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(RD);
        cv.drawPath(tri, p);
        p.setTypeface(boldSans);
        p.setColor(0xFFF2F2F2);
        fit("DRACIO // GAME SPACE", 22, 370);
        cv.drawText("DRACIO // GAME SPACE", 106, 44, p);
        boolean live = fpsVal >= 0;
        p.setColor(live ? a(0xFFFFFFFF, 110 + (int) (145 * pulse)) : 0xFF8A8A8A);
        cv.drawRect(606, 30, 618, 42, p);
        p.setColor(live ? 0xFFF2F2F2 : 0xFF8A8A8A);
        fit(live ? "LIVE" : "IDLE", 22, 70);
        cv.drawText(live ? "LIVE" : "IDLE", 626, 44, p);

        // ---- statistik kiri + bar
        p.setTypeface(black);
        String[] lab = {"CPU", "RAM", "SUHU", "BAT", "HZ"};
        String[] val = {cpu, ram, tmpS, bat, hz};
        float[] by = {112, 234, 356, 478, 610};
        float[] mw = {368, 368, 368, 300, 270};
        float[] bf = {cpuF, ramF, tmpF, batF, -1};
        for (int i = 0; i < 5; i++) {
            p.setTextSize(54);
            float full = p.measureText(lab[i]) + 16 + p.measureText(val[i]);
            float sz = full > mw[i] ? Math.max(10f, 54 * mw[i] / full * 0.98f) : 54;
            p.setTextSize(sz);
            p.setColor(RD);
            cv.drawText(lab[i], 64, by[i], p);
            float lw = p.measureText(lab[i]);
            p.setShadowLayer(0, 0, 0, 0);
            int vc = Color.WHITE;
            if (i == 2 && tempC >= 46) vc = ((now / 250) % 2 == 0) ? RD : 0xFF8A1020;
            else if (i == 2 && tempC >= 42) vc = 0xFFFF7A7A;
            p.setColor(vc);
            cv.drawText(val[i], 64 + lw + 16, by[i], p);
            if (bf[i] >= 0) {
                float f = Math.min(1f, bf[i]);
                p.setColor(0x14FFFFFF);
                tmp.set(64, by[i] + 16, 324, by[i] + 24);
                cv.drawRect(tmp, p);
                if (f > 0.01f) {
                    p.setColor(barColor(f, i == 3));
                    tmp.set(64, by[i] + 16, 64 + 260 * f, by[i] + 24);
                    cv.drawRect(tmp, p);
                }
            }
        }
        if (turbo) {
            p.setTextSize(26);
            p.setColor(a(RD, 120 + (int) (135 * pulse)));
            p.setShadowLayer(0, 0, 0, 0);
            cv.drawText("TURBO", 66, 540, p);
            p.setShadowLayer(0, 0, 0, 0);
        }

        // ---- tombol mode: jajaran genjang bersudut miring
        String[] names = {"Balance", "Aggressive", "Matikan"};
        int[] pc = {CY, RD, 0xFFC8C8C8};
        for (int i = 0; i < 3; i++) {
            RectF r = pill[i];
            int col = pc[i];
            boolean on = mode == PILL_MODE[i] && i != 2;
            boolean dim = i == 2 && mode == 0;
            pillP.reset();
            pillP.moveTo(r.left + 26, r.top); pillP.lineTo(r.right, r.top);
            pillP.lineTo(r.right - 26, r.bottom); pillP.lineTo(r.left, r.bottom); pillP.close();
            if (on) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(col);
                cv.drawPath(pillP, p);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x14FFFFFF);
                cv.drawPath(pillP, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(4);
                p.setColor(dim ? a(col, 80) : col);
                cv.drawPath(pillP, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            fit(names[i], 38, 180);
            p.setColor(on ? (i == 0 ? 0xFF0A0A0A : Color.WHITE) : (dim ? 0x66FFFFFF : 0xFFF2F2F2));
            float ty = r.centerY() - (p.descent() + p.ascent()) / 2;
            cv.drawText(names[i], r.centerX(), ty, p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        // ---- cincin FPS
        float cx = 535, cyy = 586;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(0x55FFFFFF);
        p.setPathEffect(new DashPathEffect(new float[]{3, 17}, 0));
        cv.drawCircle(cx, cyy, 190, p);
        p.setPathEffect(null);
        p.setStrokeWidth(24);
        p.setColor(0x1FFFFFFF);
        cv.drawCircle(cx, cyy, 149, p);
        float sweep = Math.max(0, Math.min(1, ringFrac)) * 360f;
        boolean lowFps = fpsVal >= 0 && fpsVal < 30;
        if (sweep > 0.5f && !(lowFps && (now / 225) % 2 == 1)) {
            p.setStrokeWidth(24); p.setColor(ringColor);
            cv.drawArc(ringRect, -90, sweep, false, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(black);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE);
        fit(fpsText, 96, 190);
        cv.drawText(fpsText, cx, 610, p);
        p.setTextSize(38);
        p.setColor(RD);
        cv.drawText(fpsLabel, cx, 672, p);
        p.setTextAlign(Paint.Align.LEFT);

        // ---- grafik riwayat FPS (data asli, 40 detik terakhir)
        if (histN >= 2) {
            int mxv = 60;
            for (int i = 0; i < histN; i++) if (hist[i] > mxv) mxv = hist[i];
            spark.reset(); sparkFill.reset();
            float x0 = 360, w = 340, y0 = 796, h = 40;
            float off = w * (HN - histN) / (HN - 1f);
            float lx = 0, fx = 0;
            for (int i = 0; i < histN; i++) {
                float x = x0 + off + w * i / (HN - 1f);
                float y = y0 + h * (1f - hist[i] / (float) mxv);
                if (i == 0) { spark.moveTo(x, y); sparkFill.moveTo(x, y0 + h); sparkFill.lineTo(x, y); fx = x; }
                else { spark.lineTo(x, y); sparkFill.lineTo(x, y); }
                lx = x;
            }
            sparkFill.lineTo(lx, y0 + h);
            sparkFill.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(a(ringColor, 40));
            cv.drawPath(sparkFill, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(3.5f); p.setColor(ringColor);
            cv.drawPath(spark, p);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(boldSans);
            p.setTextSize(19);
            p.setTextAlign(Paint.Align.RIGHT);
            p.setColor(0xFF8A8A8A);
            cv.drawText(sparkTxt, 700, 790, p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        // ---- logo Dracio
        p.setTypeface(blackIt);
        fit("Dracio", 150, 330);
        float cw = p.measureText("Dra");
        p.setColor(Color.WHITE);
        cv.drawText("Dra", 48, 770, p);
        p.setColor(RD);
        cv.drawText("cio", 48 + cw, 770, p);

        // ---- keterangan kecil
        p.setTypeface(boldSans);
        fit(caption, 23, 290);
        p.setColor(0xFF8A8A8A);
        cv.drawText(caption, 64, 832, p);

        // ---- kilatan bingkai saat ganti mode
        long st = System.currentTimeMillis() - shockT;
        if (st >= 0 && st < 450) {
            float k = st / 450f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(10);
            p.setColor(a(mode == 2 ? RD : 0xFFFFFFFF, (int) (200 * (1f - k))));
            cv.drawPath(cardPath, p);
        }

        cv.restore();
        postInvalidateDelayed(50);   // ~20 fps: cukup halus dan ringan
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float s = getWidth() / BW;
        float ux = e.getX() / s, uy = e.getY() / s;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX();
                pressed = -1;
                for (int i = 0; i < 3; i++) if (pill[i].contains(ux, uy)) pressed = i;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (pressed < 0 && listener != null) listener.onDrag(e.getRawX() - downX);
                return true;
            case MotionEvent.ACTION_UP: {
                float dx = e.getRawX() - downX;
                if (pressed >= 0) {
                    if (pill[pressed].contains(ux, uy) && listener != null) listener.onMode(PILL_MODE[pressed]);
                } else if (listener != null) listener.onRelease(dx);
                pressed = -1;
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                if (pressed < 0 && listener != null) listener.onRelease(0);
                pressed = -1;
                return true;
        }
        return false;
    }
}

package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Garis neon tipis di tepi kiri layar. */
public class NeonHandle extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final long t0 = System.currentTimeMillis();

    public NeonHandle(Context c) { super(c); }

    @Override protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        long t = System.currentTimeMillis() - t0;
        float pulse = (float) (0.5 + 0.5 * Math.sin(t / 260.0));
        float h = getHeight();
        float top = 8 * d, bot = h - 8 * d, w = 4 * d;
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, top, 0, bot, new int[]{NeonPanel.CY, NeonPanel.MG, NeonPanel.RD}, null, Shader.TileMode.CLAMP));
        float[] gw = {10 * d, 6 * d, 0};
        int[] ga = {30 + (int) (40 * pulse), 70 + (int) (60 * pulse), 255};
        for (int i = 0; i < 3; i++) {
            p.setAlpha(ga[i]);
            c.drawRoundRect(new RectF(-w, top - gw[i] / 2, w + gw[i], bot + gw[i] / 2), w, w, p);
        }
        p.setShader(null);
        // panah kecil bergerak ke kanan
        float k = (t % 1200) / 1200f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFF00E5FF);
        p.setAlpha((int) (255 * Math.sin(Math.PI * k)));
        float ax = 8 * d + k * 8 * d, ay = h / 2, s = 4 * d;
        Path a = new Path();
        a.moveTo(ax, ay - s); a.lineTo(ax + s, ay); a.lineTo(ax, ay + s);
        c.drawPath(a, p);
        postInvalidateDelayed(40);
    }
}

package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Garis pegangan di tepi kiri layar, gaya Red Magic: bilah merah solid + tab miring putih + panah. */
public class NeonHandle extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tab = new Path(), arrow = new Path();
    private final long t0 = System.currentTimeMillis();

    public NeonHandle(Context c) { super(c); }

    @Override protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        long t = System.currentTimeMillis() - t0;
        float h = getHeight(), top = 8 * d, bot = h - 8 * d, mid = h / 2;

        // bilah merah tipis
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFE4002B);
        c.drawRect(0, top, 3 * d, bot, p);

        // tab miring di tengah (putih) menandakan bisa ditarik
        float tw = 9 * d, th = 30 * d;
        tab.reset();
        tab.moveTo(0, mid - th / 2); tab.lineTo(tw, mid - th / 2 + 6 * d);
        tab.lineTo(tw, mid + th / 2 - 6 * d); tab.lineTo(0, mid + th / 2); tab.close();
        p.setColor(0xFFFFFFFF);
        c.drawPath(tab, p);

        // panah merah bergerak ke kanan
        float k = (t % 1200) / 1200f;
        float ax = 2 * d + k * 4 * d, s = 3.2f * d;
        arrow.reset();
        arrow.moveTo(ax, mid - s); arrow.lineTo(ax + s, mid); arrow.lineTo(ax, mid + s);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f * d);
        p.setColor(0xFFE4002B);
        c.drawPath(arrow, p);
        postInvalidateDelayed(66);
    }
}

package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/**
 * Panggung menu Dracio: latar hitam bertekstur + potongan miring merah, cincin berputar,
 * heksagon, lambang "D bertanduk" dan label data langsung di sekeliling lambang.
 * Animasi ~22 fps, hanya jalan saat menu terlihat (setRunning).
 */
public class DracioStage extends View {
    static final int RED = 0xFFE4002B;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path hatch = new Path(), slab = new Path(), hex = new Path(), emb = new Path(), grid = new Path(),
            hornA = new Path(), hornB = new Path(), eye = new Path(), clip = new Path();
    private final RectF r1 = new RectF(), r2 = new RectF();
    private final long t0 = System.currentTimeMillis();
    private final Typeface tf = Typeface.create("sans-serif-black", Typeface.NORMAL);
    private Shader glow, core;
    private boolean running;
    private int mode;
    String cpu = "??%", ram = "??%", tmp = "??°C", hz = "--";

    public DracioStage(Context c) {
        super(c);
        hex.moveTo(200, 92); hex.lineTo(293, 146); hex.lineTo(293, 254); hex.lineTo(200, 308); hex.lineTo(107, 254); hex.lineTo(107, 146); hex.close();
        emb.moveTo(170, 160); emb.lineTo(206, 160); emb.quadTo(240, 160, 240, 200); emb.quadTo(240, 240, 206, 240); emb.lineTo(170, 240);
        emb.lineTo(170, 222); emb.lineTo(204, 222); emb.quadTo(222, 222, 222, 200); emb.quadTo(222, 178, 204, 178); emb.lineTo(170, 178); emb.close();
        hornA.moveTo(158, 150); hornA.lineTo(168, 120); hornA.lineTo(178, 152); hornA.close();
        hornB.moveTo(170, 252); hornB.lineTo(160, 278); hornB.lineTo(188, 250); hornB.close();
        eye.moveTo(200, 192); eye.lineTo(208, 200); eye.lineTo(200, 208); eye.lineTo(192, 200); eye.close();
        for (int i = 110; i <= 290; i += 25) { grid.moveTo(110, i); grid.lineTo(290, i); grid.moveTo(i, 110); grid.lineTo(i, 290); }
        clip.addCircle(200, 200, 78, Path.Direction.CW);
        r1.set(12, 12, 388, 388);
        r2.set(54, 54, 346, 346);
    }

    void setMode(int m) { mode = m; invalidate(); }
    void setData(String cpu, String ram, String tmp, String hz) { this.cpu = cpu; this.ram = ram; this.tmp = tmp; this.hz = hz; invalidate(); }
    void setRunning(boolean r) { running = r; if (r) postInvalidateOnAnimation(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        glow = new RadialGradient(w * .5f, h * .5f, Math.max(w, h) * .5f, 0x66960019, 0x00960019, Shader.TileMode.CLAMP);
        hatch.reset();
        float step = 9 * getResources().getDisplayMetrics().density;
        for (float x = -h; x < w; x += step) { hatch.moveTo(x, h); hatch.lineTo(x + h, 0); }
        slab.reset();
        slab.moveTo(w * .66f, 0); slab.lineTo(w, 0); slab.lineTo(w, h); slab.lineTo(w * .60f, h); slab.close();
        core = new RadialGradient(200, 200, 78, 0xFF3A0610, 0xFF0B0B0B, Shader.TileMode.CLAMP);
    }

    @Override protected void onDraw(Canvas cv) {
        float W = getWidth(), H = getHeight(), d = getResources().getDisplayMetrics().density;
        long now = System.currentTimeMillis() - t0;
        cv.drawColor(0xFF070707);
        p.setStyle(Paint.Style.FILL);
        p.setShader(glow); cv.drawRect(0, 0, W, H, p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(0x09FFFFFF);
        cv.drawPath(hatch, p);
        p.setStyle(Paint.Style.FILL); p.setColor(0x29E4002B);
        cv.drawPath(slab, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(RED); p.setStrokeWidth(2.2f * d);
        cv.drawLine(W * .66f, 0, W * .60f, H, p);
        p.setColor(0x2EFFFFFF); p.setStrokeWidth(1f * d);
        cv.drawLine(W * .665f + 3 * d, 0, W * .605f + 3 * d, H, p);

        // ---- panggung 400x400 di tengah
        float s = Math.min(H * .9f, W * .6f) / 400f;
        cv.save();
        cv.translate(W / 2f - 200 * s, H / 2f - 200 * s);
        cv.scale(s, s);
        boolean hot = mode == 2;
        float spin = now / (hot ? 20f : 40f);

        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xCCE4002B); p.setStrokeWidth(1.6f);
        p.setPathEffect(new DashPathEffect(new float[]{2, 9}, spin * .6f));
        cv.drawCircle(200, 200, 190, p);
        p.setColor(0x1FFFFFFF); p.setStrokeWidth(10);
        p.setPathEffect(new DashPathEffect(new float[]{46, 22}, spin));
        cv.drawCircle(200, 200, 178, p);
        p.setColor(RED); p.setStrokeWidth(3);
        p.setPathEffect(new DashPathEffect(new float[]{70, 40, 14, 40}, -spin * 1.6f));
        cv.drawArc(r2, 0, 360, false, p);
        p.setPathEffect(null);

        // sapuan radar
        cv.save();
        cv.rotate((now / (hot ? 2200f : 5000f)) * 360f, 200, 200);
        p.setStyle(Paint.Style.FILL); p.setColor(0x2EE4002B);
        cv.drawArc(r1, -90, 24, true, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.4f); p.setColor(0x99E4002B);
        cv.drawLine(200, 200, 200, 12, p);
        cv.restore();

        p.setColor(0x2EFFFFFF); p.setStrokeWidth(1f);
        cv.drawCircle(200, 200, 126, p);
        p.setColor(RED); p.setStrokeWidth(2.4f); p.setStrokeJoin(Paint.Join.MITER);
        cv.drawPath(hex, p);

        p.setStyle(Paint.Style.FILL); p.setShader(core);
        cv.drawCircle(200, 200, 78, p); p.setShader(null);
        cv.save(); cv.clipPath(clip);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(0x40E4002B);
        cv.drawPath(grid, p);
        cv.restore();
        p.setColor(RED); p.setStrokeWidth(2);
        cv.drawCircle(200, 200, 78, p);

        // lambang D bertanduk
        p.setStyle(Paint.Style.FILL);
        p.setColor(hot ? 0xFFFF3B3B : 0xFFFFFFFF);
        cv.drawPath(emb, p); cv.drawPath(hornA, p); cv.drawPath(hornB, p);
        p.setColor(hot && (now / 400) % 2 == 0 ? 0xFFFFFFFF : RED);
        cv.drawPath(eye, p);

        // label data nyata di sekeliling lambang
        p.setTypeface(tf);
        p.setLetterSpacing(.12f);
        tag(cv, "CPU", cpu, 62, 112, 134, Paint.Align.LEFT, 60, 120, 112, 120, 128, 136);
        tag(cv, "RAM", ram, 338, 112, 134, Paint.Align.RIGHT, 340, 120, 288, 120, 272, 136);
        tag(cv, "SUHU", tmp, 62, 312, 284, Paint.Align.LEFT, 60, 290, 112, 290, 128, 274);
        tag(cv, "HZ", hz, 338, 312, 284, Paint.Align.RIGHT, 340, 290, 288, 290, 272, 274);
        p.setLetterSpacing(0);
        cv.restore();

        if (running) postInvalidateDelayed(45);
    }

    private final Path leg = new Path();

    private void tag(Canvas cv, String k, String v, float x, float yk, float yv, Paint.Align al,
                     float ax, float ay, float bx, float by, float cx, float cy) {
        leg.reset(); leg.moveTo(ax, ay); leg.lineTo(bx, by); leg.lineTo(cx, cy);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(0x80FFFFFF);
        cv.drawPath(leg, p);
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(al);
        p.setTextSize(7.5f); p.setColor(RED);
        cv.drawText(k, x, yk, p);
        p.setTextSize(11); p.setColor(0xFFF2F2F2);
        cv.drawText(v, x, yv, p);
        p.setTextAlign(Paint.Align.LEFT);
    }
}

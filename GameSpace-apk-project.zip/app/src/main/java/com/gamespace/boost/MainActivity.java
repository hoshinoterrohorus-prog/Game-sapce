package com.gamespace.boost;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import rikka.shizuku.Shizuku;

/** Menu utama horizontal ala Game Space: panel kontrol kiri, statistik + perpustakaan game kanan. */
public class MainActivity extends Activity {
    static final int REQ_SHIZUKU = 42;
    static final int CY = 0xFF00E5FF, MG = 0xFFFF00C8, RD = 0xFFFF2A4D, GN = 0xFF00FF9C, YL = 0xFFFFD000;
    static final int CARD = 0xE60D1426, DIM = 0xFF6C7A99;

    static class App { String pkg; String name; Drawable icon; boolean game; }

    /** Bar mini untuk statistik. */
    static class MiniBar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        float frac = 0; int color = GN;
        MiniBar(Context c) { super(c); }
        void set(float f, int col) { frac = Math.max(0, Math.min(1, f)); color = col; invalidate(); }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            p.setColor(0x1AFFFFFF); r.set(0, 0, w, h); cv.drawRoundRect(r, h / 2, h / 2, p);
            if (frac > 0.01f) { p.setColor(color); r.set(0, 0, w * frac, h); cv.drawRoundRect(r, h / 2, h / 2, p); }
        }
    }

    static class Stat { TextView v; MiniBar bar; }

    private final List<App> all = new ArrayList<>();
    private final List<App> shown = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private boolean onlyGames = true;
    private BaseAdapter adapter;
    private TextView chipSh, chipOv, tDesc, tCount, bBal, bAgg, bOff, bStart, fGame, fAll;
    private final Stat[] stats = new Stat[5];
    private LinearLayout content;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService ex;
    private long lastTotal = -1, lastIdle = -1;

    private final Shizuku.OnRequestPermissionResultListener permL = new Shizuku.OnRequestPermissionResultListener() {
        @Override public void onRequestPermissionResult(int requestCode, int grantResult) { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };
    private final Shizuku.OnBinderReceivedListener recvL = new Shizuku.OnBinderReceivedListener() {
        @Override public void onBinderReceived() { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };
    private final Shizuku.OnBinderDeadListener deadL = new Shizuku.OnBinderDeadListener() {
        @Override public void onBinderDead() { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    // ---------- siklus hidup ----------
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        selected.addAll(Booster.games(this));
        try {
            Shizuku.addRequestPermissionResultListener(permL);
            Shizuku.addBinderReceivedListenerSticky(recvL);
            Shizuku.addBinderDeadListener(deadL);
        } catch (Throwable ignored) {}

        FrameLayout root = new FrameLayout(this);
        root.addView(new NeonBackground(this), new FrameLayout.LayoutParams(-1, -1));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setPadding(dp(14), dp(10), dp(14), dp(10));
        content.addView(buildLeft(), new LinearLayout.LayoutParams(dp(268), -1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, -1, 1);
        rp.leftMargin = dp(12);
        content.addView(buildRight(), rp);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        // hindari lubang kamera / poni pada mode horizontal
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int l = in.getSystemWindowInsetLeft(), r = in.getSystemWindowInsetRight();
                if (Build.VERSION.SDK_INT >= 28 && in.getDisplayCutout() != null) {
                    l = Math.max(l, in.getDisplayCutout().getSafeInsetLeft());
                    r = Math.max(r, in.getDisplayCutout().getSafeInsetRight());
                }
                content.setPadding(Math.max(dp(14), l + dp(6)), dp(10), Math.max(dp(14), r + dp(6)), dp(10));
                return in;
            }
        });

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        loadApps();
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        hideBars();
        refresh();
        if (ex == null) {
            ex = Executors.newSingleThreadScheduledExecutor();
            ex.scheduleWithFixedDelay(new Runnable() { public void run() { try { poll(); } catch (Throwable ignored) {} } }, 0, 2, TimeUnit.SECONDS);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (ex != null) { ex.shutdownNow(); ex = null; }
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permL);
            Shizuku.removeBinderReceivedListener(recvL);
            Shizuku.removeBinderDeadListener(deadL);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    // ---------- helper gambar ----------
    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        return t;
    }

    private GradientDrawable round(int fill, float radDp, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radDp));
        if (stroke != 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(round(CARD, 14, 0x40_00E5FF, 1));
        c.setPadding(dp(12), dp(9), dp(12), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView heading(String s) {
        TextView t = text(s, 11, 0xFF7FE9FF, true);
        t.setLetterSpacing(.18f);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    // ---------- panel kiri ----------
    private View buildLeft() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        // logo
        final TextView logo = new TextView(this);
        logo.setText("CoreVius");
        logo.setTextSize(30);
        logo.setTypeface(Typeface.create("sans-serif-black", Typeface.ITALIC));
        logo.setTextColor(Color.WHITE);
        logo.setShadowLayer(dp(8), 0, 0, MG);
        logo.post(new Runnable() { public void run() {
            float w = logo.getPaint().measureText("CoreVius");
            logo.getPaint().setShader(new LinearGradient(0, 0, w, 0, new int[]{CY, MG, RD}, new float[]{0, .6f, 1}, Shader.TileMode.CLAMP));
            logo.invalidate();
        } });
        col.addView(logo);
        TextView tag = text("GAME SPACE", 10, 0xFF5FB8CC, true);
        tag.setLetterSpacing(.35f);
        tag.setPadding(dp(3), 0, 0, dp(8));
        col.addView(tag);

        // status
        LinearLayout c1 = card();
        c1.addView(heading("STATUS"));
        LinearLayout row = new LinearLayout(this);
        chipSh = chip(); chipOv = chip();
        chipSh.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { onShizuku(); } });
        chipOv.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } });
        row.addView(chipSh);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(8), 1);
        row.addView(new View(this), gp);
        row.addView(chipOv);
        c1.addView(row);
        col.addView(c1);

        // mode
        LinearLayout c2 = card();
        c2.addView(heading("MODE"));
        LinearLayout seg = new LinearLayout(this);
        bBal = segBtn("BALANCE"); bAgg = segBtn("AGRESIF"); bOff = segBtn("MATIKAN");
        bBal.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.BALANCE); } });
        bAgg.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.AGGRESSIVE); } });
        bOff.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.OFF); } });
        seg.addView(bBal, segLp(0)); seg.addView(bAgg, segLp(1)); seg.addView(bOff, segLp(2));
        c2.addView(seg);
        tDesc = text("", 9.5f, DIM, false);
        tDesc.setPadding(0, dp(7), 0, 0);
        c2.addView(tDesc);
        col.addView(c2);

        // mulai
        bStart = text("MULAI GAME SPACE", 15, 0xFF04121A, true);
        bStart.setGravity(Gravity.CENTER);
        bStart.setLetterSpacing(.12f);
        bStart.setPadding(0, dp(13), 0, dp(13));
        bStart.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleService(); } });
        col.addView(bStart, new LinearLayout.LayoutParams(-1, -2));

        TextView diag = text("Diagnostik & log", 10, DIM, false);
        diag.setPaintFlags(diag.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        diag.setPadding(dp(2), dp(10), 0, dp(4));
        diag.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showDiag(); } });
        col.addView(diag);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.addView(col);
        return sv;
    }

    private TextView chip() {
        TextView t = text("", 10.5f, Color.WHITE, true);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        t.setBackground(round(0x0DFFFFFF, 20, 0x1AFFFFFF, 1));
        return t;
    }

    private TextView segBtn(String s) {
        TextView t = text(s, 9.5f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(9), 0, dp(9));
        t.setLetterSpacing(.04f);
        return t;
    }

    private LinearLayout.LayoutParams segLp(int i) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.leftMargin = i == 0 ? 0 : dp(3);
        lp.rightMargin = i == 2 ? 0 : dp(3);
        return lp;
    }

    // ---------- panel kanan ----------
    private View buildRight() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        // statistik
        LinearLayout row = new LinearLayout(this);
        String[] names = {"CPU", "RAM", "SUHU", "BAT", "HZ"};
        for (int i = 0; i < 5; i++) {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setBackground(round(CARD, 12, 0x14FFFFFF, 1));
            box.setPadding(dp(10), dp(7), dp(10), dp(8));
            TextView lab = text(names[i], 8.5f, 0xFF7FE9FF, true);
            lab.setLetterSpacing(.14f);
            Stat s = new Stat();
            s.v = text("??", 17, Color.WHITE, true);
            s.v.setPadding(0, dp(2), 0, dp(3));
            s.bar = new MiniBar(this);
            box.addView(lab); box.addView(s.v);
            box.addView(s.bar, new LinearLayout.LayoutParams(-1, dp(4)));
            stats[i] = s;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i > 0) lp.leftMargin = dp(7);
            row.addView(box, lp);
        }
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.bottomMargin = dp(9);
        col.addView(row, rl);

        // perpustakaan
        LinearLayout lib = new LinearLayout(this);
        lib.setOrientation(LinearLayout.VERTICAL);
        lib.setBackground(round(CARD, 14, 0x40_00E5FF, 1));
        lib.setPadding(dp(12), dp(9), dp(12), dp(6));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView h = text("GAME LIBRARY", 11, 0xFF7FE9FF, true);
        h.setLetterSpacing(.18f);
        tCount = text("", 10, DIM, false);
        tCount.setPadding(dp(10), 0, 0, 0);
        head.addView(h); head.addView(tCount);
        View sp = new View(this);
        head.addView(sp, new LinearLayout.LayoutParams(0, 1, 1));
        fGame = filterChip("GAME"); fAll = filterChip("SEMUA");
        fGame.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { onlyGames = true; applyFilter(); } });
        fAll.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { onlyGames = false; applyFilter(); } });
        head.addView(fGame); head.addView(space(6)); head.addView(fAll);
        lib.addView(head, new LinearLayout.LayoutParams(-1, -2));

        GridView gv = new GridView(this);
        gv.setNumColumns(GridView.AUTO_FIT);
        gv.setColumnWidth(dp(104));
        gv.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        gv.setHorizontalSpacing(dp(8));
        gv.setVerticalSpacing(dp(8));
        gv.setVerticalScrollBarEnabled(false);
        gv.setSelector(new ColorDrawable(Color.TRANSPARENT));
        gv.setClipToPadding(false);
        gv.setPadding(dp(2), dp(9), dp(2), dp(6));
        adapter = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int i) { return shown.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View v, ViewGroup p) { return gameCard(i, v); }
        };
        gv.setAdapter(adapter);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> a, View v, int pos, long id) {
                String pkg = shown.get(pos).pkg;
                if (!selected.add(pkg)) selected.remove(pkg);
                Booster.setGames(MainActivity.this, selected);
                adapter.notifyDataSetChanged();
                updateCount();
            }
        });
        lib.addView(gv, new LinearLayout.LayoutParams(-1, 0, 1));
        col.addView(lib, new LinearLayout.LayoutParams(-1, 0, 1));
        return col;
    }

    private View space(int w) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1)); return v; }

    private TextView filterChip(String s) {
        TextView t = text(s, 9.5f, Color.WHITE, true);
        t.setPadding(dp(11), dp(5), dp(11), dp(5));
        return t;
    }

    private void styleFilter(TextView t, boolean on) {
        t.setBackground(round(on ? CY : 0, 20, on ? CY : 0x30FFFFFF, 1.2f));
        t.setTextColor(on ? 0xFF02131A : 0xFFA9BBD8);
    }

    private View gameCard(int i, View v) {
        FrameLayout f;
        ImageView ic; TextView nm, ck, pl;
        if (v == null) {
            f = new FrameLayout(this);
            f.setLayoutParams(new AbsListView.LayoutParams(-1, dp(98)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            ic = new ImageView(this); ic.setId(1);
            col.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
            nm = text("", 10.5f, 0xFFDCE8FF, false);
            nm.setId(2); nm.setSingleLine(true); nm.setGravity(Gravity.CENTER);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
            nm.setPadding(dp(4), dp(7), dp(4), 0);
            col.addView(nm, new LinearLayout.LayoutParams(-1, -2));
            f.addView(col, new FrameLayout.LayoutParams(-1, -1));
            ck = text("✓", 10, 0xFF02131A, true);
            ck.setId(3); ck.setGravity(Gravity.CENTER);
            ck.setBackground(round(CY, 9, 0, 0));
            FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP | Gravity.START);
            cl.setMargins(dp(6), dp(6), 0, 0);
            f.addView(ck, cl);
            pl = text("▶", 9, Color.WHITE, false);
            pl.setId(4); pl.setGravity(Gravity.CENTER);
            pl.setBackground(round(0x26FFFFFF, 12, 0, 0));
            FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.TOP | Gravity.END);
            pp.setMargins(0, dp(5), dp(5), 0);
            f.addView(pl, pp);
        } else f = (FrameLayout) v;
        final App a = shown.get(i);
        ((ImageView) f.findViewById(1)).setImageDrawable(a.icon);
        ((TextView) f.findViewById(2)).setText(a.name);
        boolean sel = selected.contains(a.pkg);
        f.findViewById(3).setVisibility(sel ? View.VISIBLE : View.GONE);
        f.findViewById(4).setOnClickListener(new View.OnClickListener() { public void onClick(View x) { launch(a.pkg); } });
        f.setBackground(cardBg(sel));
        return f;
    }

    private Drawable cardBg(boolean sel) {
        GradientDrawable main = round(0xE60D1426, 12, sel ? CY : 0x1AFFFFFF, sel ? 2f : 1.2f);
        if (!sel) return main;
        GradientDrawable glow = new GradientDrawable();
        glow.setCornerRadius(dp(14));
        glow.setStroke(dp(5), 0x4000E5FF);
        LayerDrawable ld = new LayerDrawable(new Drawable[]{glow, main});
        ld.setLayerInset(1, dp(2), dp(2), dp(2), dp(2));
        return ld;
    }

    private void launch(String pkg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(this, "Tidak bisa membuka aplikasi", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- data aplikasi ----------
    private void loadApps() {
        new Thread(new Runnable() { public void run() {
            PackageManager pm = getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            final List<App> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.name = String.valueOf(ri.loadLabel(pm));
                a.icon = ri.loadIcon(pm);
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    a.game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                } catch (Throwable ignored) {}
                out.add(a);
            }
            Collections.sort(out, new Comparator<App>() {
                public int compare(App x, App y) {
                    boolean sx = selected.contains(x.pkg), sy = selected.contains(y.pkg);
                    if (sx != sy) return sx ? -1 : 1;
                    if (x.game != y.game) return x.game ? -1 : 1;
                    return x.name.compareToIgnoreCase(y.name);
                }
            });
            runOnUiThread(new Runnable() { public void run() { all.clear(); all.addAll(out); applyFilter(); } });
        } }).start();
    }

    private void applyFilter() {
        boolean anyGame = false;
        for (App a : all) if (a.game) { anyGame = true; break; }
        if (!anyGame) onlyGames = false;   // tidak ada game terdeteksi: tampilkan semua
        shown.clear();
        for (App a : all) if (!onlyGames || a.game || selected.contains(a.pkg)) shown.add(a);
        styleFilter(fGame, onlyGames);
        styleFilter(fAll, !onlyGames);
        adapter.notifyDataSetChanged();
        updateCount();
    }

    private void updateCount() { tCount.setText(selected.size() + " dipilih  •  " + shown.size() + " aplikasi"); }

    // ---------- Shizuku & mode ----------
    private void onShizuku() {
        try {
            if (!Sh.running()) {
                Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i != null) startActivity(i);
                else Toast.makeText(this, "Shizuku belum terpasang. Pasang dari Play Store / GitHub Shizuku.", Toast.LENGTH_LONG).show();
                return;
            }
            if (!Sh.granted()) Shizuku.requestPermission(REQ_SHIZUKU);
        } catch (Throwable t) {
            Toast.makeText(this, "Shizuku error: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setMode(int m) {
        if (!Sh.granted()) {
            Toast.makeText(this, "Shizuku belum aktif / belum diizinkan. Mode tidak bisa diterapkan.", Toast.LENGTH_LONG).show();
            return;
        }
        final int target = (m == Booster.mode(this)) ? Booster.OFF : m;
        tDesc.setText("Memproses... (bisa beberapa detik)");
        final Context c = getApplicationContext();
        new Thread(new Runnable() { public void run() {
            Booster.apply(c, target, null);
            runOnUiThread(new Runnable() { public void run() { refresh(); } });
        } }).start();
    }

    private void toggleService() {
        if (OverlayService.alive) {
            startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_STOP));
            bStart.postDelayed(new Runnable() { public void run() { refresh(); } }, 400);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Beri izin tampil di atas aplikasi dulu (ketuk chip Overlay)", Toast.LENGTH_LONG).show();
            return;
        }
        bStart.setText("MELUNCURKAN...");
        bStart.animate().scaleX(.94f).scaleY(.94f).setDuration(90).withEndAction(new Runnable() {
            public void run() { bStart.animate().scaleX(1f).scaleY(1f).setDuration(140).start(); }
        }).start();
        startForegroundService(new Intent(this, OverlayService.class));
        bStart.postDelayed(new Runnable() { public void run() { refresh(); } }, 400);
    }

    private void showDiag() {
        String s = Booster.lastLog.isEmpty() ? "(belum ada log mode)" : Booster.lastLog;
        if (!Booster.fgDebug.isEmpty() || !Booster.fpsDebug.isEmpty())
            s += "\n\n[Diagnostik FPS]\nfg: " + Booster.fgDebug + "\n" + Booster.fpsDebug;
        TextView t = text(s, 10, 0xFFCFE6FF, false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        ScrollView sv = new ScrollView(this);
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Diagnostik & log").setView(sv).setPositiveButton("Tutup", null).show();
    }

    // ---------- tampilan ----------
    private void paintSeg(TextView t, boolean on, int col, int onText, boolean dim) {
        GradientDrawable g = round(on ? col : 0x0AFFFFFF, 12, col, 1.6f);
        t.setBackground(g);
        t.setTextColor(on ? onText : Color.WHITE);
        t.setAlpha(dim ? .4f : 1f);
    }

    private void refresh() {
        if (chipSh == null) return;
        boolean run = Sh.running(), ok = Sh.granted();
        setChip(chipSh, ok ? "Shizuku aktif" : run ? "Shizuku: izinkan" : "Shizuku mati", ok);
        boolean ov = Settings.canDrawOverlays(this);
        setChip(chipOv, ov ? "Overlay OK" : "Overlay belum", ov);

        int m = Booster.mode(this);
        paintSeg(bBal, m == Booster.BALANCE, CY, 0xFF02131A, false);
        paintSeg(bAgg, m == Booster.AGGRESSIVE, RD, Color.WHITE, false);
        paintSeg(bOff, false, 0xFFB8C7E6, 0xFF02131A, m == Booster.OFF);
        tDesc.setText(m == Booster.AGGRESSIVE
                ? "Agresif: performa maksimal. Batasi proses latar, notifikasi dibisukan, Data Saver, animasi mati, game mode Performance. Sementara."
                : m == Booster.BALANCE
                ? "Balance: seimbang performa dan baterai. Animasi 0,5x, adaptive battery aktif, game mode Standard."
                : "Mode mati. Semua pengaturan HP normal.");

        boolean on = OverlayService.alive;
        bStart.setText(on ? "STOP GAME SPACE" : "MULAI GAME SPACE");
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                on ? new int[]{RD, 0xFFFF8A00} : new int[]{GN, CY});
        g.setCornerRadius(dp(14));
        bStart.setBackground(g);
        bStart.setTextColor(on ? Color.WHITE : 0xFF04121A);
        if (adapter != null) updateCount();
    }

    private void setChip(TextView t, String s, boolean ok) {
        SpannableString sp = new SpannableString("● " + s);
        sp.setSpan(new ForegroundColorSpan(ok ? GN : RD), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        t.setText(sp);
    }

    // ---------- statistik langsung (tiap 2 detik saat menu terlihat) ----------
    private static int barCol(float f, boolean inv) { float b = inv ? 1 - f : f; return b < .6f ? GN : b < .85f ? YL : RD; }

    private void poll() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        final float ram = 1f - mi.availMem / (float) Math.max(1, mi.totalMem);

        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        final float temp = b != null ? b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f : 0;
        final int lvl = b != null ? b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        float hzv = 60;
        try { hzv = getWindowManager().getDefaultDisplay().getRefreshRate(); } catch (Throwable ignored) {}
        final float hz = hzv;

        float cpuv = -1;
        if (Sh.granted()) {
            try {
                String[] a = Sh.run("head -1 /proc/stat").trim().split("\\s+");
                if (a.length >= 8 && a[0].equals("cpu")) {
                    long total = 0;
                    for (int i = 1; i <= 8 && i < a.length; i++) total += Long.parseLong(a[i]);
                    long idle = Long.parseLong(a[4]) + Long.parseLong(a[5]);
                    if (lastTotal >= 0 && total > lastTotal) cpuv = 1f - (idle - lastIdle) / (float) (total - lastTotal);
                    lastTotal = total; lastIdle = idle;
                }
            } catch (Throwable ignored) {}
        }
        final float cpu = cpuv;
        runOnUiThread(new Runnable() { public void run() {
            if (stats[0] == null) return;
            setStat(0, cpu >= 0 ? Math.round(cpu * 100) + "%" : "??%", cpu, false);
            setStat(1, Math.round(ram * 100) + "%", ram, false);
            setStat(2, temp > 0 ? String.format("%.1f°C", temp) : "??°C", temp > 0 ? (temp - 25f) / 25f : -1, false);
            setStat(3, lvl >= 0 ? lvl + "%" : "??%", lvl >= 0 ? lvl / 100f : -1, true);
            stats[4].v.setText(String.format("%.0f", hz));
            stats[4].bar.set(1f, CY);
            stats[2].v.setTextColor(temp >= 46 ? RD : temp >= 42 ? 0xFFFFB000 : Color.WHITE);
        } });
    }

    private void setStat(int i, String s, float f, boolean inv) {
        stats[i].v.setText(s);
        if (f >= 0) stats[i].bar.set(f, barCol(Math.min(1f, f), inv)); else stats[i].bar.set(0, GN);
    }
}

package com.gamespace.boost;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import rikka.shizuku.Shizuku;

/** Menu utama Dracio (horizontal): daftar game kiri, lambang + data di tengah, mulai game kanan, tab LOBI / BASE. */
public class MainActivity extends Activity {
    static final int REQ_SHIZUKU = 42;
    static final int RD = 0xFFE4002B, WH = 0xFFFFFFFF, DIM = 0xFF8A8A8A, PANEL = 0xF0101010;

    static class App { String pkg; String name; Drawable icon; boolean game; }

    /** Bentuk bersudut: 0 potong-sudut, 1 trapesium (tab), 2 jajar genjang, 3 heksagon. */
    static class Poly extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final int kind, fill, stroke; private final float sw, cut;
        Poly(int kind, int fill, int stroke, float sw, float cut) { this.kind = kind; this.fill = fill; this.stroke = stroke; this.sw = sw; this.cut = cut; }
        @Override protected void onBoundsChange(Rect b) {
            path.reset();
            float l = b.left + sw / 2, t = b.top + sw / 2, r = b.right - sw / 2, bt = b.bottom - sw / 2, c = cut, cy = (t + bt) / 2;
            if (kind == 0) { path.moveTo(l + c, t); path.lineTo(r, t); path.lineTo(r, bt - c); path.lineTo(r - c, bt); path.lineTo(l, bt); path.lineTo(l, t + c); }
            else if (kind == 1) { path.moveTo(l, bt); path.lineTo(l + c, t); path.lineTo(r - c, t); path.lineTo(r, bt); }
            else if (kind == 2) { path.moveTo(l + c, t); path.lineTo(r, t); path.lineTo(r - c, bt); path.lineTo(l, bt); }
            else { float w = r - l; path.moveTo(l + w * .25f, t); path.lineTo(r - w * .25f, t); path.lineTo(r, cy); path.lineTo(r - w * .25f, bt); path.lineTo(l + w * .25f, bt); path.lineTo(l, cy); }
            path.close();
        }
        @Override public void draw(Canvas c) {
            if (fill != 0) { p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawPath(path, p); }
            if (stroke != 0 && sw > 0) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(stroke); p.setStrokeJoin(Paint.Join.MITER); c.drawPath(path, p); }
        }
        @Override public void setAlpha(int a) {}
        @Override public void setColorFilter(ColorFilter f) {}
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Ikon baterai kecil bergaya kotak. */
    static class BatView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float level = 1f;
        BatView(Context c) { super(c); }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f * d); p.setColor(WH);
            cv.drawRect(1.5f * d, 1.5f * d, w - 4 * d, h - 1.5f * d, p);
            p.setStyle(Paint.Style.FILL);
            cv.drawRect(w - 3.5f * d, h * .32f, w - 1 * d, h * .68f, p);
            p.setColor(level < .2f ? RD : WH);
            cv.drawRect(3.5f * d, 3.5f * d, 3.5f * d + (w - 9 * d) * Math.max(0f, Math.min(1f, level)), h - 3.5f * d, p);
        }
    }

    /** Bar mini statistik. */
    static class MiniBar extends View {
        private final Paint p = new Paint();
        float frac = 0; int color = WH;
        MiniBar(Context c) { super(c); }
        void set(float f, int col) { frac = Math.max(0, Math.min(1, f)); color = col; invalidate(); }
        @Override protected void onDraw(Canvas cv) {
            p.setColor(0x1FFFFFFF); cv.drawRect(0, 0, getWidth(), getHeight(), p);
            p.setColor(color); cv.drawRect(0, 0, getWidth() * frac, getHeight(), p);
        }
    }

    /** Tombol dengan kilau putih yang menyapu pelan (ringan: hanya menggambar satu pita miring). */
    static class ShineButton extends TextView {
        private final Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path sh = new Path();
        private float ph = 2f;
        private ValueAnimator va;
        ShineButton(Context c) { super(c); }
        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            va = ValueAnimator.ofFloat(0f, 2.2f);
            va.setDuration(3200);
            va.setRepeatCount(ValueAnimator.INFINITE);
            va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) { ph = (Float) a.getAnimatedValue(); if (ph < 1f) invalidate(); }
            });
            va.start();
        }
        @Override protected void onDetachedFromWindow() { if (va != null) va.cancel(); super.onDetachedFromWindow(); }
        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            if (ph >= 1f) return;
            float w = getWidth(), h = getHeight(), x = -w * .3f + ph * w * 1.5f, bw = w * .16f;
            sh.reset();
            sh.moveTo(x + bw * .5f, 0); sh.lineTo(x + bw * 1.5f, 0); sh.lineTo(x + bw, h); sh.lineTo(x, h); sh.close();
            sp.setColor(0x55FFFFFF);
            cv.save(); cv.clipRect(0, 0, w, h); cv.drawPath(sh, sp); cv.restore();
        }
    }

    /** Efek tekan: mengecil sedikit saat disentuh (klik tetap berjalan). */
    private void pressable(View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View x, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.94f).scaleY(.94f).setDuration(80).start();
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) x.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                return false;
            }
        });
    }

    /** Masuk dengan meluncur + memudar. */
    private void slideIn(View v, float dx, float dy, long delay) {
        v.animate().cancel();
        v.setAlpha(0f); v.setTranslationX(dx); v.setTranslationY(dy);
        v.animate().alpha(1f).translationX(0).translationY(0).setStartDelay(delay).setDuration(380)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
    }

    private void playLobbyIntro() {
        slideIn(libScroll, -dp(70), 0, 0);
        slideIn(lobbyRight, dp(70), 0, 120);
        slideIn(modesRow, 0, dp(40), 220);
    }

    private final List<App> all = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private String focusPkg = null;

    private DracioStage stage;
    private BatView batV;
    private TextView clockT, batT, chipSh, chipOv, gSub, gName, bStart, bStop, mBal, mAgg, mOff, tLobi, tBase, tDesc;
    private LinearLayout libBox, lobbyRight, modesRow;
    private ScrollView libScroll;
    private View baseBox;
    private final TextView[] sv = new TextView[4];
    private final MiniBar[] sb = new MiniBar[4];
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService ex;
    private long lastTotal = -1, lastIdle = -1;
    private int page = 0;   // 0 LOBI, 1 ALAT, 2 BASE
    private LinearLayout toolsBox;
    private final TextView[] toolName = new TextView[7], toolSub = new TextView[7];
    private final LinearLayout[] toolTile = new LinearLayout[7];
    private final boolean[] toolOn = new boolean[7];
    private TextView tTools;
    private FrameLayout uiLayer;

    private final Shizuku.OnRequestPermissionResultListener permL = new Shizuku.OnRequestPermissionResultListener() {
        @Override public void onRequestPermissionResult(int requestCode, int grantResult) { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };
    private final Shizuku.OnBinderReceivedListener recvL = new Shizuku.OnBinderReceivedListener() {
        @Override public void onBinderReceived() { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };
    private final Shizuku.OnBinderDeadListener deadL = new Shizuku.OnBinderDeadListener() {
        @Override public void onBinderDead() { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    // ---------- siklus hidup ----------
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        selected.addAll(Booster.games(this));
        try {
            Shizuku.addRequestPermissionResultListener(permL);
            Shizuku.addBinderReceivedListenerSticky(recvL);
            Shizuku.addBinderDeadListener(deadL);
        } catch (Throwable ignored) {}

        FrameLayout root = new FrameLayout(this);
        stage = new DracioStage(this);
        root.addView(stage, new FrameLayout.LayoutParams(-1, -1));
        uiLayer = new FrameLayout(this);
        root.addView(uiLayer, new FrameLayout.LayoutParams(-1, -1));
        buildTop();
        buildLobby();
        buildBase();
        buildTools();
        buildTabs();
        setContentView(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int l = in.getSystemWindowInsetLeft(), r = in.getSystemWindowInsetRight();
                if (Build.VERSION.SDK_INT >= 28 && in.getDisplayCutout() != null) {
                    l = Math.max(l, in.getDisplayCutout().getSafeInsetLeft());
                    r = Math.max(r, in.getDisplayCutout().getSafeInsetRight());
                }
                uiLayer.setPadding(l, 0, r, 0);
                return in;
            }
        });

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        loadApps();
        refresh();
        uiLayer.post(new Runnable() { public void run() { playLobbyIntro(); } });
    }

    @Override protected void onResume() {
        super.onResume();
        hideBars();
        stage.setRunning(true);
        refresh();
        if (ex == null) {
            ex = Executors.newSingleThreadScheduledExecutor();
            ex.scheduleWithFixedDelay(new Runnable() { public void run() { try { poll(); } catch (Throwable ignored) {} } }, 0, 2, TimeUnit.SECONDS);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        stage.setRunning(false);
        if (ex != null) { ex.shutdownNow(); ex = null; }
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permL);
            Shizuku.removeBinderReceivedListener(recvL);
            Shizuku.removeBinderDeadListener(deadL);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    // ---------- helper ----------
    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        return t;
    }

    private FrameLayout.LayoutParams fl(int w, int h, int gravity, int l, int t, int r, int b) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h, gravity);
        lp.setMargins(l, t, r, b);
        return lp;
    }

    // ---------- bar atas ----------
    private void buildTop() {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView brand = new TextView(this);
        SpannableString bs = new SpannableString("DRACIO");
        bs.setSpan(new ForegroundColorSpan(RD), 3, 6, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        brand.setText(bs);
        brand.setTextSize(20);
        brand.setLetterSpacing(.2f);
        brand.setTextColor(WH);
        brand.setTypeface(Typeface.create("sans-serif-black", Typeface.ITALIC));
        top.addView(brand);

        clockT = text("--:--", 13, WH, true);
        clockT.setPadding(dp(14), 0, dp(12), 0);
        top.addView(clockT);
        batV = new BatView(this);
        top.addView(batV, new LinearLayout.LayoutParams(dp(24), dp(12)));
        batT = text("--%", 10, WH, true);
        batT.setPadding(dp(5), 0, 0, 0);
        top.addView(batT);

        View sp = new View(this);
        top.addView(sp, new LinearLayout.LayoutParams(0, 1, 1));
        chipSh = chip(); chipOv = chip();
        chipSh.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { onShizuku(); } });
        chipOv.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } });
        top.addView(chipSh);
        LinearLayout.LayoutParams g = new LinearLayout.LayoutParams(dp(6), 1);
        top.addView(new View(this), g);
        top.addView(chipOv);
        uiLayer.addView(top, fl(-1, -2, Gravity.TOP, dp(16), dp(8), dp(16), 0));
    }

    private TextView chip() {
        TextView t = text("", 10, WH, true);
        t.setPadding(dp(14), dp(6), dp(14), dp(6));
        t.setBackground(new Poly(2, 0x14FFFFFF, 0, 0, dp(7)));
        return t;
    }

    // ---------- LOBI ----------
    private void buildLobby() {
        libBox = new LinearLayout(this);
        libBox.setOrientation(LinearLayout.VERTICAL);
        libScroll = new ScrollView(this);
        libScroll.setVerticalScrollBarEnabled(false);
        libScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        libScroll.addView(libBox);
        uiLayer.addView(libScroll, fl(dp(214), -1, Gravity.START, dp(14), dp(46), 0, dp(48)));

        lobbyRight = new LinearLayout(this);
        lobbyRight.setOrientation(LinearLayout.VERTICAL);
        lobbyRight.setGravity(Gravity.END);
        gSub = text("", 9.5f, DIM, false);
        gSub.setGravity(Gravity.END);
        lobbyRight.addView(gSub);
        gName = text("-", 21, WH, true);
        gName.setTypeface(Typeface.create("sans-serif-black", Typeface.ITALIC));
        gName.setGravity(Gravity.END);
        gName.setMaxLines(2);
        gName.setEllipsize(TextUtils.TruncateAt.END);
        gName.setPadding(0, dp(2), 0, dp(10));
        lobbyRight.addView(gName, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout go = new LinearLayout(this);
        go.setGravity(Gravity.CENTER_VERTICAL);
        bStop = text("⏻", 17, WH, true);
        bStop.setGravity(Gravity.CENTER);
        bStop.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleOverlay(); } });
        pressable(bStop);
        go.addView(bStop, new LinearLayout.LayoutParams(dp(42), dp(42)));
        go.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        bStart = new ShineButton(this);
        bStart.setText("MULAI GAME"); bStart.setTextSize(14); bStart.setTextColor(WH);
        bStart.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        bStart.setGravity(Gravity.CENTER);
        bStart.setLetterSpacing(.06f);
        bStart.setPadding(dp(24), dp(13), dp(24), dp(13));
        bStart.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { startGame(); } });
        pressable(bStart);
        go.addView(bStart);
        lobbyRight.addView(go);
        uiLayer.addView(lobbyRight, fl(dp(250), -2, Gravity.END | Gravity.BOTTOM, 0, 0, dp(16), dp(78)));

        modesRow = new LinearLayout(this);
        mBal = modeBtn("BAL"); mAgg = modeBtn("AGR"); mOff = modeBtn("OFF");
        mBal.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.BALANCE); } });
        mAgg.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.AGGRESSIVE); } });
        mOff.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.OFF); } });
        modesRow.addView(mBal); modesRow.addView(mAgg); modesRow.addView(mOff);
        pressable(mBal); pressable(mAgg); pressable(mOff);
        uiLayer.addView(modesRow, fl(-2, -2, Gravity.END | Gravity.BOTTOM, 0, 0, dp(16), dp(10)));
    }

    private TextView modeBtn(String s) {
        TextView t = text(s, 9, WH, true);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(46), dp(46));
        lp.leftMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private void paintMode(TextView t, boolean on, int onFill, int onText) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(on ? onFill : 0x80000000);
        g.setStroke(dp(2), on ? onFill : 0x66FFFFFF);
        t.setBackground(g);
        t.setTextColor(on ? onText : WH);
    }

    private boolean introRows = true;

    private void rebuildLibrary() {
        libBox.removeAllViews();
        List<App> lib = new ArrayList<>();
        for (App a : all) if (selected.contains(a.pkg)) lib.add(a);
        boolean hasFocus = false;
        for (App a : lib) if (a.pkg.equals(focusPkg)) hasFocus = true;
        if (!hasFocus) focusPkg = lib.isEmpty() ? null : lib.get(0).pkg;

        for (final App a : lib) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(6), dp(6), dp(6));
            boolean f = a.pkg.equals(focusPkg);
            GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{f ? 0x55E4002B : 0, 0});
            row.setBackground(bg);
            if (f) {
                View bar = new View(this);
                bar.setBackgroundColor(RD);
                row.addView(bar, new LinearLayout.LayoutParams(dp(3), dp(36)));
                row.addView(new View(this), new LinearLayout.LayoutParams(dp(7), 1));
            } else row.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
            ImageView ic = new ImageView(this);
            ic.setImageDrawable(a.icon);
            ic.setBackground(new Poly(0, 0, f ? WH : 0, dp(2), dp(7)));
            ic.setPadding(dp(3), dp(3), dp(3), dp(3));
            row.addView(ic, new LinearLayout.LayoutParams(dp(42), dp(42)));
            LinearLayout nm = new LinearLayout(this);
            nm.setOrientation(LinearLayout.VERTICAL);
            nm.setPadding(dp(10), 0, 0, 0);
            TextView n = text(a.name, 12, WH, true);
            n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.END);
            n.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            TextView sub = text(f ? "Dipilih • tahan untuk hapus" : "Ketuk untuk memilih", 8.5f, DIM, false);
            sub.setSingleLine(true); sub.setEllipsize(TextUtils.TruncateAt.END);
            nm.addView(n); nm.addView(sub);
            row.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            row.setAlpha(f ? 1f : .8f);
            row.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { focusPkg = a.pkg; rebuildLibrary(); refresh(); } });
            row.setOnLongClickListener(new View.OnLongClickListener() { public boolean onLongClick(View v) {
                selected.remove(a.pkg);
                Booster.setGames(MainActivity.this, selected);
                rebuildLibrary(); refresh();
                Toast.makeText(MainActivity.this, a.name + " dihapus dari daftar", Toast.LENGTH_SHORT).show();
                return true;
            } });
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
            rl.bottomMargin = dp(4);
            libBox.addView(row, rl);
            pressable(row);
            if (!f || introRows) slideIn(row, -dp(40), 0, 60L * libBox.getChildCount());
        }
        if (lib.isEmpty()) {
            TextView h = text("Belum ada game.\nKetuk + untuk memilih game dari HP-mu.", 11, DIM, false);
            h.setPadding(dp(10), dp(6), dp(6), dp(10));
            libBox.addView(h);
        }
        TextView add = text("+", 26, WH, false);
        add.setGravity(Gravity.CENTER);
        add.setBackground(new Poly(0, 0x24FFFFFF, 0, 0, dp(7)));
        add.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pickGames(); } });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(dp(42), dp(42));
        al.leftMargin = dp(14); al.topMargin = dp(4);
        libBox.addView(add, al);
    }

    /** Dialog pilih game: game terdeteksi di atas, lalu urut nama. */
    private void pickGames() {
        if (all.isEmpty()) { Toast.makeText(this, "Daftar aplikasi masih dimuat...", Toast.LENGTH_SHORT).show(); return; }
        final List<App> opts = new ArrayList<>(all);
        Collections.sort(opts, new Comparator<App>() {
            public int compare(App x, App y) {
                if (x.game != y.game) return x.game ? -1 : 1;
                return x.name.compareToIgnoreCase(y.name);
            }
        });
        CharSequence[] names = new CharSequence[opts.size()];
        final boolean[] chk = new boolean[opts.size()];
        for (int i = 0; i < opts.size(); i++) {
            names[i] = opts.get(i).name + (opts.get(i).game ? "  • game" : "");
            chk[i] = selected.contains(opts.get(i).pkg);
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Pilih game")
                .setMultiChoiceItems(names, chk, new DialogInterface.OnMultiChoiceClickListener() {
                    public void onClick(DialogInterface d, int which, boolean checked) { chk[which] = checked; }
                })
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        selected.clear();
                        for (int i = 0; i < opts.size(); i++) if (chk[i]) selected.add(opts.get(i).pkg);
                        Booster.setGames(MainActivity.this, selected);
                        rebuildLibrary(); refresh();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // ---------- BASE ----------
    private void buildBase() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(new Poly(0, 0xF2090909, 0x26FFFFFF, dp(1), dp(14)));

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        String[] names = {"CPU", "RAM", "SUHU", "BAT"};
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
        for (int i = 0; i < 4; i++) {
            LinearLayout st = new LinearLayout(this);
            st.setOrientation(LinearLayout.VERTICAL);
            st.setBackgroundColor(0x0DFFFFFF);
            st.setPadding(dp(12), dp(8), dp(12), dp(10));
            TextView k = text(names[i], 9, RD, true);
            k.setLetterSpacing(.14f);
            sv[i] = text("??", 22, WH, true);
            sv[i].setPadding(0, dp(3), 0, dp(5));
            sb[i] = new MiniBar(this);
            st.addView(k); st.addView(sv[i]); st.addView(sb[i], new LinearLayout.LayoutParams(-1, dp(3)));
            View accent = new View(this);
            LinearLayout wrap = new LinearLayout(this);
            accent.setBackgroundColor(RD);
            wrap.addView(accent, new LinearLayout.LayoutParams(dp(3), -1));
            wrap.addView(st, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            (i < 2 ? r1 : r2).addView(wrap, lp);
        }
        grid.addView(r1); grid.addView(r2);
        box.addView(grid, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), dp(4), 0, 0);
        TextView h1 = text("MODE", 10, RD, true); h1.setLetterSpacing(.16f);
        tDesc = text("", 11, 0xFFE0E0E0, false);
        tDesc.setPadding(0, dp(4), 0, dp(10));
        TextView h2 = text("TENTANG", 10, RD, true); h2.setLetterSpacing(.16f);
        TextView about = text("Dracio memakai Shizuku untuk menerapkan mode secara nyata dan sementara. Saat dimatikan, semua kembali seperti semula.", 11, 0xFFB8B8B8, false);
        about.setPadding(0, dp(4), 0, dp(10));
        TextView diag = text("Diagnostik & log", 11, WH, true);
        diag.setPadding(dp(12), dp(7), dp(12), dp(7));
        diag.setBackground(new Poly(2, 0, 0x66FFFFFF, dp(1), dp(6)));
        diag.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showDiag(); } });
        info.addView(h1); info.addView(tDesc); info.addView(h2); info.addView(about);
        info.addView(diag, new LinearLayout.LayoutParams(-2, -2));
        box.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

        baseBox = box;
        box.setVisibility(View.GONE);
        uiLayer.addView(box, fl(-1, -2, Gravity.TOP, dp(14), dp(46), dp(14), 0));
    }

    // ---------- tab bawah ----------
    private void buildTabs() {
        LinearLayout tabs = new LinearLayout(this);
        tLobi = tab("LOBI"); tTools = tab("ALAT"); tBase = tab("BASE");
        tLobi.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { switchPage(0); } });
        tTools.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { switchPage(1); } });
        tBase.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { switchPage(2); } });
        tabs.addView(tLobi); tabs.addView(tTools); tabs.addView(tBase);
        uiLayer.addView(tabs, fl(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0, 0, 0));
    }

    private void switchPage(int n) {
        if (n == page) return;
        page = n;
        refresh();
        if (n == 0) playLobbyIntro();
        else slideIn(n == 1 ? toolsBox : baseBox, 0, dp(30), 0);
    }

    // ---------- ALAT (fitur tambahan nyata via Shizuku) ----------
    private void buildTools() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(new Poly(0, 0xF2090909, 0x26FFFFFF, dp(1), dp(14)));
        TextView h = text("ALAT CEPAT", 10, RD, true);
        h.setLetterSpacing(.16f);
        h.setPadding(dp(4), 0, 0, dp(8));
        box.addView(h);
        String[] desc = {"Bersihkan RAM", "Tangkap layar", "Kunci rotasi", "Mode senyap", "Tampilkan sentuhan", "Refresh rate", "FPS melayang"};
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
        for (int i = 0; i < 7; i++) {
            final int id = i;
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(6), dp(10), dp(6), dp(10));
            toolName[i] = text(Tools.NAME[i], 15, WH, true);
            toolName[i].setSingleLine(true);
            toolName[i].setEllipsize(TextUtils.TruncateAt.END);
            toolSub[i] = text(i == 5 ? Tools.hzLabel() : desc[i], 8.5f, DIM, false);
            toolSub[i].setSingleLine(true);
            toolSub[i].setEllipsize(TextUtils.TruncateAt.END);
            t.addView(toolName[i]); t.addView(toolSub[i]);
            t.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { runTool(id); } });
            pressable(t);
            toolTile[i] = t;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(64), 1);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            (i < 4 ? r1 : r2).addView(t, lp);
        }
        View blank = new View(this);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, dp(64), 1);
        bl.setMargins(dp(4), dp(4), dp(4), dp(4));
        r2.addView(blank, bl);
        box.addView(r1); box.addView(r2);
        TextView note = text("Butuh Shizuku aktif. Pengaturan yang kamu ubah dikembalikan saat overlay dihentikan.", 9.5f, DIM, false);
        note.setPadding(dp(4), dp(8), 0, 0);
        box.addView(note);
        toolsBox = box;
        box.setVisibility(View.GONE);
        uiLayer.addView(box, fl(-1, -2, Gravity.TOP, dp(14), dp(46), dp(14), 0));
        paintTools();
    }

    private void paintTools() {
        for (int i = 0; i < 7; i++) {
            if (toolTile[i] == null) continue;
            boolean on = toolOn[i];
            toolTile[i].setBackground(new Poly(0, on ? RD : 0xC40E0E0E, on ? 0 : 0x55FFFFFF, dp(1.4f), dp(9)));
            toolSub[i].setTextColor(on ? WH : DIM);
        }
    }

    private void toastUi(final String m) { runOnUiThread(new Runnable() { public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show(); } }); }

    private void runTool(final int id) {
        if (id == 6) {
            if (!OverlayService.alive) { Toast.makeText(this, "Mulai game dulu supaya overlay aktif", Toast.LENGTH_SHORT).show(); return; }
            startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_PILL));
            toolOn[6] = !OverlayService.pillOn; paintTools();
            return;
        }
        if (!Sh.granted()) { Toast.makeText(this, "Butuh Shizuku aktif", Toast.LENGTH_SHORT).show(); return; }
        final Context c = getApplicationContext();
        switch (id) {
            case 0: new Thread(new Runnable() { public void run() { toastUi(Tools.klean(c)); } }).start(); break;
            case 1: new Thread(new Runnable() { public void run() {
                try { Thread.sleep(300); } catch (InterruptedException ignored) {}
                toastUi(Tools.shot()); } }).start(); break;
            case 2: { final boolean v = !toolOn[2]; toolOn[2] = v; paintTools();
                new Thread(new Runnable() { public void run() { Tools.setRot(v); } }).start(); break; }
            case 3: { final boolean v = !toolOn[3]; toolOn[3] = v; paintTools();
                new Thread(new Runnable() { public void run() { Tools.setDnd(v); } }).start(); break; }
            case 4: { final boolean v = !toolOn[4]; toolOn[4] = v; paintTools();
                new Thread(new Runnable() { public void run() { Tools.setTouch(v); } }).start(); break; }
            case 5: new Thread(new Runnable() { public void run() {
                Tools.cycleHz(c);
                runOnUiThread(new Runnable() { public void run() { toolOn[5] = Tools.hzMode != 0; toolSub[5].setText(Tools.hzLabel()); paintTools(); } });
            } }).start(); break;
        }
    }

    private TextView tab(String s) {
        TextView t = text(s, 12, WH, true);
        t.setLetterSpacing(.1f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(30), dp(11), dp(30), dp(10));
        pressable(t);
        return t;
    }

    // ---------- data aplikasi ----------
    private void loadApps() {
        new Thread(new Runnable() { public void run() {
            PackageManager pm = getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            final List<App> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.name = String.valueOf(ri.loadLabel(pm));
                a.icon = ri.loadIcon(pm);
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    a.game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                } catch (Throwable ignored) {}
                out.add(a);
            }
            Collections.sort(out, new Comparator<App>() {
                public int compare(App x, App y) { return x.name.compareToIgnoreCase(y.name); }
            });
            runOnUiThread(new Runnable() { public void run() { all.clear(); all.addAll(out); rebuildLibrary(); refresh(); } });
        } }).start();
    }

    private App focusApp() {
        for (App a : all) if (a.pkg.equals(focusPkg)) return a;
        return null;
    }

    private void launch(String pkg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(this, "Tidak bisa membuka aplikasi", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- Shizuku, mode, overlay ----------
    private void onShizuku() {
        try {
            if (!Sh.running()) {
                Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i != null) startActivity(i);
                else Toast.makeText(this, "Shizuku belum terpasang. Pasang dari Play Store / GitHub Shizuku.", Toast.LENGTH_LONG).show();
                return;
            }
            if (!Sh.granted()) Shizuku.requestPermission(REQ_SHIZUKU);
        } catch (Throwable t) {
            Toast.makeText(this, "Shizuku error: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setMode(int m) {
        if (!Sh.granted()) {
            Toast.makeText(this, "Shizuku belum aktif / belum diizinkan. Mode tidak bisa diterapkan.", Toast.LENGTH_LONG).show();
            return;
        }
        final int target = (m == Booster.mode(this)) ? Booster.OFF : m;
        gSub.setText("Memproses mode... (bisa beberapa detik)");
        final Context c = getApplicationContext();
        new Thread(new Runnable() { public void run() {
            Booster.apply(c, target, null);
            runOnUiThread(new Runnable() { public void run() { refresh(); } });
        } }).start();
    }

    /** true bila overlay sudah/akan berjalan. */
    private boolean ensureOverlay() {
        if (OverlayService.alive) return true;
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Beri izin tampil di atas aplikasi dulu (ketuk chip Overlay)", Toast.LENGTH_LONG).show();
            return false;
        }
        startForegroundService(new Intent(this, OverlayService.class));
        return true;
    }

    private void toggleOverlay() {
        if (OverlayService.alive) {
            startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_STOP));
        } else if (!ensureOverlay()) return;
        bStop.postDelayed(new Runnable() { public void run() { refresh(); } }, 400);
    }

    private void startGame() {
        final App a = focusApp();
        if (a == null) { Toast.makeText(this, "Pilih game dulu (ketuk +)", Toast.LENGTH_SHORT).show(); return; }
        boolean fresh = !OverlayService.alive;
        if (!ensureOverlay()) return;
        bStart.animate().scaleX(.94f).scaleY(.94f).setDuration(90).withEndAction(new Runnable() {
            public void run() { bStart.animate().scaleX(1f).scaleY(1f).setDuration(140).start(); }
        }).start();
        // beri waktu animasi peluncuran tampil sebelum game dibuka
        bStart.postDelayed(new Runnable() { public void run() { launch(a.pkg); refresh(); } }, fresh ? 1200 : 150);
    }

    private void showDiag() {
        String s = Booster.lastLog.isEmpty() ? "(belum ada log mode)" : Booster.lastLog;
        if (!Booster.fgDebug.isEmpty() || !Booster.fpsDebug.isEmpty())
            s += "\n\n[Diagnostik FPS]\nfg: " + Booster.fgDebug + "\n" + Booster.fpsDebug;
        TextView t = text(s, 10, 0xFFE6E6E6, false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(t);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Diagnostik & log").setView(scroll).setPositiveButton("Tutup", null).show();
    }

    // ---------- tampilan ----------
    private void setChip(TextView t, String s, boolean ok) {
        SpannableString sp = new SpannableString("■ " + s);
        sp.setSpan(new ForegroundColorSpan(ok ? WH : RD), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        t.setText(sp);
    }

    private void refresh() {
        if (chipSh == null || mBal == null) return;
        boolean run = Sh.running(), ok = Sh.granted();
        setChip(chipSh, ok ? "Shizuku aktif" : run ? "Shizuku: izinkan" : "Shizuku mati", ok);
        boolean ov = Settings.canDrawOverlays(this);
        setChip(chipOv, ov ? "Overlay OK" : "Overlay belum", ov);

        int m = Booster.mode(this);
        stage.setMode(m);
        paintMode(mBal, m == Booster.BALANCE, WH, 0xFF0A0A0A);
        paintMode(mAgg, m == Booster.AGGRESSIVE, RD, WH);
        paintMode(mOff, false, WH, 0xFF0A0A0A);
        mOff.setAlpha(m == Booster.OFF ? .45f : 1f);
        tDesc.setText(m == Booster.AGGRESSIVE
                ? "Agresif: performa maksimal. Batasi proses latar, notifikasi dibisukan, Data Saver, animasi mati, game mode Performance. Sementara."
                : m == Booster.BALANCE
                ? "Balance: seimbang performa dan baterai. Animasi 0,5x, adaptive battery aktif, game mode Standard."
                : "Mode mati. Semua pengaturan HP normal.");

        App fa = focusApp();
        gName.setText(fa != null ? fa.name : "Belum ada game");
        gSub.setText("MODE " + (m == Booster.AGGRESSIVE ? "AGRESIF" : m == Booster.BALANCE ? "BALANCE" : "MATI")
                + "  •  " + (ok ? "SHIZUKU AKTIF" : "TANPA SHIZUKU"));

        boolean on = OverlayService.alive;
        bStart.setText(on ? "BUKA GAME" : "MULAI GAME");
        bStart.setBackground(new Poly(0, RD, 0, 0, dp(10)));
        bStart.setTextColor(WH);
        bStop.setBackground(new Poly(3, on ? RD : 0x24FFFFFF, 0, 0, 0));

        tLobi.setBackground(new Poly(1, page == 0 ? RD : 0xFF141414, 0, 0, dp(12)));
        tTools.setBackground(new Poly(1, page == 1 ? RD : 0xFF141414, 0, 0, dp(12)));
        tBase.setBackground(new Poly(1, page == 2 ? RD : 0xFF141414, 0, 0, dp(12)));
        tLobi.setTextColor(page == 0 ? WH : DIM);
        tTools.setTextColor(page == 1 ? WH : DIM);
        tBase.setTextColor(page == 2 ? WH : DIM);
        int lv = page == 0 ? View.VISIBLE : View.GONE;
        libScroll.setVisibility(lv); lobbyRight.setVisibility(lv); modesRow.setVisibility(lv);
        toolsBox.setVisibility(page == 1 ? View.VISIBLE : View.GONE);
        baseBox.setVisibility(page == 2 ? View.VISIBLE : View.GONE);
        toolOn[6] = OverlayService.pillOn;
        paintTools();
    }

    // ---------- statistik langsung (tiap 2 detik saat menu terlihat) ----------
    private void poll() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        final float ram = 1f - mi.availMem / (float) Math.max(1, mi.totalMem);

        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        final float temp = b != null ? b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f : 0;
        final int lvl = b != null ? b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        float hzv = 60;
        try { hzv = getWindowManager().getDefaultDisplay().getRefreshRate(); } catch (Throwable ignored) {}
        final float hz = hzv;

        float cpuv = -1;
        if (Sh.granted()) {
            try {
                String[] a = Sh.run("head -1 /proc/stat").trim().split("\\s+");
                if (a.length >= 8 && a[0].equals("cpu")) {
                    long total = 0;
                    for (int i = 1; i <= 8 && i < a.length; i++) total += Long.parseLong(a[i]);
                    long idle = Long.parseLong(a[4]) + Long.parseLong(a[5]);
                    if (lastTotal >= 0 && total > lastTotal) cpuv = 1f - (idle - lastIdle) / (float) (total - lastTotal);
                    lastTotal = total; lastIdle = idle;
                }
            } catch (Throwable ignored) {}
        }
        final float cpu = cpuv;
        final boolean[] ts = Sh.granted() ? Tools.readStates() : null;
        final String clock = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        runOnUiThread(new Runnable() { public void run() {
            if (sv[0] == null) return;
            String cs = cpu >= 0 ? Math.round(cpu * 100) + "%" : "??%";
            String rs = Math.round(ram * 100) + "%";
            String ts = temp > 0 ? String.format(Locale.US, "%.1f°C", temp) : "??°C";
            String bs = lvl >= 0 ? lvl + "%" : "??%";
            stage.setData(cs, rs, ts, String.format(Locale.US, "%.0f", hz));
            sv[0].setText(cs); sv[1].setText(rs); sv[2].setText(ts); sv[3].setText(bs);
            sb[0].set(cpu >= 0 ? cpu : 0, cpu > .85f ? RD : WH);
            sb[1].set(ram, ram > .85f ? RD : WH);
            sb[2].set(temp > 0 ? (temp - 25f) / 25f : 0, temp >= 42 ? RD : WH);
            sb[3].set(lvl >= 0 ? lvl / 100f : 0, lvl >= 0 && lvl < 20 ? RD : WH);
            sv[2].setTextColor(temp >= 46 ? RD : WH);
            clockT.setText(clock);
            if (ts != null) { toolOn[2] = ts[0]; toolOn[3] = ts[1]; toolOn[4] = ts[2]; toolOn[5] = Tools.hzMode != 0; toolSub[5].setText(Tools.hzLabel()); }
            toolOn[6] = OverlayService.pillOn;
            paintTools();
            batT.setText(bs);
            batV.level = lvl >= 0 ? lvl / 100f : 0; batV.invalidate();
        } });
    }
}

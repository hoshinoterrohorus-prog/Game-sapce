package com.gamespace.boost;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    static final int REQ_SHIZUKU = 42;

    static class App { String pkg; String name; Drawable icon; boolean game; }

    private final List<App> apps = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private BaseAdapter adapter;
    private TextView tShizuku, tOverlay, tLog;
    private TextView bShizuku, bOverlay, bBal, bAgg, bOff, bToggle;

    private final Shizuku.OnRequestPermissionResultListener permL = new Shizuku.OnRequestPermissionResultListener() {
        @Override public void onRequestPermissionResult(int requestCode, int grantResult) { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };
    private final Shizuku.OnBinderReceivedListener recvL = new Shizuku.OnBinderReceivedListener() {
        @Override public void onBinderReceived() { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };
    private final Shizuku.OnBinderDeadListener deadL = new Shizuku.OnBinderDeadListener() {
        @Override public void onBinderDead() { runOnUiThread(new Runnable() { public void run() { refresh(); } }); }
    };

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8, 11, 20));
        getWindow().setNavigationBarColor(Color.rgb(8, 11, 20));
        selected.addAll(Booster.games(this));
        try {
            Shizuku.addRequestPermissionResultListener(permL);
            Shizuku.addBinderReceivedListenerSticky(recvL);
            Shizuku.addBinderDeadListener(deadL);
        } catch (Throwable ignored) {}

        ListView lv = new ListView(this);
        lv.setBackgroundColor(Color.rgb(8, 11, 20));
        lv.setDivider(null);
        lv.addHeaderView(buildHeader(), null, false);
        adapter = new BaseAdapter() {
            public int getCount() { return apps.size(); }
            public Object getItem(int i) { return apps.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View v, ViewGroup p) { return row(i, v); }
        };
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> a, View v, int pos, long id) {
                int i = pos - 1;
                if (i < 0 || i >= apps.size()) return;
                String pkg = apps.get(i).pkg;
                if (!selected.add(pkg)) selected.remove(pkg);
                Booster.setGames(MainActivity.this, selected);
                adapter.notifyDataSetChanged();
            }
        });
        setContentView(lv);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        loadApps();
        refresh();
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    @Override protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permL);
            Shizuku.removeBinderReceivedListener(recvL);
            Shizuku.removeBinderDeadListener(deadL);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private TextView button(String s) {
        TextView t = text(s, 13, Color.BLACK, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        return t;
    }

    private void paint(TextView t, int fill, int txt) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(10));
        t.setBackground(g); t.setTextColor(txt);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(18, 24, 40)); g.setCornerRadius(dp(14));
        c.setBackground(g);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        c.setLayoutParams(lp);
        return c;
    }

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(dp(14), dp(20), dp(14), dp(6));

        h.addView(text("GAME SPACE", 24, Color.rgb(0, 229, 255), true));
        TextView sub = text("Booster game via Shizuku + overlay performa", 12, Color.rgb(150, 160, 180), false);
        sub.setPadding(0, 0, 0, dp(14));
        h.addView(sub);

        // Shizuku
        LinearLayout c1 = card();
        c1.addView(text("1. Akses Shizuku", 14, Color.WHITE, true));
        tShizuku = text("", 12, Color.rgb(170, 180, 200), false);
        tShizuku.setPadding(0, dp(4), 0, dp(8));
        c1.addView(tShizuku);
        bShizuku = button("Beri izin");
        bShizuku.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { onShizuku(); } });
        c1.addView(bShizuku);
        h.addView(c1);

        // Overlay
        LinearLayout c2 = card();
        c2.addView(text("2. Izin tampil di atas aplikasi", 14, Color.WHITE, true));
        tOverlay = text("", 12, Color.rgb(170, 180, 200), false);
        tOverlay.setPadding(0, dp(4), 0, dp(8));
        c2.addView(tOverlay);
        bOverlay = button("Buka pengaturan");
        bOverlay.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } });
        c2.addView(bOverlay);
        h.addView(c2);

        // Mode
        LinearLayout c3 = card();
        c3.addView(text("3. Mode", 14, Color.WHITE, true));
        TextView d = text("Balance: seimbang performa dan baterai (animasi sistem 0,5x, adaptive battery aktif, game mode Standard, bersihkan proses cache).\n\nAgresif: performa maksimal. Batasi proses latar belakang aplikasi pihak ketiga, notifikasi dibisukan (Jangan Ganggu), Data Saver aktif, animasi dimatikan, mode performa tetap, game mode Performance.\n\nSemua sementara. Matikan = semua pengaturan dikembalikan seperti semula. Ketuk mode yang sedang aktif juga mematikannya.", 11, Color.rgb(150, 160, 180), false);
        d.setPadding(0, dp(4), 0, dp(8));
        c3.addView(d);
        LinearLayout r = new LinearLayout(this);
        bBal = button("Balance"); bAgg = button("Agresif"); bOff = button("Matikan");
        bBal.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.BALANCE); } });
        bAgg.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.AGGRESSIVE); } });
        bOff.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setMode(Booster.OFF); } });
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, -2, 1);
        p1.setMargins(0, 0, dp(3), 0);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, -2, 1);
        p2.setMargins(dp(3), 0, dp(3), 0);
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(0, -2, 1);
        p3.setMargins(dp(3), 0, 0, 0);
        r.addView(bBal, p1); r.addView(bAgg, p2); r.addView(bOff, p3);
        c3.addView(r);
        h.addView(c3);

        // Start
        bToggle = button("MULAI GAME SPACE");
        bToggle.setTextSize(15);
        bToggle.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleService(); } });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.setMargins(0, 0, 0, dp(10));
        h.addView(bToggle, tp);

        tLog = text("", 10, Color.rgb(120, 130, 150), false);
        tLog.setTypeface(android.graphics.Typeface.MONOSPACE);
        h.addView(tLog);

        TextView lt = text("4. Pilih game (ketuk untuk centang)", 14, Color.WHITE, true);
        lt.setPadding(0, dp(10), 0, dp(6));
        h.addView(lt);
        TextView hint = text("Saat game yang dicentang dibuka, mode otomatis diterapkan dan FPS-nya dipantau.", 11, Color.rgb(150, 160, 180), false);
        h.addView(hint);
        return h;
    }

    private View row(int i, View v) {
        LinearLayout r;
        if (v == null) {
            r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(14), dp(8), dp(14), dp(8));
            ImageView iv = new ImageView(this);
            iv.setId(1);
            r.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(12), 0, dp(8), 0);
            TextView n = text("", 14, Color.WHITE, false); n.setId(2); n.setSingleLine(true);
            TextView k = text("", 10, Color.rgb(120, 130, 150), false); k.setId(3); k.setSingleLine(true);
            col.addView(n); col.addView(k);
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            CheckBox cb = new CheckBox(this);
            cb.setId(4); cb.setClickable(false); cb.setFocusable(false);
            r.addView(cb);
        } else r = (LinearLayout) v;
        App a = apps.get(i);
        ((ImageView) r.findViewById(1)).setImageDrawable(a.icon);
        ((TextView) r.findViewById(2)).setText(a.name + (a.game ? "  🎮" : ""));
        ((TextView) r.findViewById(3)).setText(a.pkg);
        ((CheckBox) r.findViewById(4)).setChecked(selected.contains(a.pkg));
        return r;
    }

    private void loadApps() {
        new Thread(new Runnable() { public void run() {
            PackageManager pm = getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            final List<App> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.name = String.valueOf(ri.loadLabel(pm));
                a.icon = ri.loadIcon(pm);
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    a.game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                } catch (Throwable ignored) {}
                out.add(a);
            }
            Collections.sort(out, new Comparator<App>() {
                public int compare(App x, App y) {
                    boolean sx = selected.contains(x.pkg), sy = selected.contains(y.pkg);
                    if (sx != sy) return sx ? -1 : 1;
                    if (x.game != y.game) return x.game ? -1 : 1;
                    return x.name.compareToIgnoreCase(y.name);
                }
            });
            runOnUiThread(new Runnable() { public void run() { apps.clear(); apps.addAll(out); adapter.notifyDataSetChanged(); } });
        } }).start();
    }

    private void onShizuku() {
        try {
            if (!Sh.running()) {
                Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i != null) startActivity(i);
                else Toast.makeText(this, "Shizuku belum terpasang. Pasang dari Play Store / GitHub Shizuku.", Toast.LENGTH_LONG).show();
                return;
            }
            if (!Sh.granted()) Shizuku.requestPermission(REQ_SHIZUKU);
        } catch (Throwable t) {
            Toast.makeText(this, "Shizuku error: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setMode(int m) {
        if (!Sh.granted()) {
            Toast.makeText(this, "Shizuku belum aktif / belum diizinkan. Mode tidak bisa diterapkan.", Toast.LENGTH_LONG).show();
            return;
        }
        final int target = (m == Booster.mode(this)) ? Booster.OFF : m;
        tLog.setText("Memproses... (bisa beberapa detik)");
        final Context c = getApplicationContext();
        new Thread(new Runnable() { public void run() {
            final String s = Booster.apply(c, target, null);
            runOnUiThread(new Runnable() { public void run() { tLog.setText(s); refresh(); } });
        } }).start();
    }

    private void toggleService() {
        if (OverlayService.alive) {
            startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_STOP));
            bToggle.postDelayed(new Runnable() { public void run() { refresh(); } }, 400);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Beri izin tampil di atas aplikasi dulu", Toast.LENGTH_LONG).show();
            return;
        }
        bToggle.setText("MELUNCURKAN...");
        bToggle.animate().scaleX(.94f).scaleY(.94f).setDuration(90).withEndAction(new Runnable() {
            public void run() { bToggle.animate().scaleX(1f).scaleY(1f).setDuration(140).start(); }
        }).start();
        startForegroundService(new Intent(this, OverlayService.class));
        bToggle.postDelayed(new Runnable() { public void run() { refresh(); } }, 400);
    }

    private void refresh() {
        if (tShizuku == null) return;
        boolean run = Sh.running(), ok = Sh.granted();
        int cyan = Color.rgb(0, 229, 255), grey = Color.rgb(60, 70, 90);
        if (ok) { tShizuku.setText("✅ Aktif dan diizinkan"); bShizuku.setText("Sudah aktif"); paint(bShizuku, grey, Color.WHITE); }
        else if (run) { tShizuku.setText("Shizuku jalan, aplikasi ini belum diizinkan"); bShizuku.setText("Beri izin"); paint(bShizuku, cyan, Color.BLACK); }
        else { tShizuku.setText("Shizuku belum berjalan. Buka aplikasi Shizuku lalu Start (Wireless debugging / root)."); bShizuku.setText("Buka Shizuku"); paint(bShizuku, cyan, Color.BLACK); }

        boolean ov = Settings.canDrawOverlays(this);
        tOverlay.setText(ov ? "✅ Diizinkan" : "Belum diizinkan");
        bOverlay.setText(ov ? "Sudah aktif" : "Buka pengaturan");
        paint(bOverlay, ov ? grey : cyan, ov ? Color.WHITE : Color.BLACK);

        int m = Booster.mode(this);
        paint(bBal, m == Booster.BALANCE ? cyan : grey, m == Booster.BALANCE ? Color.BLACK : Color.WHITE);
        paint(bOff, m == Booster.OFF ? Color.rgb(35, 42, 60) : Color.rgb(184, 199, 230), m == Booster.OFF ? Color.rgb(120, 130, 150) : Color.BLACK);
        paint(bAgg, m == Booster.AGGRESSIVE ? Color.rgb(255, 82, 82) : grey, m == Booster.AGGRESSIVE ? Color.BLACK : Color.WHITE);

        boolean on = OverlayService.alive;
        bToggle.setText(on ? "STOP GAME SPACE" : "MULAI GAME SPACE");
        paint(bToggle, on ? Color.rgb(255, 82, 82) : Color.rgb(0, 230, 118), Color.BLACK);
        String dbg = Booster.lastLog;
        if (!Booster.fgDebug.isEmpty() || !Booster.fpsDebug.isEmpty())
            dbg += "\n\n[Diagnostik FPS]\nfg: " + Booster.fgDebug + "\n" + Booster.fpsDebug;
        if (!dbg.isEmpty()) tLog.setText(dbg);
    }
}

package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

/** Latar menu ala Red Magic: hitam, tekstur karbon diagonal, potongan miring merah. Statis (nol beban). */
public class NeonBackground extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public NeonBackground(Context c) { super(c); }

    @Override protected void onDraw(Canvas cv) {
        float W = getWidth(), H = getHeight(), d = getResources().getDisplayMetrics().density;
        cv.drawColor(0xFF0A0A0A);

        // tekstur garis diagonal halus
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0x0DFFFFFF);
        float step = 9 * d;
        for (float x = -H; x < W; x += step) cv.drawLine(x, H, x + H, 0, p);

        // potongan miring merah di kanan
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(W * .62f, 0, W, H, 0x00E4002B, 0x59E4002B, Shader.TileMode.CLAMP));
        path.reset();
        path.moveTo(W * .70f, 0); path.lineTo(W, 0); path.lineTo(W, H); path.lineTo(W * .46f, H); path.close();
        cv.drawPath(path, p);
        p.setShader(null);

        // dua garis aksen miring
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xFFE4002B);
        p.setStrokeWidth(3 * d);
        cv.drawLine(W * .46f, H, W * .70f, 0, p);
        p.setColor(0x33FFFFFF);
        p.setStrokeWidth(1.2f * d);
        cv.drawLine(W * .44f, H, W * .68f, 0, p);
        p.setStyle(Paint.Style.FILL);
    }
}

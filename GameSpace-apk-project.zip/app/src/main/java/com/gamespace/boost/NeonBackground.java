package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Latar menu: glow neon + grid perspektif bergerak. Ringan (~20 fps, berhenti saat tidak terlihat). */
public class NeonBackground extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final long t0 = System.currentTimeMillis();
    private Shader glowA, glowB;

    public NeonBackground(Context c) { super(c); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        glowA = new RadialGradient(w * .9f, 0, Math.max(w, h) * .75f, 0x33FF00C8, 0x00FF00C8, Shader.TileMode.CLAMP);
        glowB = new RadialGradient(0, h, Math.max(w, h) * .75f, 0x2900E5FF, 0x0000E5FF, Shader.TileMode.CLAMP);
    }

    @Override protected void onDraw(Canvas cv) {
        float W = getWidth(), H = getHeight();
        cv.drawColor(0xFF05070F);
        p.setShader(glowA); cv.drawRect(0, 0, W, H, p);
        p.setShader(glowB); cv.drawRect(0, 0, W, H, p);
        p.setShader(null);

        // grid perspektif di bagian bawah
        float hor = H * .42f, vx = W / 2f;
        float d = getResources().getDisplayMetrics().density;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f * d);
        float off = ((System.currentTimeMillis() - t0) % 2400) / 2400f;
        int rows = 14;
        for (int i = 0; i < rows; i++) {
            float k = (i + off) / rows;
            float y = hor + (H - hor) * k * k;
            p.setColor(((int) (70 * k + 8) << 24) | 0x0000E5FF);
            cv.drawLine(0, y, W, y, p);
        }
        for (int j = -9; j <= 9; j++) {
            float xb = vx + j * W * .11f;
            p.setColor(((int) (46 - Math.abs(j) * 2) << 24) | 0x00FF2A4D);
            cv.drawLine(vx + j * W * .012f, hor, xb * 1.0f + (xb - vx) * .9f, H, p);
        }
        p.setStyle(Paint.Style.FILL);
        if (isShown()) postInvalidateDelayed(50);
    }

    @Override protected void onVisibilityChanged(View v, int vis) {
        super.onVisibilityChanged(v, vis);
        if (vis == VISIBLE) postInvalidateOnAnimation();
    }
}

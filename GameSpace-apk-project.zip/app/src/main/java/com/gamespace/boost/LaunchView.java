package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

/** Animasi peluncuran layar penuh: "GAME SPACE DILUNCURKAN" (2,7 detik). */
public class LaunchView extends View {
    static final int TOTAL = 2700;
    static final int CY = 0xFFFFFFFF, MG = 0xFFFF3B3B, RD = 0xFFE4002B;
    private static final String TITLE = "GAME SPACE", SUB = "DILUNCURKAN";

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface titleTf = Typeface.create("sans-serif-black", Typeface.ITALIC);
    private final Typeface subTf = Typeface.create("sans-serif-black", Typeface.NORMAL);
    private final Typeface smallTf = Typeface.create("sans-serif", Typeface.BOLD);
    private final Path wp = new Path();
    private long start = 0;
    private boolean finished = false;
    private Runnable onDone;

    public LaunchView(Context c) { super(c); }

    void setOnDone(Runnable r) { onDone = r; }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        start = SystemClock.uptimeMillis();
    }

    private static float clamp(float x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
    private static float easeOut(float x) { float k = 1 - x; return 1 - k * k * k; }
    private static float easeIO(float x) { return x < .5f ? 4 * x * x * x : 1 - (float) Math.pow(-2 * x + 2, 3) / 2; }
    private static int al(int c, float a) { return (c & 0x00FFFFFF) | (Math.max(0, Math.min(255, (int) (a * 255))) << 24); }

    private float spacedWidth(String s, float sp) {
        float w = 0;
        for (int i = 0; i < s.length(); i++) w += p.measureText(s, i, i + 1) + sp;
        return w - sp;
    }

    @Override protected void onDraw(Canvas cv) {
        long t = SystemClock.uptimeMillis() - start;
        if (t >= TOTAL) {
            if (!finished) { finished = true; if (onDone != null) post(onDone); }
            return;
        }
        float W = getWidth(), H = getHeight();
        float out = t > 2200 ? 1 - clamp((t - 2200) / 500f) : 1;
        float inn = clamp(t / 300f);

        p.reset(); p.setAntiAlias(true);
        cv.drawColor(Color.argb((int) (255 * 0.72f * inn * out), 2, 4, 10));

        float cx = W / 2, cy = H * .46f, maxR = (float) Math.hypot(W, H) * .55f;
        float strokeBase = getResources().getDisplayMetrics().density;

        // cincin gelombang
        int[] rc = {CY, MG, RD};
        p.setStyle(Paint.Style.STROKE);
        for (int k = 0; k < 3; k++) {
            float u = (t - (100 + k * 170)) / 1000f;
            if (u <= 0 || u >= 1) continue;
            p.setColor(al(rc[k], (1 - u) * .8f * out));
            p.setStrokeWidth((6 * (1 - u) + 2) * strokeBase);
            cv.drawCircle(cx, cy, easeOut(u) * maxR, p);
        }

        // garis kecepatan
        float[] ys = {.14f, .24f, .33f, .60f, .70f, .80f, .90f};
        p.setStrokeWidth(3 * strokeBase);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < ys.length; i++) {
            float u = (t - (80 + i * 40)) / 600f;
            if (u <= 0 || u >= 1) continue;
            float len = W * .45f;
            boolean right = i % 2 == 1;
            float head = easeOut(u) * (W + len) - len;
            float x = right ? head : W - head - len;
            int col = right ? RD : CY;
            int a0 = al(col, 0), a1 = al(col, (1 - u) * .7f * out);
            p.setShader(new LinearGradient(x, 0, x + len, 0, right ? a0 : a1, right ? a1 : a0, Shader.TileMode.CLAMP));
            cv.drawLine(x, H * ys[i], x + len, H * ys[i], p);
        }
        p.setShader(null);

        // gelombang neon mengalir di seluruh layar
        float env = easeOut(clamp((t - 150) / 600f)) * out;
        if (env > 0) {
            int[] wc = {CY, MG, RD, CY, MG};
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeJoin(Paint.Join.ROUND);
            for (int i = 0; i < 5; i++) {
                float amp = H * .055f * env * (1 - Math.abs(i - 2) * .18f), y0 = cy + (i - 2) * H * .045f;
                float ph = t * .004f * (i % 2 == 1 ? -1 : 1) + i * 1.3f;
                float k = (float) (2 * Math.PI / (W * .45f)) * (1 + i * .2f);
                wp.reset();
                boolean first = true;
                for (float x = 0; x <= W + 10; x += 10) {
                    float y = y0 + amp * (float) Math.sin(k * x + ph) * (.6f + .4f * (float) Math.sin(Math.min(1f, x / W) * Math.PI));
                    if (first) { wp.moveTo(x, y); first = false; } else wp.lineTo(x, y);
                }
                p.setColor(al(wc[i], .14f * env)); p.setStrokeWidth(9 * strokeBase); cv.drawPath(wp, p);
                p.setColor(al(wc[i], .6f * env)); p.setStrokeWidth((i == 2 ? 3.6f : 2.4f) * strokeBase); cv.drawPath(wp, p);
            }
            p.setStrokeJoin(Paint.Join.MITER);
        }

        // ukuran teks
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(titleTf);
        float S1 = Math.min(W * .095f, H * .19f);
        p.setTextSize(S1);
        float tw = spacedWidth(TITLE, S1 * .06f);
        if (tw > W * .78f) { S1 *= W * .78f / tw; p.setTextSize(S1); tw = spacedWidth(TITLE, S1 * .06f); }
        float sp1 = S1 * .06f, base1 = cy + S1 * .35f, x0 = cx - tw / 2;
        float S2 = S1 * .36f, sp2 = S2 * .38f, base2 = base1 + S2 * 2f;
        float S3 = S2 * .5f, base3 = base2 + S2 * 2.2f;

        // sudut HUD membuka dari tengah
        float hu = easeOut(clamp((t - 300) / 500f));
        if (hu > 0) {
            float hw = Math.min(W * .44f, tw / 2 + S1 * .7f) * hu;
            float top = base1 - S1 * 1.15f, bot = base3 + S3 * 1.6f, mid = (top + bot) / 2, hh = (bot - top) / 2 * hu;
            float L = Math.min(30 * strokeBase, S1 * .4f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * strokeBase);
            p.setColor(al(CY, hu * out));
            int[][] sg = {{-1, -1}, {1, -1}, {-1, 1}, {1, 1}};
            for (int[] s : sg) {
                float px = cx + s[0] * hw, py = mid + s[1] * hh;
                cv.drawLine(px, py - s[1] * L, px, py, p);
                cv.drawLine(px, py, px - s[0] * L, py, p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        cv.save();
        float so = t > 2200 ? 1 + .06f * (1 - out) : 1;
        cv.scale(so, so, cx, cy);

        // judul huruf demi huruf
        p.setTypeface(titleTf);
        p.setTextSize(S1);
        if (t > 1450 && t < 1570) {
            drawTitle(cv, t, x0, base1, S1, sp1, -6, 2, CY, null, .8f * out, out);
            drawTitle(cv, t, x0, base1, S1, sp1, 6, -2, RD, null, .8f * out, out);
        }
        Shader grad = new LinearGradient(x0, 0, x0 + tw, 0, new int[]{CY, MG, RD}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP);
        drawTitle(cv, t, x0, base1, S1, sp1, 0, 0, 0, grad, out, out);

        // subjudul mengetik
        p.reset(); p.setAntiAlias(true);
        p.setTypeface(subTf);
        p.setTextSize(S2);
        float sw = spacedWidth(SUB, sp2), sx0 = cx - sw / 2;
        int shown = (int) (clamp((t - 900) / (45f * SUB.length())) * SUB.length());
        p.setColor(al(0xFFFFFFFF, out));
        p.setShadowLayer(0, 0, 0, 0);
        float x = sx0;
        for (int i = 0; i < SUB.length(); i++) {
            float w = p.measureText(SUB, i, i + 1);
            if (i < shown) cv.drawText(SUB, i, i + 1, x, base2, p);
            x += w + sp2;
        }
        if (t > 900 && t < 1750 && (t / 130) % 2 == 0) {
            float cw = shown > 0 ? spacedWidth(SUB.substring(0, shown), sp2) + sp2 : 0;
            cv.drawText("_", sx0 + cw, base2, p);
        }
        p.setShadowLayer(0, 0, 0, 0);

        // bar progres
        float bw = Math.min(W * .46f, tw), bx = cx - bw / 2, by = base2 + S2 * .9f;
        float pr = easeIO(clamp((t - 500) / 1300f));
        float bf = clamp((t - 450) / 200f) * out;
        float bh = 6 * strokeBase;
        p.setColor(al(0xFFFFFFFF, .14f * bf));
        cv.drawRect(bx, by, bx + bw, by + bh, p);
        p.setShader(new LinearGradient(bx, 0, bx + bw, 0, new int[]{CY, MG, RD}, new float[]{0, .6f, 1}, Shader.TileMode.CLAMP));
        p.setAlpha((int) (255 * bf));
        p.setShadowLayer(0, 0, 0, 0);
        cv.drawRect(bx, by, bx + bw * pr, by + bh, p);
        p.setShader(null);
        p.setShadowLayer(0, 0, 0, 0);
        p.setTypeface(smallTf);
        p.setTextSize(S3);
        p.setColor(al(0xFF9A9A9A, bf));
        String lab = pr < .34f ? "INISIALISASI" : pr < .67f ? "MEMUAT HUD" : pr < 1f ? "MENYIAPKAN PANEL" : "SIAP";
        p.setTextAlign(Paint.Align.LEFT);
        cv.drawText(lab, bx, by + S3 * 2.2f, p);
        p.setTextAlign(Paint.Align.RIGHT);
        cv.drawText(Math.round(pr * 100) + "%", bx + bw, by + S3 * 2.2f, p);
        cv.restore();

        // kilatan peluncuran
        float f = 1 - Math.abs(t - 1850) / 90f;
        if (f > 0) cv.drawColor(Color.argb((int) (255 * f * .28f), 180, 250, 255));

        postInvalidateOnAnimation();
    }

    private void drawTitle(Canvas cv, long t, float x0, float base, float S, float sp, float dx, float dy,
                           int color, Shader shader, float alphaMul, float out) {
        Paint q = p;
        q.setTypeface(titleTf);
        q.setTextSize(S);
        if (shader != null) q.setShader(shader); else { q.setShader(null); q.setColor(color); }
        float d = getResources().getDisplayMetrics().density;
        if (shader != null) q.setShadowLayer(0, 0, 0, 0); else q.setShadowLayer(0, 0, 0, 0);
        float x = x0;
        for (int i = 0; i < TITLE.length(); i++) {
            float w = q.measureText(TITLE, i, i + 1);
            float u = clamp((t - (250 + i * 55)) / 200f);
            if (u > 0 && TITLE.charAt(i) != ' ') {
                q.setAlpha((int) (255 * u * alphaMul));
                cv.drawText(TITLE, i, i + 1, x + dx, base + dy + (1 - easeOut(u)) * S * .5f, q);
            }
            x += w + sp;
        }
        q.setShader(null);
        q.setShadowLayer(0, 0, 0, 0);
        q.setAlpha(255);
    }
}

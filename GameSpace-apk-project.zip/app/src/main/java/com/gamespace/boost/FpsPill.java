package com.gamespace.boost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.View;

/** Penghitung FPS mini yang melayang di atas game (nilai nyata, tidak bisa disentuh). */
public class FpsPill extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private String text = "-- FPS";
    private int color = 0xFFFFFFFF;

    public FpsPill(Context c) { super(c); }

    void set(int fps) {
        text = (fps >= 0 ? String.valueOf(fps) : "--") + " FPS";
        color = fps < 0 ? 0xFFB5B5B5 : fps >= 50 ? 0xFFFFFFFF : fps >= 30 ? 0xFFFF7A7A : 0xFFE4002B;
        invalidate();
    }

    @Override protected void onMeasure(int w, int h) {
        float d = getResources().getDisplayMetrics().density;
        setMeasuredDimension((int) (86 * d), (int) (24 * d));
    }

    @Override protected void onDraw(Canvas cv) {
        float d = getResources().getDisplayMetrics().density, W = getWidth(), H = getHeight();
        path.reset();
        path.moveTo(6 * d, 0); path.lineTo(W, 0); path.lineTo(W - 6 * d, H); path.lineTo(0, H); path.close();
        p.setStyle(Paint.Style.FILL); p.setColor(0xCC000000); cv.drawPath(path, p);
        p.setColor(0xFFE4002B); cv.drawRect(0, 0, 3 * d, H, p);
        p.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        p.setTextSize(12 * d);
        float w = p.measureText(text), max = W - 18 * d;
        if (w > max) p.setTextSize(12 * d * max / w);
        p.setColor(color); p.setTextAlign(Paint.Align.CENTER);
        cv.drawText(text, W / 2 + 2 * d, H / 2 + 4.2f * d, p);
    }
}

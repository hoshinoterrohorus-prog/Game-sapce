package com.gamespace.boost;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OverlayService extends Service {
    static final String ACTION_STOP = "com.gamespace.boost.STOP";
    static volatile boolean alive = false;

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private LinearLayout root, panel;
    private TextView tFps, tInfo, bBal, bAgg;
    private boolean expanded = true;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService ex;

    // state di thread latar
    private long lastTotal = -1, lastIdle = -1;
    private int tick = 0;
    private String fgPkg = "";
    private String gamePkg = null;
    private String layer = null;
    private volatile int cpuPct = -1;
    private int demoFps = 58;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (alive) return START_STICKY;
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        alive = true;
        startFg();
        buildOverlay();
        ex = Executors.newSingleThreadScheduledExecutor();
        ex.scheduleWithFixedDelay(new Runnable() { public void run() { try { loop(); } catch (Throwable ignored) {} } },
                500, 1000, TimeUnit.MILLISECONDS);
        return START_STICKY;
    }

    @Override public void onDestroy() {
        alive = false;
        if (ex != null) ex.shutdownNow();
        try { if (root != null) wm.removeView(root); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("gs", "Game Space", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "gs")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setContentTitle("Game Space aktif")
                .setContentText("Overlay performa berjalan")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
                .setOngoing(true).build();
        startForeground(1, n);
    }

    private void buildOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(205, 10, 14, 24));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Color.argb(120, 0, 229, 255));
        root.setBackground(bg);
        root.setPadding(dp(8), dp(6), dp(8), dp(6));

        tFps = new TextView(this);
        tFps.setTextColor(Color.rgb(0, 229, 255));
        tFps.setTextSize(15);
        tFps.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        tFps.setText("FPS --");
        root.addView(tFps);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        tInfo = new TextView(this);
        tInfo.setTextColor(Color.WHITE);
        tInfo.setTextSize(11);
        tInfo.setTypeface(android.graphics.Typeface.MONOSPACE);
        tInfo.setText("memuat...");
        panel.addView(tInfo);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, 0);
        bBal = chip("Balance");
        bAgg = chip("Agresif");
        bBal.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pick(Booster.BALANCE); } });
        bAgg.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pick(Booster.AGGRESSIVE); } });
        row.addView(bBal);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(6), 1);
        row.addView(new View(this), sp);
        row.addView(bAgg);
        panel.addView(row);
        root.addView(panel);
        refreshChips();

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(6);
        lp.y = dp(24);

        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        root.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean drag;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = lp.x; sy = lp.y; drag = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                        if (!drag && (Math.abs(mx) > slop || Math.abs(my) > slop)) drag = true;
                        if (drag) {
                            lp.x = Math.max(0, sx + (int) mx);
                            lp.y = Math.max(0, sy + (int) my);
                            try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!drag) {
                            expanded = !expanded;
                            panel.setVisibility(expanded ? View.VISIBLE : View.GONE);
                            try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) {}
                        }
                        return true;
                }
                return false;
            }
        });
        wm.addView(root, lp);
    }

    private TextView chip(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(6), dp(12), dp(6));
        return t;
    }

    private void styleChip(TextView t, boolean on, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(8));
        if (on) { g.setColor(color); t.setTextColor(Color.BLACK); }
        else { g.setColor(Color.argb(60, 255, 255, 255)); t.setTextColor(Color.WHITE); }
        t.setBackground(g);
    }

    private void refreshChips() {
        int m = Booster.mode(this);
        styleChip(bBal, m == Booster.BALANCE, Color.rgb(0, 229, 255));
        styleChip(bAgg, m == Booster.AGGRESSIVE, Color.rgb(255, 82, 82));
    }

    private void pick(final int m) {
        Booster.setMode(this, m);
        refreshChips();
        final String g = gamePkg;
        final Context c = getApplicationContext();
        new Thread(new Runnable() { public void run() { Booster.apply(c, m, g); } }).start();
    }

    // ---------- loop pemantauan (thread latar) ----------
    private void loop() {
        tick++;
        final StringBuilder sb = new StringBuilder();

        // RAM
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        int ramPct = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));

        // baterai
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        float temp = b != null ? b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f : 0;
        int lvl = b != null ? b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;

        boolean sh = Sh.granted();
        int fps = -1;
        if (sh) {
            // CPU
            String st = Sh.run("head -1 /proc/stat");
            parseCpu(st);

            // game di layar depan (tiap 3 detik)
            if (tick % 3 == 1) detectForeground();

            if (gamePkg != null) fps = readFps(gamePkg);
        }

        boolean demo = !sh;
        if (demo) {
            demoFps = Math.max(24, Math.min(60, demoFps + (int) Math.round((Math.random() - .45) * 6)));
            fps = demoFps;
            cpuPct = Math.max(8, Math.min(95, 30 + (int) (Math.random() * 40)));
        }
        sb.append("CPU  ").append(cpuPct >= 0 ? cpuPct + "%" : "--").append('\n');
        sb.append("RAM  ").append(ramPct).append("%\n");
        sb.append("Suhu ").append(String.format("%.1f°C", temp)).append('\n');
        sb.append("Bat  ").append(lvl).append("%\n");
        if (!sh) sb.append("MODE DEMO\n(Shizuku mati,\nangka simulasi)\n");
        else sb.append(gamePkg != null ? "Game: " + shortName(gamePkg) : "Game: -");

        final String fpsText = fps >= 0 ? "FPS " + fps + (demo ? " demo" : "") : (sh ? "FPS --" : "FPS x");
        final String info = sb.toString();
        final int fcol = fps < 0 ? Color.rgb(0, 229, 255) : fps >= 50 ? Color.rgb(0, 230, 118) : fps >= 30 ? Color.rgb(255, 214, 0) : Color.rgb(255, 82, 82);
        ui.post(new Runnable() { public void run() {
            if (tFps == null) return;
            tFps.setText(fpsText); tFps.setTextColor(fcol); tInfo.setText(info); refreshChips();
        } });
    }

    private String shortName(String p) {
        int i = p.lastIndexOf('.');
        return i >= 0 && i < p.length() - 1 ? p.substring(i + 1) : p;
    }

    private void parseCpu(String st) {
        try {
            String[] a = st.trim().split("\\s+");
            if (a.length < 8 || !a[0].equals("cpu")) return;
            long total = 0;
            for (int i = 1; i < a.length && i <= 8; i++) total += Long.parseLong(a[i]);
            long idle = Long.parseLong(a[4]) + Long.parseLong(a[5]);
            if (lastTotal >= 0 && total > lastTotal) {
                cpuPct = (int) Math.max(0, Math.min(100, 100 - (idle - lastIdle) * 100 / (total - lastTotal)));
            }
            lastTotal = total; lastIdle = idle;
        } catch (Throwable ignored) {}
    }

    private void detectForeground() {
        String out = Sh.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'");
        Matcher m = Pattern.compile("u\\d+ ([A-Za-z0-9_.]+)/").matcher(out);
        String pkg = m.find() ? m.group(1) : fgPkg;
        fgPkg = pkg;
        Set<String> games = Booster.games(this);
        String now = games.contains(pkg) ? pkg : null;
        if (now == null && pkg.equals(getPackageName())) now = gamePkg; // sedang buka overlay/app ini: biarkan
        if (now != null && !now.equals(gamePkg)) {
            gamePkg = now; layer = null;
            Booster.apply(getApplicationContext(), Booster.mode(this), now);
        } else if (now == null && gamePkg != null) {
            String old = gamePkg; gamePkg = null; layer = null;
            Booster.release(getApplicationContext(), old);
        }
    }

    private int readFps(String pkg) {
        if (!Booster.safePkg(pkg)) return -1;
        if (layer == null) {
            String l = Sh.run("dumpsys SurfaceFlinger --list | grep -F " + pkg);
            String pick = null;
            for (String s : l.split("\n")) {
                s = s.trim();
                if (s.isEmpty() || s.startsWith("Background") || s.contains("Task=") || s.contains("Dim")) continue;
                if (pick == null || (s.contains("SurfaceView") && !pick.contains("SurfaceView"))) pick = s;
            }
            if (pick == null) return -1;
            layer = pick;
        }
        String out = Sh.run("dumpsys SurfaceFlinger --latency '" + layer.replace("'", "") + "'");
        String[] lines = out.split("\n");
        long max = 0; java.util.ArrayList<Long> ts = new java.util.ArrayList<>();
        for (int i = 1; i < lines.length; i++) {
            String[] c = lines[i].trim().split("\\s+");
            if (c.length < 3) continue;
            try {
                long t = Long.parseLong(c[1]);
                if (t <= 0 || t == Long.MAX_VALUE) continue;
                ts.add(t); if (t > max) max = t;
            } catch (NumberFormatException ignored) {}
        }
        if (ts.isEmpty()) { layer = null; return -1; }
        int n = 0;
        for (long t : ts) if (t > max - 1000000000L) n++;
        return Math.min(n, 240);
    }
}

package com.gamespace.boost;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OverlayService extends Service {
    static final String ACTION_STOP = "com.gamespace.boost.STOP";
    static volatile boolean alive = false;

    private WindowManager wm;
    private WindowManager.LayoutParams hlp, plp, slp;
    private FrameLayout holder;
    private NeonPanel panel;
    private NeonHandle handle;
    private View scrim;
    private int panelW, panelH, margin;
    private boolean isOpen = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService ex;

    // state di thread latar
    private long lastTotal = -1, lastIdle = -1;
    private int tick = 0;
    private String fgPkg = "";
    private String gamePkg = null;
    private String layer = null;
    private String layerPkg = "";
    private volatile int cpuPct = -1;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (alive) return START_STICKY;
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        alive = true;
        startFg();
        buildOverlay();
        ex = Executors.newSingleThreadScheduledExecutor();
        ex.scheduleWithFixedDelay(new Runnable() { public void run() { try { loop(); } catch (Throwable ignored) {} } },
                500, 1000, TimeUnit.MILLISECONDS);
        return START_STICKY;
    }

    @Override public void onDestroy() {
        alive = false;
        if (ex != null) ex.shutdownNow();
        if (Booster.mode(this) != Booster.OFF) {
            final Context c = getApplicationContext();
            new Thread(new Runnable() { public void run() { Booster.apply(c, Booster.OFF, null); } }).start();
        }
        try { if (handle != null) wm.removeView(handle); } catch (Throwable ignored) {}
        try { if (holder != null) wm.removeView(holder); } catch (Throwable ignored) {}
        try { if (scrim != null) wm.removeView(scrim); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("gs", "Game Space", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "gs")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setContentTitle("Game Space aktif")
                .setContentText("Overlay performa berjalan")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
                .setOngoing(true).build();
        startForeground(1, n);
    }

    private void setTouchable(View v, WindowManager.LayoutParams l, boolean on) {
        if (on) l.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else l.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { wm.updateViewLayout(v, l); } catch (Throwable ignored) {}
    }

    private void buildOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        margin = dp(8);
        panelW = dp(228);
        panelH = Math.round(panelW * NeonPanel.BH / NeonPanel.BW);
        final int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        final int base = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;

        // 1) tirai transparan layar penuh: ketuk area kosong = tutup panel
        scrim = new View(this);
        scrim.setBackgroundColor(Color.argb(40, 0, 0, 0));
        scrim.setVisibility(View.INVISIBLE);
        scrim.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) closePanel();
                return true;
            }
        });
        slp = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                type, base | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        slp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(scrim, slp);

        // 2) panel neon
        panel = new NeonPanel(this);
        panel.setMode(Booster.mode(this));
        panel.setVisibility(View.INVISIBLE);
        holder = new FrameLayout(this);
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(panelW, panelH);
        fp.leftMargin = margin;
        holder.addView(panel, fp);
        plp = new WindowManager.LayoutParams(panelW + margin, panelH, type, base | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT);
        plp.gravity = Gravity.TOP | Gravity.START;
        plp.x = 0;
        plp.y = dp(32);
        final int openAt = dp(48);
        panel.setListener(new NeonPanel.Listener() {
            @Override public void onMode(int m) { pick(m); }
            @Override public void onDrag(float dx) { panel.animate().cancel(); panel.setTranslationX(Math.min(0, dx)); }
            @Override public void onRelease(float dx) { if (dx < -openAt) closePanel(); else openPanel(); }
        });
        wm.addView(holder, plp);

        // 3) garis neon di tepi kiri
        final int hw = dp(26), hh = dp(100);
        handle = new NeonHandle(this);
        hlp = new WindowManager.LayoutParams(hw, hh, type, base, PixelFormat.TRANSLUCENT);
        hlp.gravity = Gravity.TOP | Gravity.START;
        hlp.x = 0;
        hlp.y = dp(96);
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        handle.setOnTouchListener(new View.OnTouchListener() {
            float x0; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                final float off = panelW + margin;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        x0 = e.getRawX(); moved = false;
                        panel.animate().cancel();
                        panel.setTranslationX(-off);
                        panel.setVisibility(View.VISIBLE);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - x0;
                        if (Math.abs(dx) > slop) moved = true;
                        panel.setTranslationX(Math.max(-off, Math.min(0, -off + dx)));
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        float dx = e.getRawX() - x0;
                        if (dx > openAt || (!moved && e.getActionMasked() == MotionEvent.ACTION_UP)) openPanel();
                        else closePanel();
                        return true;
                    }
                }
                return false;
            }
        });
        wm.addView(handle, hlp);
        if (Build.VERSION.SDK_INT >= 29) {
            handle.post(new Runnable() { public void run() {
                try { handle.setSystemGestureExclusionRects(java.util.Collections.singletonList(new android.graphics.Rect(0, 0, hw, hh))); } catch (Throwable ignored) {}
            } });
        }
    }

    private void openPanel() {
        isOpen = true;
        panel.setVisibility(View.VISIBLE);
        scrim.setVisibility(View.VISIBLE);
        setTouchable(holder, plp, true);
        setTouchable(scrim, slp, true);
        panel.animate().cancel();
        panel.animate().translationX(0).setDuration(280).setInterpolator(new OvershootInterpolator(.9f)).start();
        handle.setVisibility(View.INVISIBLE);
    }

    private void closePanel() {
        isOpen = false;
        scrim.setVisibility(View.INVISIBLE);
        setTouchable(scrim, slp, false);
        setTouchable(holder, plp, false);
        panel.animate().cancel();
        panel.animate().translationX(-(panelW + margin)).setDuration(200).withEndAction(new Runnable() {
            public void run() { if (!isOpen) { panel.setVisibility(View.INVISIBLE); handle.setVisibility(View.VISIBLE); } }
        }).start();
    }

    private void pick(int m) {
        final int cur = Booster.mode(this);
        final int target = (m == cur) ? Booster.OFF : m;   // ketuk mode yang sedang aktif = matikan
        final String fg = fgPkg;
        final Context c = getApplicationContext();
        panel.setMode(target);
        new Thread(new Runnable() { public void run() {
            Booster.apply(c, target, fg);
            ui.post(new Runnable() { public void run() { if (panel != null) panel.setMode(Booster.mode(c)); } });
        } }).start();
    }

    // ---------- loop pemantauan (thread latar) ----------
    private void loop() {
        tick++;

        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        int ramPct = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));

        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        float temp = b != null ? b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f : 0;
        int lvl = b != null ? b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;

        float hz = 60;
        try { hz = wm.getDefaultDisplay().getRefreshRate(); } catch (Throwable ignored) {}

        boolean sh = Sh.granted();
        int fps = -1;
        if (sh) {
            parseCpu(Sh.run("head -1 /proc/stat"));
            if (tick % 3 == 1) detectForeground();
            String fp = (fgPkg.isEmpty() || fgPkg.equals(getPackageName())) ? gamePkg : fgPkg;
            if (fp != null) fps = readFps(fp);
        }

        int mhz = readFreqMhz();
        final String cpuS = cpuPct >= 0 ? cpuPct + "%" : (mhz > 0 ? String.format("%.1fG", mhz / 1000f) : "??%");
        final String ramS = ramPct + "%";
        final String tmpS = temp > 0 ? String.format("%.1f°C", temp) : "??°C";
        final String batS = lvl >= 0 ? lvl + "%" : "??%";

        final String hzS = String.format("%.0f", hz);
        final String fText, fLabel; final float frac; final int col;
        if (fps >= 0) {
            fText = String.valueOf(fps); fLabel = "FPS";
            frac = fps / Math.max(60f, hz);
            col = fps >= 50 ? 0xFF00FF9C : fps >= 30 ? 0xFFFFD000 : 0xFFFF2A4D;
        } else {
            fText = "--"; fLabel = "FPS"; frac = 0f; col = 0xFF00E5FF;
        }
        final String cap = !Booster.busy.isEmpty() ? Booster.busy : !sh ? "Shizuku mati: FPS & mode tak aktif" : (gamePkg != null ? "Game: " + shortName(gamePkg) : (fgPkg.isEmpty() ? "Menunggu aplikasi" : "App: " + shortName(fgPkg)));

        ui.post(new Runnable() { public void run() {
            if (panel == null) return;
            panel.setData(cpuS, ramS, tmpS, batS, hzS, fText, fLabel, frac, col, cap);
            if (Booster.busy.isEmpty()) panel.setMode(Booster.mode(OverlayService.this));
        } });
    }

    private int readFreqMhz() {
        long best = 0;
        for (int i = 0; i < 16; i++) {
            try {
                java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq"));
                long f = Long.parseLong(r.readLine().trim());
                r.close();
                if (f > best) best = f;
            } catch (Throwable ignored) {}
        }
        return (int) (best / 1000);
    }

    private String shortName(String p) {
        int i = p.lastIndexOf('.');
        return i >= 0 && i < p.length() - 1 ? p.substring(i + 1) : p;
    }

    private void parseCpu(String st) {
        try {
            String[] a = st.trim().split("\\s+");
            if (a.length < 8 || !a[0].equals("cpu")) return;
            long total = 0;
            for (int i = 1; i < a.length && i <= 8; i++) total += Long.parseLong(a[i]);
            long idle = Long.parseLong(a[4]) + Long.parseLong(a[5]);
            if (lastTotal >= 0 && total > lastTotal) {
                cpuPct = (int) Math.max(0, Math.min(100, 100 - (idle - lastIdle) * 100 / (total - lastTotal)));
            }
            lastTotal = total; lastIdle = idle;
        } catch (Throwable ignored) {}
    }

    private void detectForeground() {
        String out = Sh.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'");
        Matcher m = Pattern.compile("u\\d+ ([A-Za-z0-9_.]+)/").matcher(out);
        String pkg = m.find() ? m.group(1) : fgPkg;
        fgPkg = pkg;
        Set<String> games = Booster.games(this);
        String now = games.contains(pkg) ? pkg : null;
        if (now == null && pkg.equals(getPackageName())) now = gamePkg; // sedang buka overlay/app ini: biarkan
        gamePkg = now;
    }

    private int readFps(String pkg) {
        if (!Booster.safePkg(pkg)) return -1;

        // SurfaceFlinger can expose several layers for one app. The first matching
        // layer is often a container/overlay that does not receive frame timestamps.
        // Try the cached layer first, then inspect all candidate layers and keep the
        // one with the most recent valid frame data.
        if (!pkg.equals(layerPkg)) {
            layer = null;
            layerPkg = pkg;
        }

        if (layer != null) {
            int cached = readLayerFps(layer);
            if (cached >= 0) return cached;
            layer = null;
        }

        String list = Sh.run("dumpsys SurfaceFlinger --list");
        if (list.startsWith("ERR ") || list.contains("Permission Denial") || list.trim().isEmpty()) return -1;

        java.util.ArrayList<String> candidates = new java.util.ArrayList<>();
        for (String raw : list.split("\\n")) {
            String candidate = raw.trim();
            if (candidate.isEmpty() || !candidate.contains(pkg)) continue;
            if (candidate.startsWith("Background") || candidate.contains("Task=") || candidate.contains("Dim")) continue;
            // Prefer actual app content layers over generic container layers.
            if (candidate.contains("SurfaceView") || candidate.contains("BLAST")) candidates.add(0, candidate);
            else candidates.add(candidate);
        }

        int bestFps = -1;
        String bestLayer = null;
        for (String candidate : candidates) {
            int value = readLayerFps(candidate);
            if (value > bestFps) {
                bestFps = value;
                bestLayer = candidate;
            }
            if (bestFps >= 0 && bestFps >= 120) break;
        }
        if (bestFps >= 0) layer = bestLayer;
        return bestFps;
    }

    /** Returns a recent frame-rate estimate for one SurfaceFlinger layer, or -1 if unavailable. */
    private int readLayerFps(String layerName) {
        if (layerName == null || layerName.isEmpty()) return -1;
        String safeLayer = layerName.replace("'", "");
        String out = Sh.run("dumpsys SurfaceFlinger --latency '" + safeLayer + "'");
        if (out.startsWith("ERR ") || out.contains("Permission Denial") || out.contains("not found")) return -1;

        String[] lines = out.split("\\n");
        long maxTimestamp = 0L;
        java.util.ArrayList<Long> timestamps = new java.util.ArrayList<>();
        // Line 1 is the refresh period. Subsequent lines are desired-present,
        // actual-present, and frame-ready timestamps in nanoseconds.
        for (int i = 1; i < lines.length; i++) {
            String[] cols = lines[i].trim().split("\\s+");
            if (cols.length < 3) continue;
            try {
                long actualPresent = Long.parseLong(cols[1]);
                if (actualPresent <= 0 || actualPresent == Long.MAX_VALUE) continue;
                timestamps.add(actualPresent);
                if (actualPresent > maxTimestamp) maxTimestamp = actualPresent;
            } catch (NumberFormatException ignored) {}
        }
        if (timestamps.size() < 2 || maxTimestamp <= 0) return -1;

        // SurfaceFlinger keeps a rolling timestamp buffer (often only ~128 frames).
        // Count unique actual-present timestamps in the latest second. Do not treat
        // an empty/stale buffer as a valid 0 FPS reading.
        java.util.HashSet<Long> recent = new java.util.HashSet<>();
        long cutoff = maxTimestamp - 1_000_000_000L;
        for (Long timestamp : timestamps) {
            if (timestamp > cutoff && timestamp <= maxTimestamp) recent.add(timestamp);
        }
        if (recent.size() < 2) return -1;
        return Math.min(recent.size(), 240);
    }
}

# Game Space (Shizuku)

Aplikasi booster game: overlay performa yang bisa digeser (kiri atas), mode Balance / Agresif, akses lewat Shizuku.

Cara pakai:
1. Pasang & jalankan Shizuku (Wireless debugging atau root).
2. Buka Game Space → Beri izin Shizuku → Beri izin overlay.
3. Centang game, tekan MULAI GAME SPACE.
4. Buka game: overlay menampilkan FPS, CPU, RAM, suhu, baterai. Ketuk overlay untuk lipat/buka, seret untuk pindah.

## Mode (semua sementara, bisa dipulihkan)
- Balance: animasi 0,5x, adaptive battery aktif, game mode Standard, bersihkan proses cache.
- Agresif: batasi proses latar belakang aplikasi pihak ketiga (RUN_ANY_IN_BACKGROUND), notifikasi dibisukan (Jangan Ganggu), Data Saver, animasi mati, performa tetap, game mode Performance.
- Matikan: pengaturan asli (di-snapshot sebelum mode dinyalakan) dikembalikan. Menghentikan Game Space juga memulihkan otomatis.

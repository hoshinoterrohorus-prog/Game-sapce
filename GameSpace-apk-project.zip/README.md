# Game Space (Shizuku)

Aplikasi booster game: overlay performa yang bisa digeser (kiri atas), mode Balance / Agresif, akses lewat Shizuku.

Cara pakai:
1. Pasang & jalankan Shizuku (Wireless debugging atau root).
2. Buka Game Space → Beri izin Shizuku → Beri izin overlay.
3. Centang game, tekan MULAI GAME SPACE.
4. Buka game: overlay menampilkan FPS, CPU, RAM, suhu, baterai. Ketuk overlay untuk lipat/buka, seret untuk pindah.

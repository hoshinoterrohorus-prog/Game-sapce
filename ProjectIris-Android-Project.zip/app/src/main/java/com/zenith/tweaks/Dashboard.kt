package com.zenith.tweaks

import android.content.Context
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

interface Page { val root: android.view.View; fun onShow(); fun onHide(); fun intro() {} }

class Dashboard(val ctx: Context, val caps: () -> Caps.Info?, val onMenu: () -> Unit) : Page {
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    override val root get() = scroll

    private val rCpu = Ring(ctx); private val rRam = Ring(ctx); private val rBat = Ring(ctx)
    private val sCpu = Spark(ctx); private val sGpu = Spark(ctx)
    private val tCpuInfo = ctx.text("", 12f, C.SUB); private val tGpuInfo = ctx.text("", 12f, C.SUB)
    private val coresBox = LinearLayout(ctx)
    private val tFg = ctx.text("—", 15f, C.TEXT, true)
    private val tFps = ctx.text("— FPS", 28f, C.CYAN, true)
    private val sFps = Spark(ctx)
    private val tTemp = ctx.text("", 13f, C.TEXT)
    private val tDev = ctx.text("", 12f, C.SUB)
    private val errCard = ctx.card(); private val tErr = ctx.text("", 11f, C.TEXT)
    private var running = false
    private var tick = 0
    private val bars = ArrayList<Pair<Bar, TextView>>()

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(8), ctx.dpi(16), ctx.dpi(24))
        scroll.addView(col, fl(-1, -2))
        scroll.isVerticalScrollBarEnabled = false

        val head = LinearLayout(ctx); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER_VERTICAL
        val mb = MenuIcon(ctx); mb.background = rr(C.CARD, ctx.dp(14f), C.STROKE); mb.press(0.9f); mb.setOnClickListener { onMenu() }
        head.addView(mb, lp(ctx.dpi(44), ctx.dpi(44)))
        head.addView(ctx.title("Dashboard"), lp().also { it.leftMargin = ctx.dpi(14) })
        col.addView(head, lp(bottom = ctx.dpi(4)))
        col.addView(ctx.text("Data langsung dari sistem lewat Shizuku", 13f, C.SUB), lp(bottom = ctx.dpi(12)))

        // Slot maskot: taruh gambar bernama mascot.png di app/src/main/res/drawable-nodpi/ lalu build ulang
        val mid = ctx.resources.getIdentifier("mascot", "drawable", ctx.packageName)
        if (mid != 0) {
            val iv = android.widget.ImageView(ctx); iv.setImageResource(mid); iv.adjustViewBounds = true
            iv.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP; iv.maxHeight = ctx.dpi(190)
            iv.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: android.view.View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, ctx.dp(16f)) }
            }
            iv.clipToOutline = true
            col.addView(iv, lp(-1, -2, bottom = ctx.dpi(12)))
        }
        errCard.addView(ctx.label("Masalah membaca sistem", C.AMBER)); errCard.addView(tErr, lp(top = ctx.dpi(4)))
        errCard.visibility = android.view.View.GONE
        col.addView(errCard, lp(bottom = ctx.dpi(12)))

        val rings = LinearLayout(ctx); rings.orientation = LinearLayout.HORIZONTAL
        for (r in listOf(rCpu, rRam, rBat)) rings.addView(r, lp(0, -2, weight = 1f))
        val c1 = ctx.card(); c1.addView(rings)
        col.addView(c1, lp(bottom = ctx.dpi(12)))

        val c2 = ctx.card()
        c2.addView(ctx.label("CPU")); c2.addView(sCpu, lp(-1, ctx.dpi(70), top = ctx.dpi(6)))
        c2.addView(tCpuInfo, lp(top = ctx.dpi(6)))
        coresBox.orientation = LinearLayout.VERTICAL
        c2.addView(coresBox, lp(top = ctx.dpi(8)))
        col.addView(c2, lp(bottom = ctx.dpi(12)))

        val c3 = ctx.card()
        c3.addView(ctx.label("GPU")); sGpu.color = C.VIOLET
        c3.addView(sGpu, lp(-1, ctx.dpi(70), top = ctx.dpi(6)))
        c3.addView(tGpuInfo, lp(top = ctx.dpi(6)))
        col.addView(c3, lp(bottom = ctx.dpi(12)))

        val c4 = ctx.card()
        c4.addView(ctx.label("Aplikasi di layar"))
        c4.addView(tFg, lp(top = ctx.dpi(4)))
        c4.addView(tFps, lp(top = ctx.dpi(4)))
        sFps.color = C.GREEN; sFps.max = 60f
        c4.addView(sFps, lp(-1, ctx.dpi(56), top = ctx.dpi(4)))
        c4.addView(ctx.text("FPS dibaca dari SurfaceFlinger. Tidak semua game bisa terbaca.", 11f, C.SUB), lp(top = ctx.dpi(4)))
        col.addView(c4, lp(bottom = ctx.dpi(12)))

        val c5 = ctx.card()
        c5.addView(ctx.label("Suhu & baterai")); c5.addView(tTemp, lp(top = ctx.dpi(6)))
        col.addView(c5, lp(bottom = ctx.dpi(12)))

        val c6 = ctx.card()
        c6.addView(ctx.label("Perangkat")); c6.addView(tDev, lp(top = ctx.dpi(6)))
        col.addView(c6)
    }

    override fun onShow() {
        if (running) return
        running = true; tick = 0; loop()
        val c = caps()
        if (c != null) bindCaps(c)
    }
    override fun onHide() { running = false }
    override fun intro() { col.stagger() }

    fun bindCaps(c: Caps.Info) {
        tDev.text = "${c.model} • Android ${c.android} (SDK ${c.sdk})\nSoC/platform: ${c.soc} • hw: ${c.hw}\nVulkan: ${c.vulkan.ifEmpty { "-" }} • EGL: ${c.egl.ifEmpty { "-" }}\nLayar: ${c.size.removePrefix("Physical size: ")} • ${c.density.removePrefix("Physical density: ")} dpi\nGame Mode: ${if (c.gameCmd) "didukung" else "tidak terdeteksi"} • ANGLE: ${if (c.angle) "ada" else "tidak ada"}"
    }

    private fun loop() {
        if (!running) return
        Sh.async(Sys.SCRIPT, 8) { r ->
            if (running) {
                val snap = Sys.parse(r.out)
                if (snap != null) { errCard.visibility = android.view.View.GONE; render(snap) }
                else { errCard.visibility = android.view.View.VISIBLE; tErr.text = "kode=${r.code}\n" + (r.err.ifBlank { r.out.take(200).ifBlank { "keluaran kosong" } }) }
                mainHandler.postDelayed({ loop() }, 1200)
            }
        }
        if (tick % 2 == 0) {
            Sh.bg {
                val pkg = Fps.foreground()
                val f = if (pkg.isNotEmpty() && pkg != ctx.packageName) Fps.measure(pkg) else -1f
                mainHandler.post {
                    if (!running) return@post
                    tFg.text = if (pkg.isEmpty()) "—" else (try { ctx.packageManager.getApplicationInfo(pkg, 0).loadLabel(ctx.packageManager).toString() } catch (e: Exception) { pkg })
                    if (f > 0) { tFps.text = String.format(Locale.US, "%.0f FPS", f); sFps.push(f, 40) }
                    else tFps.text = if (pkg == ctx.packageName) "(ini aplikasi Iris)" else "FPS tidak terbaca"
                    tFps.setTextColor(if (f >= 50) C.GREEN else if (f >= 30) C.AMBER else if (f > 0) C.RED else C.SUB)
                }
            }
        }
        tick++
    }

    private fun render(s: Sys.Snap) {
        val cpu = Sys.cpuPct(s)
        rCpu.set(cpu / 100f, "${cpu.toInt()}%", "CPU", if (cpu > 85) C.RED else if (cpu > 60) C.AMBER else C.CYAN)
        val used = (s.memTotalKb - s.memAvailKb).coerceAtLeast(0)
        val rp = if (s.memTotalKb > 0) used.toFloat() / s.memTotalKb else 0f
        rRam.set(rp, "${(rp * 100).toInt()}%", "RAM", if (rp > 0.9f) C.RED else if (rp > 0.75f) C.AMBER else C.VIOLET)
        rBat.set(s.battPct / 100f, "${s.battPct}%", if (s.charging) "Mengisi" else "Baterai", if (s.battPct < 20 && !s.charging) C.RED else C.GREEN)
        sCpu.push(cpu)
        val avg = if (s.freqKhz.isNotEmpty()) s.freqKhz.average() / 1000 else 0.0
        tCpuInfo.text = String.format(Locale.US, "Rata-rata %.0f MHz • %d core", avg, s.freqKhz.size)
        if (bars.size != s.freqKhz.size) {
            coresBox.removeAllViews(); bars.clear()
            for (i in s.freqKhz.indices) {
                val row = LinearLayout(ctx); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                val n = ctx.text("C$i", 11f, C.SUB); val b = Bar(ctx); val f = ctx.text("", 11f, C.TEXT); f.gravity = Gravity.END
                row.addView(n, lp(ctx.dpi(26), -2)); row.addView(b, lp(0, ctx.dpi(6), weight = 1f)); row.addView(f, lp(ctx.dpi(64), -2))
                coresBox.addView(row, lp(top = ctx.dpi(4)))
                bars.add(b to f)
            }
        }
        for (i in s.freqKhz.indices) {
            val mx = s.maxKhz.getOrElse(i) { 0L }.coerceAtLeast(1L)
            bars[i].first.setFrac(s.freqKhz[i].toFloat() / mx)
            bars[i].second.text = if (s.freqKhz[i] > 0) "${s.freqKhz[i] / 1000} MHz" else "off"
        }
        if (s.gpuHz > 0) {
            val mhz = s.gpuHz / 1_000_000f
            sGpu.max = maxOf(sGpu.max, mhz); sGpu.push(mhz)
            tGpuInfo.text = String.format(Locale.US, "%.0f MHz  (%s)", mhz, s.gpuName)
        } else if (s.gpuTempC > 0f) {
            sGpu.max = 100f; sGpu.push(s.gpuTempC)
            tGpuInfo.text = String.format(Locale.US, "Suhu GPU %.1f°C  (frekuensi GPU diblokir sistem di HP ini)", s.gpuTempC)
        } else tGpuInfo.text = "Frekuensi & suhu GPU tidak bisa dibaca di HP ini"
        tTemp.text = buildString {
            append(if (s.cpuTempC > 0) String.format(Locale.US, "CPU/SoC  %.1f°C\n", s.cpuTempC) else "CPU/SoC  tidak terbaca\n")
            if (s.gpuTempC > 0) append(String.format(Locale.US, "GPU  %.1f°C\n", s.gpuTempC))
            append(String.format(Locale.US, "Baterai  %.1f°C • %d mV", s.battTempC, s.battMv))
            if (s.battMa != 0) append(" • ${s.battMa} mA")
            append("\nSwap  ${(s.swapTotalKb - s.swapFreeKb) / 1024} / ${s.swapTotalKb / 1024} MB")
            append("\nRAM  ${used / 1024} / ${s.memTotalKb / 1024} MB")
        }
    }
}

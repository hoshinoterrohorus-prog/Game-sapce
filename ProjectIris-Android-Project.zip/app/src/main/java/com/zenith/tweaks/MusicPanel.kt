package com.zenith.tweaks

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Ikon kontrol pemutar yang digambar sendiri. kind: 0 prev, 1 next, 2 play, 3 pause, 4 acak, 5 ulang, 6 ulang satu. */
class MIcon(ctx: android.content.Context, val kind: Int) : View(ctx) {
    var on = false; set(v) { field = v; invalidate() }
    var big = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat(); val ox = (width - s) / 2f; val oy = (height - s) / 2f
        c.save(); c.translate(ox, oy)
        val col = if (big) C.ON else if (on) C.CYAN else C.TEXT
        p.color = col; p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        fun tri(x1: Float, x2: Float) { val t = Path(); t.moveTo(x1 * s, 0.25f * s); t.lineTo(x2 * s, 0.5f * s); t.lineTo(x1 * s, 0.75f * s); t.close(); c.drawPath(t, p) }
        when (kind) {
            0 -> { c.drawRect(0.22f * s, 0.25f * s, 0.3f * s, 0.75f * s, p); val t = Path(); t.moveTo(0.78f * s, 0.25f * s); t.lineTo(0.36f * s, 0.5f * s); t.lineTo(0.78f * s, 0.75f * s); t.close(); c.drawPath(t, p) }
            1 -> { c.drawRect(0.7f * s, 0.25f * s, 0.78f * s, 0.75f * s, p); val t = Path(); t.moveTo(0.22f * s, 0.25f * s); t.lineTo(0.64f * s, 0.5f * s); t.lineTo(0.22f * s, 0.75f * s); t.close(); c.drawPath(t, p) }
            2 -> tri(0.3f, 0.78f)
            3 -> { c.drawRoundRect(RectF(0.28f * s, 0.22f * s, 0.43f * s, 0.78f * s), s * 0.04f, s * 0.04f, p); c.drawRoundRect(RectF(0.57f * s, 0.22f * s, 0.72f * s, 0.78f * s), s * 0.04f, s * 0.04f, p) }
            4 -> { p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                c.drawLine(0.18f * s, 0.7f * s, 0.8f * s, 0.3f * s, p); c.drawLine(0.18f * s, 0.3f * s, 0.8f * s, 0.7f * s, p)
                p.style = Paint.Style.FILL; val a = Path(); a.moveTo(0.86f * s, 0.3f * s); a.lineTo(0.72f * s, 0.22f * s); a.lineTo(0.72f * s, 0.38f * s); a.close(); c.drawPath(a, p)
                val b = Path(); b.moveTo(0.86f * s, 0.7f * s); b.lineTo(0.72f * s, 0.62f * s); b.lineTo(0.72f * s, 0.78f * s); b.close(); c.drawPath(b, p) }
            else -> { p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                c.drawRoundRect(RectF(0.16f * s, 0.28f * s, 0.84f * s, 0.72f * s), s * 0.16f, s * 0.16f, p)
                p.style = Paint.Style.FILL; val a = Path(); a.moveTo(0.62f * s, 0.14f * s); a.lineTo(0.78f * s, 0.28f * s); a.lineTo(0.62f * s, 0.42f * s); a.close(); c.drawPath(a, p)
                if (kind == 6) { p.textAlign = Paint.Align.CENTER; p.textSize = s * 0.3f; c.drawText("1", 0.5f * s, 0.6f * s, p) } }
        }
        c.restore()
    }
}

/** Panel musik: muncul dari tombol ♪ di banner Menu. */
class MusicPanel(val act: Activity, val host: FrameLayout) {
    private val ctx: android.content.Context = act
    private var panel: View? = null
    private lateinit var tTitle: TextView
    private lateinit var tArtist: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private lateinit var playIc: MIcon
    private lateinit var shuf: MIcon
    private lateinit var rep: MIcon
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private var dragging = false

    val isOpen get() = panel != null

    private fun fmt(ms: Int): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

    fun show() {
        if (panel != null) return
        Music.init(ctx)
        val over = FrameLayout(ctx)
        val scrim = View(ctx); scrim.setBackgroundColor(0x99000000.toInt()); scrim.setOnClickListener { close() }
        over.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        val sheetH = (ctx.resources.displayMetrics.heightPixels * 0.80f).toInt()
        val sheet = LinearLayout(ctx); sheet.orientation = LinearLayout.VERTICAL
        sheet.background = rr(C.BG2, ctx.dp(24f), C.STROKE); sheet.isClickable = true
        val lpS = FrameLayout.LayoutParams(-1, sheetH); lpS.gravity = Gravity.BOTTOM; lpS.setMargins(ctx.dpi(8), 0, ctx.dpi(8), ctx.dpi(8))
        over.addView(sheet, lpS)

        // header
        val head = LinearLayout(ctx); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(ctx.dpi(20), ctx.dpi(16), ctx.dpi(12), ctx.dpi(4))
        head.addView(ctx.text("Musik", 20f, C.TEXT, true), lp(0, -2, weight = 1f))
        val x = ctx.text("✕", 18f, C.SUB, true); x.setPadding(ctx.dpi(12), ctx.dpi(8), ctx.dpi(12), ctx.dpi(8)); x.press(0.85f); x.setOnClickListener { close() }
        head.addView(x)
        sheet.addView(head)

        val sv = ScrollView(ctx); sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(ctx); col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(4), ctx.dpi(16), ctx.dpi(20))
        sv.addView(col, FrameLayout.LayoutParams(-1, -2))
        sheet.addView(sv, lp(-1, 0, weight = 1f))

        // sedang diputar
        val now = ctx.card()
        tTitle = ctx.text("", 17f, C.TEXT, true); tTitle.maxLines = 1; tTitle.ellipsize = TextUtils.TruncateAt.END
        tArtist = ctx.text("", 12f, C.SUB); tArtist.maxLines = 1; tArtist.ellipsize = TextUtils.TruncateAt.END
        now.addView(tTitle); now.addView(tArtist, lp(top = ctx.dpi(2)))
        seek = SeekBar(ctx)
        seek.progressTintList = ColorStateList.valueOf(C.CYAN); seek.thumbTintList = ColorStateList.valueOf(C.CYAN)
        seek.progressBackgroundTintList = ColorStateList.valueOf(C.FILL)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) tCur.text = fmt(p) }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) { dragging = false; Music.seek(seek.progress) }
        })
        now.addView(seek, lp(top = ctx.dpi(10)))
        val times = LinearLayout(ctx); times.orientation = LinearLayout.HORIZONTAL
        tCur = ctx.text("0:00", 11f, C.SUB); tTot = ctx.text("0:00", 11f, C.SUB)
        times.addView(tCur, lp(0, -2, weight = 1f)); times.addView(tTot)
        now.addView(times)

        val ctl = LinearLayout(ctx); ctl.orientation = LinearLayout.HORIZONTAL; ctl.gravity = Gravity.CENTER
        fun ic(kind: Int, size: Int, click: () -> Unit): MIcon {
            val v = MIcon(ctx, kind); v.press(0.85f); v.setOnClickListener { click() }
            ctl.addView(v, lp(ctx.dpi(size), ctx.dpi(size)).also { it.leftMargin = ctx.dpi(6); it.rightMargin = ctx.dpi(6) }); return v
        }
        shuf = ic(4, 40) { Music.shuffle = !Music.shuffle; refresh() }
        ic(0, 44) { Music.prev() }
        playIc = MIcon(ctx, 2); playIc.big = true
        val playWrap = FrameLayout(ctx); playWrap.background = rr(C.CYAN, ctx.dp(30f)); playWrap.press(0.92f)
        playWrap.addView(playIc, FrameLayout.LayoutParams(ctx.dpi(60), ctx.dpi(60)))
        playWrap.setOnClickListener { askNotif(); Music.toggle() }
        ctl.addView(playWrap, lp(ctx.dpi(60), ctx.dpi(60)).also { it.leftMargin = ctx.dpi(6); it.rightMargin = ctx.dpi(6) })
        ic(1, 44) { Music.next() }
        rep = ic(5, 40) { Music.repeat = (Music.repeat + 1) % 3; refresh() }
        now.addView(ctl, lp(top = ctx.dpi(8)))
        col.addView(now, lp(bottom = ctx.dpi(12)))

        // tambah lagu
        val acts = LinearLayout(ctx); acts.orientation = LinearLayout.HORIZONTAL
        acts.addView(ctx.button("Tambah lagu", false) { pickFiles() }, lp(0, -2, weight = 1f).also { it.rightMargin = ctx.dpi(8) })
        acts.addView(ctx.button("Pindai HP", false) { scanDevice() }, lp(0, -2, weight = 1f))
        col.addView(acts, lp(bottom = ctx.dpi(6)))
        status = ctx.text("", 11f, C.SUB)
        col.addView(status, lp(bottom = ctx.dpi(8)))

        // daftar putar
        col.addView(ctx.label("Daftar putar"), lp(bottom = ctx.dpi(8)))
        listBox = LinearLayout(ctx); listBox.orientation = LinearLayout.VERTICAL
        col.addView(listBox, lp(bottom = ctx.dpi(12)))

        // tren
        val tren = ctx.card()
        tren.addView(ctx.label("Sedang tren"))
        tren.addView(ctx.text("Pintasan ke tangga lagu dan playlist populer. Dibuka di aplikasi lain (YouTube / Spotify); lagunya tidak diunduh ke sini.", 11f, C.SUB), lp(top = ctx.dpi(4), bottom = ctx.dpi(6)))
        fun link(label: String, url: String) {
            val r = ctx.text("↗  $label", 13f, C.TEXT, true)
            r.setPadding(0, ctx.dpi(10), 0, ctx.dpi(10)); r.press(0.97f)
            r.setOnClickListener { try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Throwable) { Toast.makeText(ctx, "Tidak ada aplikasi untuk membuka link", Toast.LENGTH_SHORT).show() } }
            tren.addView(r)
        }
        link("Top 50 Spotify Indonesia (YouTube)", "https://www.youtube.com/playlist?list=PL4JC1ykIbR3L-oRBPWvptV_al5kQ5dqUM")
        link("Lagu viral TikTok 2026 (Spotify)", "https://open.spotify.com/playlist/45BDSBdlYIoAseCVTneJl0")
        link("Top Hits Indonesia 2026 (Spotify)", "https://open.spotify.com/playlist/3ETAG6xpLdpG1AoWVqNNUS")
        col.addView(tren)

        panel = over
        host.addView(over, FrameLayout.LayoutParams(-1, -1))
        over.alpha = 0f
        over.post {
            sheet.translationY = sheetH * 0.4f
            over.animate().alpha(1f).setDuration(200).start()
            sheet.animate().translationY(0f).setDuration(320).setInterpolator(DecelerateInterpolator(2f)).start()
        }
        Music.onChange = { refresh() }
        refresh(); tick()
    }

    fun close() {
        val p = panel ?: return
        panel = null; Music.onChange = null
        p.animate().alpha(0f).setDuration(180).withEndAction { host.removeView(p) }.start()
    }

    private fun tick() {
        if (panel == null) return
        if (!dragging) { seek.max = maxOf(Music.duration(), 1); seek.progress = Music.position(); tCur.text = fmt(Music.position()); tTot.text = fmt(Music.duration()) }
        mainHandler.postDelayed({ tick() }, 500)
    }

    private fun refresh() {
        if (panel == null) return
        val t = Music.current()
        tTitle.text = t?.title ?: "Belum ada lagu"
        tArtist.text = t?.artist?.ifBlank { "Artis tidak diketahui" } ?: "Tambah lagu dari file atau pindai HP"
        playIc.let { /* ikon diganti dengan view baru agar jenisnya berubah */ }
        (playIc.parent as? FrameLayout)?.let { w ->
            w.removeAllViews(); playIc = MIcon(ctx, if (Music.playing) 3 else 2); playIc.big = true
            w.addView(playIc, FrameLayout.LayoutParams(ctx.dpi(60), ctx.dpi(60)))
        }
        shuf.on = Music.shuffle
        rep.on = Music.repeat != 0
        listBox.removeAllViews()
        if (Music.list.isEmpty()) {
            listBox.addView(ctx.text("Belum ada lagu. Ketuk “Tambah lagu” untuk memilih file musik, atau “Pindai HP”.", 12f, C.SUB))
        } else for (i in Music.list.indices) {
            val tr = Music.list[i]
            val row = LinearLayout(ctx); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
            row.background = rr(if (i == Music.index) C.FILL else cardFill(), ctx.dp(14f), C.STROKE)
            row.setPadding(ctx.dpi(14), ctx.dpi(10), ctx.dpi(6), ctx.dpi(10))
            val mid = LinearLayout(ctx); mid.orientation = LinearLayout.VERTICAL
            mid.addView(ctx.text(tr.title, 14f, if (i == Music.index) C.CYAN else C.TEXT, true).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END })
            mid.addView(ctx.text((tr.artist.ifBlank { "—" }) + (if (tr.dur > 0) "  •  " + fmt(tr.dur.toInt()) else ""), 11f, C.SUB).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END })
            row.addView(mid, lp(0, -2, weight = 1f))
            val rm = ctx.text("✕", 14f, C.SUB, true); rm.setPadding(ctx.dpi(12), ctx.dpi(6), ctx.dpi(10), ctx.dpi(6))
            rm.setOnClickListener { Music.remove(i) }
            row.addView(rm)
            row.press(0.98f); row.setOnClickListener { askNotif(); Music.play(i) }
            listBox.addView(row, lp(bottom = ctx.dpi(6)))
        }
        if (Music.list.isNotEmpty()) {
            val clr = ctx.chip("Kosongkan daftar", false) { Music.clear() }
            listBox.addView(clr, lp(-2, -2, top = ctx.dpi(4)))
        }
    }

    // ---------- izin & pemilih ----------
    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && act.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            val sp = act.getSharedPreferences("zt", android.content.Context.MODE_PRIVATE)
            if (!sp.getBoolean("asked_notif", false)) { sp.edit().putBoolean("asked_notif", true).apply(); act.requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 82) }
        }
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE); i.type = "audio/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try { act.startActivityForResult(i, 80) } catch (e: Throwable) { status.text = "Tidak bisa membuka pemilih file" }
    }

    fun onPicked(data: Intent) {
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        for (u in uris) try { act.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Throwable) {}
        status.text = "Menambahkan…"
        Music.addUris(uris) { n -> if (panel != null) status.text = if (n > 0) "$n lagu ditambahkan." else "Tidak ada lagu baru (mungkin sudah ada)." }
    }

    private fun scanDevice() {
        val perm = if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_AUDIO else android.Manifest.permission.READ_EXTERNAL_STORAGE
        if (act.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) doScan()
        else act.requestPermissions(arrayOf(perm), 81)
    }

    fun onPermission(granted: Boolean) {
        if (panel == null) return
        if (granted) doScan() else status.text = "Izin akses musik ditolak. Pakai “Tambah lagu” untuk memilih file satu per satu."
    }

    private fun doScan() {
        status.text = "Memindai musik di HP…"
        Music.scan { n -> if (panel != null) status.text = if (n > 0) "$n lagu ditemukan." else "Tidak ada lagu baru ditemukan." }
    }
}

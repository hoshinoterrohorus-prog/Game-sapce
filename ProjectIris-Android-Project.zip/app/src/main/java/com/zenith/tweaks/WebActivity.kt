package com.zenith.tweaks

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Peramban mini untuk "Tools": membuka situs dengan tampilan desktop atau mobile. */
class WebActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var bar: LinearLayout
    private lateinit var tMode: TextView
    private lateinit var progress: View
    private lateinit var root: FrameLayout
    private var desktop = true
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var landscape = false

    private val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.load(this)
        window.statusBarColor = C.BG; window.navigationBarColor = C.BG
        desktop = intent.getBooleanExtra("desktop", true)
        val url = intent.getStringExtra("url") ?: "https://www.tiktok.com/"

        root = FrameLayout(this); root.setBackgroundColor(C.BG)
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        // ----- bilah atas -----
        bar = LinearLayout(this); bar.orientation = LinearLayout.HORIZONTAL; bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(C.BG2); bar.setPadding(dpi(6), 0, dpi(6), 0)
        fun btn(label: String, click: () -> Unit): TextView {
            val t = text(label, 16f, C.TEXT, true); t.gravity = Gravity.CENTER
            t.setPadding(dpi(12), dpi(10), dpi(12), dpi(10)); t.press(0.9f); t.setOnClickListener { click() }
            bar.addView(t); return t
        }
        btn("‹") { if (web.canGoBack()) web.goBack() else finish() }
        btn("⟳") { web.reload() }
        tMode = btn("") { setDesktop(!desktop) }
        btn("⟲") { rotate() }
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        btn("✕") { finish() }
        col.addView(bar, LinearLayout.LayoutParams(-1, dpi(46)))

        progress = View(this); progress.setBackgroundColor(C.CYAN); progress.scaleX = 0f; progress.pivotX = 0f
        col.addView(progress, LinearLayout.LayoutParams(-1, dpi(2)))

        web = WebView(this)
        web.setBackgroundColor(C.BG)
        col.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val s = web.settings
        s.javaScriptEnabled = true; s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.setSupportZoom(true); s.builtInZoomControls = true; s.displayZoomControls = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "http" || u.scheme == "https") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Throwable) {}
                return true
            }
            override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) { forceViewport() }
            override fun onPageFinished(v: WebView, u: String?) { forceViewport() }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                forceViewport()
                progress.animate().scaleX(p / 100f).setDuration(120).start()
                progress.visibility = if (p >= 100) View.INVISIBLE else View.VISIBLE
            }
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = v; customCb = cb
                bar.visibility = View.GONE
                root.addView(v, FrameLayout.LayoutParams(-1, -1))
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            }
            override fun onHideCustomView() { leaveFullscreen() }
        }

        applyMode()
        web.loadUrl(url)
    }

    private fun leaveFullscreen() {
        customView?.let { root.removeView(it) }; customView = null
        customCb?.onCustomViewHidden(); customCb = null
        bar.visibility = View.VISIBLE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    /** Pada mode desktop, paksa lebar viewport 1280 supaya situs memakai tata letak desktop. */
    private fun forceViewport() {
        if (!desktop) return
        web.evaluateJavascript("(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';(document.head||document.documentElement).appendChild(m)}m.content='width=1280';})()", null)
    }

    private fun applyMode() {
        val s = web.settings
        if (desktop) {
            s.userAgentString = DESKTOP_UA
            s.useWideViewPort = true; s.loadWithOverviewMode = true
            web.setInitialScale(0)
        } else {
            s.userAgentString = null
            s.useWideViewPort = true; s.loadWithOverviewMode = false
        }
        tMode.text = if (desktop) "🖥 Desktop" else "📱 Mobile"
        tMode.textSize = 13f
    }

    private fun setDesktop(d: Boolean) {
        desktop = d; applyMode()
        Toast.makeText(this, if (d) "Mode desktop" else "Mode mobile", Toast.LENGTH_SHORT).show()
        web.reload()
    }

    private fun rotate() {
        landscape = !landscape
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> leaveFullscreen()
            web.canGoBack() -> web.goBack()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private fun dpi(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun text(s: String, size: Float, color: Int, bold: Boolean) = (this as android.content.Context).text(s, size, color, bold)
}

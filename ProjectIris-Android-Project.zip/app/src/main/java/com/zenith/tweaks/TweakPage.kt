package com.zenith.tweaks

import android.content.Context
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class TweakPage(val ctx: Context, val caps: () -> Caps.Info?) : Page {
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    override val root get() = scroll
    private val tOut = ctx.text("", 11f, C.SUB)
    private val tRevert = ctx.text("", 12f, C.AMBER)
    private var revertRunnable: Runnable? = null

    override fun onShow() {}
    override fun onHide() {}
    override fun intro() { col.stagger(50, 9) }

    private fun say(s: String) { tOut.text = s }
    private fun run(cmd: String, after: String = "") {
        if (!Sh.granted()) { say("Shizuku belum aktif / belum diberi izin."); return }
        say("› $cmd")
        Sh.async(cmd, 15) { r -> say("› $cmd\n" + (r.text.ifEmpty { if (r.ok) "OK" else "gagal (kode ${r.code})" }) + after) }
    }

    private fun chipsRow(c: LinearLayout, items: List<Pair<String, () -> Unit>>) {
        val r = LinearLayout(ctx); r.orientation = LinearLayout.HORIZONTAL
        for ((l, f) in items) r.addView(ctx.chip(l, false) { f() }, lp(-2, -2).also { it.rightMargin = ctx.dpi(6) })
        c.addView(r, lp(top = ctx.dpi(8)))
    }

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(8), ctx.dpi(16), ctx.dpi(28))
        scroll.addView(col, fl(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        col.addView(ctx.title("Tweak"))
        col.addView(ctx.text("Pengaturan di bawah ini berlaku untuk SELURUH HP. Untuk per-game, pakai tab Game.", 13f, C.SUB), lp(bottom = ctx.dpi(12)))

        // Renderer UI sistem (global)
        val c1 = ctx.card()
        c1.addView(ctx.text("Renderer UI sistem (global)", 14f, C.TEXT, true))
        c1.addView(ctx.text("debug.hwui.renderer. Berlaku untuk aplikasi yang dibuka setelah ini. Hilang saat HP restart.", 11f, C.SUB), lp(top = ctx.dpi(2)))
        chipsRow(c1, listOf(
            "Skia GL" to { run("setprop debug.hwui.renderer skiagl") },
            "Skia Vulkan" to { run("setprop debug.hwui.renderer skiavk") },
            "Bawaan" to { run("setprop debug.hwui.renderer ''") }
        ))
        col.addView(c1, lp(bottom = ctx.dpi(10)))

        // Komposisi tampilan (SurfaceFlinger)
        val cc = ctx.card()
        cc.addView(ctx.text("Komposisi tampilan (global)", 14f, C.TEXT, true))
        cc.addView(ctx.text("Cara layar digabung sebelum tampil. Overlay HWC = bawaan (hemat daya). Paksa GPU = semua layer digabung GPU; bisa mengubah FPS/latensi, kadang membuat panas. Bisa dikembalikan kapan saja.", 11f, C.SUB), lp(top = ctx.dpi(2)))
        chipsRow(cc, listOf(
            "Overlay HWC (bawaan)" to { run("service call SurfaceFlinger 1008 i32 0") },
            "Paksa GPU" to { run("service call SurfaceFlinger 1008 i32 1") }
        ))
        chipsRow(cc, listOf(
            "Latch unsignaled ON" to { run("setprop debug.sf.latch_unsignaled 1") },
            "OFF" to { run("setprop debug.sf.latch_unsignaled 0") }
        ))
        col.addView(cc, lp(bottom = ctx.dpi(10)))

        // Layar
        val c2 = ctx.card()
        c2.addView(ctx.text("Resolusi layar (global)", 14f, C.TEXT, true))
        c2.addView(ctx.text("Kembali otomatis dalam 15 detik kalau tidak kamu simpan — jaga-jaga kalau layar jadi tidak terbaca.", 11f, C.SUB), lp(top = ctx.dpi(2)))
        chipsRow(c2, listOf(
            "100%" to { setScale(1.0f) }, "85%" to { setScale(0.85f) }, "75%" to { setScale(0.75f) }, "60%" to { setScale(0.6f) }
        ))
        c2.addView(tRevert, lp(top = ctx.dpi(8)))
        c2.addView(ctx.button("Reset ukuran layar", false) { run("wm size reset; wm density reset") }, lp(top = ctx.dpi(8)))
        col.addView(c2, lp(bottom = ctx.dpi(10)))

        // Refresh rate
        val c3 = ctx.card()
        c3.addView(ctx.text("Refresh rate (global)", 14f, C.TEXT, true))
        chipsRow(c3, listOf(
            "60 Hz" to { run("settings put system min_refresh_rate 60; settings put system peak_refresh_rate 60") },
            "90 Hz" to { run("settings put system min_refresh_rate 90; settings put system peak_refresh_rate 90") },
            "120 Hz" to { run("settings put system min_refresh_rate 120; settings put system peak_refresh_rate 120") },
            "Bawaan" to { run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate") }
        ))
        col.addView(c3, lp(bottom = ctx.dpi(10)))

        // Animasi
        val c4 = ctx.card()
        c4.addView(ctx.text("Skala animasi (global)", 14f, C.TEXT, true))
        chipsRow(c4, listOf(
            "Mati" to { anim("0") }, "0.5x" to { anim("0.5") }, "1x" to { anim("1") }
        ))
        col.addView(c4, lp(bottom = ctx.dpi(10)))

        // Terminal
        val c5 = ctx.card()
        c5.addView(ctx.text("Terminal Shizuku", 14f, C.TEXT, true))
        val et = EditText(ctx); et.hint = "contoh: cmd game list-modes com.xxx"; et.setHintTextColor(C.SUB); et.setTextColor(C.TEXT); et.textSize = 13f
        et.typeface = android.graphics.Typeface.MONOSPACE; et.setSingleLine(true)
        et.background = rr(C.FILL, ctx.dp(12f), C.STROKE)
        et.setPadding(ctx.dpi(12), ctx.dpi(10), ctx.dpi(12), ctx.dpi(10))
        c5.addView(et, lp(top = ctx.dpi(8)))
        c5.addView(ctx.button("Jalankan") { val s = et.text.toString().trim(); if (s.isNotEmpty()) run(s) }, lp(top = ctx.dpi(8)))
        col.addView(c5, lp(bottom = ctx.dpi(10)))

        // Diagnostik
        val c6 = ctx.card()
        c6.addView(ctx.text("Diagnostik", 14f, C.TEXT, true))
        c6.addView(ctx.text("Lihat fitur apa saja yang benar-benar didukung HP ini.", 11f, C.SUB), lp(top = ctx.dpi(2)))
        c6.addView(ctx.button("Cek kemampuan HP", false) {
            if (!Sh.granted()) { say("Shizuku belum aktif / belum diberi izin."); return@button }
            say("Memeriksa…")
            Sh.async(Caps.SCRIPT, 15) { r ->
                val i = Caps.parse(r.out)
                say(buildString {
                    append("Game Mode (downscale/FPS): ").append(if (i.gameCmd && i.sdk >= 33) "didukung" else if (i.gameCmd) "ada, tapi downscale butuh Android 13+" else "tidak terdeteksi").append('\n')
                    append("ANGLE (renderer per game): ").append(if (i.angle) "paket ANGLE ada" else "paket ANGLE tidak ditemukan → opsi ANGLE kemungkinan tanpa efek").append('\n')
                    append("Driver update: ").append(if (i.updatableDriver) "kemungkinan ada" else "tidak ada paket driver → pilihan driver kemungkinan tanpa efek").append('\n')
                    append("Vulkan: ").append(i.vulkan.ifEmpty { "-" }).append("  GPU/EGL: ").append(i.egl.ifEmpty { "-" }).append('\n')
                    append("SoC: ").append(i.soc).append("  Android ").append(i.android)
                })
            }
        }, lp(top = ctx.dpi(8)))
        col.addView(c6, lp(bottom = ctx.dpi(10)))

        val lc = ctx.card(); lc.addView(ctx.label("Hasil")); lc.addView(tOut, lp(top = ctx.dpi(4)))
        tOut.typeface = android.graphics.Typeface.MONOSPACE; tOut.setTextIsSelectable(true)
        col.addView(lc)
    }

    private fun anim(v: String) = run("settings put global window_animation_scale $v; settings put global transition_animation_scale $v; settings put global animator_duration_scale $v")

    private fun setScale(f: Float) {
        if (!Sh.granted()) { say("Shizuku belum aktif / belum diberi izin."); return }
        revertRunnable?.let { mainHandler.removeCallbacks(it) }
        if (f >= 1f) { run("wm size reset"); tRevert.text = ""; return }
        Sh.async("wm size", 8) { r ->
            val m = Regex("(\\d+)x(\\d+)").findAll(r.out).lastOrNull()
            if (m == null) { say("Tidak bisa membaca ukuran layar:\n" + r.text); return@async }
            val w = m.groupValues[1].toInt(); val h = m.groupValues[2].toInt()
            val nw = (w * f).toInt() / 2 * 2; val nh = (h * f).toInt() / 2 * 2
            run("wm size ${nw}x${nh}")
            var left = 15
            val rr = object : Runnable {
                override fun run() {
                    if (left <= 0) { Sh.bg { Sh.run("wm size reset") }; tRevert.text = "Dikembalikan otomatis."; return }
                    tRevert.text = "Kembali otomatis dalam $left dtk…  (ketuk di sini untuk MENYIMPAN)"
                    left--; mainHandler.postDelayed(this, 1000)
                }
            }
            revertRunnable = rr
            tRevert.setOnClickListener { mainHandler.removeCallbacks(rr); tRevert.text = "Disimpan."; tRevert.setOnClickListener(null) }
            rr.run()
        }
    }
}

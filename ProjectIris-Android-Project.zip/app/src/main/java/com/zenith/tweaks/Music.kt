package com.zenith.tweaks

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Pemutar musik sederhana untuk lagu milik pengguna di HP. Daftar putar disimpan di aplikasi. */
object Music {
    class Track(val uri: Uri, var title: String, var artist: String, var dur: Long)

    val list = ArrayList<Track>()
    var index = -1
    var shuffle = false
    var repeat = 0            // 0 mati, 1 semua, 2 satu lagu
    var playing = false; private set
    var onChange: (() -> Unit)? = null
    private var mp: MediaPlayer? = null
    private lateinit var app: Context
    private var inited = false
    private var focusReq: AudioFocusRequest? = null

    private fun sp() = app.getSharedPreferences("zt", Context.MODE_PRIVATE)

    fun init(c: Context) { if (inited) return; inited = true; app = c.applicationContext; load() }

    fun current(): Track? = list.getOrNull(index)
    fun position(): Int = try { mp?.currentPosition ?: 0 } catch (e: Throwable) { 0 }
    fun duration(): Int = try { mp?.duration?.takeIf { it > 0 } ?: (current()?.dur?.toInt() ?: 0) } catch (e: Throwable) { (current()?.dur?.toInt() ?: 0) }

    private fun fire() { mainHandler.post { onChange?.invoke() } }

    // ---------- penyimpanan ----------
    private fun save() {
        val a = JSONArray()
        for (t in list) a.put(JSONObject().put("u", t.uri.toString()).put("t", t.title).put("a", t.artist).put("d", t.dur))
        sp().edit().putString("music_list", a.toString()).apply()
    }
    private fun load() {
        try {
            val a = JSONArray(sp().getString("music_list", "[]") ?: "[]")
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); list.add(Track(Uri.parse(o.getString("u")), o.optString("t"), o.optString("a"), o.optLong("d"))) }
        } catch (e: Throwable) {}
    }

    // ---------- daftar ----------
    private fun displayName(uri: Uri): String {
        try {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) return it.getString(0).substringBeforeLast('.') }
        } catch (e: Throwable) {}
        return uri.lastPathSegment ?: "Lagu"
    }

    /** Tambah lagu dari pemilih file (thread latar). */
    fun addUris(uris: List<Uri>, done: (Int) -> Unit) {
        Sh.bg {
            var n = 0
            for (u in uris) {
                if (list.any { it.uri == u }) continue
                var title = ""; var artist = ""; var dur = 0L
                try {
                    val r = MediaMetadataRetriever(); r.setDataSource(app, u)
                    title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty()
                    artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty()
                    dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    r.release()
                } catch (e: Throwable) {}
                if (title.isBlank()) title = displayName(u)
                synchronized(list) { list.add(Track(u, title, artist, dur)) }; n++
            }
            save(); mainHandler.post { done(n); onChange?.invoke() }
        }
    }

    /** Pindai musik di HP lewat MediaStore (butuh izin audio). */
    fun scan(done: (Int) -> Unit) {
        Sh.bg {
            var n = 0
            try {
                val coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
                app.contentResolver.query(coll, proj, MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + MediaStore.Audio.Media.DURATION + " >= 30000", null, MediaStore.Audio.Media.DATE_ADDED + " DESC")?.use { c ->
                    while (c.moveToNext() && n < 500) {
                        val u = ContentUris.withAppendedId(coll, c.getLong(0))
                        if (list.any { it.uri == u }) continue
                        val art = c.getString(2).orEmpty().let { if (it == "<unknown>") "" else it }
                        synchronized(list) { list.add(Track(u, c.getString(1).orEmpty().ifBlank { "Lagu" }, art, c.getLong(3))) }; n++
                    }
                }
            } catch (e: Throwable) {}
            save(); mainHandler.post { done(n); onChange?.invoke() }
        }
    }

    fun remove(i: Int) {
        if (i !in list.indices) return
        val wasCur = i == index
        list.removeAt(i)
        if (wasCur) { stop(); index = -1 } else if (i < index) index--
        save(); fire()
    }

    fun clear() { stop(); list.clear(); index = -1; save(); fire() }

    // ---------- pemutaran ----------
    private fun focus(): Boolean {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener { ch -> if (ch == AudioManager.AUDIOFOCUS_LOSS || ch == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) mainHandler.post { pause() } }
            .build()
        focusReq = r
        return am.requestAudioFocus(r) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun service(start: Boolean) {
        try {
            val i = Intent(app, MusicService::class.java)
            if (start) app.startForegroundService(i) else app.stopService(i)
        } catch (e: Throwable) {}
    }

    fun play(i: Int) {
        val t = list.getOrNull(i) ?: return
        release()
        index = i
        try {
            focus()
            val m = MediaPlayer()
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            m.setDataSource(app, t.uri)
            m.setOnPreparedListener { it.start(); playing = true; service(true); fire() }
            m.setOnCompletionListener { onComplete() }
            m.setOnErrorListener { _, _, _ ->
                playing = false; fire()
                mainHandler.post { Toast.makeText(app, "Lagu tidak bisa diputar: ${t.title}", Toast.LENGTH_SHORT).show() }
                true
            }
            mp = m
            m.prepareAsync()
            fire()
        } catch (e: Throwable) {
            playing = false; fire()
            Toast.makeText(app, "Lagu tidak bisa diputar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onComplete() {
        if (repeat == 2) { play(index); return }
        val last = index >= list.size - 1
        if (last && repeat == 0 && !shuffle) { playing = false; service(false); fire(); return }
        next()
    }

    fun toggle() {
        if (mp == null) { if (list.isNotEmpty()) play(if (index in list.indices) index else 0); return }
        if (playing) pause() else resume()
    }

    fun pause() { try { mp?.pause() } catch (e: Throwable) {}; playing = false; service(false); fire() }
    fun resume() { try { focus(); mp?.start(); playing = true; service(true) } catch (e: Throwable) {}; fire() }

    fun next() {
        if (list.isEmpty()) return
        val n = if (shuffle && list.size > 1) { var r: Int; do { r = (0 until list.size).random() } while (r == index); r } else (index + 1) % list.size
        play(n)
    }
    fun prev() {
        if (list.isEmpty()) return
        if (position() > 3000) { seek(0); return }
        play(if (index <= 0) list.size - 1 else index - 1)
    }
    fun seek(ms: Int) { try { mp?.seekTo(ms) } catch (e: Throwable) {} }

    private fun stop() { release(); playing = false; service(false) }
    private fun release() { try { mp?.release() } catch (e: Throwable) {}; mp = null; playing = false }
}

/** Menjaga proses tetap hidup saat musik diputar di latar belakang. */
class MusicService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("music", "Musik", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE)
        val t = Music.current()
        val n = Notification.Builder(this, "music")
            .setContentTitle(t?.title ?: "Project Iris")
            .setContentText(t?.artist?.ifBlank { "Memutar musik" } ?: "Memutar musik")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(1, n)
        return START_NOT_STICKY
    }
}

package com.zenith.tweaks

import android.content.Context

/** Pengaturan aplikasi + terjemahan sederhana (Indonesia / English). */
object Prefs {
    var en = false
    var anim = true
    var interval = 1200L
    var wall = ""      // "", "image", "video"
    var dim = 55
    val hasWall get() = wall.isNotEmpty()
    private fun sp(c: Context) = c.getSharedPreferences("zt", Context.MODE_PRIVATE)
    fun load(c: Context) {
        val s = sp(c)
        en = s.getString("lang", "id") == "en"
        anim = s.getBoolean("anim", true)
        interval = s.getLong("interval", 1200L)
        wall = s.getString("wall", "") ?: ""
        dim = s.getInt("dim", 55)
    }
    fun setWall(c: Context, w: String) { wall = w; sp(c).edit().putString("wall", w).apply() }
    fun setDim(c: Context, d: Int) { dim = d; sp(c).edit().putInt("dim", d).apply() }
    fun chipName(c: Context): String = sp(c).getString("chip_name", "") ?: ""
    fun setChipName(c: Context, n: String) { sp(c).edit().putString("chip_name", n).apply() }
    fun setLang(c: Context, e: Boolean) { en = e; sp(c).edit().putString("lang", if (e) "en" else "id").apply() }
    fun setAnim(c: Context, a: Boolean) { anim = a; sp(c).edit().putBoolean("anim", a).apply() }
    fun setInterval(c: Context, ms: Long) { interval = ms; sp(c).edit().putLong("interval", ms).apply() }
}

object Lang {
    fun tr(s: String): String = if (Prefs.en) (EN[s] ?: s) else s

    private val EN = mapOf(
        "Data langsung dari sistem lewat Shizuku" to "Live data from the system via Shizuku",
        "Masalah membaca sistem" to "Problem reading the system",
        "Aplikasi di layar" to "Foreground app",
        "Suhu & baterai" to "Temperature & battery",
        "Perangkat" to "Device",
        "FPS dibaca dari SurfaceFlinger. Tidak semua game bisa terbaca." to "FPS is read from SurfaceFlinger. Not every game can be read.",
        "FPS tidak terbaca" to "FPS unavailable",
        "(ini aplikasi Iris)" to "(this is Iris)",
        "Game & Aplikasi" to "Games & Apps",
        "Pilih satu, atur khusus untuk dia saja" to "Pick one, tune it on its own",
        "Cari aplikasi…" to "Search apps…",
        "★ Terpilih" to "★ Selected",
        "Semua" to "All",
        "Memuat daftar aplikasi…" to "Loading apps…",
        "Tidak ditemukan." to "Not found.",
        "Belum ada yang dipilih.\nBuka tab “Game” atau “Semua”, lalu ketuk ☆ untuk menambahkan." to "Nothing selected yet.\nOpen “Game” or “All”, then tap ☆ to add.",
        "Downscale resolusi" to "Resolution downscale",
        "1.0 asli" to "1.0 original",
        "1.0×  asli" to "1.0×  original",
        "0.3 paling kasar" to "0.3 roughest",
        "Hanya game ini. Butuh Android 13+ dan aplikasi terdaftar sebagai game." to "This game only. Needs Android 13+ and the app registered as a game.",
        "Batas FPS" to "FPS cap",
        "Bawaan" to "Default",
        "Game Mode" to "Game Mode",
        "Standar" to "Standard",
        "Performa" to "Performance",
        "Hemat" to "Battery saver",
        "Renderer grafis" to "Graphics renderer",
        "ANGLE = OpenGL ES di atas Vulkan. Hanya untuk game ini; tidak semua game/HP cocok." to "ANGLE = OpenGL ES on top of Vulkan. This game only; not every game/phone is compatible.",
        "Renderer UI (Skia)" to "UI renderer (Skia)",
        "Untuk tampilan UI game. Dipakai saat dibuka lewat tombol “Terapkan & Buka” atau ▶ di daftar. Mesin grafis game (Unity/Unreal) memilih API-nya sendiri." to "For the game's UI. Used when opened via “Apply & Open” or ▶ in the list. The game engine (Unity/Unreal) picks its own API.",
        "Driver GPU" to "GPU driver",
        "Hanya game ini. Butuh paket driver yang tersedia di HP; kalau tidak ada, tidak ada efek." to "This game only. Needs a driver package on the phone; otherwise no effect.",
        "Driver sistem" to "System driver",
        "Driver update" to "Updated driver",
        "Pra-rilis" to "Prerelease",
        "Terapkan" to "Apply",
        "Terapkan & Buka" to "Apply & Open",
        "Reset game ini ke bawaan" to "Reset this game to default",
        "Log" to "Log",
        "Menerapkan…" to "Applying…",
        "Mereset…" to "Resetting…",
        "Shizuku belum aktif / belum diberi izin." to "Shizuku isn't running / permission not granted.",
        "\n\nSelesai. Game dihentikan paksa; buka ulang agar pengaturan dipakai." to "\n\nDone. The game was force-stopped; reopen it to use the settings.",
        "\n\nSudah kembali ke bawaan." to "\n\nBack to default.",
        "Tweak" to "Tweak",
        "Pengaturan di bawah ini berlaku untuk SELURUH HP. Untuk per-game, pakai tab Game." to "Settings below apply to the WHOLE phone. For per-game, use the Game tab.",
        "Renderer UI sistem (global)" to "System UI renderer (global)",
        "debug.hwui.renderer. Berlaku untuk aplikasi yang dibuka setelah ini. Hilang saat HP restart." to "debug.hwui.renderer. Applies to apps opened afterwards. Lost on reboot.",
        "Komposisi tampilan (global)" to "Display composition (global)",
        "Cara layar digabung sebelum tampil. Overlay HWC = bawaan (hemat daya). Paksa GPU = semua layer digabung GPU; bisa mengubah FPS/latensi, kadang membuat panas. Bisa dikembalikan kapan saja. Catatan: di beberapa HP (Android 16) saklar ini ditolak sistem." to "How layers are combined before display. HWC overlay = default (saves power). Force GPU = all layers composed by GPU; may change FPS/latency and run hotter. Reversible anytime. Note: some phones (Android 16) reject this switch.",
        "Overlay HWC (bawaan)" to "HWC overlay (default)",
        "Paksa GPU" to "Force GPU",
        "Lihat komposisi lapisan sekarang" to "Show current layer composition",
        "DEVICE = disusun HWC (hardware). CLIENT = disusun GPU. Ubah pilihan di atas, lalu cek lagi untuk melihat bedanya." to "DEVICE = composed by HWC (hardware). CLIENT = composed by GPU. Change the option above, then check again to see the difference.",
        "Resolusi layar (global)" to "Screen resolution (global)",
        "Kembali otomatis dalam 15 detik kalau tidak kamu simpan — jaga-jaga kalau layar jadi tidak terbaca." to "Reverts automatically in 15 seconds unless you keep it, in case the screen becomes unreadable.",
        "Reset ukuran layar" to "Reset screen size",
        "Refresh rate (global)" to "Refresh rate (global)",
        "Skala animasi (global)" to "Animation scale (global)",
        "Mati" to "Off",
        "Terminal Shizuku" to "Shizuku terminal",
        "contoh: cmd game list-modes com.xxx" to "e.g. cmd game list-modes com.xxx",
        "Jalankan" to "Run",
        "Diagnostik" to "Diagnostics",
        "Lihat fitur apa saja yang benar-benar didukung HP ini." to "See which features this phone really supports.",
        "Cek kemampuan HP" to "Check phone capabilities",
        "Hasil" to "Result",
        "Memeriksa…" to "Checking…",
        "Buka Shizuku" to "Open Shizuku",
        "Beri izin ke Iris" to "Grant permission to Iris",
        "Cek ulang" to "Check again",
        "Shizuku aktif. Iris butuh izin untuk menjalankan perintah sistem." to "Shizuku is running. Iris needs permission to run system commands.",
        "Shizuku belum berjalan.\n\nPasang aplikasi Shizuku, jalankan lewat Wireless debugging (atau root), lalu kembali ke sini." to "Shizuku isn't running.\n\nInstall Shizuku, start it via Wireless debugging (or root), then come back here.",
        "Izin sebelumnya ditolak. Buka aplikasi Shizuku → Aplikasi terotorisasi → aktifkan Project Iris." to "Permission was denied. Open Shizuku → Authorized apps → enable Project Iris.",
        "Menu" to "Menu",
        "Pengaturan, bahasa, dan info aplikasi" to "Settings, language and app info",
        "Bahasa" to "Language",
        "Indonesia" to "Indonesian",
        "Pilihan bahasa berlaku untuk label dan teks tetap; pesan log sistem tetap apa adanya." to "Language applies to labels and fixed text; system log messages stay as they are.",
        "Tampilan" to "Display",
        "Animasi" to "Animations",
        "Nyala" to "On",
        "Kecepatan dashboard" to "Dashboard speed",
        "Cepat (1 dtk)" to "Fast (1 s)",
        "Normal (2 dtk)" to "Normal (2 s)",
        "Hemat (4 dtk)" to "Saver (4 s)",
        "Interval pembaruan data. Lebih lambat = lebih hemat baterai." to "Data refresh interval. Slower = saves battery.",
        "Shizuku" to "Shizuku",
        "Data & profil" to "Data & profiles",
        "Reset semua profil game" to "Reset all game profiles",
        "Reset semua profil?" to "Reset all profiles?",
        "Belum ada profil game yang tersimpan." to "No saved game profiles.",
        "Batal" to "Cancel",
        "Reset" to "Reset",
        "Tentang" to "About",
        "Tutup" to "Close",
        "Alat tweak per game lewat Shizuku: downscale, batas FPS, Game Mode, renderer, driver GPU, dan dashboard sistem.\n\nHasil bergantung pada HP dan game. Kalau ada yang bermasalah, pakai Reset per game atau “Reset semua profil”." to "Per-game tweak tool via Shizuku: downscale, FPS cap, Game Mode, renderer, GPU driver and a system dashboard.\n\nResults depend on the phone and game. If something misbehaves, use Reset per game or “Reset all profiles”.",
        "Semua pengaturan memakai perintah sistem resmi lewat Shizuku dan bisa di-reset." to "Everything uses official system commands via Shizuku and can be reset.",
        "Dashboard" to "Dashboard",
        "Game" to "Games",
        "Baterai" to "Battery",
        "Alat kecil tambahan" to "Small extra tools",
        "Buka" to "Open",
        "Wallpaper" to "Wallpaper",
        "Foto" to "Photo",
        "Video" to "Video",
        "Hapus" to "Remove",
        "Kegelapan" to "Dimming",
        "Mengisi" to "Charging"
    )
}

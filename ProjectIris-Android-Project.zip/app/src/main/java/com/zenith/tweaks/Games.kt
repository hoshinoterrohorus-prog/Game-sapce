package com.zenith.tweaks

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.util.LruCache
import org.json.JSONObject

/** Pengaturan khusus SATU aplikasi/game. Tidak menyentuh aplikasi lain. */
data class Profile(
    val scale: Int = 100,          // 100 = tanpa downscale, 50..90 = persen resolusi
    val fps: Int = 0,              // 0 = bawaan
    val mode: String = "default",  // default | standard | performance | battery
    val renderer: String = "default", // default | angle | native
    val driver: String = "default",  // default | system | production | prerelease
    val ui: String = "default"       // default | skiagl | skiavk (renderer UI Skia, dipakai saat dibuka dari Iris)
) {
    val isDefault get() = scale == 100 && fps == 0 && mode == "default" && renderer == "default" && driver == "default" && ui == "default"
    fun toJson() = JSONObject().put("s", scale).put("f", fps).put("m", mode).put("r", renderer).put("d", driver).put("u", ui)
    companion object {
        fun from(o: JSONObject) = Profile(o.optInt("s", 100), o.optInt("f", 0), o.optString("m", "default"), o.optString("r", "default"), o.optString("d", "default"), o.optString("u", "default"))
    }
}

class AppItem(val pkg: String, val label: String, val isGame: Boolean)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("zt", Context.MODE_PRIVATE)

    fun pinned(c: Context): MutableSet<String> = HashSet(sp(c).getStringSet("pinned", emptySet()) ?: emptySet())
    fun setPinned(c: Context, s: Set<String>) { sp(c).edit().putStringSet("pinned", s).apply() }

    fun profile(c: Context, pkg: String): Profile {
        val j = sp(c).getString("p_$pkg", null) ?: return Profile()
        return try { Profile.from(JSONObject(j)) } catch (e: Exception) { Profile() }
    }
    fun saveProfile(c: Context, pkg: String, p: Profile) {
        sp(c).edit().apply { if (p.isDefault) remove("p_$pkg") else putString("p_$pkg", p.toJson().toString()) }.apply()
    }
    fun hasProfile(c: Context, pkg: String) = sp(c).contains("p_$pkg")
    fun allProfiles(c: Context): List<String> = sp(c).all.keys.filter { it.startsWith("p_") }.map { it.removePrefix("p_") }
    fun clearProfiles(c: Context) { sp(c).edit().apply { for (k in sp(c).all.keys) if (k.startsWith("p_")) remove(k) }.apply() }
}

object Apps {
    private val icons = LruCache<String, Drawable>(120)

    fun list(c: Context): List<AppItem> {
        val pm = c.packageManager
        val out = ArrayList<AppItem>()
        for (ai in pm.getInstalledApplications(0)) {
            if (ai.packageName == c.packageName) continue
            if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue
            @Suppress("DEPRECATION")
            val game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            out.add(AppItem(ai.packageName, ai.loadLabel(pm).toString(), game))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun icon(c: Context, pkg: String): Drawable? {
        icons.get(pkg)?.let { return it }
        return try { c.packageManager.getApplicationIcon(pkg).also { icons.put(pkg, it) } } catch (e: PackageManager.NameNotFoundException) { null }
    }
}

/** Menyusun & menjalankan perintah per-paket. */
object Tweaks {
    private val DOWN = listOf(90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30)

    private fun q(s: String) = "'" + s.replace("'", "") + "'"

    /** Ambil nilai settings global sebagai list (dipisah koma). */
    private fun getList(key: String): List<String> {
        val v = Sh.run("settings get global $key", 6).out.trim()
        return if (v.isEmpty() || v == "null") emptyList() else v.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun putList(key: String, l: List<String>): String =
        if (l.isEmpty()) "settings delete global $key" else "settings put global $key ${q(l.joinToString(","))}"

    /** Mengembalikan log hasil. Dipanggil di thread latar. */
    fun apply(pkg: String, p: Profile, caps: Caps.Info?): String {
        val sb = StringBuilder()
        val cmds = ArrayList<String>()

        // 1) Game Mode: downscale / FPS / mode  (per paket)
        if (p.scale == 100 && p.fps == 0 && p.mode == "default") {
            cmds.add("cmd game reset ${q(pkg)}")
        } else {
            val mode = when (p.mode) { "standard" -> 1; "battery" -> 3; else -> 2 }
            val sc = if (p.scale >= 100) "disable" else DOWN.minByOrNull { Math.abs(it - p.scale) }!!.let { v -> if (v % 10 == 0) "0.${v / 10}" else "0.%02d".format(v) }
            val fps = if (p.fps == 0) "disable" else p.fps.toString()
            cmds.add("cmd game set --mode $mode --downscale $sc --fps $fps ${q(pkg)}")
            // aktifkan mode itu supaya downscale benar-benar dipakai
            cmds.add("cmd game mode $mode ${q(pkg)}")
        }

        // 2) Renderer (ANGLE / native) per paket
        val pk = getList("angle_gl_driver_selection_pkgs").toMutableList()
        val vl = getList("angle_gl_driver_selection_values").toMutableList()
        val map = LinkedHashMap<String, String>()
        for (i in pk.indices) map[pk[i]] = vl.getOrElse(i) { "default" }
        if (p.renderer == "default") map.remove(pkg) else map[pkg] = p.renderer
        cmds.add(putList("angle_gl_driver_selection_pkgs", map.keys.toList()))
        cmds.add(putList("angle_gl_driver_selection_values", map.values.toList()))

        // 3) Driver GPU per paket (updatable driver)
        val keys = mapOf(
            "system" to "updatable_driver_production_opt_out_apps",
            "production" to "updatable_driver_production_opt_in_apps",
            "prerelease" to "updatable_driver_prerelease_opt_in_apps"
        )
        for ((mode, key) in keys) {
            val l = getList(key).toMutableList()
            l.remove(pkg)
            if (p.driver == mode) l.add(pkg)
            cmds.add(putList(key, l))
        }

        // 4) Paksa berhenti agar pengaturan dipakai saat dibuka lagi
        cmds.add("am force-stop ${q(pkg)}")

        for (c in cmds) {
            val r = Sh.run(c, 10)
            sb.append("› ").append(c.replace("settings ", "").take(90)).append('\n')
            val t = r.text
            if (t.isNotEmpty()) sb.append("   ").append(t.take(160).replace("\n", "\n   ")).append('\n')
            else if (!r.ok) sb.append("   gagal (kode ${r.code})\n")
        }
        return sb.toString().trim()
    }

    fun reset(pkg: String, caps: Caps.Info?) = apply(pkg, Profile(), caps)

    fun launch(pkg: String) = Sh.run("monkey -p ${q(pkg)} -c android.intent.category.LAUNCHER 1", 8)

    /** Buka game. Kalau ada renderer UI khusus, prop dipasang hanya selama game dimulai lalu dikembalikan. */
    fun launchWith(pkg: String, p: Profile): String {
        if (p.ui == "default") { val r = launch(pkg); return "› buka game " + (if (r.ok) "OK" else r.text) }
        val sb = StringBuilder()
        sb.append("› setprop debug.hwui.renderer ${p.ui}\n")
        Sh.run("setprop debug.hwui.renderer ${p.ui}", 6)
        Sh.run("am force-stop ${q(pkg)}", 6)
        val r = launch(pkg)
        sb.append("› buka game ").append(if (r.ok) "OK" else r.text).append('\n')
        Thread.sleep(9000)
        Sh.run("setprop debug.hwui.renderer ''", 6)
        sb.append("› renderer UI dikembalikan ke bawaan (game tetap memakai ${p.ui} selama sesi ini)")
        return sb.toString()
    }
}

package com.zenith.tweaks

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var aurora: Aurora
    private lateinit var content: FrameLayout
    private lateinit var setup: LinearLayout
    private lateinit var setupMsg: TextView
    private lateinit var nav: FrameLayout
    private lateinit var navRow: LinearLayout
    private lateinit var pill: View
    private lateinit var dash: Dashboard
    private lateinit var games: GamesPage
    private lateinit var tweak: TweakPage
    private lateinit var pages: List<Page>
    private val icons = ArrayList<TabIcon>()
    private val labels = ArrayList<TextView>()
    private var cur = -1
    private var caps: Caps.Info? = null
    private var setupShown = true

    private val onResult = Shizuku.OnRequestPermissionResultListener { _, _ -> mainHandler.post { refresh() } }
    private val onBinder = Shizuku.OnBinderReceivedListener { mainHandler.post { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { mainHandler.post { refresh() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.BG; window.navigationBarColor = C.BG
        val ctx: Context = this

        val root = FrameLayout(ctx)
        aurora = Aurora(ctx); root.addView(aurora, fl())

        val column = LinearLayout(ctx); column.orientation = LinearLayout.VERTICAL
        root.addView(column, fl())
        content = FrameLayout(ctx)
        column.addView(content, lp(-1, 0, weight = 1f))

        dash = Dashboard(ctx) { caps }; games = GamesPage(ctx) { caps }; tweak = TweakPage(ctx) { caps }
        pages = listOf(dash, games, tweak)
        for (p in pages) { p.root.visibility = View.GONE; content.addView(p.root, fl()) }

        // ----- bilah navigasi melayang -----
        nav = FrameLayout(ctx)
        nav.background = rr(C.CARD, ctx.dp(20f), C.STROKE)
        pill = View(ctx); pill.background = rr(C.FILL, ctx.dp(14f))
        nav.addView(pill, FrameLayout.LayoutParams(0, ctx.dpi(56)).also { it.gravity = Gravity.CENTER_VERTICAL })
        navRow = LinearLayout(ctx); navRow.orientation = LinearLayout.HORIZONTAL
        nav.addView(navRow, FrameLayout.LayoutParams(-1, -2).also { it.gravity = Gravity.CENTER_VERTICAL })
        val names = listOf("Dashboard", "Game", "Tweak")
        for (i in names.indices) {
            val tab = LinearLayout(ctx); tab.orientation = LinearLayout.VERTICAL; tab.gravity = Gravity.CENTER
            tab.setPadding(0, ctx.dpi(8), 0, ctx.dpi(8))
            val ic = TabIcon(ctx, i); tab.addView(ic, lp(ctx.dpi(24), ctx.dpi(24)))
            val t = ctx.text(names[i], 11f, C.SUB, true); t.gravity = Gravity.CENTER; tab.addView(t, lp(top = ctx.dpi(2)))
            tab.press(0.92f); tab.setOnClickListener { select(i) }
            icons.add(ic); labels.add(t); navRow.addView(tab, lp(0, -2, weight = 1f))
        }
        column.addView(nav, lp(-1, -2).also { it.setMargins(ctx.dpi(16), ctx.dpi(4), ctx.dpi(16), ctx.dpi(10)) })

        setup = buildSetup(); root.addView(setup, fl())
        setContentView(root)

        column.setOnApplyWindowInsetsListener { v, ins ->
            val top: Int; val bot: Int
            if (Build.VERSION.SDK_INT >= 30) { val s = ins.getInsets(WindowInsets.Type.systemBars()); top = s.top; bot = s.bottom }
            else { @Suppress("DEPRECATION") top = ins.systemWindowInsetTop; @Suppress("DEPRECATION") bot = ins.systemWindowInsetBottom }
            v.setPadding(0, top, 0, bot)
            setup.setPadding(ctx.dpi(24), top + ctx.dpi(24), ctx.dpi(24), bot + ctx.dpi(24))
            ins
        }
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        else @Suppress("DEPRECATION") run { window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION }

        nav.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val w = (r - l - 0) / 3
            val lpp = pill.layoutParams as FrameLayout.LayoutParams
            if (lpp.width != w - ctx.dpi(12)) { lpp.width = w - ctx.dpi(12); pill.layoutParams = lpp }
            if (cur >= 0) pill.translationX = cur * w + ctx.dpi(6).toFloat()
        }

        try {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onResult)
        } catch (e: Throwable) {}
        select(0)
    }

    private fun buildSetup(): LinearLayout {
        val ctx: Context = this
        val l = LinearLayout(ctx); l.orientation = LinearLayout.VERTICAL; l.gravity = Gravity.CENTER
        l.setBackgroundColor(C.BG); l.setPadding(ctx.dpi(24), ctx.dpi(24), ctx.dpi(24), ctx.dpi(24))
        l.isClickable = true
        l.addView(Logo(ctx), lp(ctx.dpi(150), ctx.dpi(150)))
        val t = ctx.title("Project Iris"); t.gravity = Gravity.CENTER; l.addView(t, lp(bottom = ctx.dpi(8)))
        setupMsg = ctx.text("", 14f, C.SUB); setupMsg.gravity = Gravity.CENTER; l.addView(setupMsg, lp(bottom = ctx.dpi(24)))
        l.addView(ctx.button("Buka Shizuku") { openShizuku() }, lp(bottom = ctx.dpi(10)))
        l.addView(ctx.button("Beri izin ke Iris", false) { askPermission() }, lp(bottom = ctx.dpi(10)))
        l.addView(ctx.button("Cek ulang", false) { refresh() }, lp())
        return l
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) startActivity(i)
        else try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))) } catch (e: Exception) {}
    }

    private fun askPermission() {
        try {
            if (!Sh.alive()) { refresh(); return }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                setupMsg.text = "Izin sebelumnya ditolak. Buka aplikasi Shizuku → Aplikasi terotorisasi → aktifkan Project Iris."
            } else Shizuku.requestPermission(1)
        } catch (e: Throwable) { refresh() }
    }

    private fun showSetup(show: Boolean) {
        if (show == setupShown) return
        setupShown = show
        if (show) { setup.visibility = View.VISIBLE; setup.alpha = 0f; setup.animate().alpha(1f).setDuration(300).start() }
        else setup.animate().alpha(0f).setDuration(380).withEndAction { if (setupShown == false) setup.visibility = View.GONE }.start()
    }

    private fun refresh() {
        val ready = Sh.granted()
        if (ready) {
            showSetup(false)
            if (caps == null) Sh.async(Caps.SCRIPT, 15) { r -> caps = Caps.parse(r.out); dash.bindCaps(caps!!) }
            if (cur >= 0) pages[cur].onShow()
        } else {
            showSetup(true)
            setupMsg.text = when {
                !Sh.alive() -> "Shizuku belum berjalan.\n\nPasang aplikasi Shizuku, jalankan lewat Wireless debugging (atau root), lalu kembali ke sini."
                else -> "Shizuku aktif. Iris butuh izin untuk menjalankan perintah sistem."
            }
        }
    }

    private fun select(i: Int) {
        if (cur == i) return
        val ctx: Context = this
        val old = if (cur >= 0) pages[cur] else null
        val dir = if (cur < 0 || i > cur) 1 else -1
        old?.onHide()
        val nw = pages[i]
        nw.root.animate().cancel()
        nw.root.visibility = View.VISIBLE
        if (old != null) {
            nw.root.alpha = 0f; nw.root.translationX = dir * ctx.dp(36f)
            nw.root.animate().alpha(1f).translationX(0f).setDuration(340).setInterpolator(DecelerateInterpolator(2f)).start()
            val o = old.root
            o.animate().cancel()
            o.animate().alpha(0f).translationX(-dir * ctx.dp(36f)).setDuration(200).withEndAction {
                if (pages[cur].root !== o) { o.visibility = View.GONE }
                o.translationX = 0f; o.alpha = 1f
            }.start()
        }
        cur = i
        for (k in icons.indices) {
            val on = k == i
            icons[k].on = on; labels[k].setTextColor(if (on) C.CYAN else C.SUB)
            if (on) { icons[k].scaleX = 0.7f; icons[k].scaleY = 0.7f; icons[k].animate().scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(OvershootInterpolator(3f)).start() }
        }
        val w = nav.width / 3
        pill.animate().translationX(i * w + ctx.dpi(6).toFloat()).setDuration(360).setInterpolator(OvershootInterpolator(1.1f)).start()
        if (Sh.granted()) nw.onShow()
        nw.intro()
    }

    override fun onResume() {
        super.onResume(); aurora.start()
        refresh()
    }

    override fun onPause() { super.onPause(); aurora.stop(); if (cur >= 0) pages[cur].onHide() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (cur == 1 && games.handleBack()) return
        @Suppress("DEPRECATION") super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onResult)
        } catch (e: Throwable) {}
    }
}

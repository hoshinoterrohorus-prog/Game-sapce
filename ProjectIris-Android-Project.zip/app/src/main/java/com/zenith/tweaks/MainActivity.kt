package com.zenith.tweaks

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.graphics.Rect
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.widget.Toast
import android.view.View
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var aurora: Aurora
    private lateinit var content: FrameLayout
    private lateinit var setup: LinearLayout
    private lateinit var setupMsg: TextView
    private lateinit var nav: FrameLayout
    private lateinit var navRow: LinearLayout
    private lateinit var pill: View
    private lateinit var dash: Dashboard
    private lateinit var games: GamesPage
    private lateinit var tweak: TweakPage
    private lateinit var pages: List<Page>
    private val icons = ArrayList<TabIcon>()
    private val labels = ArrayList<TextView>()
    private var cur = -1
    private var caps: Caps.Info? = null
    private var setupShown = true
    private lateinit var drawer: LinearLayout
    private lateinit var scrim: View
    private lateinit var drawerStatus: TextView
    private val navRows = ArrayList<LinearLayout>()
    private var drawerW = 0
    private var dprog = 0f
    private var dragging = false; private var candidate = false
    private var startX = 0f; private var startY = 0f; private var startP = 0f
    private var vt: VelocityTracker? = null
    private var drawerAnim: ValueAnimator? = null
    private var insTop = 0; private var insBot = 0

    private val onResult = Shizuku.OnRequestPermissionResultListener { _, _ -> mainHandler.post { refresh() } }
    private val onBinder = Shizuku.OnBinderReceivedListener { mainHandler.post { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { mainHandler.post { refresh() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.BG; window.navigationBarColor = C.BG
        val ctx: Context = this

        val root = FrameLayout(ctx)
        aurora = Aurora(ctx); root.addView(aurora, fl())

        val column = LinearLayout(ctx); column.orientation = LinearLayout.VERTICAL
        root.addView(column, fl())
        content = FrameLayout(ctx)
        column.addView(content, lp(-1, 0, weight = 1f))

        dash = Dashboard(ctx, { caps }, { animateDrawer(1f) }); games = GamesPage(ctx) { caps }; tweak = TweakPage(ctx) { caps }
        pages = listOf(dash, games, tweak)
        for (p in pages) { p.root.visibility = View.GONE; content.addView(p.root, fl()) }

        // ----- bilah navigasi melayang -----
        nav = FrameLayout(ctx)
        nav.background = rr(C.CARD, ctx.dp(20f), C.STROKE)
        pill = View(ctx); pill.background = rr(C.FILL, ctx.dp(14f))
        nav.addView(pill, FrameLayout.LayoutParams(0, ctx.dpi(56)).also { it.gravity = Gravity.CENTER_VERTICAL })
        navRow = LinearLayout(ctx); navRow.orientation = LinearLayout.HORIZONTAL
        nav.addView(navRow, FrameLayout.LayoutParams(-1, -2).also { it.gravity = Gravity.CENTER_VERTICAL })
        val names = listOf("Dashboard", "Game", "Tweak")
        for (i in names.indices) {
            val tab = LinearLayout(ctx); tab.orientation = LinearLayout.VERTICAL; tab.gravity = Gravity.CENTER
            tab.setPadding(0, ctx.dpi(8), 0, ctx.dpi(8))
            val ic = TabIcon(ctx, i); tab.addView(ic, lp(ctx.dpi(24), ctx.dpi(24)))
            val t = ctx.text(names[i], 11f, C.SUB, true); t.gravity = Gravity.CENTER; tab.addView(t, lp(top = ctx.dpi(2)))
            tab.press(0.92f); tab.setOnClickListener { select(i) }
            icons.add(ic); labels.add(t); navRow.addView(tab, lp(0, -2, weight = 1f))
        }
        column.addView(nav, lp(-1, -2).also { it.setMargins(ctx.dpi(16), ctx.dpi(4), ctx.dpi(16), ctx.dpi(10)) })

        drawerW = minOf(ctx.dpi(300), (resources.displayMetrics.widthPixels * 0.82f).toInt())
        scrim = View(ctx); scrim.setBackgroundColor(0xB3000000.toInt()); scrim.visibility = View.GONE; scrim.alpha = 0f
        scrim.setOnClickListener { animateDrawer(0f) }
        root.addView(scrim, fl())
        drawer = buildDrawer(); drawer.visibility = View.GONE
        root.addView(drawer, FrameLayout.LayoutParams(drawerW, -1))
        setDrawer(0f)

        setup = buildSetup(); root.addView(setup, fl())
        setContentView(root)

        column.setOnApplyWindowInsetsListener { v, ins ->
            val top: Int; val bot: Int
            if (Build.VERSION.SDK_INT >= 30) { val s = ins.getInsets(WindowInsets.Type.systemBars()); top = s.top; bot = s.bottom }
            else { @Suppress("DEPRECATION") top = ins.systemWindowInsetTop; @Suppress("DEPRECATION") bot = ins.systemWindowInsetBottom }
            v.setPadding(0, top, 0, bot); insTop = top; insBot = bot
            drawer.setPadding(ctx.dpi(18), top + ctx.dpi(22), ctx.dpi(18), bot + ctx.dpi(18))
            setup.setPadding(ctx.dpi(24), top + ctx.dpi(24), ctx.dpi(24), bot + ctx.dpi(24))
            ins
        }
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        else @Suppress("DEPRECATION") run { window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION }

        if (Build.VERSION.SDK_INT >= 29) root.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            v.systemGestureExclusionRects = listOf(Rect(0, v.height / 4, ctx.dpi(36), minOf(v.height, v.height / 4 + ctx.dpi(190))))
        }
        nav.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val w = (r - l - 0) / 3
            val lpp = pill.layoutParams as FrameLayout.LayoutParams
            if (lpp.width != w - ctx.dpi(12)) { lpp.width = w - ctx.dpi(12); pill.layoutParams = lpp }
            if (cur >= 0) pill.translationX = cur * w + ctx.dpi(6).toFloat()
        }

        try {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onResult)
        } catch (e: Throwable) {}
        select(0)
    }

    // ---------- menu samping ----------
    private fun buildDrawer(): LinearLayout {
        val ctx: Context = this
        val d = LinearLayout(ctx); d.orientation = LinearLayout.VERTICAL
        d.setBackgroundColor(C.BG2); d.elevation = ctx.dp(16f); d.isClickable = true

        val head = LinearLayout(ctx); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Logo(ctx), lp(ctx.dpi(78), ctx.dpi(78)))
        val nm = LinearLayout(ctx); nm.orientation = LinearLayout.VERTICAL
        nm.addView(ctx.text("Project Iris", 20f, C.TEXT, true))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
        nm.addView(ctx.text("versi $ver", 12f, C.SUB))
        head.addView(nm, lp(0, -2, weight = 1f).also { it.leftMargin = ctx.dpi(4) })
        d.addView(head, lp(bottom = ctx.dpi(10)))

        drawerStatus = ctx.text("", 12f, C.SUB)
        drawerStatus.background = rr(C.CARD, ctx.dp(12f), C.STROKE); drawerStatus.setPadding(ctx.dpi(12), ctx.dpi(10), ctx.dpi(12), ctx.dpi(10))
        d.addView(drawerStatus, lp(bottom = ctx.dpi(18)))

        d.addView(ctx.label("Menu utama"), lp(bottom = ctx.dpi(8)))
        val names = listOf("Dashboard", "Game & Aplikasi", "Tweak")
        for (i in names.indices) {
            val row = menuRow(names[i], i) { animateDrawer(0f); select(i) }
            navRows.add(row); d.addView(row, lp(bottom = ctx.dpi(4)))
        }

        d.addView(View(ctx).also { it.setBackgroundColor(C.STROKE) }, lp(-1, ctx.dpi(1), top = ctx.dpi(12), bottom = ctx.dpi(12)))
        d.addView(ctx.label("Lainnya"), lp(bottom = ctx.dpi(8)))
        d.addView(menuRow("Buka Shizuku", -1, "↗") { animateDrawer(0f); openShizuku() }, lp(bottom = ctx.dpi(4)))
        d.addView(menuRow("Reset semua profil game", -1, "↺") { confirmResetAll() }, lp(bottom = ctx.dpi(4)))
        d.addView(menuRow("Tentang", -1, "i") { showAbout() }, lp(bottom = ctx.dpi(4)))
        d.addView(View(ctx), lp(-1, 0, weight = 1f))
        d.addView(ctx.text("Semua pengaturan memakai perintah sistem resmi lewat Shizuku dan bisa di-reset.", 11f, C.SUB))
        return d
    }

    private fun menuRow(label: String, navIndex: Int, glyph: String = "", click: () -> Unit): LinearLayout {
        val ctx: Context = this
        val r = LinearLayout(ctx); r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(ctx.dpi(12), ctx.dpi(12), ctx.dpi(12), ctx.dpi(12))
        if (navIndex >= 0) { val ic = TabIcon(ctx, navIndex); ic.on = false; r.addView(ic, lp(ctx.dpi(24), ctx.dpi(24))) }
        else { val g = ctx.text(glyph, 17f, C.SUB, true); g.gravity = Gravity.CENTER; r.addView(g, lp(ctx.dpi(24), ctx.dpi(24))) }
        r.addView(ctx.text(label, 15f, C.TEXT, true), lp().also { it.leftMargin = ctx.dpi(14) })
        r.press(0.97f); r.setOnClickListener { click() }
        return r
    }

    private fun confirmResetAll() {
        val n = Store.allProfiles(this).size
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Reset semua profil?")
            .setMessage(if (n == 0) "Belum ada profil game yang tersimpan." else "$n game akan dikembalikan ke pengaturan bawaan (downscale, FPS, renderer, driver). Game-nya dihentikan paksa.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Reset") { _, _ ->
                animateDrawer(0f)
                val list = Store.allProfiles(this)
                if (list.isEmpty() || !Sh.granted()) { Toast.makeText(this, "Tidak ada yang direset / Shizuku belum siap", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                Sh.bg {
                    for (p in list) Tweaks.reset(p, caps)
                    mainHandler.post { Store.clearProfiles(this); Toast.makeText(this, "${list.size} game direset ke bawaan", Toast.LENGTH_LONG).show() }
                }
            }.show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Project Iris")
            .setMessage("Alat tweak per game lewat Shizuku: downscale, batas FPS, Game Mode, renderer, driver GPU, dan dashboard sistem.\n\nHasil bergantung pada HP dan game. Kalau ada yang bermasalah, pakai Reset per game atau “Reset semua profil”.")
            .setPositiveButton("Tutup", null).show()
    }

    private fun updateDrawerStatus() {
        val (txt, col) = when {
            Sh.granted() -> "● Shizuku aktif  •  API v${Sh.version()}  •  uid ${Sh.uid()}" to C.GREEN
            Sh.alive() -> "● Shizuku aktif, belum diberi izin" to C.AMBER
            else -> "● Shizuku belum berjalan" to C.RED
        }
        drawerStatus.text = txt; drawerStatus.setTextColor(col)
        for (k in navRows.indices) navRows[k].background = if (k == cur) rr(C.FILL, ctx().dp(12f)) else null
    }
    private fun ctx(): Context = this

    private fun setDrawer(p: Float) {
        dprog = p
        drawer.translationX = -(1f - p) * drawerW
        scrim.alpha = p
        val vis = if (p > 0.001f) View.VISIBLE else View.GONE
        if (scrim.visibility != vis) { scrim.visibility = vis; drawer.visibility = vis }
    }

    private fun animateDrawer(to: Float) {
        drawerAnim?.cancel()
        if (to > 0f) updateDrawerStatus()
        val a = ValueAnimator.ofFloat(dprog, to)
        a.duration = (300 * Math.abs(to - dprog) + 100).toLong()
        a.interpolator = DecelerateInterpolator(2f)
        a.addUpdateListener { setDrawer(it.animatedValue as Float) }
        drawerAnim = a; a.start()
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = e.x; startY = e.y; startP = dprog; dragging = false
                candidate = (dprog == 0f && e.x < ctx().dpi(60)) || dprog > 0.99f
                vt?.recycle(); vt = VelocityTracker.obtain(); vt!!.addMovement(e)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (candidate && !dragging) {
                    val dx = e.x - startX; val dy = e.y - startY
                    val slop = ViewConfiguration.get(this).scaledTouchSlop
                    val dirOk = if (startP < 0.5f) dx > 0 else dx < 0
                    if (dirOk && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.4f) {
                        dragging = true; drawerAnim?.cancel()
                        val c = MotionEvent.obtain(e); c.action = MotionEvent.ACTION_CANCEL
                        super.dispatchTouchEvent(c); c.recycle()
                    }
                }
                if (dragging) { setDrawer((startP + (e.x - startX) / drawerW).coerceIn(0f, 1f)); return true }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    vt?.addMovement(e); vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    dragging = false; candidate = false; vt?.recycle(); vt = null
                    val to = if (vx > 900f) 1f else if (vx < -900f) 0f else if (dprog > 0.5f) 1f else 0f
                    if (to > 0f) updateDrawerStatus()
                    animateDrawer(to)
                    return true
                }
                candidate = false; vt?.recycle(); vt = null
            }
        }
        return super.dispatchTouchEvent(e)
    }

    private fun buildSetup(): LinearLayout {
        val ctx: Context = this
        val l = LinearLayout(ctx); l.orientation = LinearLayout.VERTICAL; l.gravity = Gravity.CENTER
        l.setBackgroundColor(C.BG); l.setPadding(ctx.dpi(24), ctx.dpi(24), ctx.dpi(24), ctx.dpi(24))
        l.isClickable = true
        l.addView(Logo(ctx), lp(ctx.dpi(150), ctx.dpi(150)))
        val t = ctx.title("Project Iris"); t.gravity = Gravity.CENTER; l.addView(t, lp(bottom = ctx.dpi(8)))
        setupMsg = ctx.text("", 14f, C.SUB); setupMsg.gravity = Gravity.CENTER; l.addView(setupMsg, lp(bottom = ctx.dpi(24)))
        l.addView(ctx.button("Buka Shizuku") { openShizuku() }, lp(bottom = ctx.dpi(10)))
        l.addView(ctx.button("Beri izin ke Iris", false) { askPermission() }, lp(bottom = ctx.dpi(10)))
        l.addView(ctx.button("Cek ulang", false) { refresh() }, lp())
        return l
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) startActivity(i)
        else try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))) } catch (e: Exception) {}
    }

    private fun askPermission() {
        try {
            if (!Sh.alive()) { refresh(); return }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                setupMsg.text = "Izin sebelumnya ditolak. Buka aplikasi Shizuku → Aplikasi terotorisasi → aktifkan Project Iris."
            } else Shizuku.requestPermission(1)
        } catch (e: Throwable) { refresh() }
    }

    private fun showSetup(show: Boolean) {
        if (show == setupShown) return
        setupShown = show
        if (show) { setup.visibility = View.VISIBLE; setup.alpha = 0f; setup.animate().alpha(1f).setDuration(300).start() }
        else setup.animate().alpha(0f).setDuration(380).withEndAction { if (setupShown == false) setup.visibility = View.GONE }.start()
    }

    private fun refresh() {
        val ready = Sh.granted()
        if (ready) {
            showSetup(false)
            if (caps == null) Sh.async(Caps.SCRIPT, 15) { r -> caps = Caps.parse(r.out); dash.bindCaps(caps!!) }
            if (cur >= 0) pages[cur].onShow()
        } else {
            showSetup(true)
            setupMsg.text = when {
                !Sh.alive() -> "Shizuku belum berjalan.\n\nPasang aplikasi Shizuku, jalankan lewat Wireless debugging (atau root), lalu kembali ke sini."
                else -> "Shizuku aktif. Iris butuh izin untuk menjalankan perintah sistem."
            }
        }
    }

    private fun select(i: Int) {
        if (cur == i) return
        val ctx: Context = this
        val old = if (cur >= 0) pages[cur] else null
        val dir = if (cur < 0 || i > cur) 1 else -1
        old?.onHide()
        val nw = pages[i]
        nw.root.animate().cancel()
        nw.root.visibility = View.VISIBLE
        if (old != null) {
            nw.root.alpha = 0f; nw.root.translationX = dir * ctx.dp(36f)
            nw.root.animate().alpha(1f).translationX(0f).setDuration(340).setInterpolator(DecelerateInterpolator(2f)).start()
            val o = old.root
            o.animate().cancel()
            o.animate().alpha(0f).translationX(-dir * ctx.dp(36f)).setDuration(200).withEndAction {
                if (pages[cur].root !== o) { o.visibility = View.GONE }
                o.translationX = 0f; o.alpha = 1f
            }.start()
        }
        cur = i
        for (k in icons.indices) {
            val on = k == i
            icons[k].on = on; labels[k].setTextColor(if (on) C.CYAN else C.SUB)
            if (on) { icons[k].scaleX = 0.7f; icons[k].scaleY = 0.7f; icons[k].animate().scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(OvershootInterpolator(3f)).start() }
        }
        val w = nav.width / 3
        pill.animate().translationX(i * w + ctx.dpi(6).toFloat()).setDuration(360).setInterpolator(OvershootInterpolator(1.1f)).start()
        if (Sh.granted()) nw.onShow()
        nw.intro()
    }

    override fun onResume() {
        super.onResume(); aurora.start()
        refresh()
    }

    override fun onPause() { super.onPause(); aurora.stop(); if (cur >= 0) pages[cur].onHide() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (dprog > 0f) { animateDrawer(0f); return }
        if (cur == 1 && games.handleBack()) return
        @Suppress("DEPRECATION") super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onResult)
        } catch (e: Throwable) {}
    }
}

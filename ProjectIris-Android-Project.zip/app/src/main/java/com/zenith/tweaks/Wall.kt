package com.zenith.tweaks

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import java.io.File

/** Latar belakang aplikasi: foto atau video pilihan pengguna, dengan lapisan gelap agar teks terbaca. */
class WallView(ctx: Context) : FrameLayout(ctx) {
    private val img = ImageView(ctx)
    private val dimV = View(ctx)
    private var tv: TextureView? = null
    private var mp: MediaPlayer? = null
    private var vw = 0; private var vh = 0
    private var started = false

    init {
        setBackgroundColor(C.BG)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(img, LayoutParams(-1, -1)); addView(dimV, LayoutParams(-1, -1))
        setDim(Prefs.dim)
    }

    fun setDim(pct: Int) { dimV.setBackgroundColor(Color.argb((pct.coerceIn(0, 95) * 255) / 100, 0, 0, 0)) }

    fun load(type: String) {
        release()
        val f = File(context.filesDir, if (type == "video") "wall.mp4" else "wall.jpg")
        if (type.isEmpty() || !f.exists()) return
        if (type == "image") {
            try {
                val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(f.path, o)
                var ss = 1; while (o.outHeight / ss > 1800) ss *= 2
                val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
                img.setImageBitmap(BitmapFactory.decodeFile(f.path, o2))
            } catch (e: Throwable) {}
        } else {
            val t = TextureView(context)
            tv = t
            addView(t, 0, LayoutParams(-1, -1))
            t.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { play(f, st) }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { fit() }
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { stopPlayer(); return true }
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
        }
    }

    private fun play(f: File, st: SurfaceTexture) {
        try {
            val m = MediaPlayer()
            m.setDataSource(f.path)
            m.setSurface(Surface(st))
            m.isLooping = true
            m.setVolume(0f, 0f)
            m.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; fit() }
            m.setOnPreparedListener { it.start(); started = true }
            m.setOnErrorListener { _, _, _ -> true }
            m.prepareAsync()
            mp = m
        } catch (e: Throwable) {}
    }

    /** Isi layar penuh dengan crop tengah. */
    private fun fit() {
        val t = tv ?: return
        val w = t.width.toFloat(); val h = t.height.toFloat()
        if (w <= 0f || h <= 0f || vw <= 0 || vh <= 0) return
        val s = maxOf(w / vw, h / vh)
        val m = Matrix(); m.setScale(vw * s / w, vh * s / h, w / 2, h / 2)
        t.setTransform(m)
    }

    fun pause() { try { if (started) mp?.pause() } catch (e: Throwable) {} }
    fun resume() { try { if (started) mp?.start() } catch (e: Throwable) {} }

    private fun stopPlayer() { try { mp?.release() } catch (e: Throwable) {}; mp = null; started = false }

    fun release() {
        stopPlayer()
        tv?.let { removeView(it) }; tv = null
        img.setImageDrawable(null)
    }
}

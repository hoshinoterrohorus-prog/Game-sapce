package com.zenith.tweaks

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.view.View

/** Deteksi chipset HP (tanpa perlu Shizuku) + gambar chip buatan sendiri. */
object Chipset {
    class Info(val vendorKey: String, val vendor: String, val name: String, val code: String, val short: String, val gpu: String, val cores: Int)

    private fun prop(k: String): String = try {
        val c = Class.forName("android.os.SystemProperties")
        (c.getMethod("get", String::class.java).invoke(null, k) as? String) ?: ""
    } catch (e: Throwable) { "" }

    // kode platform (huruf kecil) -> nama pemasaran
    private val NAMES = mapOf(
        // Qualcomm
        "sun" to "Snapdragon 8 Elite", "sm8750" to "Snapdragon 8 Elite",
        "pineapple" to "Snapdragon 8 Gen 3", "sm8650" to "Snapdragon 8 Gen 3",
        "kalama" to "Snapdragon 8 Gen 2", "sm8550" to "Snapdragon 8 Gen 2",
        "taro" to "Snapdragon 8 Gen 1", "sm8450" to "Snapdragon 8 Gen 1",
        "sm8475" to "Snapdragon 8+ Gen 1",
        "lahaina" to "Snapdragon 888", "sm8350" to "Snapdragon 888",
        "kona" to "Snapdragon 865", "sm8250" to "Snapdragon 865",
        "msmnile" to "Snapdragon 855", "sm8150" to "Snapdragon 855",
        "sdm845" to "Snapdragon 845", "sdm710" to "Snapdragon 710",
        "lito" to "Snapdragon 765G", "sm7250" to "Snapdragon 765G",
        "holi" to "Snapdragon 480", "sm4350" to "Snapdragon 480",
        // MediaTek
        "mt6989" to "Dimensity 9300", "mt6985" to "Dimensity 9200", "mt6983" to "Dimensity 9000",
        "mt6893" to "Dimensity 1200", "mt6891" to "Dimensity 1100", "mt6877" to "Dimensity 900",
        "mt6853" to "Dimensity 720", "mt6833" to "Dimensity 700",
        "mt6785" to "Helio G90 series", "mt6769" to "Helio G85 series", "mt6789" to "Helio G99 / G100 family",
        "mt6781" to "Helio G96", "mt6765" to "Helio P35 / G35",
        // Samsung Exynos
        "s5e9945" to "Exynos 2400", "s5e9925" to "Exynos 2200", "universal2100" to "Exynos 2100",
        "s5e8825" to "Exynos 1280", "universal9825" to "Exynos 9825",
        // Google Tensor
        "gs101" to "Tensor G1", "gs201" to "Tensor G2", "zuma" to "Tensor G3", "zumapro" to "Tensor G4",
        // Unisoc
        "ums512" to "Unisoc T618"
    )

    private fun vendorOf(code: String, man: String): String {
        val c = code.lowercase(); val m = man.lowercase()
        return when {
            m.contains("mediatek") || c.startsWith("mt") -> "mediatek"
            m.contains("qualcomm") || c.startsWith("sm") || c.startsWith("sdm") || c.startsWith("msm") || c.startsWith("qcom") ||
                c in listOf("lahaina", "kona", "taro", "kalama", "pineapple", "sun", "msmnile", "lito", "holi", "bengal", "trinket", "atoll") -> "qualcomm"
            c.startsWith("s5e") || c.startsWith("exynos") || c.startsWith("universal") || m.contains("samsung") -> "exynos"
            c.startsWith("gs1") || c.startsWith("gs2") || c.startsWith("zuma") || m.contains("google") -> "tensor"
            c.startsWith("kirin") || c.startsWith("hi3") || c.startsWith("hi6") -> "kirin"
            c.startsWith("ums") || c.startsWith("sc9") || c.startsWith("sp9") || m.contains("unisoc") || m.contains("spreadtrum") -> "unisoc"
            else -> "generic"
        }
    }

    private val VENDOR = mapOf("qualcomm" to "Qualcomm", "mediatek" to "MediaTek", "exynos" to "Samsung", "tensor" to "Google", "kirin" to "HiSilicon", "unisoc" to "Unisoc", "generic" to "")

    fun detect(caps: Caps.Info?, override: String = ""): Info {
        val plat = (caps?.kv?.get("soc")?.takeIf { it.isNotBlank() } ?: prop("ro.board.platform")).lowercase()
        val model = (if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else "").lowercase()
        val man = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER else ""
        val hw = Build.HARDWARE.lowercase()
        val code = listOf(plat, model, hw).firstOrNull { it.isNotBlank() && it != "unknown" } ?: "?"
        val nm = NAMES[plat] ?: NAMES[model] ?: NAMES[hw]
        val vk = vendorOf(if (plat.isNotBlank()) plat else if (model.isNotBlank()) model else hw, man)
        val name = if (override.isNotBlank()) override.trim() else nm ?: (if (model.isNotBlank() && model != "unknown") model.uppercase() else code.uppercase())
        val short = Regex("(G\\d+|\\d{3,4}\\+?|T\\d{3})").findAll(name).lastOrNull()?.value ?: code.uppercase().take(6)
        val gles = caps?.kv?.get("gles") ?: ""
        val gpu = gles.substringAfter("GLES:", "").split(",").getOrNull(1)?.trim() ?: ""
        return Info(vk, VENDOR[vk] ?: "", name, code, short, gpu, Runtime.getRuntime().availableProcessors())
    }
}

/** Gambar chip sederhana (bukan logo merek): badan, kaki, dan label singkat. */
class ChipArt(ctx: Context, val vendorKey: String, val label: String) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accent = when (vendorKey) {
        "qualcomm" -> 0xFFE57F84.toInt(); "mediatek" -> 0xFFE6B567.toInt(); "exynos" -> 0xFF86B7F0.toInt()
        "tensor" -> 0xFF8FD1C4.toInt(); "kirin" -> 0xFFE06A78.toInt(); "unisoc" -> 0xFFC3A4DD.toInt(); else -> C.CYAN
    }
    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat(); val ox = (width - s) / 2f; val oy = (height - s) / 2f
        c.save(); c.translate(ox, oy)
        val b = RectF(s * 0.2f, s * 0.2f, s * 0.8f, s * 0.8f)
        p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.035f; p.strokeCap = Paint.Cap.ROUND; p.color = accent
        for (i in 0..3) {
            val t = s * (0.32f + i * 0.12f)
            c.drawLine(t, s * 0.08f, t, s * 0.2f, p); c.drawLine(t, s * 0.8f, t, s * 0.92f, p)
            c.drawLine(s * 0.08f, t, s * 0.2f, t, p); c.drawLine(s * 0.8f, t, s * 0.92f, t, p)
        }
        p.style = Paint.Style.FILL; p.color = C.FILL; c.drawRoundRect(b, s * 0.1f, s * 0.1f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.03f; p.color = accent; c.drawRoundRect(b, s * 0.1f, s * 0.1f, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.color = C.TEXT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = if (label.length <= 4) s * 0.26f else s * 0.19f
        c.drawText(label, s / 2, s * 0.5f + p.textSize * 0.34f, p)
        c.restore()
    }
}

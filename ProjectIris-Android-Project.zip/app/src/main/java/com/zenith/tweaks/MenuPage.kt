package com.zenith.tweaks

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Halaman Menu: pengaturan aplikasi, bahasa, Shizuku, data. */
class MenuPage(val act: Activity, val caps: () -> Caps.Info?, val openShizuku: () -> Unit, val askPermission: () -> Unit) : Page {
    private val ctx: Context = act
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    override val root get() = scroll
    private val tStatus = ctx.text("", 13f, C.SUB)

    private fun row(c: LinearLayout, items: List<Triple<String, Boolean, () -> Unit>>) {
        val r = LinearLayout(ctx); r.orientation = LinearLayout.HORIZONTAL
        for ((l, on, f) in items) r.addView(ctx.chip(l, on, f), lp(-2, -2).also { it.rightMargin = ctx.dpi(8) })
        c.addView(r, lp(top = ctx.dpi(10)))
    }

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(8), ctx.dpi(16), ctx.dpi(28))
        scroll.addView(col, fl(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        build()
    }

    private val bannerFile get() = java.io.File(ctx.filesDir, "banner.jpg")

    /** Halaman Menu: banner gambar pilihan sendiri + kartu chipset yang menyesuaikan HP. */
    private fun build() {
        col.removeAllViews()
        col.setPadding(ctx.dpi(16), ctx.dpi(16), ctx.dpi(16), ctx.dpi(28))

        // ----- Banner -----
        val bf = bannerFile
        val bmp = if (bf.exists()) try {
            val o = android.graphics.BitmapFactory.Options(); o.inJustDecodeBounds = true
            android.graphics.BitmapFactory.decodeFile(bf.path, o)
            var ss = 1; while (o.outWidth / ss > 1400) ss *= 2
            val o2 = android.graphics.BitmapFactory.Options(); o2.inSampleSize = ss
            android.graphics.BitmapFactory.decodeFile(bf.path, o2)
        } catch (e: Throwable) { null } else null
        val bannerH = ctx.dpi(200)
        if (bmp != null) {
            val iv = android.widget.ImageView(ctx); iv.setImageBitmap(bmp)
            iv.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            iv.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: android.view.View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, ctx.dp(20f)) }
            }
            iv.clipToOutline = true
            iv.press(0.98f)
            iv.setOnClickListener { pick() }
            iv.setOnLongClickListener { bannerFile.delete(); Toast.makeText(ctx, if (Prefs.en) "Banner removed" else "Banner dihapus", Toast.LENGTH_SHORT).show(); build(); true }
            col.addView(iv, lp(-1, bannerH, bottom = ctx.dpi(6)))
            col.addView(ctx.text(if (Prefs.en) "Tap to change • long-press to remove" else "Ketuk untuk ganti • tahan lama untuk hapus", 10f, C.SUB), lp(bottom = ctx.dpi(14)))
        } else {
            val ph = LinearLayout(ctx); ph.orientation = LinearLayout.VERTICAL; ph.gravity = Gravity.CENTER
            ph.background = rr(C.CARD, ctx.dp(20f), C.STROKE)
            ph.addView(ctx.text("＋", 34f, C.CYAN, true).also { it.gravity = Gravity.CENTER })
            ph.addView(ctx.text(if (Prefs.en) "Tap to choose your banner image" else "Ketuk untuk pilih gambar banner", 14f, C.TEXT, true).also { it.gravity = Gravity.CENTER }, lp(top = ctx.dpi(4)))
            ph.addView(ctx.text(if (Prefs.en) "Use your own picture. It stays on this phone." else "Pakai gambarmu sendiri. Disimpan hanya di HP ini.", 11f, C.SUB).also { it.gravity = Gravity.CENTER }, lp(top = ctx.dpi(2)))
            ph.press(0.98f); ph.setOnClickListener { pick() }
            col.addView(ph, lp(-1, bannerH, bottom = ctx.dpi(14)))
        }

        // ----- Chipset -----
        val ci = Chipset.detect(caps())
        val card = ctx.card()
        val row = LinearLayout(ctx); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        val own = ctx.resources.getIdentifier("chip_" + ci.vendorKey, "drawable", ctx.packageName)
        if (own != 0) {
            val iv = android.widget.ImageView(ctx); iv.setImageResource(own); iv.scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            row.addView(iv, lp(ctx.dpi(104), ctx.dpi(104)))
        } else row.addView(ChipArt(ctx, ci.vendorKey, ci.short), lp(ctx.dpi(104), ctx.dpi(104)))
        val info = LinearLayout(ctx); info.orientation = LinearLayout.VERTICAL
        info.addView(ctx.label("Chipset"))
        info.addView(ctx.text(ci.name, 20f, C.TEXT, true), lp(top = ctx.dpi(2)))
        val sub = (if (ci.vendor.isNotEmpty()) ci.vendor + "  •  " else "") + ci.code
        info.addView(ctx.text(sub, 12f, C.SUB), lp(top = ctx.dpi(2)))
        info.addView(ctx.text("${ci.cores} core" + (if (ci.gpu.isNotEmpty()) "  •  ${ci.gpu}" else ""), 12f, C.SUB), lp(top = ctx.dpi(6)))
        row.addView(info, lp(0, -2, weight = 1f).also { it.leftMargin = ctx.dpi(10) })
        card.addView(row)
        col.addView(card)
        card.enter(0, 12f)
    }

    private fun pick() {
        val i = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE); i.type = "image/*"
        try { act.startActivityForResult(i, 77) } catch (e: Throwable) { Toast.makeText(ctx, "Tidak bisa membuka pemilih gambar", Toast.LENGTH_SHORT).show() }
    }

    /** Dipanggil dari MainActivity setelah gambar dipilih. Disalin ke penyimpanan aplikasi. */
    fun onPicked(uri: android.net.Uri) {
        Sh.bg {
            try {
                val o = android.graphics.BitmapFactory.Options(); o.inJustDecodeBounds = true
                act.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
                var ss = 1; while (o.outWidth / ss > 1600) ss *= 2
                val o2 = android.graphics.BitmapFactory.Options(); o2.inSampleSize = ss
                val bm = act.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
                if (bm != null) {
                    bannerFile.outputStream().use { bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
                    mainHandler.post { build() }
                }
            } catch (e: Throwable) {
                mainHandler.post { Toast.makeText(ctx, "Gagal memuat gambar", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    fun refreshChip() { build() }

    @Suppress("unused")
    private fun buildFull() {
        col.removeAllViews()
        col.addView(ctx.title("Menu"))
        col.addView(ctx.text("Pengaturan, bahasa, dan info aplikasi", 13f, C.SUB), lp(bottom = ctx.dpi(12)))

        // Profil aplikasi
        val p = ctx.card()
        val h = LinearLayout(ctx); h.orientation = LinearLayout.HORIZONTAL; h.gravity = Gravity.CENTER_VERTICAL
        h.addView(Logo(ctx), lp(ctx.dpi(84), ctx.dpi(84)))
        val nm = LinearLayout(ctx); nm.orientation = LinearLayout.VERTICAL
        nm.addView(ctx.text("Project Iris", 20f, C.TEXT, true))
        val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "" }
        nm.addView(ctx.text("v$ver", 12f, C.SUB))
        nm.addView(tStatus, lp(top = ctx.dpi(4)))
        h.addView(nm, lp(0, -2, weight = 1f).also { it.leftMargin = ctx.dpi(4) })
        p.addView(h)
        col.addView(p, lp(bottom = ctx.dpi(12)))

        // Bahasa
        val l = ctx.card()
        l.addView(ctx.label("Bahasa"))
        row(l, listOf(
            Triple("Indonesia", !Prefs.en) { if (Prefs.en) { Prefs.setLang(ctx, false); act.recreate() } },
            Triple("English", Prefs.en) { if (!Prefs.en) { Prefs.setLang(ctx, true); act.recreate() } }
        ))
        l.addView(ctx.text("Pilihan bahasa berlaku untuk label dan teks tetap; pesan log sistem tetap apa adanya.", 11f, C.SUB), lp(top = ctx.dpi(8)))
        col.addView(l, lp(bottom = ctx.dpi(12)))

        // Tampilan
        val d = ctx.card()
        d.addView(ctx.label("Tampilan"))
        d.addView(ctx.text("Animasi", 14f, C.TEXT, true), lp(top = ctx.dpi(8)))
        row(d, listOf(
            Triple("Nyala", Prefs.anim) { Prefs.setAnim(ctx, true); buildFull() },
            Triple("Mati", !Prefs.anim) { Prefs.setAnim(ctx, false); buildFull() }
        ))
        d.addView(ctx.text("Kecepatan dashboard", 14f, C.TEXT, true), lp(top = ctx.dpi(14)))
        row(d, listOf(
            Triple("Cepat (1 dtk)", Prefs.interval == 1000L) { Prefs.setInterval(ctx, 1000L); buildFull() },
            Triple("Normal (2 dtk)", Prefs.interval == 2000L) { Prefs.setInterval(ctx, 2000L); buildFull() },
            Triple("Hemat (4 dtk)", Prefs.interval == 4000L) { Prefs.setInterval(ctx, 4000L); buildFull() }
        ))
        d.addView(ctx.text("Interval pembaruan data. Lebih lambat = lebih hemat baterai.", 11f, C.SUB), lp(top = ctx.dpi(8)))
        col.addView(d, lp(bottom = ctx.dpi(12)))

        // Shizuku
        val s = ctx.card()
        s.addView(ctx.label("Shizuku"))
        s.addView(ctx.button("Buka Shizuku", false) { openShizuku() }, lp(top = ctx.dpi(10)))
        s.addView(ctx.button("Beri izin ke Iris", false) { askPermission() }, lp(top = ctx.dpi(8)))
        col.addView(s, lp(bottom = ctx.dpi(12)))

        // Data
        val x = ctx.card()
        x.addView(ctx.label("Data & profil"))
        x.addView(ctx.button("Reset semua profil game", false) { confirmResetAll() }, lp(top = ctx.dpi(10)))
        x.addView(ctx.button("Tentang", false) { showAbout() }, lp(top = ctx.dpi(8)))
        col.addView(x)
        updateStatus()
    }

    private fun updateStatus() {
        val (txt, c) = when {
            Sh.granted() -> "● Shizuku v${Sh.version()} • uid ${Sh.uid()}" to C.GREEN
            Sh.alive() -> (if (Prefs.en) "● Shizuku running, no permission" else "● Shizuku aktif, belum diberi izin") to C.AMBER
            else -> (if (Prefs.en) "● Shizuku not running" else "● Shizuku belum berjalan") to C.RED
        }
        tStatus.text = txt; tStatus.setTextColor(c)
    }

    private fun confirmResetAll() {
        val n = Store.allProfiles(ctx).size
        val en = Prefs.en
        AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(Lang.tr("Reset semua profil?"))
            .setMessage(if (n == 0) Lang.tr("Belum ada profil game yang tersimpan.") else if (en) "$n game(s) will be restored to default (downscale, FPS, renderer, driver). The games are force-stopped." else "$n game akan dikembalikan ke pengaturan bawaan (downscale, FPS, renderer, driver). Game-nya dihentikan paksa.")
            .setNegativeButton(Lang.tr("Batal"), null)
            .setPositiveButton(Lang.tr("Reset")) { _, _ ->
                val list = Store.allProfiles(ctx)
                if (list.isEmpty() || !Sh.granted()) { Toast.makeText(ctx, if (en) "Nothing to reset / Shizuku not ready" else "Tidak ada yang direset / Shizuku belum siap", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                Sh.bg {
                    for (p in list) Tweaks.reset(p, caps())
                    mainHandler.post { Store.clearProfiles(ctx); Toast.makeText(ctx, if (en) "${list.size} game(s) reset" else "${list.size} game direset ke bawaan", Toast.LENGTH_LONG).show() }
                }
            }.show()
    }

    private fun showAbout() {
        AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Project Iris")
            .setMessage(Lang.tr("Alat tweak per game lewat Shizuku: downscale, batas FPS, Game Mode, renderer, driver GPU, dan dashboard sistem.\n\nHasil bergantung pada HP dan game. Kalau ada yang bermasalah, pakai Reset per game atau “Reset semua profil”."))
            .setPositiveButton(Lang.tr("Tutup"), null).show()
    }

    override fun onShow() { }
    override fun onHide() {}
    override fun intro() { col.stagger(70, 4) }
}

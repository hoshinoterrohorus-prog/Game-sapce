package com.zenith.tweaks

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Halaman Menu: pengaturan aplikasi, bahasa, Shizuku, data. */
class MenuPage(val act: Activity, val caps: () -> Caps.Info?, val openShizuku: () -> Unit, val askPermission: () -> Unit) : Page {
    private val ctx: Context = act
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    override val root get() = scroll
    private val tStatus = ctx.text("", 13f, C.SUB)

    private fun row(c: LinearLayout, items: List<Triple<String, Boolean, () -> Unit>>) {
        val r = LinearLayout(ctx); r.orientation = LinearLayout.HORIZONTAL
        for ((l, on, f) in items) r.addView(ctx.chip(l, on, f), lp(-2, -2).also { it.rightMargin = ctx.dpi(8) })
        c.addView(r, lp(top = ctx.dpi(10)))
    }

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(8), ctx.dpi(16), ctx.dpi(28))
        scroll.addView(col, fl(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        build()
    }

    private fun build() {
        col.removeAllViews()
        col.addView(ctx.title("Menu"))
        col.addView(ctx.text("Pengaturan, bahasa, dan info aplikasi", 13f, C.SUB), lp(bottom = ctx.dpi(12)))

        // Profil aplikasi
        val p = ctx.card()
        val h = LinearLayout(ctx); h.orientation = LinearLayout.HORIZONTAL; h.gravity = Gravity.CENTER_VERTICAL
        h.addView(Logo(ctx), lp(ctx.dpi(84), ctx.dpi(84)))
        val nm = LinearLayout(ctx); nm.orientation = LinearLayout.VERTICAL
        nm.addView(ctx.text("Project Iris", 20f, C.TEXT, true))
        val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "" }
        nm.addView(ctx.text("v$ver", 12f, C.SUB))
        nm.addView(tStatus, lp(top = ctx.dpi(4)))
        h.addView(nm, lp(0, -2, weight = 1f).also { it.leftMargin = ctx.dpi(4) })
        p.addView(h)
        col.addView(p, lp(bottom = ctx.dpi(12)))

        // Bahasa
        val l = ctx.card()
        l.addView(ctx.label("Bahasa"))
        row(l, listOf(
            Triple("Indonesia", !Prefs.en) { if (Prefs.en) { Prefs.setLang(ctx, false); act.recreate() } },
            Triple("English", Prefs.en) { if (!Prefs.en) { Prefs.setLang(ctx, true); act.recreate() } }
        ))
        l.addView(ctx.text("Pilihan bahasa berlaku untuk label dan teks tetap; pesan log sistem tetap apa adanya.", 11f, C.SUB), lp(top = ctx.dpi(8)))
        col.addView(l, lp(bottom = ctx.dpi(12)))

        // Tampilan
        val d = ctx.card()
        d.addView(ctx.label("Tampilan"))
        d.addView(ctx.text("Animasi", 14f, C.TEXT, true), lp(top = ctx.dpi(8)))
        row(d, listOf(
            Triple("Nyala", Prefs.anim) { Prefs.setAnim(ctx, true); build() },
            Triple("Mati", !Prefs.anim) { Prefs.setAnim(ctx, false); build() }
        ))
        d.addView(ctx.text("Kecepatan dashboard", 14f, C.TEXT, true), lp(top = ctx.dpi(14)))
        row(d, listOf(
            Triple("Cepat (1 dtk)", Prefs.interval == 1000L) { Prefs.setInterval(ctx, 1000L); build() },
            Triple("Normal (2 dtk)", Prefs.interval == 2000L) { Prefs.setInterval(ctx, 2000L); build() },
            Triple("Hemat (4 dtk)", Prefs.interval == 4000L) { Prefs.setInterval(ctx, 4000L); build() }
        ))
        d.addView(ctx.text("Interval pembaruan data. Lebih lambat = lebih hemat baterai.", 11f, C.SUB), lp(top = ctx.dpi(8)))
        col.addView(d, lp(bottom = ctx.dpi(12)))

        // Shizuku
        val s = ctx.card()
        s.addView(ctx.label("Shizuku"))
        s.addView(ctx.button("Buka Shizuku", false) { openShizuku() }, lp(top = ctx.dpi(10)))
        s.addView(ctx.button("Beri izin ke Iris", false) { askPermission() }, lp(top = ctx.dpi(8)))
        col.addView(s, lp(bottom = ctx.dpi(12)))

        // Data
        val x = ctx.card()
        x.addView(ctx.label("Data & profil"))
        x.addView(ctx.button("Reset semua profil game", false) { confirmResetAll() }, lp(top = ctx.dpi(10)))
        x.addView(ctx.button("Tentang", false) { showAbout() }, lp(top = ctx.dpi(8)))
        col.addView(x)
        updateStatus()
    }

    private fun updateStatus() {
        val (txt, c) = when {
            Sh.granted() -> "● Shizuku v${Sh.version()} • uid ${Sh.uid()}" to C.GREEN
            Sh.alive() -> (if (Prefs.en) "● Shizuku running, no permission" else "● Shizuku aktif, belum diberi izin") to C.AMBER
            else -> (if (Prefs.en) "● Shizuku not running" else "● Shizuku belum berjalan") to C.RED
        }
        tStatus.text = txt; tStatus.setTextColor(c)
    }

    private fun confirmResetAll() {
        val n = Store.allProfiles(ctx).size
        val en = Prefs.en
        AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(Lang.tr("Reset semua profil?"))
            .setMessage(if (n == 0) Lang.tr("Belum ada profil game yang tersimpan.") else if (en) "$n game(s) will be restored to default (downscale, FPS, renderer, driver). The games are force-stopped." else "$n game akan dikembalikan ke pengaturan bawaan (downscale, FPS, renderer, driver). Game-nya dihentikan paksa.")
            .setNegativeButton(Lang.tr("Batal"), null)
            .setPositiveButton(Lang.tr("Reset")) { _, _ ->
                val list = Store.allProfiles(ctx)
                if (list.isEmpty() || !Sh.granted()) { Toast.makeText(ctx, if (en) "Nothing to reset / Shizuku not ready" else "Tidak ada yang direset / Shizuku belum siap", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                Sh.bg {
                    for (p in list) Tweaks.reset(p, caps())
                    mainHandler.post { Store.clearProfiles(ctx); Toast.makeText(ctx, if (en) "${list.size} game(s) reset" else "${list.size} game direset ke bawaan", Toast.LENGTH_LONG).show() }
                }
            }.show()
    }

    private fun showAbout() {
        AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Project Iris")
            .setMessage(Lang.tr("Alat tweak per game lewat Shizuku: downscale, batas FPS, Game Mode, renderer, driver GPU, dan dashboard sistem.\n\nHasil bergantung pada HP dan game. Kalau ada yang bermasalah, pakai Reset per game atau “Reset semua profil”."))
            .setPositiveButton(Lang.tr("Tutup"), null).show()
    }

    override fun onShow() { updateStatus() }
    override fun onHide() {}
    override fun intro() { col.stagger(55, 8) }
}

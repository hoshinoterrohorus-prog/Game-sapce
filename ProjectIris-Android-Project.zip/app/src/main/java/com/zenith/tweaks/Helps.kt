package com.zenith.tweaks

import android.app.AlertDialog
import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Info bantuan per fitur: fungsi, versi Android, catatan. */
class Help(
    val minSdk: Int, val minName: String,
    val fnId: String, val fnEn: String,
    val noteId: String, val noteEn: String
)

object Helps {
    val RENDER_UI = Help(29, "10",
        "Mengganti mesin gambar (Skia GL / Skia Vulkan) untuk tampilan UI aplikasi yang dibuka sesudahnya.",
        "Switches the UI drawing engine (Skia GL / Skia Vulkan) for apps opened afterwards.",
        "Skia Vulkan butuh GPU yang mendukung Vulkan. Berlaku global dan hilang saat HP restart. Beberapa ROM mengabaikannya.",
        "Skia Vulkan needs a Vulkan-capable GPU. Global, and lost on reboot. Some ROMs ignore it.")
    val COMPOSE = Help(21, "5",
        "Mengatur cara sistem menggabungkan lapisan layar: lewat hardware (HWC) atau digabung GPU.",
        "Controls how the system combines screen layers: via hardware (HWC) or by the GPU.",
        "Di Android versi baru (termasuk Android 16 di HP kamu) saklar ini sering ditolak sistem dengan “Operation not permitted”. Latch unsignaled biasanya baru dibaca saat sistem menyala.",
        "On newer Android (including Android 16 on your phone) this switch is often rejected with “Operation not permitted”. Latch unsignaled is usually only read at boot.")
    val RES = Help(18, "4.3",
        "Menurunkan resolusi seluruh layar HP. Otomatis kembali dalam 15 detik kalau tidak disimpan.",
        "Lowers the resolution of the whole phone screen. Reverts automatically after 15 seconds unless kept.",
        "Berlaku untuk seluruh HP, bukan per game. Untuk per game pakai downscale di tab Game.",
        "Applies to the whole phone, not per game. For per-game, use downscale in the Game tab.")
    val HZ = Help(29, "10",
        "Memaksa refresh rate layar (60/90/120 Hz).",
        "Forces the screen refresh rate (60/90/120 Hz).",
        "Hanya pilihan yang dimiliki layarmu yang bisa dipakai. Beberapa ROM punya pengaturan sendiri yang menimpa ini.",
        "Only rates your panel supports will work. Some ROMs have their own setting that overrides this.")
    val ANIM = Help(18, "4.3",
        "Mengatur kecepatan animasi sistem (jendela, transisi, durasi).",
        "Sets the system animation speed (window, transition, duration).",
        "Sama dengan opsi di Pengaturan Pengembang. Berlaku global.",
        "Same as the Developer options entries. Global.")
    val TERM = Help(26, "8",
        "Menjalankan perintah shell dengan hak akses Shizuku (setara adb shell).",
        "Runs shell commands with Shizuku privileges (like adb shell).",
        "Hati-hati: perintah yang salah bisa mengubah pengaturan sistem. Tidak punya akses root kecuali Shizuku dijalankan lewat root.",
        "Careful: wrong commands can change system settings. No root access unless Shizuku runs via root.")
    val DIAG = Help(26, "8",
        "Memeriksa fitur apa yang kemungkinan didukung HP ini (Game Mode, ANGLE, driver).",
        "Checks which features this phone likely supports (Game Mode, ANGLE, driver).",
        "Hasilnya perkiraan dari pembacaan sistem, bukan jaminan fitur pasti berpengaruh.",
        "Results are estimates from system readings, not a guarantee a feature will have an effect.")

    // ---- per game ----
    val DOWNSCALE = Help(33, "13",
        "Menurunkan resolusi render hanya untuk game ini (0.3 paling kasar sampai 1.0 asli). Biasanya menaikkan FPS.",
        "Lowers render resolution for this game only (0.3 roughest up to 1.0 original). Usually raises FPS.",
        "Memakai Game Mode bawaan Android. Aplikasi harus terdaftar sebagai game. Buka ulang game setelah menerapkan. Perkiraan versi; tergantung ROM.",
        "Uses Android's built-in Game Mode. The app must be registered as a game. Reopen the game after applying. Version is an estimate; ROM-dependent.")
    val FPS = Help(33, "13",
        "Membatasi atau menetapkan FPS maksimum untuk game ini.",
        "Caps or sets the maximum FPS for this game.",
        "Memakai Game Mode. Efeknya bergantung game dan layar. Perkiraan versi; tergantung ROM.",
        "Uses Game Mode. The effect depends on the game and display. Version is an estimate; ROM-dependent.")
    val MODE = Help(31, "12",
        "Memilih Game Mode game ini: Standar, Performa, atau Hemat.",
        "Picks this game's Game Mode: Standard, Performance or Battery saver.",
        "Downscale dan FPS hanya dipakai dari mode yang aktif, jadi Iris ikut mengaktifkan mode saat menerapkan.",
        "Downscale and FPS apply only from the active mode, so Iris also activates the mode when applying.")
    val ANGLE = Help(29, "10",
        "Memilih driver OpenGL ES untuk game ini: ANGLE (di atas Vulkan) atau GL native bawaan GPU.",
        "Chooses the OpenGL ES driver for this game: ANGLE (on top of Vulkan) or the GPU's native GL.",
        "Butuh paket ANGLE di HP. Hanya game OpenGL ES yang terpengaruh. Cek di Tweak → Cek kemampuan HP.",
        "Needs the ANGLE package on the phone. Only OpenGL ES games are affected. Check in Tweak → Check phone capabilities.")
    val UI = Help(29, "10",
        "Memilih Skia GL atau Skia Vulkan untuk tampilan UI game ini, dipasang sementara saat dibuka lewat Iris.",
        "Chooses Skia GL or Skia Vulkan for this game's UI, set temporarily when launched via Iris.",
        "Mesin game (Unity/Unreal) memilih API grafisnya sendiri, jadi efeknya hanya ke UI Android-nya.",
        "The game engine (Unity/Unreal) picks its own graphics API, so this only affects the Android UI.")
    val DRIVER = Help(29, "10",
        "Memilih driver GPU untuk game ini: sistem, driver update, atau pra-rilis.",
        "Chooses the GPU driver for this game: system, updated or prerelease.",
        "Butuh paket driver dari vendor yang terpasang. Di banyak HP (terutama MediaTek) tidak ada, jadi tidak berpengaruh.",
        "Needs a vendor driver package installed. Many phones (especially MediaTek) don't have one, so there's no effect.")

    fun show(ctx: Context, title: String, h: Help) {
        val en = Prefs.en
        val ok = Build.VERSION.SDK_INT >= h.minSdk
        val sb = StringBuilder()
        sb.append(if (en) "What it does\n" else "Fungsinya\n").append(if (en) h.fnEn else h.fnId)
        sb.append(if (en) "\n\nAndroid support\n" else "\n\nDukungan Android\n")
        sb.append(if (en) "Android ${h.minName} or newer (estimate)" else "Android ${h.minName} ke atas (perkiraan)")
        sb.append(if (en) "\nYour phone: Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) — " else "\nHP kamu: Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) — ")
        sb.append(if (ok) (if (en) "meets the version requirement ✓" else "memenuhi syarat versi ✓") else (if (en) "below the requirement ✗" else "di bawah syarat ✗"))
        sb.append(if (en) "\n\nNotes\n" else "\n\nCatatan\n").append(if (en) h.noteEn else h.noteId)
        sb.append(if (en) "\n\nMeeting the version doesn't guarantee it works; it depends on the ROM and hardware." else "\n\nMemenuhi versi belum menjamin berfungsi; tergantung ROM dan hardware.")
        AlertDialog.Builder(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(Lang.tr(title)).setMessage(sb.toString()).setPositiveButton(Lang.tr("Tutup"), null).show()
    }
}

/** Baris judul + tombol "?" bulat kecil. */
fun Context.headRow(title: TextView, name: String, h: Help): LinearLayout {
    val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
    r.addView(title, LinearLayout.LayoutParams(-2, -2))
    val q = TextView(this); q.text = "?"; q.textSize = 12f; q.gravity = Gravity.CENTER
    q.setTextColor(C.CYAN); q.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    q.background = rr(0x00000000, dp(11f), C.CYAN)
    val lpq = LinearLayout.LayoutParams(dpi(22), dpi(22)); lpq.leftMargin = dpi(10)
    r.addView(q, lpq)
    q.press(0.85f)
    q.setOnClickListener { Helps.show(this, name, h) }
    return r
}

package com.zenith.tweaks

import android.content.Context
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.widget.EditText
import android.widget.TextView
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView

/** Halaman Tools: kumpulan alat kecil. */
class ToolsPage(val ctx: Context) : Page {
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    override val root get() = scroll

    private val HELP_TIKTOK = Help(21, "5",
        "Membuka TikTok versi web di dalam aplikasi dengan tampilan situs desktop (layar lebar), bukan tampilan HP.",
        "Opens TikTok's website inside the app using the desktop layout (wide screen) instead of the mobile one.",
        "Butuh internet. TikTok bisa meminta login atau captcha, dan sebagian fitur web mungkin dibatasi di dalam WebView. Tidak ada jaminan semuanya jalan. Bisa pindah ke mode mobile lewat tombol di bilah atas.",
        "Needs internet. TikTok may ask for login or a captcha, and some web features may be limited inside a WebView. No guarantee everything works. You can switch to mobile mode from the top bar.")


    private val HELP_DL = Help(21, "5",
        "Mengunduh video TikTok (MP4), suaranya (MP3), atau foto dari postingan foto, lewat link. Video/audio disimpan ke Download/ProjectIris, foto ke Pictures/ProjectIris.",
        "Downloads a TikTok video (MP4), its sound (MP3), or photos from a photo post via link. Video/audio go to Download/ProjectIris, photos to Pictures/ProjectIris.",
        "Butuh internet. Cara kerjanya membaca halaman publik TikTok, jadi bisa berhenti bekerja kalau TikTok mengubah halamannya atau membatasi video tertentu. Video privat tidak bisa diunduh. Audio disimpan sebagai MP3 kalau server memberi MP3, kalau tidak sebagai M4A. Hanya untuk simpanan pribadi; hormati hak cipta dan pembuat video.",
        "Needs internet. It reads TikTok's public page, so it can stop working if TikTok changes the page or restricts a video. Private videos can't be downloaded. Audio is saved as MP3 if the server gives MP3, otherwise as M4A. For personal use only; respect copyright and creators.")
    private var busy = false

    private var player: android.widget.VideoView? = null

    private fun downloader() {
        val act = ctx as Activity
        val en = Prefs.en
        val c = ctx.card()
        c.addView(ctx.headRow(ctx.text("Unduh TikTok (MP4 / MP3)", 16f, C.TEXT, true), "Unduh TikTok (MP4 / MP3)", HELP_DL))
        c.addView(ctx.text(if (en) "Paste a TikTok link, preview it, then choose video or audio." else "Tempel link TikTok, lihat pratinjau, lalu pilih video atau audio.", 12f, C.SUB), lp(top = ctx.dpi(4)))
        val et = EditText(ctx); et.hint = "https://vm.tiktok.com/…"
        et.setHintTextColor(C.SUB); et.setTextColor(C.TEXT); et.textSize = 13f; et.setSingleLine(true)
        et.background = rr(C.FILL, ctx.dp(12f), C.STROKE)
        et.setPadding(ctx.dpi(12), ctx.dpi(10), ctx.dpi(12), ctx.dpi(10))
        c.addView(et, lp(top = ctx.dpi(10)))

        // ----- pratinjau -----
        val pv = LinearLayout(ctx); pv.orientation = LinearLayout.VERTICAL; pv.visibility = android.view.View.GONE
        val box = android.widget.FrameLayout(ctx)
        box.setBackgroundColor(0xFF000000.toInt())
        box.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: android.view.View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, ctx.dp(16f)) }
        }
        box.clipToOutline = true
        val cover = android.widget.ImageView(ctx); cover.scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        box.addView(cover, fl())
        val vv = android.widget.VideoView(ctx)
        vv.visibility = android.view.View.GONE
        box.addView(vv, android.widget.FrameLayout.LayoutParams(-1, -1).also { it.gravity = Gravity.CENTER })
        player = vv
        val playBtn = ctx.text("▶", 34f, C.TEXT, true); playBtn.gravity = Gravity.CENTER
        playBtn.background = rr(0x99000000.toInt(), ctx.dp(34f))
        box.addView(playBtn, android.widget.FrameLayout.LayoutParams(ctx.dpi(68), ctx.dpi(68)).also { it.gravity = Gravity.CENTER })
        pv.addView(box, lp(-1, ctx.dpi(360)))
        val info = ctx.text("", 12f, C.TEXT); info.maxLines = 3
        val grid = LinearLayout(ctx); grid.orientation = LinearLayout.VERTICAL; grid.visibility = android.view.View.GONE
        pv.addView(grid, lp(top = ctx.dpi(4)))
        pv.addView(info, lp(top = ctx.dpi(8)))
        c.addView(pv, lp(top = ctx.dpi(12)))

        var cached: Pair<String, TikTokDl.Meta>? = null
        var shownFor = ""
        var videoUrl = ""
        var started = false
        playBtn.setOnClickListener {
            if (videoUrl.isBlank()) return@setOnClickListener
            vv.visibility = android.view.View.VISIBLE
            if (!started) {
                started = true
                try {
                    vv.setVideoURI(Uri.parse(videoUrl), TikTokDl.headersFor(videoUrl))
                    vv.setOnPreparedListener { mp -> mp.isLooping = true; vv.start(); playBtn.visibility = android.view.View.GONE; cover.visibility = android.view.View.GONE }
                    vv.setOnErrorListener { _, _, _ -> started = false; vv.visibility = android.view.View.GONE; playBtn.visibility = android.view.View.VISIBLE; cover.visibility = android.view.View.VISIBLE
                        info.text = (if (en) "Can't play the preview here, but the download may still work." else "Pratinjau tidak bisa diputar di sini, tapi unduhan mungkin masih bisa."); true }
                } catch (e: Throwable) { started = false }
            } else vv.start()
        }
        vv.setOnClickListener { if (vv.isPlaying) { vv.pause(); playBtn.visibility = android.view.View.VISIBLE } else { vv.start(); playBtn.visibility = android.view.View.GONE } }

        var doGo: (Boolean) -> Unit = {}
        var doImages: (Boolean) -> Unit = {}
        val mp4Btn = ctx.button("MP4") { doGo(false) }
        val mp3Btn = ctx.button("MP3") { doGo(true) }
        val selBtn = ctx.button("", false) { doImages(false) }
        val allBtn = ctx.button(if (en) "All photos" else "Semua foto") { doImages(true) }
        val r3 = LinearLayout(ctx); r3.orientation = LinearLayout.HORIZONTAL; r3.visibility = android.view.View.GONE
        r3.addView(selBtn, lp(0, -2, weight = 1f).also { it.rightMargin = ctx.dpi(8) })
        r3.addView(allBtn, lp(0, -2, weight = 1f))
        var sel = BooleanArray(0)
        fun refreshSel() { val n = sel.count { it }; selBtn.text = (if (en) "Selected ($n)" else "Terpilih ($n)"); selBtn.alpha = if (n > 0) 1f else 0.5f }

        fun buildGrid(url: String, m: TikTokDl.Meta) {
            grid.removeAllViews()
            val cell = (ctx.resources.displayMetrics.widthPixels - ctx.dpi(64)) / 3 - ctx.dpi(6)
            var row: LinearLayout? = null
            for (i in m.images.indices) {
                if (i % 3 == 0) { row = LinearLayout(ctx); row.orientation = LinearLayout.HORIZONTAL; grid.addView(row, lp(bottom = ctx.dpi(6))) }
                val f = android.widget.FrameLayout(ctx); f.setBackgroundColor(C.FILL)
                val iv = android.widget.ImageView(ctx); iv.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                f.addView(iv, fl())
                val shade = android.view.View(ctx); shade.setBackgroundColor(0x00000000); f.addView(shade, fl())
                val mark = ctx.text("", 14f, C.ON, true); mark.gravity = Gravity.CENTER
                f.addView(mark, android.widget.FrameLayout.LayoutParams(ctx.dpi(24), ctx.dpi(24)).also { it.gravity = Gravity.TOP or Gravity.END; it.setMargins(0, ctx.dpi(6), ctx.dpi(6), 0) })
                fun paint() { mark.text = if (sel[i]) "✓" else ""; mark.background = if (sel[i]) rr(C.CYAN, ctx.dp(12f)) else rr(0x66000000, ctx.dp(12f), 0xFFFFFFFF.toInt()); shade.setBackgroundColor(if (sel[i]) 0x33000000 else 0x00000000) }
                paint()
                f.press(0.96f)
                f.setOnClickListener { sel[i] = !sel[i]; paint(); refreshSel() }
                val lpc = LinearLayout.LayoutParams(cell, cell); lpc.rightMargin = ctx.dpi(6)
                row!!.addView(f, lpc)
                Thread {
                    val bm = TikTokDl.fetchThumb(m.images[i])
                    if (bm != null) mainHandler.post { if (shownFor == url) iv.setImageBitmap(bm) }
                }.start()
            }
        }

        fun showPreview(url: String, m: TikTokDl.Meta) {
            if (shownFor == url) return
            shownFor = url; started = false; videoUrl = m.video
            vv.stopPlayback(); vv.visibility = android.view.View.GONE; cover.visibility = android.view.View.VISIBLE
            cover.setImageDrawable(null)
            playBtn.visibility = if (m.video.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            val dur = if (m.duration > 0) "  •  ${m.duration / 60}:%02d".format(m.duration % 60) else ""
            info.text = (if (m.author.isNotBlank()) "@${m.author}$dur\n" else if (dur.isNotEmpty()) dur.trim() + "\n" else "") + m.desc.take(160)
            val photo = m.images.isNotEmpty()
            sel = BooleanArray(m.images.size); refreshSel()
            box.visibility = if (photo) android.view.View.GONE else android.view.View.VISIBLE
            grid.visibility = if (photo) android.view.View.VISIBLE else android.view.View.GONE
            r3.visibility = if (photo) android.view.View.VISIBLE else android.view.View.GONE
            mp4Btn.visibility = if (photo && m.video.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            if (photo) buildGrid(url, m)
            pv.visibility = android.view.View.VISIBLE; pv.enter(0, 12f)
            if (!photo && m.cover.isNotBlank()) Thread {
                val bm = TikTokDl.fetchBitmap(m.cover)
                if (bm != null) mainHandler.post { if (shownFor == url) cover.setImageBitmap(bm) }
            }.start()
        }

        val status = ctx.text("", 12f, C.SUB); status.setTextIsSelectable(true)
        var lastSaved: TikTokDl.Saved? = null
        val openBtn = ctx.chip(if (en) "Open file" else "Buka file", false) {
            val s = lastSaved
            if (s?.uri != null) try {
                val i = Intent(Intent.ACTION_VIEW); i.setDataAndType(s.uri, s.mime); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                ctx.startActivity(i)
            } catch (e: Throwable) { status.text = (if (en) "No app can open this file." else "Tidak ada aplikasi untuk membuka file ini.") }
        }
        openBtn.visibility = android.view.View.GONE

        /** Ambil data video (dari cache kalau link sama), lalu panggil cb. */
        fun withMeta(url: String, cb: (TikTokDl.Meta) -> Unit) {
            val cc = cached
            if (cc != null && cc.first == url) { cb(cc.second); return }
            status.text = if (en) "Reading link…" else "Membaca link…"
            TikTokDl.resolve(act, url) { meta, err ->
                if (meta == null) { busy = false; status.text = err; return@resolve }
                cached = url to meta
                showPreview(url, meta)
                status.text = ""
                cb(meta)
            }
        }
        fun linkOrNull(): String? {
            val url = TikTokDl.extractUrl(et.text.toString())
            if (url == null || !TikTokDl.isTikTok(url)) { status.text = if (en) "Paste a valid TikTok link." else "Tempel link TikTok yang valid."; return null }
            return url
        }
        fun preview() {
            if (busy) return
            val url = linkOrNull() ?: return
            busy = true; openBtn.visibility = android.view.View.GONE
            withMeta(url) { busy = false }
        }
        fun go(audio: Boolean) {
            if (busy) return
            val url = linkOrNull() ?: return
            busy = true; openBtn.visibility = android.view.View.GONE
            withMeta(url) { meta ->
                val media = if (audio) meta.audio else meta.video
                if (media.isBlank()) { busy = false; status.text = if (audio) (if (en) "No audio link found." else "Link audio tidak ditemukan.") else (if (en) "No video link found." else "Link video tidak ditemukan."); return@withMeta }
                status.text = if (en) "Downloading…" else "Mengunduh…"
                Thread {
                    try {
                        val saved = TikTokDl.download(act, media, audio, meta) { p -> mainHandler.post { status.text = (if (en) "Downloading " else "Mengunduh ") + p + "%" } }
                        mainHandler.post {
                            busy = false; lastSaved = saved
                            status.text = (if (en) "Done. Saved to:\n" else "Selesai. Disimpan di:\n") + saved.where
                            if (saved.uri != null) openBtn.visibility = android.view.View.VISIBLE
                        }
                    } catch (e: Throwable) {
                        mainHandler.post { busy = false; status.text = (if (en) "Download failed: " else "Gagal mengunduh: ") + (e.message ?: e.javaClass.simpleName) }
                    }
                }.start()
            }
        }

        val r1 = LinearLayout(ctx); r1.orientation = LinearLayout.HORIZONTAL
        r1.addView(ctx.button(if (en) "Paste" else "Tempel", false) {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
            if (t.isNotBlank()) { et.setText(t); preview() }
        }, lp(0, -2, weight = 1f).also { it.rightMargin = ctx.dpi(8) })
        r1.addView(ctx.button(if (en) "Preview" else "Pratinjau", false) { preview() }, lp(0, -2, weight = 1f))
        c.addView(r1, lp(top = ctx.dpi(10)))
        val r2 = LinearLayout(ctx); r2.orientation = LinearLayout.HORIZONTAL
        r2.addView(mp4Btn, lp(0, -2, weight = 1f).also { it.rightMargin = ctx.dpi(8) })
        r2.addView(mp3Btn, lp(0, -2, weight = 1f))
        c.addView(r3, lp(top = ctx.dpi(8)))
        c.addView(r2, lp(top = ctx.dpi(8)))
        doGo = { go(it) }
        fun images(all: Boolean) {
            if (busy) return
            val m = cached?.second ?: return
            val idx = if (all) m.images.indices.toList() else sel.indices.filter { sel[it] }
            if (idx.isEmpty()) { status.text = if (en) "Select at least one photo." else "Pilih minimal satu foto."; return }
            busy = true; openBtn.visibility = android.view.View.GONE
            Thread {
                var last: TikTokDl.Saved? = null; var fail = 0
                for ((k, i) in idx.withIndex()) {
                    mainHandler.post { status.text = (if (en) "Downloading photo " else "Mengunduh foto ") + (k + 1) + "/" + idx.size }
                    try { last = TikTokDl.downloadImage(act, m.images[i], m, i) {} } catch (e: Throwable) { fail++ }
                }
                mainHandler.post {
                    busy = false; lastSaved = last
                    val ok = idx.size - fail
                    status.text = if (ok == 0) (if (en) "Download failed." else "Gagal mengunduh foto.")
                        else (if (en) "Done. $ok photo(s) saved to Pictures/ProjectIris" else "Selesai. $ok foto disimpan di Pictures/ProjectIris") + (if (fail > 0) (if (en) " ($fail failed)" else " ($fail gagal)") else "")
                    if (last?.uri != null) openBtn.visibility = android.view.View.VISIBLE
                }
            }.start()
        }
        doImages = { images(it) }
        c.addView(status, lp(top = ctx.dpi(10)))
        c.addView(openBtn, lp(-2, -2, top = ctx.dpi(8)))
        c.addView(ctx.text(if (en) "For personal use only. Respect copyright and don't repost without permission." else "Hanya untuk simpanan pribadi. Hormati hak cipta dan jangan unggah ulang tanpa izin.", 10f, C.SUB), lp(top = ctx.dpi(10)))
        col.addView(c, lp(bottom = ctx.dpi(12)))
    }

    private fun tool(title: String, desc: String, help: Help, action: String, go: () -> Unit) {
        val c = ctx.card()
        c.addView(ctx.headRow(ctx.text(title, 16f, C.TEXT, true), title, help))
        c.addView(ctx.text(desc, 12f, C.SUB), lp(top = ctx.dpi(4)))
        c.addView(ctx.button(action) { go() }, lp(top = ctx.dpi(12)))
        col.addView(c, lp(bottom = ctx.dpi(12)))
    }

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(16), ctx.dpi(16), ctx.dpi(28))
        scroll.addView(col, fl(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        col.addView(ctx.title("Tools"))
        col.addView(ctx.text("Alat kecil tambahan", 13f, C.SUB), lp(bottom = ctx.dpi(12)))

        tool("TikTok Web (Mode Desktop)", "Buka TikTok di dalam aplikasi dengan tampilan desktop. Bisa diputar ke landscape dan pindah ke mode mobile.", HELP_TIKTOK, "Buka") {
            val i = Intent(ctx, WebActivity::class.java)
            i.putExtra("url", "https://www.tiktok.com/"); i.putExtra("desktop", true)
            ctx.startActivity(i)
        }
        downloader()
    }

    override fun onShow() {}
    override fun onHide() { try { player?.pause() } catch (e: Throwable) {} }
    override fun intro() { col.stagger(60, 6) }
}

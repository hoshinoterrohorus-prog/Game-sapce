package com.zenith.tweaks

import android.content.Context
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.widget.EditText
import android.widget.TextView
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView

/** Halaman Tools: kumpulan alat kecil. */
class ToolsPage(val ctx: Context) : Page {
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    override val root get() = scroll

    private val HELP_TIKTOK = Help(21, "5",
        "Membuka TikTok versi web di dalam aplikasi dengan tampilan situs desktop (layar lebar), bukan tampilan HP.",
        "Opens TikTok's website inside the app using the desktop layout (wide screen) instead of the mobile one.",
        "Butuh internet. TikTok bisa meminta login atau captcha, dan sebagian fitur web mungkin dibatasi di dalam WebView. Tidak ada jaminan semuanya jalan. Bisa pindah ke mode mobile lewat tombol di bilah atas.",
        "Needs internet. TikTok may ask for login or a captcha, and some web features may be limited inside a WebView. No guarantee everything works. You can switch to mobile mode from the top bar.")


    private val HELP_DL = Help(21, "5",
        "Mengunduh video TikTok (MP4) atau suaranya (MP3) dari link, lalu menyimpannya ke Download/ProjectIris.",
        "Downloads a TikTok video (MP4) or its sound (MP3) from a link and saves it to Download/ProjectIris.",
        "Butuh internet. Cara kerjanya membaca halaman publik TikTok, jadi bisa berhenti bekerja kalau TikTok mengubah halamannya atau membatasi video tertentu. Video privat tidak bisa diunduh. Audio disimpan sebagai MP3 kalau server memberi MP3, kalau tidak sebagai M4A. Hanya untuk simpanan pribadi; hormati hak cipta dan pembuat video.",
        "Needs internet. It reads TikTok's public page, so it can stop working if TikTok changes the page or restricts a video. Private videos can't be downloaded. Audio is saved as MP3 if the server gives MP3, otherwise as M4A. For personal use only; respect copyright and creators.")
    private var busy = false

    private fun downloader() {
        val act = ctx as Activity
        val en = Prefs.en
        val c = ctx.card()
        c.addView(ctx.headRow(ctx.text("Unduh TikTok (MP4 / MP3)", 16f, C.TEXT, true), "Unduh TikTok (MP4 / MP3)", HELP_DL))
        c.addView(ctx.text(if (en) "Paste a TikTok link, then choose video or audio." else "Tempel link TikTok, lalu pilih video atau audio.", 12f, C.SUB), lp(top = ctx.dpi(4)))
        val et = EditText(ctx); et.hint = if (en) "https://vm.tiktok.com/…" else "https://vm.tiktok.com/…"
        et.setHintTextColor(C.SUB); et.setTextColor(C.TEXT); et.textSize = 13f; et.setSingleLine(true)
        et.background = rr(C.FILL, ctx.dp(12f), C.STROKE)
        et.setPadding(ctx.dpi(12), ctx.dpi(10), ctx.dpi(12), ctx.dpi(10))
        c.addView(et, lp(top = ctx.dpi(10)))
        val status = ctx.text("", 12f, C.SUB); status.setTextIsSelectable(true)
        var lastSaved: TikTokDl.Saved? = null
        val openBtn = ctx.chip(if (en) "Open file" else "Buka file", false) {
            val s = lastSaved
            if (s?.uri != null) try {
                val i = Intent(Intent.ACTION_VIEW); i.setDataAndType(s.uri, s.mime); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                ctx.startActivity(i)
            } catch (e: Throwable) { status.text = (if (en) "No app can open this file." else "Tidak ada aplikasi untuk membuka file ini.") }
        }
        openBtn.visibility = android.view.View.GONE

        fun go(audio: Boolean) {
            if (busy) return
            val url = TikTokDl.extractUrl(et.text.toString())
            if (url == null || !TikTokDl.isTikTok(url)) { status.text = if (en) "Paste a valid TikTok link." else "Tempel link TikTok yang valid."; return }
            busy = true; openBtn.visibility = android.view.View.GONE
            status.text = if (en) "Reading link…" else "Membaca link…"
            TikTokDl.resolve(act, url) { meta, err ->
                if (meta == null) { busy = false; status.text = err; return@resolve }
                val media = if (audio) meta.audio else meta.video
                if (media.isBlank()) { busy = false; status.text = if (audio) (if (en) "No audio link found." else "Link audio tidak ditemukan.") else (if (en) "No video link found." else "Link video tidak ditemukan."); return@resolve }
                status.text = if (en) "Downloading…" else "Mengunduh…"
                Thread {
                    try {
                        val saved = TikTokDl.download(act, media, audio, meta) { p -> mainHandler.post { status.text = (if (en) "Downloading " else "Mengunduh ") + p + "%" } }
                        mainHandler.post {
                            busy = false; lastSaved = saved
                            status.text = (if (en) "Done. Saved to:\n" else "Selesai. Disimpan di:\n") + saved.where
                            if (saved.uri != null) openBtn.visibility = android.view.View.VISIBLE
                        }
                    } catch (e: Throwable) {
                        mainHandler.post { busy = false; status.text = (if (en) "Download failed: " else "Gagal mengunduh: ") + (e.message ?: e.javaClass.simpleName) }
                    }
                }.start()
            }
        }

        val r = LinearLayout(ctx); r.orientation = LinearLayout.HORIZONTAL
        r.addView(ctx.button(if (en) "Paste" else "Tempel", false) {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
            if (t.isNotBlank()) et.setText(t)
        }, lp(0, -2, weight = 1f).also { it.rightMargin = ctx.dpi(8) })
        r.addView(ctx.button("MP4") { go(false) }, lp(0, -2, weight = 1f).also { it.rightMargin = ctx.dpi(8) })
        r.addView(ctx.button("MP3") { go(true) }, lp(0, -2, weight = 1f))
        c.addView(r, lp(top = ctx.dpi(10)))
        c.addView(status, lp(top = ctx.dpi(10)))
        c.addView(openBtn, lp(-2, -2, top = ctx.dpi(8)))
        c.addView(ctx.text(if (en) "For personal use only. Respect copyright and don't repost without permission." else "Hanya untuk simpanan pribadi. Hormati hak cipta dan jangan unggah ulang tanpa izin.", 10f, C.SUB), lp(top = ctx.dpi(10)))
        col.addView(c, lp(bottom = ctx.dpi(12)))
    }

    private fun tool(title: String, desc: String, help: Help, action: String, go: () -> Unit) {
        val c = ctx.card()
        c.addView(ctx.headRow(ctx.text(title, 16f, C.TEXT, true), title, help))
        c.addView(ctx.text(desc, 12f, C.SUB), lp(top = ctx.dpi(4)))
        c.addView(ctx.button(action) { go() }, lp(top = ctx.dpi(12)))
        col.addView(c, lp(bottom = ctx.dpi(12)))
    }

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(16), ctx.dpi(16), ctx.dpi(28))
        scroll.addView(col, fl(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        col.addView(ctx.title("Tools"))
        col.addView(ctx.text("Alat kecil tambahan", 13f, C.SUB), lp(bottom = ctx.dpi(12)))

        tool("TikTok Web (Mode Desktop)", "Buka TikTok di dalam aplikasi dengan tampilan desktop. Bisa diputar ke landscape dan pindah ke mode mobile.", HELP_TIKTOK, "Buka") {
            val i = Intent(ctx, WebActivity::class.java)
            i.putExtra("url", "https://www.tiktok.com/"); i.putExtra("desktop", true)
            ctx.startActivity(i)
        }
        downloader()
    }

    override fun onShow() {}
    override fun onHide() {}
    override fun intro() { col.stagger(60, 6) }
}

package com.zenith.tweaks

import android.content.Context
import android.content.Intent
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView

/** Halaman Tools: kumpulan alat kecil. */
class ToolsPage(val ctx: Context) : Page {
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    override val root get() = scroll

    private val HELP_TIKTOK = Help(21, "5",
        "Membuka TikTok versi web di dalam aplikasi dengan tampilan situs desktop (layar lebar), bukan tampilan HP.",
        "Opens TikTok's website inside the app using the desktop layout (wide screen) instead of the mobile one.",
        "Butuh internet. TikTok bisa meminta login atau captcha, dan sebagian fitur web mungkin dibatasi di dalam WebView. Tidak ada jaminan semuanya jalan. Bisa pindah ke mode mobile lewat tombol di bilah atas.",
        "Needs internet. TikTok may ask for login or a captcha, and some web features may be limited inside a WebView. No guarantee everything works. You can switch to mobile mode from the top bar.")

    private fun tool(title: String, desc: String, help: Help, action: String, go: () -> Unit) {
        val c = ctx.card()
        c.addView(ctx.headRow(ctx.text(title, 16f, C.TEXT, true), title, help))
        c.addView(ctx.text(desc, 12f, C.SUB), lp(top = ctx.dpi(4)))
        c.addView(ctx.button(action) { go() }, lp(top = ctx.dpi(12)))
        col.addView(c, lp(bottom = ctx.dpi(12)))
    }

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dpi(16), ctx.dpi(16), ctx.dpi(16), ctx.dpi(28))
        scroll.addView(col, fl(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        col.addView(ctx.title("Tools"))
        col.addView(ctx.text("Alat kecil tambahan", 13f, C.SUB), lp(bottom = ctx.dpi(12)))

        tool("TikTok Web (Mode Desktop)", "Buka TikTok di dalam aplikasi dengan tampilan desktop. Bisa diputar ke landscape dan pindah ke mode mobile.", HELP_TIKTOK, "Buka") {
            val i = Intent(ctx, WebActivity::class.java)
            i.putExtra("url", "https://www.tiktok.com/"); i.putExtra("desktop", true)
            ctx.startActivity(i)
        }
    }

    override fun onShow() {}
    override fun onHide() {}
    override fun intro() { col.stagger(60, 6) }
}

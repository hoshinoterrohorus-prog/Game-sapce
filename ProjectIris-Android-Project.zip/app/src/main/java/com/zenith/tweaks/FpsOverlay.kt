package com.zenith.tweaks

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Pengaturan + hasil rekam untuk overlay FPS. */
object Ov {
    val KEYS = listOf(
        "ov_fps" to "Tampilkan FPS Counter (real-time)",
        "ov_cpu" to "Tampilkan clock speed CPU (MHz) + beban",
        "ov_gpu" to "Tampilkan clock speed GPU (MHz)",
        "ov_ram" to "Tampilkan pemakaian RAM (%)",
        "ov_bat" to "Tampilkan suhu baterai (°C)",
        "ov_soc" to "Tampilkan suhu thermal SoC (°C)"
    )
    private fun sp(c: Context) = c.getSharedPreferences("zt", Context.MODE_PRIVATE)
    fun on(c: Context, k: String) = sp(c).getBoolean(k, true)
    fun set(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    @Volatile var running = false
    @Volatile var recording = false
    @Volatile var result = ""
    var onChange: (() -> Unit)? = null

    val fpsLog = ArrayList<Float>()
    var tempStart = 0f; var tempMax = 0f; var recStart = 0L

    fun canDraw(c: Context) = Settings.canDrawOverlays(c)

    fun start(c: Context) {
        val i = Intent(c, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
    }
    fun stop(c: Context) { c.stopService(Intent(c, OverlayService::class.java)) }

    fun startRec() { synchronized(fpsLog) { fpsLog.clear() }; tempStart = 0f; tempMax = 0f; recStart = System.currentTimeMillis(); recording = true; result = "Merekam… main game dulu, lalu tekan Stop."; onChange?.invoke() }
    fun stopRec() {
        recording = false
        val l = synchronized(fpsLog) { ArrayList(fpsLog) }
        val sec = (System.currentTimeMillis() - recStart) / 1000
        result = if (l.size < 3) "Data terlalu sedikit (${l.size} sampel). Pastikan overlay menyala dan game berjalan di layar."
        else {
            val s = l.sorted(); val avg = l.average()
            val n = maxOf(1, (s.size * 0.01f).toInt().coerceAtLeast(1))
            val low = s.take(n).average()
            "Durasi: ${sec}s  •  sampel: ${l.size}\nFPS rata-rata: %.1f\nFPS min / max: %.0f / %.0f\n1%% Low: %.1f\nSuhu: %.1f → %.1f °C (naik %.1f)".format(avg, s.first(), s.last(), low, tempStart, tempMax, tempMax - tempStart)
        }
        onChange?.invoke()
    }
}

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var box: LinearLayout? = null
    private var tv: TextView? = null
    @Volatile private var alive = false
    private var pkg = ""

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (alive) return START_STICKY
        if (!Ov.canDraw(this)) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("ov", "Overlay FPS", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ov").setContentTitle("Project Iris").setContentText("Overlay FPS aktif")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(7, n)
        } catch (e: Throwable) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(WindowManager::class.java)
        val t = TextView(this); t.setTextColor(0xFFFFFFFF.toInt()); t.textSize = 11f; t.typeface = Typeface.MONOSPACE
        t.setShadowLayer(3f, 0f, 0f, 0xFF000000.toInt()); t.text = "Iris…"
        val b = LinearLayout(this); b.background = rr(0xB0000000.toInt(), dp(10f), 0x33FFFFFF)
        b.setPadding(dpi(10), dpi(7), dpi(10), dpi(7)); b.addView(t)
        val p = WindowManager.LayoutParams(-2, -2,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START; p.x = dpi(12); p.y = dpi(40)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                MotionEvent.ACTION_MOVE -> { p.x = ox + (e.rawX - sx).toInt(); p.y = oy + (e.rawY - sy).toInt(); try { wm?.updateViewLayout(b, p) } catch (x: Throwable) {} }
            }
            true
        }
        try { wm?.addView(b, p) } catch (e: Throwable) { stopSelf(); return START_NOT_STICKY }
        box = b; tv = t; alive = true; Ov.running = true; Ov.onChange?.invoke()
        Sh.bg { loop() }
        return START_STICKY
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun dpi(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun loop() {
        var tick = 0
        while (alive) {
            val t0 = System.currentTimeMillis()
            val fpsOn = Ov.on(this, "ov_fps") || Ov.recording
            var fps = -1f
            if (fpsOn) {
                if (tick % 4 == 0) { val f = Fps.foreground(); if (f.isNotBlank() && f != packageName && !f.contains("systemui")) pkg = f }
                fps = Fps.measure(pkg)
            }
            val s = Sys.parse(Sh.run(Sys.SCRIPT, 6).out)
            val lines = ArrayList<String>()
            if (Ov.on(this, "ov_fps")) lines.add("FPS  " + if (fps >= 0) "%.0f".format(fps) else "--")
            if (s != null) {
                if (Ov.on(this, "ov_cpu")) {
                    val mx = (s.freqKhz.maxOrNull() ?: 0L) / 1000
                    lines.add("CPU  $mx MHz · %.0f%%".format(Sys.cpuPct(s)))
                }
                if (Ov.on(this, "ov_gpu")) lines.add("GPU  " + if (s.gpuHz > 0) "${s.gpuHz / 1_000_000} MHz" else "N/A")
                if (Ov.on(this, "ov_ram") && s.memTotalKb > 0) lines.add("RAM  %.0f%%".format(100f * (s.memTotalKb - s.memAvailKb) / s.memTotalKb))
                if (Ov.on(this, "ov_bat")) lines.add("BAT  %.1f°C".format(s.battTempC))
                if (Ov.on(this, "ov_soc")) lines.add("SoC  " + if (s.cpuTempC > 0) "%.1f°C".format(s.cpuTempC) else "N/A")
                if (Ov.recording) {
                    val temp = if (s.cpuTempC > 0) s.cpuTempC else s.battTempC
                    if (Ov.tempStart == 0f) Ov.tempStart = temp
                    Ov.tempMax = maxOf(Ov.tempMax, temp)
                }
            }
            if (Ov.recording && fps >= 0) synchronized(Ov.fpsLog) { Ov.fpsLog.add(fps) }
            if (Ov.recording) lines.add("● REC")
            if (lines.isEmpty()) lines.add("Iris")
            val txt = lines.joinToString("\n")
            mainHandler.post { tv?.text = txt }
            tick++
            val left = 1000 - (System.currentTimeMillis() - t0)
            if (left > 0) try { Thread.sleep(left) } catch (e: Throwable) {}
        }
    }

    override fun onDestroy() {
        alive = false; Ov.running = false
        if (Ov.recording) Ov.stopRec()
        try { box?.let { wm?.removeView(it) } } catch (e: Throwable) {}
        box = null; Ov.onChange?.invoke()
        super.onDestroy()
    }
}

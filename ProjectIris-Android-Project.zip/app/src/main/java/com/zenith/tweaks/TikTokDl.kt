package com.zenith.tweaks

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Unduh video/audio TikTok dari link untuk simpanan pribadi.
 * Alurnya: buka halaman publik di WebView tersembunyi, baca data halaman, lalu unduh URL media yang sama
 * dengan yang dipakai pemutar web. Struktur halaman TikTok bisa berubah sewaktu-waktu.
 */
object TikTokDl {
    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

    class Meta(val video: String, val audio: String, val author: String, val id: String)
    class Saved(val uri: Uri?, val where: String, val mime: String)

    fun extractUrl(t: String): String? = Regex("https?://[^\\s]+").find(t)?.value?.trimEnd('.', ',', ')', '!', '”')

    fun isTikTok(u: String): Boolean = try {
        val h = (Uri.parse(u).host ?: "").lowercase(); h == "tiktok.com" || h.endsWith(".tiktok.com")
    } catch (e: Throwable) { false }

    private const val JS = "(function(){var e=document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__')||document.getElementById('SIGI_STATE');return e?e.textContent:''})()"

    /** Dipanggil di thread utama. cb(meta, pesanError). */
    @SuppressLint("SetJavaScriptEnabled")
    fun resolve(act: Activity, url: String, cb: (Meta?, String) -> Unit) {
        val wv = WebView(act)
        wv.alpha = 0f
        act.addContentView(wv, ViewGroup.LayoutParams(1, 1))
        val s = wv.settings
        s.javaScriptEnabled = true; s.domStorageEnabled = true; s.userAgentString = UA
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        var started = false; var tries = 0; var done = false
        val en = Prefs.en

        fun finish(m: Meta?, msg: String) {
            if (done) return
            done = true
            try { (wv.parent as? ViewGroup)?.removeView(wv); wv.destroy() } catch (e: Throwable) {}
            cb(m, msg)
        }

        lateinit var poll: () -> Unit
        poll = {
            if (!done) wv.evaluateJavascript(JS) { raw ->
                var diag = ""
                val str = try { JSONTokener(raw ?: "null").nextValue() as? String } catch (e: Throwable) { null }
                if (!str.isNullOrBlank()) {
                    try {
                        val root = JSONObject(str)
                        val scope = root.optJSONObject("__DEFAULT_SCOPE__")
                        val vd = scope?.optJSONObject("webapp.video-detail")
                        var item = vd?.optJSONObject("itemInfo")?.optJSONObject("itemStruct")
                        if (item == null) {
                            val im = root.optJSONObject("ItemModule")
                            if (im != null && im.keys().hasNext()) item = im.optJSONObject(im.keys().next())
                        }
                        if (item != null) {
                            if (item.has("downloadable") && !item.optBoolean("downloadable", true)) {
                                finish(null, if (en) "The creator disabled downloads for this video." else "Pembuat video menonaktifkan unduhan untuk video ini."); return@evaluateJavascript
                            }
                            val v = item.optJSONObject("video")
                            var play = v?.optString("playAddr").orEmpty()
                            if (play.isBlank()) {
                                val br = v?.optJSONArray("bitrateInfo")?.optJSONObject(0)?.optJSONObject("PlayAddr")?.optJSONArray("UrlList")
                                if (br != null && br.length() > 0) play = br.optString(0)
                            }
                            if (play.isBlank()) play = v?.optString("downloadAddr").orEmpty()
                            val aud = item.optJSONObject("music")?.optString("playUrl").orEmpty()
                            val author = item.optJSONObject("author")?.optString("uniqueId").orEmpty().ifBlank { item.optString("author") }
                            if (play.isNotBlank() || aud.isNotBlank()) { finish(Meta(play, aud, author, item.optString("id")), ""); return@evaluateJavascript }
                        }
                        val code = vd?.optInt("statusCode", 0) ?: 0
                        diag = if (code != 0) (if (en) "TikTok status $code (video unavailable/private?)" else "Status TikTok $code (video tidak tersedia / privat?)")
                               else "keys=" + (scope?.keys()?.asSequence()?.take(6)?.joinToString(",") ?: root.keys().asSequence().take(6).joinToString(","))
                    } catch (e: Throwable) { diag = e.javaClass.simpleName }
                }
                if (++tries > 20) finish(null, (if (en) "Couldn't read the video data. " else "Gagal membaca data video. ") + diag)
                else mainHandler.postDelayed({ poll() }, 700)
            }
        }
        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) {}
            override fun onPageFinished(v: WebView, u: String?) { if (!started) { started = true; poll() } }
        }
        wv.loadUrl(url)
        mainHandler.postDelayed({ if (!done && !started) { started = true; poll() } }, 8000)
    }

    private fun open(u: String): HttpURLConnection {
        var cur = u
        for (i in 0..5) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15000; c.readTimeout = 20000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Referer", "https://www.tiktok.com/")
            CookieManager.getInstance().getCookie(cur)?.let { c.setRequestProperty("Cookie", it) }
            val code = c.responseCode
            if (code in 300..399) { cur = URL(URL(cur), c.getHeaderField("Location") ?: break).toString(); c.disconnect(); continue }
            return c
        }
        throw java.io.IOException("redirect")
    }

    private fun clean(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)

    /** Dipanggil di thread latar. */
    fun download(act: Activity, mediaUrl: String, audio: Boolean, meta: Meta, onProgress: (Int) -> Unit): Saved {
        val c = open(mediaUrl)
        if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
        val ct = (c.contentType ?: "").lowercase()
        val ext = if (!audio) "mp4" else if (ct.contains("mpeg") || mediaUrl.contains(".mp3")) "mp3" else "m4a"
        val mime = if (!audio) "video/mp4" else if (ext == "mp3") "audio/mpeg" else "audio/mp4"
        val base = "tiktok_" + clean(meta.author.ifBlank { "video" }) + "_" + clean(meta.id.ifBlank { System.currentTimeMillis().toString() })
        val name = "$base.$ext"
        val total = c.contentLength.toLong()
        var out: java.io.OutputStream
        var uri: Uri? = null
        var where: String
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name); cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ProjectIris"); cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw java.io.IOException("MediaStore")
            out = act.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("stream")
            where = "Download/ProjectIris/$name"
        } else {
            val dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: act.filesDir
            val f = File(dir, name); out = f.outputStream(); where = f.path
        }
        try {
            c.inputStream.use { input ->
                val buf = ByteArray(64 * 1024); var done = 0L; var last = 0L
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    val now = System.currentTimeMillis()
                    if (total > 0 && now - last > 200) { last = now; onProgress((done * 100 / total).toInt()) }
                }
            }
        } finally { out.close(); c.disconnect() }
        if (Build.VERSION.SDK_INT >= 29 && uri != null) {
            val cv = ContentValues(); cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
            act.contentResolver.update(uri, cv, null, null)
        }
        return Saved(uri, where, mime)
    }
}
